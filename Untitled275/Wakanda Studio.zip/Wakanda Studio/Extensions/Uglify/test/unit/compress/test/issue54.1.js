foo.toString();
a.toString(16);
b.toString.call(c);
