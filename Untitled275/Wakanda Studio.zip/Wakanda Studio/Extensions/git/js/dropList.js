function btn_servers_click( ) {
    var srvLstCtrl = document.getElementById("lst_servers");
	
	if ( srvLstCtrl.style.display == "none" ) {
		// Remove all items from list
		while (srvLstCtrl.length > 0)
			srvLstCtrl.remove(srvLstCtrl.length-1);
		srvLstCtrl.size = 0;
	
		// Add items into list
		var serversNbr = serversList.length;

		for ( var i = 0; i < serversNbr; i++ ) {
			var ip = serversList[i].ip,
			sslport = serversList[i].sslPort,
			host = serversList[i].host.replace(/\.local$/g, ''),
			solution = serversList[i].solution;
			
			var newSrv = document.createElement('option');
			newSrv.text = solution + ' on ' + host;
			newSrv.value = ip + ':' + sslport;

			srvLstCtrl.add(newSrv, null);
		}
		//document.getElementById("btn_servers").style.position = "absolute";
				
		var
		btn_top     = document.getElementById("btn_servers").offsetTop ,
		btn_left     = document.getElementById("btn_servers").offsetLeft ,
		btn_height  = document.getElementById("btn_servers").offsetHeight;

		srvLstCtrl.style.position = "absolute";
		srvLstCtrl.style.top = btn_top + btn_height + "px";
		srvLstCtrl.style.left = btn_left + "px";
		srvLstCtrl.style["z-index"] = 10;
		srvLstCtrl.style.display = "";
		if (srvLstCtrl.options.length <= 2)
			srvLstCtrl.size = 2;
		else
			srvLstCtrl.size = srvLstCtrl.options.length;
    } else {
        srvLstCtrl.style.display = "none";
    }
}

/*
function btn_servers_click( ) {
    var srvLstCtrl = document.getElementById("lst_servers");
    if ( srvLstCtrl.options.length === 0 ) {
        
		var serversNbr = serversList.length;
        //srvLstCtrl.options.length = serversNbr;

        for ( var i = 0; i < serversNbr; i++ ) {
            var ip = serversList[i].ip,
            sslport = serversList[i].sslPort,
			host = serversList[i].host.replace(/\.local$/g, ''),
			solution = serversList[i].solution;
			
			var newSrv = document.createElement('option');
			newSrv.text = solution + ' on ' + host;
			newSrv.value = ip + ':' + sslport;

			srvLstCtrl.add(newSrv, null);
        }
        document.getElementById("btn_servers").style.position = "absolute";
                
        var
        btn_top     = document.getElementById("btn_servers").offsetTop ,
        btn_left     = document.getElementById("btn_servers").offsetLeft ,
        btn_height  = document.getElementById("btn_servers").offsetHeight;

        srvLstCtrl.style.position = "absolute";
        srvLstCtrl.style.top = btn_top + btn_height + "px";
        srvLstCtrl.style.left = btn_left + "px";
        srvLstCtrl.style["z-index"] = 10;
		srvLstCtrl.style.display = "";
		srvLstCtrl.size = srvLstCtrl.options.length;
		
    } else if ( srvLstCtrl.style.display == "none" ) {
        srvLstCtrl.style.display = ""
    } else {
        srvLstCtrl.style.display = "none";
    }
}
*/

function lst_servers_select( ) {
    var ipPort = document.getElementById("lst_servers").value;
    var arr = ipPort.split(':');
    
    document.getElementById("gitWakAddr").value = arr[0];
    document.getElementById("gitWakPort").value = arr[1];
    checkWakSrvAddrValidated();
}
        
window.onclick = function () {
            
    if ( event.srcElement.id != "btn_servers") {
        if (document.getElementById("lst_servers") != null)
            document.getElementById("lst_servers").style.display = "none";
    }
}