
var gitExeBuffer;
var gitdiffBuffer;
var gitMergeBuffer;
var gitUrlBuffer;
var wakAddrBuffer;
var wakPortBuffer;
var	settings;
var serversList;
var isGitHubOnLive = true;


function initControls(version, hasSolutionOpened, isGitInitialized) {
	"use strict";
	var gitIgnoreStr;

    // Header git version number or download link
	if(version == '' || version == null) {
	    document.getElementById('gitDownloadLink').innerHTML = settings.gitExecutablePath === ''?'<a href="http://git-scm.com/downloads" target="_blank">Download Git</a>':'';
	    //document.getElementById('gitDownloadLink').innerHTML = settings.gitExecutablePath === ''?'<a href="goToUrlAndQuit.html">Download Git</a>':'';
	} else {
        document.getElementById('gitVersion').textContent = version;
	}
	
	document.getElementById('createLocalGitRepo').disabled = !hasSolutionOpened || isGitInitialized || !studio.extension.isPrefFileExisting();
	document.getElementById('publishOnGithub').disabled = !hasSolutionOpened;
	document.getElementById('publishOnWakanda').disabled = !hasSolutionOpened;
	
	document.getElementById('saveInSolution').disabled = !hasSolutionOpened;
	var saveType = 'default';
	if (hasSolutionOpened)
		saveType = 'solution';
	setRadioButtonValue('saveOption', saveType);
	

	// Global Advanced Settings
	document.getElementById('gitExecutablePath').value =  (typeof settings.gitExecutablePath !== 'undefined') ? settings.gitExecutablePath : '';
	document.getElementById('gitDiffToolPath').value = (typeof settings.gitDiffToolPath !== 'undefined') ? settings.gitDiffToolPath : '';
	document.getElementById('gitMergeToolPath').value = (typeof settings.gitMergeToolPath !== 'undefined') ? settings.gitMergeToolPath : '';

	detectPath('gitExecutablePath', 'gitPathMessage');
	detectPath('gitDiffToolPath', 'diffPathMessage');
	detectPath('gitMergeToolPath', 'mergePathMessage');
	
    gitExeBuffer = document.getElementById('gitExecutablePath').value;
    gitdiffBuffer = document.getElementById('gitDiffToolPath').value;
    gitMergeBuffer = document.getElementById('gitMergeToolPath').value;
	
	// Global Server Settings
	document.getElementById('gitUser').value =  (typeof settings.gitUser === 'undefined')?'':settings.gitUser;
	document.getElementById('gitPassword').value =  (typeof settings.gitPassword === 'undefined')?'':settings.gitPassword;
	document.getElementById('gitIsPasswordLocalyStored').checked =  (typeof settings.gitRememberPassword === 'undefined')?true:settings.gitRememberPassword;
	document.getElementById('gitURL').value =  (typeof settings.gitURL === 'undefined')?'https://github.com/':settings.gitURL;
	document.getElementById('gitEmail').value =  (typeof settings.gitEmail === 'undefined')?'':settings.gitEmail;
	document.getElementById('isPrivateRepository').checked =  (typeof settings.gitIsPrivateRepository === 'undefined')?false:settings.gitIsPrivateRepository;

	document.getElementById('gitWakUser').value =  (typeof settings.wakUser === 'undefined')?'':settings.wakUser;
	document.getElementById('gitWakPassword').value =  (typeof settings.wakPassword === 'undefined')?'':settings.wakPassword;
	document.getElementById('gitWakIsPasswordLocalyStored').checked =  (typeof settings.wakRememberPassword === 'undefined')?true:settings.wakRememberPassword;
	document.getElementById('gitWakAddr').value =  (typeof settings.wakAddr === 'undefined')?'localhost':settings.wakAddr;
	document.getElementById('gitWakPort').value =  (typeof settings.wakPort === 'undefined')?'4433':settings.wakPort;
	document.getElementById('gitWakRepo').value =  (typeof settings.wakRepository === 'undefined')?'Wakanda':settings.wakRepository;
	
	if (hasSolutionOpened && typeof settings.wakRepository !== 'undefined')
		document.getElementById('captionTitle').innerHTML =  'Settings for ' + settings.wakRepository;

	
	gitIgnoreStr = settings.gitIgnore;
	if (typeof gitIgnoreStr !== 'undefined') {
		var newGitIgnore = gitIgnoreStr.replace(/\\n/g, '\n');
		newGitIgnore = newGitIgnore.replace(/\\r/g, '\r');
		document.getElementById('gitIgnore').value =  newGitIgnore;
	}
	
	checkGithubUrlValidated();
	gitUrlBuffer = document.getElementById('gitURL').value;
	//document.getElementById("gitURL").onkeyup = handleGitUrlKeyPress;
	//document.getElementById("gitURL").onpaste = handleGitUrlKeyPress;
	
	checkWakSrvAddrValidated();
	wakAddrBuffer = document.getElementById('gitWakAddr').value;
	wakPortBuffer = document.getElementById('gitWakPort').value;
	//document.getElementById("gitWakAddr").onkeyup = handleWakAddrKeyPress;
	//document.getElementById("gitWakAddr").onpaste = handleWakAddrKeyPress;
	//document.getElementById("gitWakPort").onkeyup = handleWakAddrKeyPress;
	//document.getElementById("gitWakPort").onpaste = handleWakAddrKeyPress;
	
	if (typeof settings.serverType === 'undefined') {
		settings.serverType = 'none'; // by default
	} else if (settings.serverType !== 'github' && settings.serverType !== 'wak' && settings.serverType !== 'none' ) {
		settings.serverType = 'none'; // by default
	}
	setSolutionSettings(settings.serverType);
}

//--------------------------------------------------------------

function compareServers(a,b) {
  "use strict";
  if (a.host < b.host)
     return -1;
  if (a.host > b.host)
    return 1;
  return 0;
}

function removeDuplicateServers(serversArray) {
	"use strict";
	var newArray = new Array();
	
	label:for(var i = 0;  i < serversArray.length; i++ ) {  
		for (var j = 0; j < newArray.length;j++ ) {
			if (newArray[j].host == serversArray[i].host && 
				newArray[j].port == serversArray[i].port &&
				newArray[j].solution == serversArray[i].solution)
					continue label;
		}
		newArray[newArray.length] = serversArray[i];
	}
	return newArray;
}

function getServersLoop() {
	"use strict";
	serversList = studio.getServersList();
    serversList.sort(compareServers);
    serversList = removeDuplicateServers(serversList);
};

setInterval(getServersLoop, 4000);


//--------------------------------------------------------------
function setValidation() {
	"use strict";
	var
		isMac, okHtml, cancelHtml;

	isMac = (navigator.platform.indexOf("Mac") !== -1) ? true : false;
	okHtml = '<input type="button" onclick="getValueAndQuitHtmlPage();" value="OK" />';
	cancelHtml = '<input type="button" onclick="quitWithoutSaving();" value="Cancel" />';

	document.getElementById('validation').innerHTML = (isMac) ? cancelHtml + okHtml : okHtml + cancelHtml;
}

function init() {
	"use strict";
	
	settings = studio.extension.storage.dialogArguments.settings;
	var ver = studio.extension.storage.dialogArguments.gitVersion;
	var hasSolution = studio.extension.storage.dialogArguments.hasSolutionOpened;
	var isGitInited = studio.extension.storage.dialogArguments.isGitInitialized;
	initControls(ver, hasSolution, isGitInited);
	setValidation();
}

function quitWithoutSaving() {
	"use strict";
	//studio.alert('close');
	studio.extension.storage.returnValue = null;
	studio.extension.quitDialog();
}

//
// This function read the current values from the dialog and write them to global "settings" object
//
function getSettings() {
	"use strict";
	settings.saveToSolution = getRadioButtonValue('saveOption') === 'solution';
	
	if (document.getElementById('gitExecutablePath').value !== '')
	{
		settings.gitExecutablePath = document.getElementById('gitExecutablePath').value;
	}
	if (document.getElementById('gitDiffToolPath').value !== '')
	{
		settings.gitDiffToolPath = document.getElementById('gitDiffToolPath').value;
	}

	if (document.getElementById('gitMergeToolPath').value !== '')
	{
		settings.gitMergeToolPath = document.getElementById('gitMergeToolPath').value;
	}
	
	settings.serverType = getRadioButtonValue('selRepoServer');
	
	if (document.getElementById('gitUser').value !== '')
	{
		settings.gitUser = document.getElementById('gitUser').value;
	}

	settings.gitRememberPassword = document.getElementById('gitIsPasswordLocalyStored').checked;
	
	if (document.getElementById('gitPassword').value !== '')
	{
		settings.gitPassword = document.getElementById('gitPassword').value;
	}
	if (document.getElementById('gitURL').value !== '')
	{
		settings.gitURL = document.getElementById('gitURL').value;
	}
	if (document.getElementById('gitEmail').value !== '')
	{
		settings.gitEmail = document.getElementById('gitEmail').value;
	}

	settings.gitIsPrivateRepository = document.getElementById('isPrivateRepository').checked;


	var newGitIgnore = document.getElementById('gitIgnore').value;
	newGitIgnore = newGitIgnore.replace(/[\r]/g, '\\r');
	newGitIgnore = newGitIgnore.replace(/[\n]/g, '\\n');
	//studio.alert(newGitIgnore);
	settings.gitIgnore = newGitIgnore;


	settings.wakUser = document.getElementById('gitWakUser').value;
	settings.wakRememberPassword = document.getElementById('gitWakIsPasswordLocalyStored').checked;
	settings.wakPassword = document.getElementById('gitWakPassword').value;

	if (document.getElementById('gitWakAddr').value !== '')
	{
		settings.wakAddr = document.getElementById('gitWakAddr').value;
	}
	if (document.getElementById('gitWakPort').value !== '')
	{
		settings.wakPort = document.getElementById('gitWakPort').value;
	}
	if (document.getElementById('gitWakRepo').value !== '')
	{
		settings.wakRepository = document.getElementById('gitWakRepo').value;
	}
	
	return settings;
}

function getValueAndQuitHtmlPage() {
	"use strict";
	
	studio.extension.storage.returnValue = getSettings();
	studio.stopUpdateServersList();
	studio.extension.quitDialog();
}

function getExePathManually(id, msgId) {
	"use strict";
	
	var isMac = (navigator.platform.indexOf("Mac") !== -1) ? true : false;
	
	var selFile = studio.fileSelectDialog();
	if (selFile != null) {
		var pathStr = selFile.path;
		if (!isMac)
			pathStr = pathStr.replace(/\//g, '\\');
		document.getElementById(id).value = pathStr;
	}
	
	detectPath(id, msgId);
}


function detectPath(src, dest) {
	"use strict";
	var path = document.getElementById(src).value;
	
	if (src === 'gitExecutablePath') {
		if (gitExeBuffer === path)
			return;
		gitExeBuffer = path;
	}
	else if (src === 'gitDiffToolPath') {
		if (gitdiffBuffer === path)
			return;
		gitdiffBuffer = path;
	}
	else if (src === 'gitMergeToolPath') {
		if (gitMergeBuffer === path)
			return;
		gitMergeBuffer = path;
	}
	else {
		return;
	}
	if (path === '') {
		if (src === 'gitExecutablePath') {
			document.getElementById(dest).className = '';
		}
		else {
			document.getElementById(dest).className = '';
		}
	} else {
		var gitFile = studio.File(path);
		//studio.alert('after');
		
		if (gitFile.exists) {
			document.getElementById(dest).className = 'field_check ok';
		}
		else {
    		document.getElementById(dest).className = '' ;
		}
	}
}


// --------------------------------------------------------------------------------
function validateURLFormat(textval) {
	"use strict";
      var urlregex = new RegExp(
            "^(http|https)\://([a-zA-Z0-9\.\-]+(\:[a-zA-Z0-9\.&amp;%\$\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|([a-zA-Z0-9\-]+\.)*[a-zA-Z0-9\-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(\:[0-9]+)*(/($|[a-zA-Z0-9\.\,\?\'\\\+&amp;%\$#\=~_\-]+))*$");
			
      return urlregex.test(textval);
}


// gitURL ----------------------------------------------------------------------------

var githubTimer = null;
/*
function handleGitUrlKeyPress() {
    "use strict";
	if (githubTimer != null) {
		clearTimeout( githubTimer );
	}
	githubTimer = setTimeout(checkGithubUrlValidated , 1000);   
}
*/
function isGitUrlOnLive(url) {
	"use strict";
	
    var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 ) {
            if(xmlhttp.status == 200) {
				//OK
				document.getElementById('gitUrlMsg').className = 'field_check ok' ;
            } else {
				//Some HTTP Error
				document.getElementById('gitUrlMsg').className = '' ;
            }
        }
    }
	xmlhttp.open("GET", url, true);
	try{
		xmlhttp.send();
	} catch(e) {
		document.getElementById('gitURL').className = '';
	}
}

function checkGithubUrlValidated() {
	"use strict";

	var urlCtrl = document.getElementById('gitURL');
	
	// Check the global variabl which is the result of detection of https://git.com/
	if (!isGitHubOnLive) {
		document.getElementById('gitUrlMsg').className = ''; // not ok
		return;
	}
	
	if (urlCtrl.value == 'https://github.com/') {
		document.getElementById('gitUrlMsg').className = 'field_check ok';
		return;
	}

	if (gitUrlBuffer === urlCtrl.value)
		return;

	githubTimer = null;
	//debugger;
	
	if (validateURLFormat(urlCtrl.value)) {
		isGitUrlOnLive(urlCtrl.value);
	}
	else {
		document.getElementById('gitUrlMsg').className = '' ; // not OK
	}
	gitUrlBuffer = urlCtrl.value;
}

// wakServer Addr ----------------------------------------------------------------------------

var wakTimer = null;

/*
function handleWakAddrKeyPress() {
    "use strict";
	if (wakTimer != null) {
		clearTimeout( wakTimer );
	}
	wakTimer = setTimeout(checkWakSrvAddrValidated, 1000);   
}
*/

function isWakAddrOnLive(addr) {
	"use strict";
	//debugger;
    var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		//debugger;
        if (xmlhttp.readyState == 4 ) {
            if(xmlhttp.status == 200) {
				//OK
				document.getElementById('addrErrorMessage').className = 'field_check ok' ;
            } else {
				//Some HTTP Error
				document.getElementById('addrErrorMessage').className = '' ;
            }
        }
    }
	xmlhttp.open("GET", addr, true);
	try{
		xmlhttp.send();
	} catch(e) {
		document.getElementById('addrErrorMessage').className = '' ;
	}
}

function checkWakSrvAddrValidated() {
	"use strict";
	wakTimer = null;
	//debugger;
	var urlCtrl = document.getElementById('gitWakAddr');
	var sslPortCtrl = document.getElementById('gitWakPort');
	
	if (wakAddrBuffer === urlCtrl.value && wakPortBuffer === sslPortCtrl.value )
		return;

	isWakAddrOnLive('https://' + urlCtrl.value + ':' + sslPortCtrl.value);

	wakAddrBuffer = urlCtrl.value;
	wakPortBuffer = sslPortCtrl.value;
}
//----------------------------------------------------------------------------

function setSolutionSettings(type) {
	"use strict";
	
	setRadioButtonValue('selRepoServer', type);
	updateSolutionSettings();
}


function getRadioButtonValue(radioGroupName) {
	var opt = document.getElementsByName(radioGroupName);
	for (var i = 0; i < opt.length; i++)
    {
    	if (opt[i].checked)
    	{
    		return opt[i].value;
    	}
    }
}

function setRadioButtonValue(radioGroupName, radioButtonName) {
	var opt = document.getElementsByName(radioGroupName);
	for (var i = 0; i < opt.length; i++) {
    	if (opt[i].value == radioButtonName) {
    		opt[i].checked = true;
    	}
		else {
    		opt[i].checked = false;
		}
    }
}


function updateSolutionSettings() {
	"use strict";

	var val = getRadioButtonValue('selRepoServer');
	
	var githubSettings = document.getElementById('githubSettings');
	var wakServerSettings = document.getElementById('wakServerSettings');
	var noSelectedServer = document.getElementById('noSelectedServer');
	var title = document.getElementById('serverChoiceLabel');

	if (val === 'github') {
		githubSettings.setAttribute('style', 'display:block');
		wakServerSettings.setAttribute('style', 'display:none');
		noSelectedServer.setAttribute('style', 'display:none');
		title.innerText = 'Set up your GitHub server';
	} else if (val === 'wak') {
		githubSettings.setAttribute('style', 'display:none');
		wakServerSettings.setAttribute('style', 'display:block');
		noSelectedServer.setAttribute('style', 'display:none');
		title.innerText = 'Set up your Git Wakanda server';
	} else { //none 
		githubSettings.setAttribute('style', 'display:none');
		wakServerSettings.setAttribute('style', 'display:none');
		noSelectedServer.setAttribute('style', 'display:block');
		title.innerText = 'Set up your Git remote server';
	}
}

function showOrHideGlobalSettings() {
	"use strict";
	var globalSettingsArea = document.getElementById('GlobalSettingsArea');
	var showHideSettingsButton = document.getElementById('showHideSettingsButton');
	var showHideSettingsIcon = document.getElementById('showHideSettingsIcon');
	var w = 760;
	var h;
	if (globalSettingsArea.style.display === 'none') {
		globalSettingsArea.style.display = 'block';
		showHideSettingsButton.innerHTML = 'Hide Advance Settings';
		showHideSettingsIcon.className = 'icon icon-on';
		h = 610;

	} else {
		globalSettingsArea.style.display = 'none';
		showHideSettingsButton.innerHTML = 'Show Advance Settings';
		showHideSettingsIcon.className = 'icon';
		h = 326;
	}
	studio.extension.resizeDialog(w, h);
}


function modifyGitAccountURL() {
	"use strict";
	var login = document.getElementById('gitUser').value;
	document.getElementById('gitURL').value = 'https://github.com/' + login;
}

function createLocalGitRepository() {
	"use strict";
	studio.sendCommand('git.gitInitRepository');
	document.getElementById('createLocalGitRepo').disabled = true;
}

function publishOnGithub() {
	"use strict";
	studio.extension.storage.setItem("settings", getSettings());
	// Call publish method
	studio.sendCommand('git.gitPush');
	studio.extension.storage.clear();
}

function publishOnWakanda() {
	"use strict";
	studio.extension.storage.setItem("settings", getSettings());
	// Call publish method
	//studio.sendCommand('');
	studio.extension.storage.clear();
}
