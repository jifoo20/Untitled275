/* Copyright (c) 4D, 2012
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/


// git config --global mergetool.keepBackup false

/*
TO KNOW IF A GIVEN FILE IS TRACKED BY GIT

cmd>git ls-files TestGitProj/untracked.js --error-unmatch
error: pathspec 'TestGitProj/untracked.js' did not match any file(s) known to git.
Did you forget to 'git add'?

cmd>git ls-files -ot

*/



var				actions = { };

var				gitModule;

var				isGitReady = false;
var				gitRepository;
var				gitRepositoryQuoted;
var				gitWorkTree;
var				gitWorkTreeQuoted;
var				gitExecPath;
var				isVerbose = true;
var				gitLogCounter;
var				isRepositoryValid = false;



function gitExecuteHTTPRequest ( inURL, inVerb, inBody )
{
	var headers, resultObj;

	var			strResult = "";
   
	var			xhr = new studio. XMLHttpRequest ( );
   
	xhr. onreadystatechange = function ( )
	{
		var		state = this. readyState;
		if ( state !== 4 )
		{
			// while the status event is not Done we continue
			return;
		}
	 
		strResult = this. responseText;
     };
   
	xhr. open ( inVerb, inURL );
	if ( typeof ( inBody ) != "undefined" && inBody != null )
		xhr. send ( inBody );
	else
		xhr. send ( );
		
//studio. alert ( "HTTP status " + xhr. status );
//studio. alert ( strResult );
//var		objRepos = JSON. parse ( strResult );
//studio. alert ( objRepos [ 0 ]. clone_url );
 
	return ( xhr. status == 200 || xhr. status == 201 ? strResult : undefined );
}

function gitDebugMsg ( inMessage )
{
	if ( isVerbose )
		studio. alert ( inMessage );
}

/*
	@return True if there was an error and it was presented to the user, false otherwise.
*/
function displayExecutionError ( inGitResponse, inIfErrorMessage, inIfOKMessage )
{
	var				gitUserPassword = _gitGetSetting ( "gitPassword" );
	var				execError = gitModule. extractError ( inGitResponse, gitUserPassword );
	if ( execError == null )
	{
		if ( typeof ( inIfOKMessage ) != "undefined" && inIfOKMessage != null )
			studio. showMessageOnStatusBar ( "Git: " + inIfOKMessage, "normal" );
			
		return false;
	}
		
	if ( typeof ( inIfErrorMessage ) != "undefined" && inIfErrorMessage != null )
		studio. showMessageOnStatusBar ( "Git error: " + inIfErrorMessage, "error" );
			
	var			strMessage = ""
	if ( execError. fatal != "" )
		strMessage = execError. fatal + "\n\n";

	if ( execError. error != "" )
		strMessage += execError. error + "\n\n";
		
	if ( execError. warning != "" )
		strMessage += execError. warning + "\n\n";
		
	strMessage += "(Please see log for more details.)";
	studio. alert ( strMessage );
	
	return true;
}

function gitPrepareFilePath ( inPath )
{
	var		pathConverted = inPath;
	
	if ( os. isMac )
	{
		pathConverted = "'" + pathConverted + "'";
	}

	return pathConverted;
}

function gitConvertToArrayOfPaths ( inArrayOfFoldersAndFiles )
{
	var		arrPaths = new Array ( );
	for ( var i = 0; i < inArrayOfFoldersAndFiles. length; i++ )
		arrPaths. push ( inArrayOfFoldersAndFiles [ i ]. path );
		
	return arrPaths;
}

/*
	First, looks up the solution's setting and if not found then looks for global one.
*/
function _gitGetSetting ( inName )
{
	var			gitSolutionSetting = studio. extension. getSolutionPref ( inName );
	if ( typeof ( gitSolutionSetting ) != "undefined" && gitSolutionSetting != null && gitSolutionSetting != "" )
		return gitSolutionSetting;
		
	var			gitGlobalSetting = studio. extension. getPref ( inName );
	if ( typeof ( gitGlobalSetting ) != "undefined" && gitGlobalSetting != null && gitGlobalSetting != "" )
		return gitGlobalSetting;
		
	return gitSolutionSetting;
}

function gitSetPref ( inKey, inValue )
{
	if ( inKey == "" )
		return;
		
	var			bResult = studio. extension. setPref ( inKey, inValue );
	if ( !bResult )
		studio. alert ( "Error: failed to save preferences for " + inKey + " = " + inValue );
}

actions. gitResetPreferences = function doGitResetPreferences ( inMessage )
{
	var				bReset = studio. confirm ( "Do you really want to reset git preferences?" );
	if ( !bReset )
		return;

	var			bResult = studio. extension. setPref ( "gitExecutablePath", "" );
	bResult = studio. extension. setPref ( "gitUser", "" );
	bResult = studio. extension. setPref ( "gitPassword", "" );
	bResult = studio. extension. setPref ( "gitURL", "" );
	//bResult = studio. extension. setPref ( "", "" );
	
	if ( !bResult )
		studio. alert ( "Failed to reset preferences" );
}

function _gitGetWakandaRemoteRepository ( inWithDefaultName )
{
	var			wakRemoteRepository = _gitGetSetting ( "wakRepository" );
	if ( wakRemoteRepository == null && inWithDefaultName )
		wakRemoteRepository = studio. currentSolution. getSolutionFile ( ). nameNoExt;
		
	return wakRemoteRepository;
}

function _gitGetRemoteURLPref ( )
{
	var				gitServerType = _gitGetSetting ( "serverType" );
	var				gitURL = "";
	if ( gitServerType == "wak" )
		gitURL = _gitGetSetting ( "wakAddr" ) + ":" + _gitGetSetting ( "wakPort" );
	else
		gitURL = _gitGetSetting ( "gitURL" );

	return gitURL;
}

actions. gitSetRemoteURL = function doGitSetRemoteURL ( inMessage )
{
	var			gitURL = studio. extension. getPref ( "gitURL" );
	if ( typeof ( gitURL ) === "undefined" || gitURL == null || gitURL. length == 0 )
		gitURL = "github.com/stemnikov/WakandaSolutionTest.git or 192.168.x.y/gitservice"; // Just an example to give a general idea
		
	gitURL = studio. prompt ( "Please enter URL of the git server", gitURL );
	if ( typeof ( gitURL ) === "undefined" || gitURL == null )
		return;

	var			bResult = studio. extension. setPref ( "gitURL", gitURL );
	
	if ( !bResult )
		studio. alert ( "Failed to set remote URL" );
}

function gitInitSettings ( )
{
	var			bResult = false;
	
	// First let's check if git's path is set up on Windows
	if ( os. isWindows )
	{
		gitExecPath = studio. extension. getPref ( "gitExecutablePath" );
		/*if ( gitExecPath == "" )
		{
			// TODO: The studio app itself can check if git is installed in its default location and expose this info in JS
			gitExecPath = studio. prompt (
								"Looks like this is the first time you access git.\nPlease tell me where to find the git executable.",
								"C:\\Program Files (x86)\\Git\\bin\\git.exe" );
			if ( typeof ( gitExecPath ) != "undefined" && gitExecPath != null )
				gitSetPref ( "gitExecutablePath", gitExecPath );
		}*/
	}
	else if ( os. isMac )
		gitExecPath = studio. extension. getPref ( "gitExecutablePath" );
	else
		studio. alert ( "Error: unknown OS" );
	
	if ( typeof ( gitModule ) != "undefined" )
		gitModule. setGitExecPath ( gitExecPath );
}


function getGithubUserPasswordObject() {
	var gitUserPasswordObject = studio.extension.getUserAndPassword('github');
	if (gitUserPasswordObject === null) { // no solution login & password found - try to get them from global settings
		var loginString = _gitGetSetting ( "gitUser" );
		var passwordString = _gitGetSetting ( "gitPassword" );
		gitUserPasswordObject = new Object();
		gitUserPasswordObject.user = loginString;
		gitUserPasswordObject.password = passwordString;
	}
	return gitUserPasswordObject;
}

function getSourceServerURL ( )
{
	// Hardcoded for the moment but should rather read the necessary values from solution settings
	
	// Intranet git
	/*
	var				gitUserPassword = "sergiy:123";
	var				gitAddress = "192.168.6.23:4443";
	var				gitURL = "https://" + gitUserPassword + "@" + gitAddress + "/gitservice/MyRepo";
	*/
	
	// github
	/*var				gitUserPassword = "stemnikov:put_real_pass_here";
	var				gitAddress = "github.com";
	var				gitURL = "https://" + gitUserPassword + "@" + gitAddress + "/stemnikov/TestS.git";*/
	
try
{
	var				gitUserName = "";
	var				gitUserPassword = "";
	var				gitURL = "";
	var				strProtocolPrefix = "";
	
	var				gitServerType = _gitGetSetting ( "serverType" );
//studio. alert ( "gitServerType == " + gitServerType );
	if ( gitServerType == "wak" )
	{
		gitUserName = _gitGetSetting ( "wakUser" );
		gitUserPassword = _gitGetSetting ( "wakPassword" );
		gitURL = _gitGetSetting ( "wakAddr" ) + ":" + _gitGetSetting ( "wakPort" );
		strProtocolPrefix = "https://";
	}
	else
	{

		var githubUserPasswordObject = getGithubUserPasswordObject();
		gitUserName = githubUserPasswordObject.user;
		gitUserPassword = githubUserPasswordObject.password;
		
		if ( gitUserName == "" )
		{
			gitUserName = studio. prompt ( "Please enter your git user name", "" );
			/*
			if ( typeof ( gitUserName ) != "undefined" && gitUserName != null )
				gitSetPref ( "gitUser", gitUserName );
			*/
		}
		
		if ( gitUserPassword == "" )
		{
			gitUserPassword = studio. prompt ( "Please enter your git user password", "" );
			/*
			if ( typeof ( gitUserPassword ) != "undefined" && gitUserPassword != null )
				gitSetPref ( "gitPassword", gitUserPassword );
			*/
		}
/*
		gitUserName = _gitGetSetting ( "gitUser" );
		if ( gitUserName == "" )
		{
			gitUserName = studio. prompt ( "Please enter your git user name", "" );
			if ( typeof ( gitUserName ) != "undefined" && gitUserName != null )
				gitSetPref ( "gitUser", gitUserName );
		}

		gitUserPassword = _gitGetSetting ( "gitPassword" );
		if ( gitUserPassword == "" )
		{
			gitUserPassword = studio. prompt ( "Please enter your git user password", "" );
			if ( typeof ( gitUserPassword ) != "undefined" && gitUserPassword != null )
				gitSetPref ( "gitPassword", gitUserPassword );
		}
*/
		gitURL = _gitGetSetting ( "gitURL" );
		if ( gitURL == "" )
		{
			gitURL = studio. prompt ( "Please enter your git URL: server(IP or DNS)[:port]/resourceURI", "192.168.6.23:4443/gitservice/MyRepo or github.com/stemnikov/TestS.git" );
			if ( typeof ( gitURL ) != "undefined" && gitURL != null )
				gitSetPref ( "gitURL", gitURL );
		}
		
		strProtocolPrefix = "https://";
	}
	
	if ( gitURL. indexOf ( "http://" ) == 0 )
	{
		gitURL = gitURL. substring ( 7 );
		strProtocolPrefix = "http://";
	}
	else if ( gitURL. indexOf ( "https://" ) == 0 )
		gitURL = gitURL. substring ( 8 );
		
	var				gitFullURL = "";
	
	if ( gitServerType == "wak" )
	{
		if ( gitUserName. length > 0 && gitUserPassword. length > 0 )
			gitURL = gitUserName + ":" + gitUserPassword + "@" + gitURL;

		if ( gitURL [ gitURL. length - 1 ] != "/" )
			gitURL += "/";
			
		gitURL += "gitservice/repo";
		gitFullURL = strProtocolPrefix + gitURL;
	}
	else // gitURL. indexOf ( "github.com/" ) == 0
	{
		var		nSecondSlashIndex = gitURL. indexOf ( "/", "github.com/". length );
		if ( !( nSecondSlashIndex >= 0 && nSecondSlashIndex != gitURL. length - 1 ) )
		{
			// Add current solution name as the github repository name
			if ( gitURL. charAt ( gitURL. length - 1 ) != "/" )
				gitURL += "/";
				
			gitURL += studio. currentSolution. getSolutionFile ( ). nameNoExt + ".git";
		}
		
		gitFullURL = strProtocolPrefix + gitUserName + ":" + gitUserPassword + "@" + gitURL;
	}
		
	//gitDebugMsg ( gitFullURL );
}
catch ( e )
{
	studio. alert ( e. message );
}
	
	return gitFullURL;
}


function extractFolderArray ( inPaths )
{
	var			arrUniqueFolders = new Array ( );
	for ( var i = 0; i < inPaths. length; i++ )
	{
		//studio. alert ( inPaths [ i ] );
		if ( inPaths [ i ]. charAt ( inPaths [ i ]. length - 1 ) == '/' )
		{
			if ( arrUniqueFolders. indexOf ( inPaths [ i ] ) < 0 )
				// add folders as is
				arrUniqueFolders. push ( inPaths [ i ] );
		}
		else
		{
			var		strFolder = inPaths [ i ]. substring ( 0, inPaths [ i ]. lastIndexOf ( "/" ) );
			if ( arrUniqueFolders. indexOf ( strFolder ) < 0 )
				// move up one level from file to folder
				arrUniqueFolders. push ( strFolder );
		}
	}
	
	return arrUniqueFolders;
}

function runGitClientCommand ( inCommand, inRootPath )
{
	//gitDebugMsg ( "Type of gitLogCounter is " + typeof ( gitLogCounter ) );
	if ( typeof ( gitLogCounter ) === "undefined" || isNaN ( gitLogCounter ) )
		gitLogCounter = 0;
		
	gitLogCounter++;
	studio. extension. storage. setItem ( "gitLogCounter" + gitLogCounter, inCommand );
		
	//gitDebugMsg ( "Log counter == " + gitLogCounter );
	//gitDebugMsg ( inCommand );
	
	var			gitResponse = gitModule. execute ( inCommand, inRootPath );
	
	gitLogCounter++;
	studio. extension. storage. setItem ( "gitLogCounter" + gitLogCounter, gitResponse );
	
	var			arrLines = gitResponse. split ( "\n" );
	
	return arrLines;
}

function gitCheckVersion ( )
{
	var		didCheck = studio. extension. storage. getItem ( "gitVersionCheck" );
	if ( typeof ( didCheck ) != "undefined" && didCheck != null )
		return;
		
	studio. extension. storage. setItem ( "gitVersionCheck", "done" );
	
	var				gitVersion = gitModule. getVersion ( );
	var				expectedVersion;
	if ( os. isWindows )
		expectedVersion = "git version 1.7.9.msysgit.0";
	else if ( os. isMac )
		expectedVersion = "git version 1.7.8.3";
	else
		studio. alert ( "Error: unknown OS" );
		
	//if ( gitVersion != expectedVersion )
	//	studio. alert ( "Warning: git extension was developed and tested \nwith git version " + expectedVersion + "\nYou are running " + gitVersion );

}


function gitInitIgnore ( )
{
	var			bResult = true;

	var			gitIgnorePath = gitModule. initIgnore ( gitWorkTree );		

	if ( gitIgnorePath == null )
		bResult = false;
	else if ( gitIgnorePath != "" )
	{
		// Let's add the .gitignore to the local repository
		var		arrPath = new Array ( gitIgnorePath );
		gitStageFiles ( arrPath );
		bResult = true;
	}
	
	return bResult;
}

var	gitLogCallback = function ( inCommand, inResponse )
{
	if ( typeof ( gitLogCounter ) === "undefined" || isNaN ( gitLogCounter ) )
		gitLogCounter = 0;
		
	gitLogCounter++;
	studio. extension. storage. setItem ( "gitLogCounter" + gitLogCounter, inCommand );
		
	//gitDebugMsg ( "Log counter == " + gitLogCounter );
	//gitDebugMsg ( inCommand );
	
	gitLogCounter++;
	studio. extension. storage. setItem ( "gitLogCounter" + gitLogCounter, inResponse );
}

function gitInit ( )
{
	if ( isGitReady )
		return;
	
	// Hardcoded for the moment, will be stored in solution's settings
	if ( os. isMac )
	{
		gitWorkTree = studio. currentSolution. getSolutionFile ( ). path;
		gitWorkTree = gitWorkTree. substring ( 0, gitWorkTree. lastIndexOf ( "/" ) ); // Go up to solution's folder
		gitWorkTree = gitWorkTree. substring ( 0, gitWorkTree. lastIndexOf ( "/" ) ); // Go up to the default git root folder
		//studio. alert ( "work-tree == " + gitWorkTree );
		gitRepository = gitWorkTree + "/.git";
		//studio. alert ( "repo == " + gitRepository );

		gitRepositoryQuoted = "'" + gitRepository + "'";
		gitWorkTreeQuoted = "'" + gitWorkTree + "'";
	}
	else if ( os. isWindows )
	{
		gitWorkTree = studio. currentSolution. getSolutionFile ( ). path;
		gitWorkTree = gitWorkTree. substring ( 0, gitWorkTree. lastIndexOf ( "/" ) ); // Go up to solution's folder
		gitWorkTree = gitWorkTree. substring ( 0, gitWorkTree. lastIndexOf ( "/" ) ); // Go up to the default git root folder
		gitRepository = gitWorkTree + "/.git";
		
		gitRepositoryQuoted = '"' + gitRepository + '"';
		gitWorkTreeQuoted = '"' + gitWorkTree + '"';
	}
	else
		studio. alert ( "Error: unknown OS" );

	gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	gitModule. init ( gitExecPath, gitLogCallback, gitWorkTree );
	
	gitCheckVersion ( );
	isRepositoryValid = gitModule. verifyRepository ( gitWorkTree );
	if ( isRepositoryValid )
		gitInitIgnore ( );
	
	isGitReady = true;
}

function doGitMerge ( inMessage )
{
	var					gitResponse = gitModule. mergeAll ( gitWorkTree );
	displayExecutionError ( gitResponse, "Failed to merge", "Merge completed" );
}

function _gitPull ( inURL )
{
	var				gitCommand;
	
	var				gitServerType = _gitGetSetting ( "serverType" );
	var				wakRemoteRepository = _gitGetWakandaRemoteRepository ( true );
	var				strRemoteURL = _gitGetRemoteURLPref ( );

	var				hasModifications = gitModule. repositoryHasModifications ( gitWorkTree );
	var				gitResponse;
	if ( hasModifications )
	{
		// Let's stash our current modifications, pull and then pop the stash back
		gitResponse = gitModule. saveStash ( gitWorkTree, "autostash before pull" );
		displayExecutionError ( gitResponse, "Failed to stash uncommitted local changes before pulling from remote server", null );
	}
	
//studio. alert ( "Will be pulling from " + inURL );
//studio. alert ( "gitServerType == " + gitServerType );
	if ( gitServerType == "wak" )
	{
		gitModule. setRemoteRepository ( inURL, wakRemoteRepository );
	}

	gitResponse = gitModule. pull ( inURL, gitWorkTree );
	var				bHadErrors = displayExecutionError (
												gitResponse,
												"Failed to pull from remote server " + strRemoteURL,
												"Pulled from remote server " + strRemoteURL );
		
	if ( gitModule. responseHasConflicts ( gitResponse ) )
	{
		studio. alert ( "There are one or more conflicts, please resolve them..." );
		doGitMerge ( null );
	}
	
	if ( hasModifications )
	{
		// Let's pop our current modifications
		gitResponse = gitModule. popStash ( gitWorkTree );
		displayExecutionError ( gitResponse, "Failed to pop stashed uncommitted local changes after pulling from remote server", null );
		if ( gitModule. responseHasConflicts ( gitResponse ) )
		{
			studio. alert ( "There are one or more conflicts, please resolve them..." );
			doGitMerge ( null );
		}
	}
	
	gitUpdateAllIcons ( );
}

actions. gitPull = function doGitPull ( inMessage )
{
	var				gitURL = getSourceServerURL ( );
	_gitPull ( gitURL );
}

function gitStageFiles ( arrPaths )
{
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
		/* No items has been selected so there is nothing to stage */
		return;
		
	var				gitResponse = gitModule. stage ( arrPaths, gitWorkTree );
	//displayExecutionError ( gitResponse );
}

actions. gitStage = function doGitStage ( inMessage )
{
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	var				gitResponse = gitStageFiles ( arrPaths );
	displayExecutionError ( gitResponse, "Failed to stage files", null );
};

function gitCommitLocal ( inPathsOptional )
{
	var				gitComment;

	var				nCommitCount = gitModule. getCommitCount ( gitWorkTree ) + 1;
	gitComment = studio. prompt ( "Please write a description", "#" + nCommitCount );
	if ( typeof ( gitComment ) === "undefined" || gitComment == null )
	{
		studio. showMessageOnStatusBar ( "Git: " + "Changes were not committed", "warning" );
		
		return false;
	}
	
	var		gitResponse = gitModule. commit ( gitComment, gitWorkTree, inPathsOptional );
	//displayExecutionError ( gitResponse );
	
	gitUpdateAllIcons ( );
	
	return true;
}

actions. gitCommit = function doGitCommit ( inMessage )
{
	gitCommitLocal ( );
}

actions. gitCommitSelected = function doGitCommitSelected ( inMessage )
{
	var		arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	gitCommitLocal ( arrPaths );
}

function _gitPush ( inURL )
{
	// First, the changes need to be committed locally
	if ( !gitCommitLocal ( ) )
		return;

	var				gitServerType = _gitGetSetting ( "serverType" );
	if ( gitServerType == "wak" )
	{
		var			wakRemoteRepository = _gitGetWakandaRemoteRepository ( true );
		var			bRepoExists = gitWakandaRepositoryExists ( wakRemoteRepository );
		if ( bRepoExists == null )
		{
			studio. alert ( "Error: Remote Wakanda Server is not responding." );
			
			return;
		}
		
		if ( !bRepoExists )
		{
			var		strMessage = "The remote repository '" + wakRemoteRepository + "' does not exist\n";
			strMessage += "and needs to be created. Would you like to continue?";
			var		bCreate = studio. confirm ( strMessage );
			if ( !bCreate )
				return;
				
			gitCreateWakandaRepository ( wakRemoteRepository );
		}
		
		gitModule. setRemoteRepository ( inURL, wakRemoteRepository );
	}
	else 
	{
		var			gitRemoteURL = _gitGetSetting ( "gitURL" );
		var			gitRemoteRepoInfo = gitParseGitHubRepoURL ( gitRemoteURL );
		if ( gitRemoteRepoInfo. repositoryName == null )
			gitRemoteRepoInfo. repositoryName = studio. currentSolution. getSolutionFile ( ). nameNoExt;
			
		if ( !gitGitHubRepositoryExists ( gitRemoteRepoInfo. userName, gitRemoteRepoInfo. repositoryName ) )
		{
			var		strMessage = "The remote repository '" + gitRemoteRepoInfo. repositoryName + "' does not exist\n";
			strMessage += "and needs to be created. Would you like to continue?";
			var		bCreate = studio. confirm ( strMessage );
			if ( !bCreate )
				return;
				
			// TODO: Need to be able to tell if URL is for user or organization
			gitCreateGitHubRepository ( gitRemoteRepoInfo. userName, gitRemoteRepoInfo. repositoryName );
		}
	}
	
//studio. alert ( "User name from remote Git URL == " + gitRemoteRepoInfo. userName );
//studio. alert ( "Repository name from remote Git URL == " + gitRemoteRepoInfo. repositoryName );
	
//studio. alert ( "Push URL == " + inURL );
	var				gitResponse = gitModule. push ( inURL, gitRepository );
	displayExecutionError (
						gitResponse,
						"Failed to push to remote server " + _gitGetRemoteURLPref ( ),
						"Pushed to remote server " + _gitGetRemoteURLPref ( ) );

}

actions. gitPush = function doGitPush ( inMessage )
{
	var				gitURL = getSourceServerURL ( );
//studio. alert ( "Will be pushing to " + gitURL );
	_gitPush ( gitURL );
}

actions. gitClone = function doGitClone ( inMessage )
{
	/*
		In our case git is executed with a SystemWorker and so its current directroy is not the current git repository directory.
		--git-dir needs to be used to specify where exactly the '.git' is to be created. 
		There is no need to specify the --work-tree because there is nothing to work with yet. 'clone' action should be performed
		on an empty directory or with a valid path that can be created on disk. Under these conditions git will not create a subfolder
		named 'MyRepo' (the last resource name in a smart HTTP URL) and the source files will be cloned directly into the
		destination repository directory. Full example that can be executed directly from Wakanda studio without having to care
		about the current directory of the studio process or of the current system worker.
		
		git --git-dir /DBs/Test/gitClientRepo7/.git clone https://sergiy:123@192.168.6.23:4443/gitservice/MyRepo /DBs/Test/gitClientRepo7
		
		gitClientRepo7 (and also Test) directory will be created if it does not exist
		
		Error handling:
			- Make sure that clone destination is valid before cloning: empty folder or valid path to create
			- Any error text returned by worker needs to be parsed if possible and returned to user in a readable form
	*/

	var				gitDestination;
	gitDestination = studio. prompt ( "Please enter local path to clone to.\nIt will be created if necessary.", "" );
	if ( typeof ( gitDestination ) === "undefined" || gitDestination == null )
		return;
	
	var				gitURL = getSourceServerURL ( );
	gitURL = studio. prompt ( "Please enter full URL of a repository to clone.\nhttp[s]://[user[:password]@]ip_or_dns[:port]/URI", gitURL );
	if ( typeof ( gitURL ) === "undefined" || gitURL == null )
		return;
		
	// git --git-dir=/DBs/Test/gitClientRepo22/.git clone https://sergiy:123@192.168.6.23:4443/gitservice/MyRepo /DBs/Test/gitClientRepo22  --progress > /DBs/Test/mygit4.txt 2>&1

	var				gitResponse = gitModule. clone ( gitURL, gitDestination );
	displayExecutionError ( gitResponse, "Failed to clone", "Clone completed" );
};


actions. gitRevert = function doGitRevert ( inMessage )
{
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
	{
		/* No items has been selected so there is nothing to stage */
		studio. alert ( "Please select files or folders to revert" );
		
		return;
	}

	var				bRevert = studio. confirm ( "Do you really want to revert changes to selected items?" );
	if ( !bRevert )
		return;

	var				arrResult = gitModule. revert ( arrPaths, gitWorkTree );
	
	var			arrUniqueFolders = extractFolderArray ( arrPaths );
		
	gitProvideFilesStatus ( arrUniqueFolders, true );
};


/*
	This revert version is needed to revert back to local, stashed, uncommited modifications after failing to merge remote modifications
	retrieved with 'pull'. 
*/
actions. gitResetAllMerged = function doGitResetAllMerged ( inMessage )
{
	var				bRevert = studio. confirm ( "Do you really want to revert unmerged files?\n\n(You may need to pop the latest stash, run\nmerge and then delete the stash manually.)" );
	if ( !bRevert )
		return;

	gitModule. resetAllMerged ( gitWorkTree );
	gitUpdateAllIcons ( );
};


actions. gitStatus = function doGitStatus ( inMessage )
{
	gitModule. getStatus ( gitWorkTree );
}

actions. gitKDiff3 = function doGitKDiff3 ( inMessage )
{
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
	{
		/* No items has been selected so there is nothing to stage */
		studio. alert ( "Please select a file or folder to diff" );
		
		return;
	}
	
	var				gitResponse = gitModule. launchDiffApp ( arrPaths, gitWorkTree );
	displayExecutionError ( gitResponse, "Failed to run diff application", null );
};

actions. gitCustom = function doGitCustom ( inMessage )
{
	var				gitCommand = studio. prompt ( "Hack away!", "" );
	if ( typeof ( gitCommand ) === "undefined" || gitCommand == null )
		return;
		
	var				gitResponse = gitModule. executeCustom ( gitCommand, gitWorkTree );
	displayExecutionError ( gitResponse, "Execution of custom command failed", "Custom command completed" );
	gitUpdateAllIcons ( );
};

actions. gitLog = function doGitLog ( inMessage )
{
//var		gitUser = _gitGetSetting ( "gitUser" );
//studio. alert ( "gitUser == " + gitUser );

	studio. extension. showModelessDialog ( "log.html", "git log", 400, 800);
};


actions. gitK = function doGitK ( inMessage )
{
//studio. alert ( "Navigate your terminal to a git repository and run 'gitk'" );
	var				gitResponse = gitModule. launchHistoryApp ( gitWorkTree );
	displayExecutionError ( gitResponse, "Failed to launch history application", null );
};


actions. onSolutionOpened = function doOnSolutionOpened ( inMessage )
{
	gitUpdateAllIcons ( );
}

actions. onProjectCreated = function doOnProjectCreated ( inMessage )
{
	var			arrPaths = new Array ( );
	arrPaths. push ( inMessage. source. data [ 0 ]. path );
	
	// git stages folder content recursively
	gitStageFiles ( arrPaths );
	gitProvideFilesStatus ( arrPaths, true );
}

actions. onFolderExpanded = function doOnFolderExpanded ( inMessage )
{
	var		arrPaths = gitConvertToArrayOfPaths ( inMessage. source. data );
	//studio. alert ( "Folder expanded, " + arrPaths. length + " item, " + arrPaths [ 0 ] );
	
	gitProvideFilesStatus ( arrPaths, true );
	//gitProvideFilesStatus ( arrPaths, false );
}


actions. onFolderCollapsed = function doOnFolderCollapsed ( inMessage )
{
	var		arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	//studio. alert ( "Folder collapsed, " + arrPaths. length + " item, " + arrPaths [ 0 ] );
}


actions. onFilesAddedInSolution = function onFilesAddedInSolution ( inMessage )
{
	var			arrPaths = gitConvertToArrayOfPaths ( inMessage. source. data );
//studio. alert ( "File added " + arrPaths [ 0 ] );
	var			gitResponse = gitModule. stage ( arrPaths, gitWorkTree );
	//displayExecutionError ( gitResponse );
	
	var			arrUniqueFolders = extractFolderArray ( arrPaths );
	gitProvideFilesStatus ( arrUniqueFolders, true );
}

actions. onStudioFileSave = function onStudioFileSave ( inMessage )
{
	var		arrPaths = gitConvertToArrayOfPaths ( inMessage. source. data );
	var		gitResponse = gitStageFiles ( arrPaths );
	displayExecutionError ( gitResponse, "Failed to stage files", null );
	
	arrPaths [ 0 ] = arrPaths [ 0 ]. substring ( 0, arrPaths [ 0 ]. lastIndexOf ( "/" ) );
	gitProvideFilesStatus ( arrPaths, true );

	/*var displayMsg = 'Action "' + message.action + '" is triggered by\n';
	displayMsg += '"' + message.event + '" from "' + message.source.name + '"\n\n';
	for (var i=0; i < .length; i++) {
		displayMsg += message.source.data[i] + '\n';
	}
	studio.alert(displayMsg);*/
};

actions. onFilesRemovedFromSolution = function onFilesRemovedFromSolution ( inMessage )
{
	var				arrPaths = gitConvertToArrayOfPaths ( inMessage. source. data );
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
		/* No items has been selected so there is nothing to stage */
		return;

//studio. alert ( "File removed" );
		
	var				gitResponse = gitModule. remove ( arrPaths, gitWorkTree );
	displayExecutionError ( gitResponse, "Failed to remove files from repository", null );
}

actions. gitHardResetAll = function gitHardResetAll ( inMessage )
{
	var				bReset = studio. confirm ( "Do you really want to revert all changes?" );
	if ( bReset )
		bReset = studio. confirm ( "Are you sure you know what you are doing? :-)\n\nAll uncommitted changes will be lost.\nYour repository will be reset to the last known committed state." );

	if ( !bReset )
	{
		studio. alert ( "Ooofff... That was close!" );
		
		return;
	}

	gitModule. hardResetAll ( gitWorkTree );
	gitUpdateAllIcons ( );
}

actions. gitMerge = function gitMerge ( inMessage )
{
	doGitMerge ( inMessage );
}


function gitGetIgnoreFilePath ( )
{
	var			gitIgnorePath = gitWorkTree;
	gitIgnorePath += "/";
		
	gitIgnorePath += ".gitignore";
	
	return gitIgnorePath;
}

actions. gitIgnore = function gitIgnore ( inMessage )
{
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
	{
		/* No items has been selected so there is nothing to stage */
		studio. alert ( "Please select files or folders to ignore." );
		
		return;
	}

	//for ( var i = 0; i < arrPaths. length; i++ )
	//	studio. alert ( "SELECTED " + arrPaths [ i ] );
	
	if ( !gitInitIgnore ( ) )
		return;
		
	gitModule. ignore ( arrPaths, gitWorkTree );
	
	// TODO: Need to collect all folder paths inored and refresh file icons

	var				arrUniqueFolders = extractFolderArray ( arrPaths );
	if ( arrUniqueFolders. length > 0 )
		gitProvideFilesStatus ( arrUniqueFolders, true );
	
	return true;
}

actions. gitFollow = function gitFollow ( inMessage )
{
	var				gitCommand;
	
	// Remove references to followed files from .gitignore
	// run "git update-index --no-assume-unchanged <file>" to start tracking again
	
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
	{
		/* No items has been selected so there is nothing to stage */
		studio. alert ( "Please select files or folders to ignore." );
		
		return;
	}


	if ( !gitInitIgnore ( ) )
		return;
		
	gitModule. follow ( arrPaths, gitWorkTree );
	
	var				arrUniqueFolders = extractFolderArray ( arrPaths );
	if ( arrUniqueFolders. length > 0 )
		gitProvideFilesStatus ( arrUniqueFolders, true );
}

actions. gitEditPreferences = function gitEditPreferences ( inMessage )
{
	// TODO: Provide a real prferences editor in html form
	// For now, this is just an alert that shows all values
	
	var			prefMessage = "";
	
	var			gitExecPathPref = studio. extension. getPref ( "gitExecutablePath" );
	if ( typeof ( gitExecPathPref ) === "undefined" || gitExecPathPref == null )
		prefMessage += "git executable path - not defined\n";
	else if ( gitExecPathPref == "" )
		prefMessage += "git executable path - git\n\n";
	else
		prefMessage += "git executable path - " + gitExecPathPref + "\n\n";
		
	var			gitURLPref = studio. extension. getPref ( "gitURL" );
	if ( typeof ( gitURLPref ) === "undefined" || gitURLPref == null )
		prefMessage += "git remote URL - not defined\n";
	else
		prefMessage += "git remote URL - '" + gitURLPref + "'\n\n";
	
	var			gitUserNamePref = studio. extension. getPref ( "gitUser" );
	if ( typeof ( gitUserNamePref ) === "undefined" || gitUserNamePref == null )
		prefMessage += "git user name - not defined\n";
	else
		prefMessage += "git user name - '" + gitUserNamePref + "'\n\n";
	
	var			gitUserPasswordPref = studio. extension. getPref ( "gitPassword" );
	if ( typeof ( gitUserPasswordPref ) === "undefined" || gitUserPasswordPref == null )
		prefMessage += "git user password - not defined\n";
	else
		prefMessage += "git user password - '" + gitUserPasswordPref + "'\n\n";
	
	studio. alert ( prefMessage );
}

function gitProvideFilesStatus ( arrPaths, inIsStaged )
{
	if ( typeof ( arrPaths ) === "undefined" || arrPaths == null || arrPaths. length == 0 )
		return;
		
	for ( var i = 0; i < arrPaths. length; i++ )
	{
		var		arrOfOne = new Array ( );
		arrOfOne. push ( arrPaths [ i ] );
		gitProvideFolderStatus ( arrOfOne, inIsStaged );
	}
}

// Notifies the studio about the status of all staged/non-staged files within a given folder (within inMessage)
function gitProvideFolderStatus ( arrPaths, inIsStaged )
{
	var				bIsOneFolderSelected = false;
	if ( typeof ( arrPaths ) != "undefined" && arrPaths != null && arrPaths. length == 1 )
	{
		var			fldr = studio.Folder ( arrPaths [ 0 ] );
		if ( fldr. exists )
			bIsOneFolderSelected = true;
	}
	
	if ( !bIsOneFolderSelected )
	{
		/*studio. alert ( "Please select exactly one folder to get the status on. Current selection is:" );
		for ( var i = 0; i < arrPaths. length; i++ )
			studio. alert ( arrPaths [ i ] );*/
		
		return;
	}
	
	var		objStatus = gitModule. provideFolderStatus ( arrPaths [ 0 ], inIsStaged, gitWorkTree );

	// Now here I need to pass arrays of file paths together with a corresponding icon to the studio object
	// so that it can update its interafce and show git status of each file within a given folder.
	if ( objStatus. addedFiles. length > 0 )
	{
		//studio. alert ( arrAddedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. addedFiles, studio. extension. getFolder ( ). path + 'gitAddedStaged.png', 'LowerRight');
	}
	if ( objStatus. modifiedFiles. length > 0 )
	{
		//studio. alert ( arrModifiedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. modifiedFiles, studio. extension. getFolder ( ). path + 'gitModifiedStaged.png', 'LowerRight');
	}
	if ( objStatus. deletedFiles. length > 0 )
	{
		//studio. alert ( arrDeletedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. deletedFiles, studio. extension. getFolder ( ). path + 'gitDeletedStaged.png', 'LowerRight');
	}
	if ( objStatus. unmergedFiles. length > 0 )
	{
		//studio. alert ( arrUnmergedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. unmergedFiles, studio. extension. getFolder ( ). path + 'gitResolveNeeded.png', 'LowerRight');
	}
	if ( objStatus. renamedFiles. length > 0 )
	{
		//studio. alert ( arrRenamedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. renamedFiles, studio. extension. getFolder ( ). path + 'gitRenamedStaged.png', 'LowerRight');
	}
		
 	if ( objStatus. notModifiedFiles. length > 0 )
	{
		//studio. alert ( arrNotModifiedFiles [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. notModifiedFiles, studio. extension. getFolder ( ). path + 'gitFollowedNotModified.png', 'LowerRight');
	}
 	if ( objStatus. notFollowedFiles. length > 0 )
	{
		//studio. alert ( arrNotFollowed [ 0 ] );
		studio. currentSolution. restoreItemsIcon ( objStatus. notFollowedFiles );
	}
 	if ( objStatus. ignoredFiles. length > 0 )
	{
		//studio. alert ( arrIgnored [ 0 ] );
		studio. currentSolution. setItemsOverlayIcon ( objStatus. ignoredFiles, studio. extension. getFolder ( ). path + 'gitIgnored.png', 'LowerRight');
	}
	
	//studio. alert ( studio. extension. getFolder ( ). path );
}


function gitUpdateAllIcons ( )
{
	// Update interface icons
	var			arrExpandedFolders = studio. currentSolution. getExpandedFolders ( );
	var			arrExpanded = new Array ( );
	for ( var i = 0; i < arrExpandedFolders. length; i++ )
		arrExpanded. push ( arrExpandedFolders [ i ]. path );
	
	// Filter Wakanda Studio.app:Contents:Resources:Web Components:walib:WAF:medias:
	var			arrToFilter = new Array ( );
	for ( var i = 0; i < arrExpanded. length; i++ )
		if ( arrExpanded [ i ]. indexOf ( "Contents/Resources/Web Components/walib/WAF/medias" ) != -1 )
			arrToFilter. push ( arrExpanded [ i ] );
			
	for ( var i = 0; i < arrToFilter. length; i++ )
		arrExpanded. splice ( arrExpanded. indexOf ( arrToFilter [ i ] ), 1 );
		
	for ( var i = 0; i < arrExpanded. length; i++ )
		gitProvideFilesStatus ( new Array ( arrExpanded [ i ] ), true );		
}


	/*
		git diff --name-only --cached			<--- staged files == "checked-out existing"
		git diff --name-only					<--- modified but not staged files == "?"
		git diff --name-only --diff-filter=A	<--- newly added files = "+"
		git ls-files -to						<--- non-tracked files, '?' status == "files not under source control"
		git ls-files -tc						<--- tracked files, 'H' status == "all files under source control - checked in, out, added"
			"-to + -tc == -tco" to produce a combined list ?+H

		git diff --name-status --cached --diff-filter=AM -- TestGitProj/
		git diff --name-status --cached --diff-filter=ACDMRUX
	*/
	

actions. DEBUG_gitShowStagedStatus = function DEBUG_gitShowStagedStatus ( inMessage )
{
	//studio. alert ( "DEBUG_gitShowStagedStatus" );
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	gitProvideFilesStatus ( arrPaths, true )
}

actions. DEBUG_gitShowNonStagedStatus = function DEBUG_gitShowNonStagedStatus ( inMessage )
{
	//studio. alert ( "DEBUG_gitShowNonStagedStatus" );
	var				arrPaths = gitConvertToArrayOfPaths ( studio. currentSolution. getSelectedItems ( ) );
	gitProvideFilesStatus ( arrPaths, false )
}

actions. DEBUG_gitInitRepoOnWakanda = function doDEBUG_gitInitRepoOnWakanda ( inMessage )
{
	// HARDCODED TEST CODE
	
	//studio. alert ( "DEBUG_gitInitRepoOnWakanda" );
	gitModule. initRepositoryOnRemoteWakanda ( "http://admin:123@127.0.0.1:8081/gitservice/repo", "/Volumes/SECOND/DBs/ClonedFromWakanda5" );
}

actions. DEBUG_gitPublishRepoOnWakanda = function doDEBUG_gitPublishRepoOnWakanda ( inMessage )
{
	// HARDCODED TEST CODE ON WINDOWS
	
	gitModule. initRemoteRepository ( "http://127.0.0.1:8081/gitservice/repo", "HostedByWakand" );
	gitModule. setRemoteRepository ( "http://127.0.0.1:8081/gitservice/repo", "HostedByWakand" );
	gitModule. push ( "http://sergiy:123@127.0.0.1:8081/gitservice/repo master", gitRepository );
	
	//gitModule. myTest ( );
}

actions. gitSaveStash = function doGitSaveStash ( inMessage )
{
	var			gitComment = studio. prompt ( "Please write a description", "" );
	if ( typeof ( gitComment ) === "undefined" || gitComment == null )
	{
		studio. alert ( "Stash was not saved" );
	
		return;
	}
		
	gitModule. saveStash ( gitWorkTree, gitComment );
	gitUpdateAllIcons ( );
}

actions. gitPopLatestStash = function doGitPopLatestStash ( inMessage )
{
	gitModule. popStash ( gitWorkTree );
	gitUpdateAllIcons ( );
}

actions. gitListStashes = function doGitListStashes ( inMessage )
{
	gitModule. listStashes ( gitWorkTree );
	gitUpdateAllIcons ( );
}

actions. gitShowLatestStash = function doGitShowLatestStash ( inMessage )
{
	gitModule. showLatestStash ( gitWorkTree );
	gitUpdateAllIcons ( );
}

actions. gitClearAllStashes = function doGitClearAllStashes ( inMessage )
{
	gitModule. clearAllStashes ( gitWorkTree );
	gitUpdateAllIcons ( );
}

actions. gitHubListRepositories = function doGitHubListRepositories ( inMessage )
{
	var			gitUserName = studio. extension. getPref ( "gitUser" );
	var			gitUserPassword = studio. extension. getPref ( "gitPassword" );

	//var			strURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/users/" + gitUserName + "/repos";
	var			strURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/users/" + "Wakanda" + "/repos";
	var			strRepos = gitExecuteHTTPRequest ( strURL, 'GET' );
	if ( strRepos == undefined )
	{
		studio. alert ( "Failed to retrieve github repositories." );
		
		return;
	}
	
	studio. extension. showModelessDialog ( "githubRepos.html", "github.com repositories", 400, 800);
	
//var	objRepos = JSON. parse ( strRepos );
//studio. alert ( objRepos [ 0 ]. name );
//studio. alert ( objRepos [ 1 ]. name );

	studio. extension. storage. setItem ( "githubRepositories", strRepos );
}

function gitInitLocalRepository ( )
{
	// Init git repository
	var			gitResponse = gitModule. initRepository ( gitWorkTree );
	displayExecutionError ( gitResponse, "Failed to initialize local repository", "Local repositry is initialized" );
	
	// Add .gitignore
	gitInitIgnore ( );
	
	var			gitIgnorePath = gitWorkTree;
	gitIgnorePath += "/";
	gitIgnorePath += ".gitignore";
	
	var		arrPath = new Array ( gitIgnorePath );
	gitStageFiles ( arrPath );
	gitModule. commit ( "Commit gitignore", gitWorkTree );
	
	// Add and commit the rest of the solution folder
	arrPath = new Array ( "." );
	gitStageFiles ( arrPath );
	gitModule. commit ( "Initial commit", gitWorkTree );
	
	isRepositoryValid = true;
	
	gitUpdateAllIcons ( );
}

actions. gitInitRepository = function doGitInitRepository ( inMessage )
{
	gitInitLocalRepository ( );
}

/*
@return: An object with the following attributes: userName, repositoryName. Attribute exists but is null if not present in the given url.
*/
function gitParseGitHubRepoURL ( inURL )
{
	/*
		GitHub.com URLs:
			- user pattern			- [https://]github.com/userName[/]
			- user repo				- [https://]github.com/userName/repoName[.git]
			- organization pattern	- [https://]github.com/orgName[/]
			- organization repo		- [https://]github.com/orgName/repoName[.git]
	*/
	
	var			strURL = inURL;
	// Let's strip "https://" if it is present
	if ( strURL. indexOf ( "https://" ) == 0 )
		strURL = strURL. substring ( "https://". length );
		
	// Let's remove the "github.com/"
	strURL = strURL. substring ( "github.com/". length );
	
	var			objResult = new Object ( );
	objResult. userName = null;
	objResult. repositoryName = null;
	
	// The substring from start to the first slash (or end of string if there is no slash) is the user name or organization name
	var			nSlashIndex = strURL. indexOf ( "/" );
	if ( nSlashIndex < 0 )
	{
		objResult. userName = strURL;
	}
	else
	{
		objResult. userName = strURL. substring ( 0, nSlashIndex );
		strURL = strURL. substring ( nSlashIndex + 1 );
		if ( strURL. length > 0 )
		{
			// The rest is the repository name that potentially ends ".git" and then with "/"
			
			// Remove the last slash if it is present
			if ( strURL [ strURL. length - 1 ] == "/" )
				strURL = strURL. substring ( 0, strURL. length - 1 );
				
			// Let's see if the string ends with ".git"
			if ( strURL. length >= 4 && strURL. substring ( strURL. length - 4 ) == ".git" )
				strURL = strURL. substring ( 0, strURL. length - 4 );
				
			objResult. repositoryName = strURL;
		}
	}
	
	return objResult;
}

function gitWakandaRepositoryExists ( inRemoteRepository )
{
	/*
		http[s]://wakanda_ip_address/gitservice/repo/winfo/?path=repo_path_relative_to_documents
		returns either full json description or an error message in json:
		{ "message": "Not Found" }		
	*/
	
	var			bResult = false;

	var			gitUserName = _gitGetSetting ( "wakUser" );
	var			gitUserPassword = _gitGetSetting ( "wakPassword" );
	var			gitAddress = _gitGetSetting ( "wakAddr" ) + ":" + _gitGetSetting ( "wakPort" );

	var				strProtocol = "https://";
	if ( gitAddress. indexOf ( "http://" ) == 0 )
	{
		gitAddress = gitAddress. substring ( 7 );
		strProtocol = "http://";
	}
	else if ( gitAddress. indexOf ( "https://" ) == 0 )
	{
		gitAddress = gitAddress. substring ( 8 );
		strProtocol = "https://";
	}
	
	if ( gitAddress. charAt ( gitAddress. length - 1 ) != "/" )
		gitAddress += "/";

	var				strURL = strProtocol;
	if ( gitUserName. length > 0 && gitUserPassword. length > 0 )
		strURL += gitUserName + ":" + gitUserPassword + "@";
		
	strURL += gitAddress + "gitservice/repo/winfo?path=" + inRemoteRepository;

//studio. alert ( "strURL = " + strURL );
	var			strResponse = gitExecuteHTTPRequest ( strURL, 'GET' );
//studio. alert ( "strResponse = " + strResponse );
	if ( typeof ( strResponse ) === "undefined" )
	{
		//studio. alert ( "Repository does NOT exist on remote Wakanda." );
		bResult = null;
	}
	else
	{
		var		objResponse = JSON. parse ( strResponse );
		bResult = ( typeof ( objResponse. path ) != "undefined" && objResponse. path != null );
		//studio. alert ( "Repository DOES exist remote Wakanda." );
	}
	
	return bResult;
}

function gitGitHubRepositoryExists ( inUserName, inRepositoryName )
{
//studio. alert ( "Testing if repository '" + inRepositoryName + "' exists for user '" + inUserName + "'" );
	/*
		https://api.github.com/repos/user_name/repo_name returns either full json description or an error message in json:
		{ "message": "Not Found" }		
	*/
	
	//var			gitRemoteURL = studio. extension. getPref ( "gitURL" );
	//var			gitRemoteRepoInfo = gitParseGitHubRepoURL ( gitRemoteURL );
	//studio. alert ( "User name from remote Git URL == " + gitRemoteRepoInfo. userName );
	//studio. alert ( "Repository name from remote Git URL == " + gitRemoteRepoInfo. repositoryName );
	
	var			bResult = false;

	var			strURL = "https://api.github.com/repos/" + inUserName + "/" + inRepositoryName;
	var			strResponse = gitExecuteHTTPRequest ( strURL, 'GET' );
	if ( strResponse == undefined )
		;//studio. alert ( "Repository does NOT exist on github." );
	else
	{
		bResult = true;
		//studio. alert ( "Repository DOES exist on github." );
	}
	
	return bResult;
}

function gitCreateWakandaRepository ( inRepositoryName )
{
	var				gitUserName = _gitGetSetting ( "wakUser" );
	var				gitUserPassword = _gitGetSetting ( "wakPassword" );
	var				gitAddress = _gitGetSetting ( "wakAddr" ) + ":" + _gitGetSetting ( "wakPort" );

	var				strURL = "https://";
	if ( gitAddress. indexOf ( "http://" ) == 0 )
	{
		gitAddress = gitAddress. substring ( 7 );
		strURL = "http://";
	}
	else if ( gitAddress. indexOf ( "https://" ) == 0 )
	{
		gitAddress = gitAddress. substring ( 8 );
		strURL = "https://";
	}

	if ( gitUserName. length > 0 && gitUserPassword. length > 0 )
		strURL += gitUserName + ":" + gitUserPassword + "@";

	if ( gitAddress [ gitAddress. length - 1 ] != "/" )
		gitAddress += "/";
		
	strURL += gitAddress + "gitservice/repo";
	gitModule. initRemoteRepository ( strURL, "HostedByWakand" );

//studio. alert ( strURL );
	gitModule. initRemoteRepository ( strURL, inRepositoryName );
}

function _gitGitHubUserIsOrganization ( inUserName )
{
	var			strURL = "https://api.github.com/orgs/" + inUserName;
	var			strResponse = gitExecuteHTTPRequest ( strURL, 'GET', null );
	if ( typeof ( strResponse ) === "undefined" || strResponse == null )
	{
//		studio. alert ( "User '" + inUserName + "' is not an organization." );
		
		return false;
	}
	
	var			objRseponse = JSON. parse ( strResponse );
	if (	typeof ( objRseponse. message ) != "undefined" &&
			objResponse. message != null &&
			objRseponse. message == "Not Found" )
	{
//		studio. alert ( "User '" + inUserName + "' is not an organization." );
	
		return false;
	}
	
//studio. alert ( "User '" + inUserName + "' is an organization." );
	return true;
}

function gitCreateGitHubRepository ( inUserName, inRepositoryName )
{
	var			gitUserName = _gitGetSetting ( "gitUser" );
	var			gitUserPassword = _gitGetSetting ( "gitPassword" );

	// Need to see if inUserName represents a real user or an organization
	
	var			strURL = "";
	if ( _gitGitHubUserIsOrganization ( inUserName ) )
		strURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/orgs/" + inUserName + "/repos";
	else
		strURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/user/repos";

	gitModule. initRemoteRepository ( strURL, inRepositoryName );
}

actions. gitHubPublish = function goGitHubPublish ( inMessage )
{
	//studio. alert ( "Should publish this solution on GitHub" );
	
	// gitUpdateAllIcons ( );
	
	var			strDefaultName = studio. currentSolution. getSolutionFile ( ). nameNoExt;
	var			strNewName = studio. prompt ( "Please, enter the new repository name", strDefaultName );
	if ( typeof ( strNewName ) === "undefined" || strNewName == null )
		return;
	
	// TODO: Spaces in repository name are replaced by '-'. See if there are other characters to escape or replace.

	var			gitUserName = _gitGetSetting ( "gitUser" );
	var			gitUserPassword = _gitGetSetting ( "gitPassword" );

	var			strURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/user/repos";
	var			strBody = '{ "name": "' + strNewName + '", "description": "Created by studio", "homepage": "https://github.com", "private": false, "has_issues": true, "has_wiki": true, "has_downloads": true }';
	var			strResponse = gitExecuteHTTPRequest ( strURL, 'POST', strBody );
	if ( strResponse == undefined )
	{
		studio. alert ( "Failed to create a github repository." );
		
		return;
	}
	
	//studio. alert ( strResponse );
	
	var				strNewURL = "https://" + gitUserName + ":" + gitUserPassword + "@api.github.com/" + gitUserName + "/" + strNewName;
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = gitExecPath + " push " + strNewURL + " master:master" + " --progress";
	else if ( os. isMac )
		gitCommand = 'bash -c "git' + ' push ' + strNewURL + ' master:master' + ' --progress' + ' 2>&1"';
	else
		studio. alert ( "Error: unknown OS" );
		
	studio. alert ( gitCommand );
	runGitClientCommand ( gitCommand, gitWorkTree );
}

/*******************/
/* Global Settings */
/*******************/
var globalGitDiffToolPathString, globalGitMergeToolPathString;
function getOptFromGlobalPref() {
	"use strict";
	var settings;
	var gitExecutablePathString;
	var gitURLString, gitUserString, gitPasswordString, gitIgnoreString, gitEmailString, gitIsPrivateRepositoryString, gitRememberPasswordString;
	var serverTypeString, wakUserString, wakPasswordString, wakAddrString, wakPortString, wakRepositoryString, wakRememberPasswordString;
	
	settings = {};

	gitExecutablePathString = studio.extension.getPref('gitExecutablePath');
	if (gitExecutablePathString !== '') {
		settings.gitExecutablePath = gitExecutablePathString;
	}
	globalGitDiffToolPathString = studio.extension.getPref('gitDiffToolPath');
	if (globalGitDiffToolPathString !== '') {
		settings.gitDiffToolPath = globalGitDiffToolPathString;
	}

	globalGitMergeToolPathString = studio.extension.getPref('gitMergeToolPath');
	if (globalGitMergeToolPathString !== '') {
		settings.gitMergeToolPath = globalGitMergeToolPathString;
	}
	
	// Global Settings
	gitURLString = studio.extension.getPref('gitURL');
	if (gitURLString !== '') {
		settings.gitURL = gitURLString;
	}
	
	gitUserString = studio.extension.getPref('gitUser');
	if (gitUserString !== '') {
		settings.gitUser = gitUserString;
	}
	
	gitRememberPasswordString = studio.extension.getPref('gitRememberPassword');
	if (gitRememberPasswordString === '') {
		settings.gitRememberPassword = true;
	}
	else {
		settings.gitRememberPassword = gitRememberPasswordString === 'true';
	}
	
	if (settings.gitRememberPassword) {
		gitPasswordString = studio.extension.getPref('gitPassword');
		if (gitPasswordString !== '') {
			settings.gitPassword = gitPasswordString;
		}
	}
	
	gitEmailString = studio.extension.getPref('gitEmail');
	if (gitEmailString !== '') {
		settings.gitEmail = gitEmailString;
	}

	gitIsPrivateRepositoryString = studio.extension.getPref('gitIsPrivateRepository');
	settings.gitIsPrivateRepository = gitIsPrivateRepositoryString === 'true';
	
	gitIgnoreString = studio.extension.getPref('gitIgnore');
	if (gitIgnoreString !== '') {
		settings.gitIgnore = gitIgnoreString;
	}
	else {
		var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
		settings.gitIgnore = gitModule.getDefaultIgnore();
	}
	
	serverTypeString = studio.extension.getPref('serverType');
	if (serverTypeString !== '') {
		settings.serverType = serverTypeString;
	}
	
	wakUserString = studio.extension.getPref('wakUser');
	if (wakUserString !== '') {
		settings.wakUser = wakUserString;
	}
	
	wakRememberPasswordString = studio.extension.getPref('wakRememberPassword');
	if (wakRememberPasswordString === '') {
		settings.wakRememberPassword = true;
	}
	else {
		settings.wakRememberPassword = wakRememberPasswordString === 'true';
	}
	
	if (settings.wakRememberPassword) {
		wakPasswordString = studio.extension.getPref('wakPassword');
		if (wakPasswordString !== '') {
			settings.wakPassword = wakPasswordString;
		}
	}
	
	wakAddrString = studio.extension.getPref('wakAddr');
	if (wakAddrString !== '') {
		settings.wakAddr = wakAddrString;
	}

	wakPortString = studio.extension.getPref('wakPort');
	if (wakPortString !== '') {
		settings.wakPort = wakPortString;
	}

	return settings;
}

function writeOptToGlobalPref(settings) {
	"use strict";
	var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	
	if (typeof settings.gitExecutablePath !== 'undefined') {
		studio.extension.setPref("gitExecutablePath", settings.gitExecutablePath);
	}
	
	if (typeof settings.gitDiffToolPath !== 'undefined') {
		studio.extension.setPref("gitDiffToolPath", settings.gitDiffToolPath);
		
		if (globalGitDiffToolPathString !== settings.gitDiffToolPath) {
			gitModule.setDiffToolPath(settings.gitDiffToolPath);
		}
	}
	
	if (typeof settings.gitMergeToolPath !== 'undefined') {
		studio.extension.setPref("gitMergeToolPath", settings.gitMergeToolPath);
		
		if (globalGitMergeToolPathString !== settings.gitMergeToolPath) {
			gitModule.setMergeToolPath(settings.gitMergeToolPath);
		}
	}

	if (typeof settings.serverType !== 'undefined') {
		studio.extension.setPref("serverType ", settings.serverType);
	}
	
	if (typeof settings.gitUser !== 'undefined') {
		studio.extension.setPref("gitUser", settings.gitUser);
	}
	
	if (typeof settings.gitRememberPassword === 'undefined')
		settings.gitRememberPassword = true;
	studio.extension.setPref("gitRememberPassword", settings.gitRememberPassword === true);
		
	if (settings.gitRememberPassword) {
		if (typeof settings.gitPassword !== 'undefined') {
			studio.extension.setPref("gitPassword", settings.gitPassword);
		}
	}
	
	if (typeof settings.gitURL !== 'undefined') {
		studio.extension.setPref("gitURL", settings.gitURL);
	}
	if (typeof settings.gitEmail !== 'undefined') {
		studio.extension.setPref("gitEmail", settings.gitEmail);
	}
	if (typeof settings.gitIsPrivateRepository === 'undefined') 
		studio.extension.setPref("gitIsPrivateRepository", false);
	else
		studio.extension.setPref("gitIsPrivateRepository", settings.gitIsPrivateRepository === true);

	
	if (typeof settings.gitIgnore !== 'undefined') {
		studio.extension.setPref("gitIgnore", settings.gitIgnore);
	}

	if (typeof settings.wakUser !== 'undefined') {
		studio.extension.setPref("wakUser", settings.wakUser);
	}
	
	if (typeof settings.wakRememberPassword === 'undefined')
		settings.wakRememberPassword = true;
	studio.extension.setPref("wakRememberPassword", settings.wakRememberPassword === true);
	
	if (settings.wakRememberPassword) {
		if (typeof settings.wakPassword !== 'undefined') {
			studio.extension.setPref("wakPassword", settings.wakPassword);
		}
	}
	
	if (typeof settings.wakAddr !== 'undefined') {
		studio.extension.setPref("wakAddr", settings.wakAddr);
	}
	if (typeof settings.wakPort !== 'undefined') {
		studio.extension.setPref("wakPort", settings.wakPort);
	}
}


actions. doSettingsCallBack = function doSettingsCallBack() {
	"use strict";
	//studio.alert('doSettingsCallBack');
	studio.stopUpdateServersList();
	if (typeof studio.extension.storage.returnValue !== 'undefined' && studio.extension.storage.returnValue != null) {

		if (studio.extension.storage.returnValue.saveToSolution) {
		
			// Write the solution settings
			writeOptToSolutionPref(studio.extension.storage.returnValue);
			
			// Write the global settings
			if (typeof studio.extension.storage.returnValue.gitExecutablePath !== 'undefined') {
				studio.extension.setPref("gitExecutablePath", studio.extension.storage.returnValue.gitExecutablePath);
			}
			if (typeof studio.extension.storage.returnValue.gitDiffToolPath !== 'undefined') {
				studio.extension.setPref("gitDiffToolPath", studio.extension.storage.returnValue.gitDiffToolPath);
				
				if (globalGitDiffToolPathString !== studio.extension.storage.returnValue.gitDiffToolPath) {
					gitModule.setDiffToolPath(studio.extension.storage.returnValue.gitDiffToolPath);
				}
			}
			if (typeof studio.extension.storage.returnValue.gitMergeToolPath !== 'undefined') {
				studio.extension.setPref("gitMergeToolPath", studio.extension.storage.returnValue.gitMergeToolPath);
				
				if (globalGitMergeToolPathString !== studio.extension.storage.returnValue.gitMergeToolPath) {
					gitModule.setMergeToolPath(studio.extension.storage.returnValue.gitMergeToolPath);
				}
			}
		}
		else {
			studio.extension.deletePrefFile();
			writeOptToGlobalPref(studio.extension.storage.returnValue);
		}
	}
};

function getInstalledGitPath() {
	"use strict";
	var isMac, gitDefaultPath1, gitDefaultPath2, gitExecutable;

	if (os.isMac)
    {
		gitDefaultPath1 = "/usr/bin/git";
        gitDefaultPath2 = "/usr/local/bin/git";
    }
	else if (os.isWindows)
    {
		gitDefaultPath1 = "C:\\Program Files (x86)\\Git\\bin\\git.exe";
        gitDefaultPath2 = gitDefaultPath1;
    }
	else
		return "";
	
	gitExecutable = studio.File( gitDefaultPath1 );
	if ( gitExecutable. exists )
		return gitDefaultPath1;
    else
    {
        gitExecutable = studio.File( gitDefaultPath2 );
        if ( gitExecutable. exists )
            return gitDefaultPath2;
    }

	return "";
}

function hasSolutionOpened() {
	"use strict";
	var solutionObj = studio.currentSolution.getSolutionFile();
	return (solutionObj !== null)
}

function isGitInitialized() {
	"use strict";
	if (!hasSolutionOpened)
		return false;
	var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	return gitModule.verifyRepository (gitWorkTree);
}

function getPreference(isGlobalPref) {
	"use strict";
	
	var pref = getOptFromGlobalPref();
	if (isGlobalPref)
		return pref;
	else {
		var solSettings = getOptFromSolutionPref();

		if (typeof (solSettings.serverType) !== 'undefined' && solSettings.serverType !== '')
			pref.serverType = solSettings.serverType;

		if (typeof (solSettings.gitURL) !== 'undefined' && solSettings.gitURL !== '')
			pref.gitURL = solSettings.gitURL;

		if (typeof (solSettings.gitEmail) !== 'undefined' && solSettings.gitEmail !== '')
			pref.gitEmail = solSettings.gitEmail;

		if (typeof (solSettings.gitIsPrivateRepository) === 'undefined')
			pref.gitIsPrivateRepository = false;
		else
			pref.gitIsPrivateRepository = solSettings.gitIsPrivateRepository === true;

		if (typeof (solSettings.gitUser) !== 'undefined' && solSettings.gitUser !== '') {
			if (typeof (solSettings.gitPassword) !== 'undefined' && solSettings.gitPassword !== '') {
				pref.gitUser = solSettings.gitUser;
				pref.gitPassword = solSettings.gitPassword;
			}
		}
		
		if (typeof (solSettings.gitIgnore) !== 'undefined' && solSettings.gitIgnore !== '')
			pref.gitIgnore = solSettings.gitIgnore;

		if (typeof (solSettings.wakUser) !== 'undefined' && solSettings.wakUser !== '') {
			if (typeof (solSettings.wakPassword) !== 'undefined' && solSettings.wakPassword !== '') {
				pref.wakUser = solSettings.wakUser;
				pref.wakPassword = solSettings.wakPassword;
			}
		}

		if (typeof (solSettings.wakAddr) !== 'undefined' && solSettings.wakAddr !== '') {
			if (typeof (solSettings.wakPort) !== 'undefined' && solSettings.wakPort !== '') {
				pref.wakAddr = solSettings.wakAddr;
				pref.wakPort = solSettings.wakPort;
			}
		}

		if (typeof (solSettings.wakRepository) !== 'undefined' && solSettings.wakRepository !== '')
			pref.wakRepository = solSettings.wakRepository;

		if (typeof (solSettings.gitRememberPassword) !== 'undefined')
			pref.gitRememberPassword = solSettings.gitRememberPassword;
	}
	return pref;
}

actions. doSettings = function doSettings ( inMessage )
{
	"use strict";
	
	var args, settings;
	var solutionOpened = hasSolutionOpened();
	var isGitInited = isGitInitialized();
	var isGlobalPref = !solutionOpened;
	//settings = getOptFromGlobalPref();
	
	//studio.alert('1');
	settings = getPreference(isGlobalPref);
	//studio.alert('2');

	if ( typeof ( settings.gitExecutablePath ) === 'undefined' || settings.gitExecutablePath === '' ) {
		settings.gitExecutablePath = getInstalledGitPath();
	}
	else {
		var gitExecutable = studio.File( settings.gitExecutablePath );

		if ( !gitExecutable. exists ) {
			settings.gitExecutablePath = getInstalledGitPath();
		}
	}

	var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	var ver = gitModule.getVersion();
	if (ver !== null) {
		var n = ver.search(".msysgit");
		if (n !== -1)
			ver = ver.substring(0, n);
	}
	
	args = {
		'settings': settings,
		'gitVersion': ver,
		'hasSolutionOpened': solutionOpened,
		'isGitInitialized': isGitInited
	};

		
	studio.startUpdateServersList();
	studio.extension.showModalDialog("globalPreferenceDialog.html", args, {title: "Wakanda Studio", dialogwidth: 760, dialogheight: 790, resizable: true }, 'doSettingsCallBack');
}


function isEmpty(obj) {
	for(var prop in obj) {
		if(obj.hasOwnProperty(prop))
			return false;
	}
	return true;
}


/*********************/
/* Solution Settings */
/*********************/

function getOptFromSolutionPref() {
	"use strict";
	var opts;
	var gitURLString, gitUserString, gitPasswordString, gitIgnoreString, gitEmailString, gitIsPrivateRepositoryString, gitRememberPasswordString;
	var serverTypeString, wakUserString, wakPasswordString, wakAddrString, wakPortString, wakRepositoryString, wakRememberPasswordString;
	var userPassword, wakUserPassword;
	
	
	opts = {};
	serverTypeString = studio.extension.getSolutionPref('serverType');
	if (serverTypeString !== '') {
		opts.serverType = serverTypeString;
	}

	gitURLString = studio.extension.getSolutionPref('gitURL');
	if (gitURLString !== '') {
		opts.gitURL = gitURLString;
	}

	gitEmailString = studio.extension.getSolutionPref('gitEmail');
	if (gitEmailString !== '') {
		opts.gitEmail = gitEmailString;
	}
	
	gitIsPrivateRepositoryString = studio.extension.getSolutionPref('gitIsPrivateRepository');
	opts.gitIsPrivateRepository = gitIsPrivateRepositoryString === 'true';
	
	gitRememberPasswordString = studio.extension.getSolutionPref('gitRememberPassword');
	if (gitRememberPasswordString === '') {
		opts.gitRememberPassword = true;
	}
	else {
		opts.gitRememberPassword = gitRememberPasswordString === 'true';
	}
	
	userPassword = studio.extension.getUserAndPassword('github');
	if (userPassword !== null) {
		opts.gitUser = userPassword.user;
		if (opts.gitRememberPassword)
			opts.gitPassword = userPassword.password;
		else
			opts.gitPassword = '';
	}
	
	var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	gitIgnoreString = gitModule.getIgnoreContent ( gitWorkTree );
	if (gitIgnoreString !== '') {
		opts.gitIgnore = gitIgnoreString;
	} 
	else {
		opts.gitIgnore = gitModule.getDefaultIgnore();
	}
	
	wakRememberPasswordString = studio.extension.getSolutionPref('wakRememberPassword');
	if (wakRememberPasswordString === '') {
		opts.wakRememberPassword = true;
	}
	else {
		opts.wakRememberPassword = wakRememberPasswordString === 'true';
	}
	
	wakUserPassword = studio.extension.getUserAndPassword('wak');
	
	if (wakUserPassword !== null) {
		opts.wakUser = wakUserPassword.user;
		if (opts.wakRememberPassword)
			opts.wakPassword = wakUserPassword.password;
		else
			opts.wakPassword = '';
	}
	
	wakAddrString = studio.extension.getSolutionPref('wakAddr');
	if (wakAddrString !== '') {
		opts.wakAddr = wakAddrString;
	}

	wakPortString = studio.extension.getSolutionPref('wakPort');
	if (wakPortString !== '') {
		opts.wakPort = wakPortString;
	}
	
	wakRepositoryString = studio.extension.getSolutionPref('wakRepository');
	if (wakRepositoryString !== '') {
		opts.wakRepository = wakRepositoryString;
	}
	else {
		opts.wakRepository = studio.currentSolution.getSolutionName();
	}

	return opts;
}

function writeOptToSolutionPref(settings) {
	"use strict";
	
	if (typeof settings.serverType !== 'undefined') {
		studio.extension.setSolutionPref("serverType", settings.serverType);
	}
	
	if (typeof settings.gitRememberPassword === 'undefined') 
		settings.gitRememberPassword = true;
	studio.extension.setSolutionPref("gitRememberPassword", settings.gitRememberPassword === true);
	
	if (typeof settings.gitUser !== 'undefined' && settings.gitUser !== '') {
		var passwd = '';
		if (settings.gitRememberPassword) {
			if (typeof settings.gitPassword !== 'undefined')
				passwd = settings.gitPassword;
		}
			
		studio.extension.setUserAndPassword('github', settings.gitUser, passwd);
	}
	
	if (typeof settings.gitURL !== 'undefined') {
		studio.extension.setSolutionPref("gitURL", settings.gitURL);
	}

	if (typeof settings.gitEmail !== 'undefined') {
		studio.extension.setSolutionPref("gitEmail", settings.gitEmail);
	}
	if (typeof settings.gitIsPrivateRepository === 'undefined') 
		studio.extension.setSolutionPref("gitIsPrivateRepository", false);
	else
		studio.extension.setSolutionPref("gitIsPrivateRepository", settings.gitIsPrivateRepository === true);
	
	var gitModule = require ( "../../Modules/waf-git/waf-Git.js" );
	if (typeof settings.gitIgnore !== 'undefined') {
		gitModule.setIgnoreContent(settings.gitIgnore, gitWorkTree);
	} else {
		gitModule.setIgnoreContent(gitModule.getDefaultIgnore());
	}
	
	if (typeof settings.wakRememberPassword === 'undefined') 
		settings.wakRememberPassword = true;
	studio.extension.setSolutionPref("wakRememberPassword", settings.wakRememberPassword === true);
	
	if (typeof settings.wakUser !== 'undefined' && settings.wakUser !== '') {
		var passwd = '';
		if (settings.wakRememberPassword) {
			if (typeof settings.wakPassword !== 'undefined')
				passwd = settings.wakPassword;
		}
		studio.extension.setUserAndPassword('wak', settings.wakUser, passwd);
	}

	if (typeof settings.wakAddr !== 'undefined') {
		studio.extension.setSolutionPref("wakAddr", settings.wakAddr);
	}
	if (typeof settings.wakPort !== 'undefined') {
		studio.extension.setSolutionPref("wakPort", settings.wakPort);
	}
	if (typeof settings.wakRepository !== 'undefined') {
		studio.extension.setSolutionPref("wakRepository", settings.wakRepository);
	}
}


/*************/
/* GUI Stuff */
/*************/
actions.disableSolutionCommands = function disableSolutionCommands ( inMessage ) {
	"use strict";
	studio.setActionEnabled('gitPull', false);
	studio.setActionEnabled('gitCommit', false);
	studio.setActionEnabled('gitPush', false);
}

actions.enableSolutionCommands = function enableSolutionCommands ( inMessage ) {
	"use strict";
	studio.setActionEnabled('gitPull', true);
	studio.setActionEnabled('gitCommit', true);
	studio.setActionEnabled('gitPush', true);
}

actions.guiInit = function guiInit ( inMessage ) {
	"use strict";
	studio.setActionEnabled('gitPull', false);
	studio.setActionEnabled('gitCommit', false);
	studio.setActionEnabled('gitPush', false);
	studio.setActionEnabled('gitPullFromSolutionServer', false);
	studio.setActionEnabled('gitPushToSolutionServer', false);
}

/**************/
/* Clone repo */
/**************/
  
 actions. cloneRepoCallBack = function cloneRepoCallBack() {
	"use strict";
	if (typeof studio.extension.storage.returnValue !== 'undefined') {
		// TODO: Use API to write/use opt
		var result;
		result = studio.extension.storage.returnValue.localDestination+'\n';
		result += studio.extension.storage.returnValue.userName+'\n';
		result += studio.extension.storage.returnValue.repositoryName;
		studio.alert(result);
	}
}

function getCloneRepoOptFromPref() {
	// TODO: Use API to get opt
	
	var opts = {};
	opts.localDestination = 'c:/toto';
	opts.userName = 'donho';
	opts.repositoryNames = ['item1', 'item2', 'item3'];
	return opts;
}

actions. doClone = function doClone ( inMessage )
{
	"use strict";
	
	var args, settings;
	
	settings = getCloneRepoOptFromPref();

	args = {
		'settings': settings
	};

	studio.extension.showModalDialog("cloneRepoDialog.html", args, {title: "Git Clone", dialogwidth: 760, dialogheight: 700, resizable: true }, 'cloneRepoCallBack');
	
}



actions. gitPullFromSolutionServer = function gitPullFromSolutionServer ( inMessage )
{
	studio. alert ( "gitPullFromSolutionServer" );
}
actions. gitPushToSolutionServer = function gitPushToSolutionServer ( inMessage )
{
	try
	{
		var			currentUser = studio. currentSolution. getUserCredentials ( );
		if ( typeof ( currentUser ) === "undefined" )
		{
			studio. showMessageOnStatusBar ( "Git: Push to the solution server was cancelled", "error" );
			
			return;
		}
		else if ( currentUser == null )
		{
			studio. showMessageOnStatusBar ( "Git: Push failed; studio is not connected to a server", "error" );
			
			return;
		}
		
		var			userName = currentUser. user;
		var			userPassword = currentUser. password;
		studio. alert ( "User name == " + userName );
		//studio. alert ( "User password == " + userPassword );
		
		var			srvrInfo = studio. currentConnectedServerInfo ( );
		studio. alert ( "Server address == " + srvrInfo. serverAddress );
		studio. alert ( "Admin port == " + srvrInfo. adminPort );
		studio. alert ( "SSL flag == " + srvrInfo. isSSL );
	}
	catch ( e )
	{
		studio. alert ( "NOT IMPLEMENTED: gitPushToSolutionServer" );
	}
}

actions. gitToolBar1 = function gitToolBar1 ( inMessage )
{
	studio. alert ( "git menu test 1" );
}
actions. gitToolBar2 = function gitToolBar2 ( inMessage )
{
	studio. alert ( "git menu test 2" );
}
actions. gitToolBar3 = function gitToolBar3 ( inMessage )
{
	studio. alert ( "git menu test 3" );
}


//point d'entree unique de l'extension
exports. handleMessage = function handleMessage ( message )
{
	var			actionName;
	actionName = message.action;
	
	if ( message. action != "doSettings" && message. action != "doSettingsCallBack" &&
		 message. action != "doClone" && message. action != "cloneRepoCallBack" &&
		 message. action != "solutionSettings" && message. action != "solutionSettingsCallBack" &&
		 message. action != "disableSolutionCommands" && message. action != "enableSolutionCommands" &&
		 message. action != "guiInit")
		gitInit ( );
	
	
	if (!actions.hasOwnProperty(actionName))
	{
		//console.warn('action does not exist:', actionName, 'message:', message);
		studio. alert ( "Unknow message: " + actionName );
		
		return false;
	}
	
	if ( isRepositoryValid && message. action == "gitInitRepository" )
	{
		studio. alert ( "Git repository has already been created." );
		
		return;
	}

	if ( !isRepositoryValid && (
			message. action == "gitCommit" || 
			message. action == "gitPull" || 
			message. action == "gitPush" ||
			message. action == "gitK" ||
			message. action == "gitLog" ||
			message. action == "gitStatus" ||
			message. action == "gitStage" ||
			message. action == "gitSaveStash" ||
			message. action == "gitPopLatestStash" ||
			message. action == "gitListStashes" ||
			message. action == "gitShowLatestStash" ||
			message. action == "gitClearAllStashes" ||
			message. action == "gitHubPublish" ) )
	{
		var		bShouldInit = studio. confirm ( "A local Git repository needs to be created.\nWould you like to continue?" );
		if ( bShouldInit )
		{
			gitInitSettings ( );
			gitInitLocalRepository ( );
		}
	}
			
	if (	!isRepositoryValid &&
			message. action != "gitClone" &&
			message. action != "gitEditPreferences" &&
			message. action != "gitResetPreferences" &&
			message. action != "gitInitRepository" &&
			message. action != "cloneRepoCallBack" &&
			message. action != "doClone" &&
			message. action != "doSettingsCallBack" &&
			message. action != "doSettings" &&
			message. action != "solutionSettingsCallBack" &&
			message. action != "solutionSettings" &&
			message. action != "disableSolutionCommands" &&
			message. action != "enableSolutionCommands" &&
			message. action != "guiInit" )
	{
		if (	message. action != "onFolderExpanded" &&
				message. action != "onFolderCollapsed" &&
				message. action != "onSolutionOpened" &&
				message. action != "onSolutionClosed" &&
				message. action != "onProjectCreated" &&
				message. action != "onFilesAddedInSolution" &&
				message. action != "onFilesRemovedFromSolution" &&
				message. action != "onStudioFileSave" )
			studio. alert ( "Not a valid git repository!" );
		
		return;
	}
	
	gitInitSettings ( );

	try
	{
		actions[actionName](message);
	}
	catch ( e )
	{
		studio. alert ( e. message );
	}
}
