/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
var init,
    isMac = (navigator.platform.indexOf("Mac")!= -1) ? true : false,
    isWin = (navigator.platform.indexOf("Win")!= -1) ? true : false,
    isLinux = (navigator.platform.indexOf("Linux")!= -1) ? true : false,
	server = {
		selected : {
			id : null,
			ip : null,
			port: null,
			sslPort: null,
			type : null
		},
		hover : {
			id : null
		}
	};


function getServerList() {
	var serversList = studio.getServersList(),
		serversNbr = serversList.length,
		html = '';
	
	serversList.sort(compareServers);
	serversList = removeDuplicateServers(serversList);
	
	// Update servers list div
	for (var count = 0; count < serversNbr; count++) {
		//var id = count + 1,
		var id = serversList[count].id,
			host = serversList[count].host.replace(/\.local$/g, ''),
			solution = serversList[count].solution,
			className = 'row studio-state';
		
		if (('row-' + id) === server.selected.id) {
			className += ' studio-state-active';
		}

		if (('row-' + id) === server.hover.id) {
			className += ' studio-state-hover';
		}

		html += '<div id="row-' + id + '" class="' + className + '" data-type="running" data-ip="' + serversList[count].ip + '" data-port="' + serversList[count].port + '" data-sslport="' + serversList[count].sslPort + '">';
		html += '<span class="icon"></span><strong> ' + solution + '</strong> on <strong>' + host + '</strong>';
		html += '</div>';
	}

	document.getElementById('running-servers-content').innerHTML = html;
	
	
	if (init === true) {
		setTimeout("getServerList()", 4000);
	}
}

function compareServers(a,b) {
  if (a.host < b.host)
     return -1;
  if (a.host > b.host)
    return 1;
  return 0;
}

function removeDuplicateServers(serversArray) {
	
	var newArray = new Array();
	
	label:for(var i = 0;  i < serversArray.length; i++ ) {  
		for (var j = 0; j < newArray.length;j++ ) {
			if (newArray[j].host == serversArray[i].host && 
				newArray[j].port == serversArray[i].port &&
				newArray[j].solution == serversArray[i].solution)
					continue label;
		}
		newArray[newArray.length] = serversArray[i];
	}
	return newArray;
}

function setValidation() {
	var cancelHtml = '<input id="cancel" type="button" value="Cancel" />',
		connectHtml = '<input id="connect" type="button" value="Connect" disabled="disabled" />';

	$('#validation').html(
		(isMac) ?
			cancelHtml + connectHtml :
			connectHtml + cancelHtml
	);
}