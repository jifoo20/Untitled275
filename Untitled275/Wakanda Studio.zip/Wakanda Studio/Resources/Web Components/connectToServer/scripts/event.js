/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
$(document).ready(function() {
	
	$(window)
	.load(function() {
		//initToolTips(559, 351);
		init = true;
		getServerList();
		setValidation();
	})
	.unload(function() {
		init = false;
	});
	
	
	$('body')
	.delegate('.studio-state:not(.studio-state-disabled)', {
		mouseover: function() {
			var $this = $(this);

			server.hover.id = $this.prop('id');
			$('.row').removeClass('studio-state-hover');
			$this.addClass('studio-state-hover');
		},
		mousedown: function() {
			var $this = $(this);
			
			if ($this.prop('id') !== server.selected.id) {
				$('#' + server.selected.id).removeClass('studio-state-hover studio-state-active');
			}
			
			$this.addClass('studio-state-active');
		}
	})
	.delegate('.row', 'click', function() {
		var $this = $(this);
		
		server.selected.id = $this.prop('id');
		server.selected.type = $this.data('type');
		server.selected.ip = $this.data('ip');
		server.selected.port = $this.data('port');
		server.selected.sslPort = $this.data('sslport');
		
		$('#server-ip').val(server.selected.ip);
		$('#server-port').val(server.selected.port);
		$('#server-SSLPort').val(server.selected.sslPort);
		
		$('#connect').prop('disabled', '');
	});


	$('#running-servers-content').mouseleave(function() {
		server.hover.id = null;
		$('.row').removeClass('studio-state-hover');
	});
	
	$('#server-ip')
	.keyup(function() {
		var ip = $(this).val(),
			existingRow = $('.row[data-ip="' + ip + '"]'),
			existingId = existingRow.prop('id');

		if (ip !== server.selected.ip) {
			$('#' + server.selected.id).removeClass('studio-state-active');
			server.selected.id = null;
			server.selected.type = null;
			server.selected.ip = null;
			server.selected.port = null;
			server.selected.sslPort = null;
}

		id = $('.row[data-ip="' + ip + '"]').prop('id');

		if (typeof existingId !== 'undefined') {
			server.selected.id = existingId;
			server.selected.type = existingRow.data('type');
			server.selected.ip = existingRow.data('ip');
			server.selected.port = existingRow.data('port');
			server.selected.sslPort = existingRow.data('sslPort');

			$('#' + server.selected.id).addClass('studio-state-active');
		}
		
		$('#connect').prop('disabled', '');
	})
	.blur(function() {
		if (!$(this).val().length) {
			$('#connect').prop('disabled', 'disabled');
		}
	});
	
	
	$('#validation')
	.delegate('#connect', {
		click : function() {
			server.selected.ip = $('#server-ip').val();
			server.selected.port = $('#server-port').val();
			server.selected.sslPort = $('#server-SSLPort').val();
			
			if (server.selected.ip.length && server.selected.port.length) {
				//console.log('Connecting to: ' + server.selected.ip + ':' + server.selected.port);
				try {
					studio.connectToServer(server.selected.ip, server.selected.port, server.selected.sslPort);
				} catch(e) {
				}
				
				studio.closeConnectToServerDialog();
			}
		}
	})
	.delegate('#cancel', {
		click : function() {
			studio.closeConnectToServerDialog();
		}
	});
});