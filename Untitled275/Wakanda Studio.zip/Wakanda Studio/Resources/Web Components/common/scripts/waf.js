/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, devel: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true */

/*global studio, $ */

var
    WAF;

WAF = WAF || {
    widgets: [],
    Widget: {},
    parseWidgets: function WAF_parseWidgets() {
    
        var
            Widget;
            
        Widget = WAF.Widget;

        function WAF_parseWidget_forEachWidgetConstructor(constructorName) {

            var
                Element,
                elementNodesList,
                elementNodesArray;

            Element = Widget[constructorName];
            elementNodesList = document.getElementsByClassName(Element.CSS_CLASS);
            elementNodesArray = Array.prototype.slice.call(elementNodesList, 0);

            function WAF_parseWidget_forEachElement(elementNode) {

                var
                    widget;

                widget = new Element(elementNode);
                WAF.widgets.push(widget);
                WAF.widgets[widget.id] = widget;

            }

            elementNodesArray.forEach(WAF_parseWidget_forEachElement);

        }

        Object.getOwnPropertyNames(Widget).forEach(WAF_parseWidget_forEachWidgetConstructor);
    
    }
};

(function WAF_Scope_loadTemplate() {

    var
        templates,
        nbLeftToLoad;

    function WAF_loadTemplate_manageReponse() {
    
        if (this.readyState !== 4) {
            return;
        }
        
        if (this.status === 200 || (this.status === 0 && this.responseText && this.responseText.length)) {
            this.token.callback(this.token.name, this.responseText);
        } else {
            this.token.callback(this.token.name, "");
        }
        
        if (nbLeftToLoad === 0 && WAF.ontemplatesloaded) {
            WAF.ontemplatesloaded();
        }
        
    }

    WAF.loadTemplate = function WAF_loadTemplate(name, callback) {
    
        var 
            xhr;
            
        xhr = new XMLHttpRequest();
        xhr.open('GET', 'templates/' + name + '.tmp.html');
        xhr.onreadystatechange = WAF_loadTemplate_manageReponse;
        xhr.token = {
            name: name,
            callback: callback
        };
        
        try {
            xhr.send();
        } catch (e) {
            callback(name, "");
            if (nbLeftToLoad === 0 && WAF.ontemplatesloaded) {
                WAF.ontemplatesloaded();
            }
        }
        
    };
    
    
    function saveTemplate(name, template) {
    
        templates[name] = template;
        nbLeftToLoad -= 1;
        
    }

    WAF.loadTemplates = function WAF_loadTemplates(templatesArg) {
    
        templates = templatesArg;
        nbLeftToLoad = templates.length;
        
        templates.forEach(
            function WAF_templates_forEach_loadTemplate(template) {
            
                WAF.loadTemplate(template, saveTemplate);
                
            }
        );
        
    };
    
}());
