/*global jQuery*/

/*jslint white: true, browser: true, devel: true, evil: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true */


/*
 * jQuery treeTable Plugin 2.3.0
 * http://ludo.cubicphuse.nl/jquery-plugins/treeTable/
 *
 * Copyright 2010, Ludo van den Boom
 * Dual licensed under the MIT or GPL Version 2 licenses.
 */
(function Scope_jQuery_treeTable($) {

    // Helps to make options available to all functions
    // TODO: This gives problems when there are both expandable and non-expandable
    // trees on a page. The options shouldn't be global to all these instances!
    var
        options,
        defaultPaddingLeft;
    


    // === Private functions
    
    function parentOf($row) {
        var 
            prefixLength,
            classNames;
        
        prefixLength = options.childPrefix.length;
        classNames = $row[0].className.split(' ');
        
        $.each(
            classNames,
            function parentOf_each_className(className) {
                if (className.match(options.childPrefix)) {
                    return $("#" + className.substring(prefixLength));
                }
            }
        );
    }
    
    function ancestorsOf($node) {
        var
            ancestors;
        
        ancestors = [];
        $node = parentOf($node);
        
        // generate ancestors stack
        while ($node) {
            ancestors.push($node[0]);
            $node = parentOf($node);
        }
        
        return ancestors;
    }
    
    function childrenOf($node) {
        return $("table.treeTable tbody tr." + options.childPrefix + $node[0].id);
    }
    
    
    function getPaddingLeft($node) {
        var
            paddingLeft;
        
        paddingLeft = parseInt($node.css('paddingLeft'), 10);
        
        return isNaN(paddingLeft) ? defaultPaddingLeft : paddingLeft;
    }
    
    
    function indent($nodes, value) {
        var
            $cells;
        
        $cells = $nodes.children("td").slice(options.treeColumn, 1);
        $cells.css('paddingLeft', getPaddingLeft($cells) + value + "px");
        
        childrenOf($nodes).each(
            function treeTable_indent_each_nodes_child() {
                var
                    $child;
                    
                $child = $(this);
                
                indent($child, value);
            }
        );
    }
    
    function initialize($row) {
        var 
            subRows,
            $treeCell,
            padding;
        
        if (!$row.hasClass("initialized")) {
            $row.addClass("initialized");
            
            subRows = childrenOf($row);
            
            if (!$row.hasClass("parent") && subRows.length > 0) {
                $row.addClass("parent");
            }
            
            // WARNING !!! Modified for Debugger (arrows for subsections)
            if ($row.hasClass("parent") || $row.hasClass("subsection")) {
                $treeCell = $row.children("td").slice(options.treeColumn, 1);
                padding = getPaddingLeft($treeCell) + options.indent;
                
                subRows.each(
                    function treeTable_initialize_each_subRow() {
                        var 
                            $subRow;
                            
                        $subRow = $(this);
                        
                        $subRow.children("td").slice(options.treeColumn, 1).css('paddingLeft', padding + "px");
                    }
                );
                
                if (options.expandable) {
                    $treeCell.prepend('<span style="margin-left: -' + options.indent + 'px; padding-left: ' + options.indent + 'px" class="expander"></span>');
                    if (!options.delegatedExpand) {
                        $treeCell.first().click(
                            function treeCell_expander_click() {
                                $row.toggleBranch();
                            }
                        );
                        if (options.clickableNodeNames) {
                            $treeCell.css('cursor', 'pointer');
                            $treeCell.click(
                                function treeTable_nodeName_click(event) {
                                    // Don't double-toggle if the click is on the existing expander icon
                                    if (event.target.className !== 'expander') {
                                        $row.toggleBranch();
                                    }
                                }
                            );
                        }
                    }
                    
                    // Check for a class set explicitly by the user, otherwise set the default class
                    if (!($row.hasClass("expanded") || $row.hasClass("collapsed"))) {
                        $row.addClass(options.initialState);
                    }

                    if ($row.hasClass("expanded")) {
                        $row.expand();
                    }
                }
            }
        }
    }
    
    function move($row, destination) {
        var 
            row;
        
        row = $row[0];
        
        $row.insertAfter(destination);
        childrenOf($row).reverse().each(
            function treeTable_move_each_subRow() {
                var
                    $subRow;
                
                $subRow = $(this);
                
                move($subRow, row); 
            }
        );
    }
    
        
    // === Public API
        
    $.fn.treeTable = function treeTable(optionsArg) {
    
        options = $.extend({}, $.fn.treeTable.defaults, optionsArg);
        
        return this.each(
            function treeTable_each_table() {
                $(this).addClass("treeTable").find("tbody tr").each(
                    function treeTable_each_row() {
                        var 
                            row,
                            $row;
                        
                        row = this;
                        $row = $(row);
                        
                        // Initialize root nodes only if possible
                        if (!options.expandable || row.className.indexOf(options.childPrefix) === -1) {
                            // To optimize performance of indentation, I retrieve the padding-left
                            // value of the first root node. This way I only have to call +css+ 
                            // once.
                            if (isNaN(defaultPaddingLeft)) {
                                defaultPaddingLeft = parseInt($row.children("td").slice(options.treeColumn, 1).css('padding-left'), 10);
                            }
                            
                            initialize($row);
                            
                        } else if (options.initialState === "collapsed") {
                            row.style.display = "none"; // Performance! $row.hide() is slow...
                        }
                    }
                );
            }
        );
    };
    
    $.fn.treeTable.defaults = {
        childPrefix: "child-of-",
        clickableNodeNames: false,
        expandable: true,
        indent: 19,
        initialState: "collapsed",
        treeColumn: 0
    };
    
    // Recursively hide all node's children in a tree
    $.fn.collapse = function treeTable_collapse() {
        
        var 
            $nodes;
        
        $nodes = this;
        
        $nodes.addClass("collapsed");
        
        childrenOf($nodes).each(
            function treeTable_collapse_each_child() {
                var 
                    $node;
                
                $node = $(this);
                
                if (!$node.hasClass("collapsed")) {
                    $node.collapse();
                }
                this.style.display = "none"; // Performance! $node.hide() is slow...
            }
        );
        
        return this;
    };
    
    // Recursively show all node's children in a tree
    $.fn.expand = function treeTable_expand() {
        var 
            $nodes;
            
        $nodes = this;
        
        $nodes.removeClass("collapsed").addClass("expanded");
        
        childrenOf($nodes).each(
            function treeTable_expand_each_child() {
                var 
                    $node;
                    
                $node = $(this);
                
                initialize($node);
            
                if ($node.is(".expanded.parent")) {
                    $node.expand();
                }
            
                // this.style.display = "table-row"; // Unfortunately this is not possible with IE :-(
                $node.show();
            }
        );
        
        return this;
    };


    // Reveal a node by expanding all ancestors
    $.fn.reveal = function treeTable_reveal() {
        
        var
            $nodes;
            
        $nodes = this;
        
        $(ancestorsOf($nodes).reverse()).each(
            function treeTable_reveal_each_ancestor() {
                var
                    $node;
                
                $node = $(this);
                
                initialize($node);
                $node.expand().show();
            }
        );
        
        return this;
    };


    // Add an entire branch to +destination+
    $.fn.appendBranchTo = function treeTable_appendBranchTo(destination) {
        var
            $node,
            $parent,
            node,
            parent,
            ancestorNames,
            nbAncestors;
            
        $node = $(this);
        node = this;
        $parent = parentOf($node);
        parent = $parent && $parent[0];
        
        ancestorNames = $.map(
            ancestorsOf($(destination)), 
            function treeTable_appendBranchTo_map_ancestors(ancestor) { 
                return ancestor.id;
            }
        );
        
        // Conditions:
        // 1: +node+ should not be inserted in a location in a branch if this would
        //        result in +node+ being an ancestor of itself.
        // 2: +node+ should not have a parent OR the destination should not be the
        //        same as +node+'s current parent (this last condition prevents +node+
        //        from being moved to the same location where it already is).
        // 3: +node+ should not be inserted as a child of +node+ itself.
        if ($.inArray(node.id, ancestorNames) === -1 && (!parent || (destination.id !== parent.id)) && destination.id !== node.id) {
            
            nbAncestors = ancestorsOf($node).length;
            
            indent($node, nbAncestors * options.indent * -1); // Remove indentation
            
            if (parent) { 
                $node.removeClass(options.childPrefix + parent.id); 
            }
            
            $node.addClass(options.childPrefix + destination.id);
            move($node, destination); // Recursively move nodes to new location
            indent($node, nbAncestors * options.indent);
        }
        
        return this;
    };
    
    // Add reverse() function from JS Arrays
    $.fn.reverse = function treeTable_reverse() {
        return this.pushStack(this.get().reverse(), arguments);
    };
    
    // Toggle an entire branch
    $.fn.toggleBranch = function treeTable_toggleBranch() {
        var 
            $nodes;
        
        $nodes = this;
        
        if ($nodes.hasClass("collapsed")) {
            $nodes.expand();
        } else {
            $nodes.removeClass("expanded").collapse();
        }
        
        return this;
    };
    
    
}(jQuery));
