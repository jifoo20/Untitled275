/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*global WAF, document */

/**
 * @module Widgets
 */
if (!('Widget' in WAF)) {
    WAF.Widget = {};
}

/**
 * Widget Box
 *
 * @class WAF.Box
 * @extends Object
 */
(function Box_Scope() {

	var 
        uuidIndex, 
        baseName, 
        proto, 
        states, 
        headerNodes, 
        titleNodes, 
        contentNodes;
	
    /**
     * uuidIndex
     *
     * @static
     * @private
     * @property uuidIndex
     * @type Number 
     **/
	uuidIndex = -1;
    
    /**
     * baseName
     *
     * @static
     * @private
     * @property baseName
     * @type String 
     * @default "box"
     **/
	baseName = 'box';
    
    /**
     * headerNodes
     *
     * @static
     * @private
     * @property headerNodes
     * @type Object 
     **/
	headerNodes = {};
    
    /**
     * titleNodes
     *
     * @static
     * @private
     * @property titleNodes
     * @type Object 
     **/
	titleNodes = {};
    
    /**
     * contentNodes
     *
     * @static
     * @shared
     * @private
     * @property contentNodes
     * @type Object 
     **/
	contentNodes = {};
    
    
    /**
     * initDomNode
     *
     * @static
     * @shared
     * @private 
     * @method initDomNode
     * @param {WAF.HBox|WAF.VBox} obj
     * @param {HTMLDivElement|String|null} domNode 
     * @param {Number} uuidIndex
     * @param {String} baseName
     **/
    function initDomNode(obj, domNode, uuidIndex, baseName) {
    
        var
            tagName;
		
		// find the dom Element
		switch (typeof domNode) {
		case 'object':
                        tagName = domNode.tagName && domNode.tagName.toLowerCase();
			domNode = (['div', 'section'].indexOf(tagName) !== -1) ? domNode :null;
			break;
		case 'string':
			domNode = document.getElementById(domNode);
			break;
		default:
			domNode = null;
		}
		
		// create a dom element if none have been delivered
		if (domNode === null) {
                    domNode = document.createElement('div');
                    domNode.innerHTML = WAF.loadTemplate('Box');
                    document.appendChild(domNode);
		}
		
		// assign the widget id or create a unique one
		if (typeof domNode.id === "string" && domNode.id !== "") {
		    obj.id = domNode.id;
		} else {
                    do {
                            uuidIndex += 1;
                    } while (document.getElementById(baseName + uuidIndex) !== null);
		    obj.id = baseName + uuidIndex;
		    domNode.id = this.id;
		}
		
		obj.domNode = domNode;
    }

    /**
     * @private
     * @constructor
     * @param {HTMLDivElement|String} domNode Div element or id of a div element
     * @param {Number} type VERTICAL or HORIZONTAL
     **/
    WAF.Box = function WAF_Box(domNode, type) {

        var
            self,
            headerNode,
            titleNode,
            contentNode,
            tagName;
		
        /**
         * self
         *
         * @private
         * @property self
         * @type WAF.Widget.Panel
         **/
	self = this;
        
        /**
         * domNode
         *
         * @property domNode
         * @type HTMLDivElement
         **/
        this.domNode = null;
		
        /**
         * headerNode
         *
         * @private
         * @property headerNode
         * @type HTMLDivElement
         **/
	headerNodes[this.id] = headerNode = $('> .waf-header', domNode)[0];
        
        /**
         * titleNode
         *
         * @private
         * @property titleNode
         * @type HTMLDivElement
         **/
	titleNodes[this.id] = titleNode = $('> .waf-title', headerNode)[0];
        
        /**
         * contentNode
         *
         * @private
         * @property contentNode
         * @type HTMLDivElement
         **/
	contentNodes[this.id] = contentNode = $('> .waf-content', domNode)[0];
		
    };
    WAF.Widget.Box = WAF.Box;
    
	
    /**
     * CSS Class Widget identifier
     *
     * @static
     * @property CSS_CLASS
     * @type String
     * @default "waf-horizontal"
     **/
    WAF.Box.CSS_CLASS_HORIZONTAL = 'waf-horizontal';


    proto = WAF.Box.prototype;
    proto.constructor.name = 'WAF_Box';
	
    /**
     * Toggle the content of the panel
     *
     * @method toggle
     */
    proto.toggle = function WAF_Box_toggle() {
        var
            collapsed,
            action;

        collapsed = states.collapsed[this.id];
        action = collapsed ? 'addClass' : 'removeClass';

        $(this.contentNode)[action]('waf-collapsed');
        states.collapsed[this.id] = !collapsed;
    };
	
    /**
     * Inform on the visibility of the panel content
     *
     * @method isCollapsed
     * @return {Boolean}
     */
    proto.isCollapsed = function WAF_Box_isOpened() {
        return states.collapsed[this.id];
    };
	
    /**
     * <p>Set the title of the panel.</p>
     *
     * @method setTitle
     * @param {String} title
     */
    proto.setTitle = function WAF_Box_setTitle(title) {
        titleNodes[this.id].innerHTML = title;
    };
	
    /**
     * <p>Get the current title of the panel.</p>
     *
     * @method getTitle
     * @return {String} The current title of the panel
     */
    proto.getTitle = function WAF_Box_getTitle() {
        return titleNodes[this.id].innerHTML;
    };
	
	
    /**
     * insertSection
     *
     * If "section" or "before" is a string, it is interpreted as an id
     * If "before" is a number, it is interpreted as the position of the target
     *
     * @method insertSection
     * @param {WAF_Panel|WAF_Tabset|WAF_Section|HTMLDivElement} section
     * @param {WAF_Panel|WAF_Tabset|WAF_Section|HTMLDivElement|String|Number} [before] Section before wiche the new section must be inserted
     */
    proto.insertSection = function WAF_Box_insertSection(section, before) {
    if (this.domNode.children.length > 0) {

        // create splitter

        // append/prepend splitter

    }

    // append/prepend the section

    };
    
    
    /**
     * destroySection
     *
     * If "section" is a string, it is interpreted as an id
     * If "section" is a number, it is interpreted as the position of the target
     *
     * @method destroySection
     * @param {WAF_Panel|WAF_Tabset|WAF_Section|HTMLDivElement|String|Number} section
     */
    proto.destroySection = function WAF_Box_destroySection(section) {
            return contentNodes[this.id].innerHTML;
    };
    
    
	/**
     * <p>Remove the box.</p>
     *
     * @method remove
     */
    proto.remove = function WAF_Box_remove() {
        $(this.domNode).remove();
    };
    

    /**
     * Widget HBox
     *
     * @class WAF.HBox
     * @extends WAF.Box
     */
    (function HBox_Scope() {
        
        var 
            uuidIndex,
            baseName,
            proto;
            
        /**
         * uuidIndex
         *
         * @static
         * @private
         * @property uuidIndex
         * @type Number 
         **/
        uuidIndex = -1;
        
        /**
         * baseName
         *
         * @static
         * @private
         * @property baseName
         * @type String 
         * @default "box"
         **/
        baseName = 'hbox';



        function mousemove_resize_boxes(mouseEvent) {
			var
				splitter,
				positionDif,
				previousBox,
				nextBox,
				newWidth;
                
			splitter = mouseEvent.data.splitter;
			previousBox = splitter.previousBox;
			nextBox = splitter.nextBox;
			
			positionDif = mouseEvent.clientX - splitter.oldMouseX;
			splitter.oldMouseX = mouseEvent.clientX;
			
			newWidth = parseInt(previousBox.style.width, 10) + positionDif;
			splitter.style.left = newWidth + "px";
			previousBox.style.width = newWidth + "px";
			nextBox.style.width = (parseInt(nextBox.style.width , 10) - positionDif) + "px";
			
            event.stopPropagation();
			return false;
        }
        
        
        function mousedown_resize_boxes(mouseEvent) {
			var
				splitter,
				splitterPosition,
				splitterWidth,
				nextBox,
				previousBox;
			
			splitter = this;
			nextBox = splitter.nextBox;
			previousBox = splitter.previousBox;
			splitterWidth = $(splitter).width();
			
			nextBox.oldWidth = $(nextBox).width();
			
			splitterPosition = $(splitter).position();
			splitter.oldLeft = parseInt(splitter.style.left, 10);
			splitter.oldMouseX = mouseEvent.clientX;
			
			//init value => splitterWidth / 2 always display mouse pointer at middle of slitter
			$(nextBox).width($(nextBox).width() + (splitterWidth / 2));
			$(previousBox).width(splitterPosition.left + (splitterWidth / 2));
			splitter.style.left = (splitterPosition.left + (splitterWidth / 2)) + "px";
			
			splitter.moving = true;
			
			$("body").bind('mousemove', {'splitter' : splitter}, mousemove_resize_boxes);
			$("body").bind('mouseup', {'splitter' : splitter}, mouseup_resize_boxes);
			
            event.stopPropagation();
			return false;
        }
        
        function mouseup_resize_boxes(mouseEvent) {
			var
				splitter,
				splitterPosition,
				positionDif,
				nextBox,
				nextBoxStyle;
			    
			splitter = mouseEvent.data === null ? this : mouseEvent.data.splitter;
			nextBox = splitter.nextBox;
			nextBoxStyle = nextBox.style;
			
			if (splitter.moving) {
			    // resizing boxes
			    splitterPosition = $(splitter).position();
			    positionDif = splitterPosition.left - splitter.oldLeft;
			    
			    $(nextBox).width(nextBox.oldWidth - positionDif);
				
				$("body").unbind('mousemove', mousemove_resize_boxes);
				$("body").unbind('mouseup', mouseup_resize_boxes);
				splitter.moving = false;
				
				event.stopPropagation();
				return false;
			} else {
			    // dropping box
			    // TODO: insert WAF.dragContent
			}
        }


        WAF.Widget.HBox = WAF.HBox = function WAF_HBox (domNode, type) {
        
			var
			    self, 
			    headerNode, 
			    titleNode, 
			    contentNode,
			    $domNode,
			    $splitters,
			    $boxes;
			
			initDomNode(this, domNode, uuidIndex, baseName);
			
			$domNode = $(this.domNode);
			
			$boxes = this.$boxes = $domNode.children('.waf-box');
			
			$splitters =  $domNode.children('.waf-splitter');
			$splitters.each(
			    function WAF_VBox_Constructor_each_splitter(index, splitter) {
			        this.previousBox = this.previousElementSibling;
			        this.nextBox = this.nextElementSibling;
			    }
			);
			$splitters.mouseup(mouseup_resize_boxes);
			$splitters.mousedown(mousedown_resize_boxes);
            
        };
        
        proto = WAF.HBox.prototype = new WAF.Box();
        
        /**
         * CSS Class Widget identifier
         *
         * @static
         * @property CSS_CLASS
         * @type String
         * @default "waf-hbox"
         **/
        WAF.HBox.CSS_CLASS = 'waf-hbox';

    }()); // HBox_Scope
    
    
    
    
    /**
     * Widget VBox
     *
     * @class WAF.VBox
     * @extends WAF.Box
     */
    (function VBox_Scope() {
        
        var 
            uuidIndex,
            baseName,
            proto;
            
        /**
         * uuidIndex
         *
         * @static
         * @private
         * @property uuidIndex
         * @type Number 
         **/
        uuidIndex = -1;
        
        /**
         * baseName
         *
         * @static
         * @private
         * @property baseName
         * @type String 
         * @default "vbox"
         **/
        baseName = 'vbox';

        function mousemove_resize_boxes(mouseEvent) {
            var
                splitter,
                positionDif,
                previousBox,
				nextBox,
				newHeight;
                
            splitter = mouseEvent.data.splitter;
			previousBox = splitter.previousBox;
			nextBox = splitter.nextBox;
            
            positionDif = mouseEvent.clientY - splitter.oldMouseY;
            splitter.oldMouseY = mouseEvent.clientY;
            
			newHeight = parseInt(previousBox.style.height, 10) + positionDif;
			splitter.style.top = newHeight + "px";
			previousBox.style.height = newHeight + "px";
			nextBox.style.height = (parseInt(nextBox.style.height , 10) - positionDif) + "px";
			
            event.stopPropagation();
			return false;
		}
        
        
        function mousedown_resize_boxes(mouseEvent) {
            var
                splitter,
				splitterPosition,
				splitterHeight,
				nextBox,
				previousBox;
            
            splitter = this;
            nextBox = splitter.nextBox;
			previousBox = splitter.previousBox;
			splitterHeight = $(splitter).height();
			
			nextBox.oldHeight = $(nextBox).height();
			
            splitterPosition = $(splitter).position();
			splitter.oldTop = parseInt(splitter.style.top, 10);
			splitter.oldMouseY = mouseEvent.clientY;
			
			//init value => splitterHeight / 2 always display mouse pointer at middle of slitter
			$(nextBox).height($(nextBox).height() + (splitterHeight / 2));
			$(previousBox).height(splitterPosition.top + (splitterHeight / 2));
			splitter.style.top = (splitterPosition.top + (splitterHeight / 2)) + "px";
			
			splitter.moving = true;
			
			$("body").bind('mousemove', {'splitter' : splitter}, mousemove_resize_boxes);
			$("body").bind('mouseup', {'splitter' : splitter}, mouseup_resize_boxes);
			
            event.stopPropagation();
			return false;
        }
        
        function mouseup_resize_boxes(mouseEvent) {
            var
				splitter,
				splitterPosition,
				positionDif,
				nextBox,
				nextBoxStyle;
			
            splitter = mouseEvent.data === null ? this : mouseEvent.data.splitter;
            nextBox = splitter.nextBox;
            nextBoxStyle = nextBox.style;
            
            if (splitter.moving) {
                // resizing boxes
				splitterPosition = $(splitter).position();
				positionDif = splitterPosition.top - splitter.oldTop;
				
				$(nextBox).height(nextBox.oldHeight - positionDif);
				
				$("body").unbind('mousemove', mousemove_resize_boxes);
				$("body").unbind('mouseup', mouseup_resize_boxes);
				splitter.moving = false;
				
				event.stopPropagation();
				return false;
            } else {
                // dropping box
                // TODO: insert WAF.dragContent
            }
        }


        WAF.Widget.VBox = WAF.VBox = function WAF_VBox (domNode, type) {
		
            var
                self, 
                headerNode, 
                titleNode, 
                contentNode,
                $domNode,
                $splitters,
                $boxes;
        
            initDomNode(this, domNode, uuidIndex, baseName);
            
            $domNode = $(this.domNode);
            
            $boxes = this.$boxes = $domNode.children('.waf-box');
            
            $splitters =  $domNode.children('.waf-splitter');
            $splitters.each(
                function WAF_VBox_Constructor_each_splitter(index, splitter) {
                    this.previousBox = this.previousElementSibling;
                    this.nextBox = this.nextElementSibling;
                }
            );
            $splitters.mouseup(mouseup_resize_boxes);
            $splitters.mousedown(mousedown_resize_boxes);
            
        }; 
        
        proto = WAF.VBox.prototype = new WAF.Box();
        
        /**
         * CSS Class Widget identifier
         *
         * @static
         * @property CSS_CLASS
         * @type String
         * @default "waf-hbox"
         **/
        WAF.VBox.CSS_CLASS = 'waf-vbox';

    }()); // VBox_Scope

}()); // Box_Scope

