/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
 * @module Widgets
 */


/**
 * Widget Panel
 *
 * @class WAF.Widget.Panel
 * @extends Object
 */
(function Panel_Scope() {
    
    
    // "use strict";

	var 
        uuidIndex, 
        baseName, 
        proto, 
        states, 
        headerNodes, 
        titleNodes, 
        contentNodes;
	
    /**
     * uuidIndex
     *
     * @static
     * @private
     * @property uuidIndex
     * @type Number 
     **/
	uuidIndex = -1;
    
    /**
     * baseName
     *
     * @static
     * @private
     * @property baseName
     * @type String 
     * @default "panel"
     **/
	baseName = 'panel';
	
    /**
     * states
     *
     * @static
     * @private
     * @property states
     * @type Object 
     **/
	states = {
		collapsed: {}
	};
    
    /**
     * headerNodes
     *
     * @static
     * @private
     * @property headerNodes
     * @type Object 
     **/
	headerNodes = {};
    
    /**
     * titleNodes
     *
     * @static
     * @private
     * @property titleNodes
     * @type Object 
     **/
	titleNodes = {};
    
    /**
     * contentNodes
     *
     * @static
     * @private
     * @property contentNodes
     * @type Object 
     **/
	contentNodes = {};

    /**
     * @constructor
     * @param {HTMLDivElement|String} domNode Div element or id of a div element
     **/
	WAF.Widget.Panel = 
    WAF.Panel = function WAF_Panel(domNode) {
		
		var
            self, 
            headerNode, 
            titleNode, 
            contentNode, 
            tagName;
		
        /**
         * self
         *
         * @private
         * @property self
         * @type WAF.Widget.Panel
         **/
		self = this;
		
		// find the dom Element
		switch (typeof domNode) {
		case 'object':
            tagName = domNode.tagName && domNode.tagName.toLowerCase();
			domNode = tagName === 'div' ? domNode : null;
			break;
		case 'string':
			domNode = document.getElementById(domNode);
			break;
		default:
			domNode = null;
		}
		
		// create a dom element if none have been delivered
		if (domNode === null) {
			domNode = document.createElement('div');
			domNode.innerHTML = WAF.loadTemplate('Panel');
			document.appendChild(domNode);
		}
		
		// assign the widget id or create a unique one
		if (typeof domNode.id === "string" && domNode.id !== "") {
		    this.id = domNode.id;
		} else {
			do {
				uuidIndex += 1;
			} while (document.getElementById(baseName + uuidIndex) !== null);
		    this.id = baseName + uuidIndex;
		    domNode.id = this.id;
		}
		
		this.domNode = domNode;
		
        /**
         * headerNode
         *
         * @private
         * @property headerNode
         * @type HTMLDivElement
         **/
		headerNodes[this.id] = 
        headerNode = $('> .waf-header', domNode)[0];
        
        /**
         * titleNode
         *
         * @private
         * @property titleNode
         * @type HTMLDivElement
         **/
		titleNodes[this.id] = 
        titleNode = $('> .waf-title', headerNode)[0];
        
        /**
         * contentNode
         *
         * @property contentNode
         * @type HTMLDivElement
         **/
		contentNodes[this.id] = 
        this.contentNode = $('> .waf-content', domNode)[0];
		
	};
	
    /**
     * CSS Class Widget identifier
     *
     * @static
     * @property CSS_CLASS
     * @type String
     * @default "waf-panel"
     **/
	WAF.Panel.CSS_CLASS = 'waf-panel';
	
	proto = WAF.Panel.prototype;
	//WAF.Panel.prototype.constructor.name = 'WAF_Panel';
	
    /**
     * Toggle the content of the panel
     *
     * @method toggle
     */
	proto.toggle = function WAF_Panel_toggle() {

		var
            collapsed, 
            action;
		
        window.console.debug(states, this);
        if (!([this.id] in states.collapsed)) {
            collapsed = false;
        } else {
            collapsed = states.collapsed[this.id];
		}
        action = collapsed ? 'addClass' : 'removeClass';
		
		$(this.domNode)[action]('waf-collapsed'); 
		states.collapsed[this.id] = !collapsed;
        
	};
	
    /**
     * Inform on the visibility of the panel content
     *
     * @method isCollapsed
     * @return {Boolean}
     */
	proto.isCollapsed = function WAF_Panel_isOpened() {
		return states.collapsed[this.id];
	};
	
    /**
     * <p>Set the title of the panel.</p>
     *
     * @method setTitle
     * @param {String} title
     */
	proto.setTitle = function WAF_Panel_setTitle(title) {
        titleNodes[this.id].innerHTML = title;
	};
	
    /**
     * <p>Get the current title of the panel.</p>
     *
     * @method getTitle
     * @return {String} The current title of the panel
     */
	proto.getTitle = function WAF_Panel_getTitle() {
		return titleNodes[this.id].innerHTML;
	};
	
	
    /**
     * <p>Set the content of the panel.</p>
     *
     * <p>If the content parameter is a DOM Element, it will be moved in the content
     * Element of the panel</p>
     *
     * @method setContent
     * @param {String|HTMLElement|XMLHttpRequest} content
     * @param {String} [template]
     */
	proto.setContent = function WAF_Panel_setContent(content, template) {
		if (typeof content === "string") {
            contentNodes[this.id].innerHTML = content;
        }
        if (typeof content === "object") {
            if (typeof content.tagName === "string") {
                $(contentNodes[this.id]).children().remove();
                contentNodes[this.id].appendChild(content);
            }
        }
	};
    
    
	/**
     * <p>Get the content of the panel.</p>
     *
     * <p>If the content parameter is a DOM Element, it will be moved in the content
     * Element of the panel</p>
     *
     * @method getContent
     * @param {String} format
     * @return {String|HTMLElement}
     */
	proto.getContent = function WAF_Panel_getContent(format) {
		return contentNodes[this.id].innerHTML;
	};
    
    
	/**
     * <p>Remove the panel.</p>
     *
     * @method remove
     */
    proto.remove = function WAF_Panel_remove() {
        $(this.domNode).remove();
    };

}()); // Panel_Scope

