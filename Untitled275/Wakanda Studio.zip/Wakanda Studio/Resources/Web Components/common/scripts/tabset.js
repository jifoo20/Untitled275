/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true */

/*global WAF,$,window*/

// create a Tabset

(function Tabset_Scope(document) {

	//// "use strict";

    var
        uuidIndex, 
        proto;
    
    uuidIndex = -1;
    
    function WAF_Tabset_select(tabName) {
        var
            oldSelectedTab, 
            className, 
            newSelectedTab, 
            currentTab, 
            inactiveTabs;
        
        oldSelectedTab = this.selectedTab;
        newSelectedTab = this.tabs[tabName];
        
        // unselect the current tab
        if (oldSelectedTab !== null) {
            $(oldSelectedTab.link.domNode).removeClass('waf-active');
            $(oldSelectedTab.domNode).removeClass('waf-active');
        }
        
        // select the new tab
        $(newSelectedTab.link.domNode).addClass('waf-active');
        $(newSelectedTab.domNode).addClass('waf-active');
        
        this.selectedTab = newSelectedTab;
        
    }
    
    function selectThisTabName() {
        WAF_Tabset_select.apply(this.tabset, [this.tabName]);
    }
    
    WAF.Widget.Tabset = WAF.Tabset = function WAF_Tabset(domNode) {
        
        var 
            self, 
            toc, 
            tabName, 
            baseName,
            $domNode;
        
        self = this;
        
        // assign the widget id or create a unique one
        if (typeof domNode.id === "string" && domNode.id !== "") {
            this.id = domNode.id;
        } else {
            baseName = this.constructor.name;
            do {
                uuidIndex += 1;
            } while (document.getElementById(baseName + uuidIndex) !== null);
            this.id = baseName + uuidIndex;
            domNode.id = this.id;
        }
        
        $domNode = $(domNode);
        
        this.domNode = domNode;
        this.toc = [];
        this.tabs = [];
        this.selectedTab = null;
        
        toc = $domNode.find('.waf-navigation > li');
        
        toc.each(
            function WAF_TabSet_toc_each(tabIndex, tabLinkNode) {
                
                var
                    tabLink,
                    tab,
                    tabNode,
                    tabName,
                    selected,
                    anchorNode,
                    $tabLinkNode;
                
                $tabLinkNode = $(tabLinkNode);
                
                tabName = $tabLinkNode.find('a')[0].hash.substr(1);
                selected = $tabLinkNode.hasClass('waf-active');
                
                tabLink = {
                    tabset: self,
                    index: tabIndex,
                    tabName: tabName,
                    content: null,
                    domNode: tabLinkNode,
                    selected: selected,
                    select: selectThisTabName    
                };
                
                anchorNode = $domNode.find('.waf-content > a[name=' + tabName + ']')[0];
                tabNode = $(anchorNode).next('div')[0];
                
                tab = {
                    tabset: self,
                    index: tabIndex,
                    tabName: tabName,
                    link: tabLink,
                    anchorNode: anchorNode,
                    domNode: tabNode,
                    selected: selected,
                    select: selectThisTabName
                };
                
                tabLink.content = tab;
                
                self.toc[tabName] = self.toc[tabIndex] = tabLink;
                self.tabs[tabName] = self.tabs[tabIndex] = tab;
                
                tabNode.tabset = tabLinkNode.tabset = self;
                tabNode.tabName = tabLinkNode.tabName = tabName;
                
                tab.select = tabNode.onclick = selectThisTabName;
                tabLink.select = tabLinkNode.onclick = selectThisTabName;
                
                if (selected) {
                    self.selectedTab = tab;
                }
                
            }
        );
        
        if (this.toc.length > 0) {
            tabName = window.location.hash.substr(1);;
            if (tabName in this.toc) {
                this.select(tabName);    
            }

            if (this.selectedTab === null) {
                this.select(this.toc[0].tabName);    
            }            
        }
    };
    
    WAF.Tabset.CSS_CLASS = 'waf-tabset';
    
    proto = WAF.Tabset.prototype;
    //proto.constructor.name = 'WAF_Tabset';
    proto.select = WAF_Tabset_select;

}(document)); // Tabset_Scope

