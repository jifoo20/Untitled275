/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, strict: true */

// devel: true // "Assume console, alert, ..." not supported by JSLint plugin
// immed: true // "Require parens around immediate invocations" not supported by JSLint plugin

/*global WAF, waStudio, $, Mustache, window, alert */

/**
 *  MANAGE WATCHERS
 *
 * @static
 * @method manageWatchers
 **/
waStudio.Debugger.manageWatchers = function Debugger_manageWatchers() {

    // "use strict";

    var
        Debugger,
        //Context,
        Frame,
        templates,
        contexts,
        config,
        subSections,
        $contentWatchers,
        $watchersContainer,
        objectOwners,
        expandedObjects,
        watchExpressions,
        watchExpressionsByName,
        $watchers,
        $watchersEmpty,
        $watchExpressions,
        $newExpressionForm,
        $columnHeads,
        $currentWatchers,
        evalSequences,
        sorters,
        tools,
        sequences,
        DEBUG,
        exceptionDisplayed;


    /* CONFIG */

    // main objects direct references
    Debugger = waStudio.Debugger;

    /**
     * @class Context
     */
    Context = Debugger.Context;
    Frame = Debugger.Frame;
    templates = Debugger.templates;
    tools = Debugger.tools;
    contexts = Debugger.contexts;

    sequences = [];
    exceptionDisplayed = {};

    // config
    Debugger.config.watchers = {
        indent: 19,
        delegatedExpand: true,
        groupFunctions: true,
        groupOwnProperties: true,
        sortBy: "name",
        sortOrder: 1
    };
    config = Debugger.config.watchers;
    DEBUG = Debugger.DEBUG && true;

    // required templates
    templates.push(
        'watchersBody',
        'watchersSubSectionLoading',
        'watchersExpressionLoading',
        'watchersPropertiesLoading',
        'watchersScopePropertiesLoading',
        'watchersScopesLoading',
        'watchersNoExpression',
        'watchersExpression',
        'watchersScopes',
        'watcher'
    );

    // required events
    Debugger.events.push(
        'scopereceived',
        'scopesreceived',
        //'objectpropertiesreceived',
        //'evaluated',
        'stackready',
        'framechange',
        'resume',
        'enablepanels'
    );


    /* FUNCTION DECLARATIONS */
    
    function crossfireClient_watchers_initSubSection(sectionId, name) {

        var
            $subSection,
            path;

        $subSection = $('#' + sectionId);
        path = 'subSection:' + sectionId;

        $subSection.path = path;
        $subSection.data('path', path);

        $subSection.target = Debugger.EVAL_WATCHERS;
        $subSection.name = name;
        $subSection.level = 0;
        $subSection.uuid = sectionId;

        $subSection.$body = $subSection.parent();
        $subSection.$rows = $subSection;
        $subSection.$children = $('.child-of-' + sectionId);
        $subSection.$rows.add($subSection.$children);

        objectOwners[$subSection.path] = $subSection;

        subSections.push($subSection);

        return $subSection;
    }



    /**
     * @method getScopes
     **/
    Frame.prototype.getScopes = function crossfireClient_Frame_getScopes() {

        var
            context,
            frame;

        context = this.context;
        frame = this;

        window.console.log(Debugger.iframe + ' Debugger.getScopes ', context.id, frame.number);
        Debugger.getScopes(context.id, frame.number);
        

    };

    
    /**
     * @event onscopesreceived
     * @param {ScopesReceivedEvent} scopesReceivedEvent
     */
    Frame.onscopesreceived = function crossfireClient_onscopesreceived_watchersListener(scopesReceivedEvent) {

        var
            body,
            context,
            frame;

        context = Debugger.contexts['#' + scopesReceivedEvent.context_id];
        if (context === undefined) {
            return false;
        }

        body = scopesReceivedEvent.body;
        if (body.hasOwnProperty('frameIndex')) {
            frame = context.frames[body.frameIndex];
        } else {
            console.error('onscopesreceived: frameIndex is not available');
            
            // hack because different order
            body.scopes.length = body.totalScopes || (body.toScope + 1);
            body.scopes = [].reverse.call(body.scopes);
            delete body.scopes.length;
            // end of hack
            
            frame = context.currentFrame;
        }

        if (frame === undefined) {
            return false;
        }

        frame.onscopesreceived(scopesReceivedEvent);
        return true;

    };

    /**
     * @event onscopesreceived
     * @param {ScopesReceivedEvent} scopesReceivedEvent
     **/
    Frame.prototype.onscopesreceived = function crossfireClient_Frame_onscopesreceived(scopesReceivedEvent) {
        
        //window.console.info(Debugger.iframe + '> crossfireClient_onscopereceived_watchersListener', event);

        if (this.scopeData && this.scopeData.stepIndex < this.context.stepIndex) {
            window.console.warn(Debugger.iframe + '> crossfireClient_onscopereceived_watchersListener', 'request expired! another step have been done');
            return false;
        }

        this.scopesData = scopesReceivedEvent.body.scopes;
        this.createScopes();
        this.renderScopes();

        return true;

    };


    /**
     * @class WatchExpression
     */
    function WatchExpression(name, path) {
        
        var
            html;

        this.name = name;
        this.expression = '(' + name + ')';
        this.path = path;
        this.domId = 'watchExpressions-' + Number(new Date());
        this.expressionDomId = this.domId;

        this.level = 1;
        this.colspan = '';
        this.removable = true;
        this.empty = false;
        this.indent = config.indent;
        this.comma = ', ';

        // TODO: real owner is Watch Expression Scope
        this.owner = $watchExpressions;
        this.ownerDomId = 'watchExpressions';

        watchExpressions.push(this);
        watchExpressions[path] = this;
        objectOwners[path] = this;
        watchExpressionsByName[name] = this;

        html = Mustache.to_html(templates.watchersExpressionLoading, this);
        $watchExpressions[0].insertAdjacentHTML("afterend", html);
        
        this.$domId = '#' + this.domId;
        this.$domNode = $(this.$domId);
        this.$cols = this.$domNode.children().slice(2, 3);

    }


    /**
     * update this Watch Expression
     *
     * @method updateWatchExpression
     **/
    WatchExpression.prototype.update = function crossfireClient_WatchExpression_update() {

        if (Debugger.currentContext instanceof Debugger.Context) {
            this.$cols.html('loading');
            Debugger.currentContext.currentFrame.evaluate(this);
        } else {
            this.$cols.html('<span class="waf-error">No Context</span>');
			this.$cols.prev().children("span").remove();
			this.$cols.next().html("");
        }

    };


    /**
     * remove this Watch Expression
     *
     * @method remove
     **/
    WatchExpression.prototype.remove = function crossfireClient_WatchExpression_remove() {

        $('.grand-child-of-' + this.expressionDomId).empty().remove();
        if (this.hasOwnProperty('handle')) {
            crossfireClient_watchers_unreferenceOwners(this);
        }

        this.$domNode.empty().remove();

        delete watchExpressionsByName[this.name];
        watchExpressions.splice(watchExpressions.indexOf(this), 1);
        delete watchExpressions[this.path];
        delete objectOwners[this.path];

        if (watchExpressions.length === 0) {
            // Show the default message
            $watchExpressions.after($watchExpressions.$empty);
            $watchExpressions.$empty.show();
            //$watchExpressions.$empty.attach();
        }

    };


    /**
     * onevaluated
     *
     * @event onevaluated
     * @param {EvaluatedEvent} evaluatedEvent
     **/
    WatchExpression.prototype.onevaluated = function crossfireClient_WatchExpression_onevaluated(evaluatedEvent) {

        var
            previewData;

        previewData = tools.createPreviewLevel1(this, evaluatedEvent.body, /*watchExpressions*/ objectOwners, config);

        if (this.hasOwnProperty('$rows')) {
            this.$rows.empty().remove();
        }

        ['handle', 'type', 'preview', 'hasProperties', 'nbMore', 'isObject', 'isFunction', 'isError', 'isScalar'].forEach(
            function (property) {
                this[property] = previewData[property];
            },
            this
        );


        // Apply template
        // Show the expression
        this.$domNode[0].outerHTML = Mustache.to_html(
            templates.watchersExpression,
            this
        );
            
        this.$domNode = $(this.$domId);
        this.$cols = this.$domNode.children().slice(2, 3);

        // restore expanded status
        if (this.hasProperties && (expandedObjects.hasOwnProperty(this.path))) {
            this.propertiesRequested = false;
            this.expand();
        //    this.$rows.first().find('.expander').click();
        }
        
        crossfireClient_watchers_refresh_remove();

    };
    
    WatchExpression.prototype.getProperties = function crossfireClient_ServerObject_getProperties() {

        if (!this.propertiesRequested) {
            this.propertiesRequested = true;
            Debugger.currentContext.currentFrame.getObjectProperties(this);
        }

    };

    

    function crossfireClient_watchers_updateWatchExpressionForEach(watchExpression) {
        watchExpression.update();
    }

    /**
     * updateAllWatchExpressions
     *
     * @static
     * @method updateAll
     **/
    WatchExpression.updateAll = function crossfireClient_watchers_updateAllWatchExpressions() {

        var
            nbWatchExpressions;

        //window.console.info(Debugger.iframe + '> updateAllWatchExpressions');

        nbWatchExpressions = watchExpressions.length;

        if (nbWatchExpressions === 0 || $watchExpressions.hasClass("collapsed")) {
            return;
        }

        //watchExpressions.currentContext = Debugger.currentContext;
        //watchExpressions.stepIndex = Debugger.currentContext.stepIndex;
        $('.watchExpObjProp').empty().remove();

        watchExpressions.forEach(crossfireClient_watchers_updateWatchExpressionForEach);

    };
    


    /**
     * @class ServerObject
     * @extends Object
     *
     * @constructor
     * @param {Object} data
     * @param {Frame} frame
     * @param {ServerObject} owner
     */
    function ServerObject(data, frame, owner) {

        var
            baseDomId,
            basePath;

        // FIX: for the console... is it pertinent ?
        if (frame === undefined) {
            frame = Debugger.currentContext.currentFrame;
        }

        /**
         * @property handle
         * @type Number
         */
        this.handle = (data.handle !== undefined) ? data.handle : data.object && data.object.handle;

        /**
         * @property frame
         * @type Frame
         */
        this.frame = frame;

        /**
         * @property stepIndex
         * @type Number
         */
        this.stepIndex = (frame && frame.context) ? frame.context.stepIndex : 0;


        /**
         * @property hasProperties
         * @type Boolean
         * @default true
         */
        this.hasProperties = true;
        
        /**
         * @property isWatchExpProperty
         * @type Boolean
         */
        this.isWatchExpProperty = Boolean(data.isWatchExpProperty);

        if (owner !== undefined) {

            /**
             * @property owner
             * @type ServerObject | undefined
             **/
            this.owner = owner;
            
            /**
             * @property expressionDomId
             * @type String | undefined
             **/
            if (owner.hasOwnProperty('expressionDomId')) {
                this.expressionDomId = owner.expressionDomId;
            }

            baseDomId = owner.domId;
            basePath = (owner instanceof Scope) ? '' : owner.path;

            /**
             * @property level
             * @type Number
             * @default 1
             **/
            this.level = owner.level + 1;
        } else {
            baseDomId = frame.domId;
            basePath = frame.domId;
            this.level = 1;
        }

        /**
         * @property domId
         * @type String
         **/
        this.domId = baseDomId + '_serveurObject' + this.handle;
        
        if (data.name !== undefined) {

            /**
             * @property name
             * @type String | undefined
             **/
            this.name = data.name;

            /**
             * @property path
             * @type String
             **/
            this.path = basePath + "['" + this.name.replace("'", "\\'") + "']";
        } else if (this instanceof Scope) {
            this.path = basePath + '.scope(' + this.handle + ')';
        } else {
            //this.path = basePath + "['" + this.name.replace("'", "\\'") + "']";
            this.path = basePath + '.serveurObject(' + this.handle + ')';
        }

        /**
         * @property propertiesRequested
         * @type Boolean
         * @default false
         **/
        this.propertiesRequested = false;

        objectOwners[this.path] = this;
    
    }

    /**
     * @method getProperties
     **/
    ServerObject.prototype.getProperties = function crossfireClient_ServerObject_getProperties() {

        if (!this.propertiesRequested) {
            this.propertiesRequested = true;
            this.frame.getObjectProperties(this);
        }

    };

    /**
     * @method expand
     **/
    ServerObject.prototype.expand = function crossfireClient_ServerObject_expand() {

        var
            $domNode;

        $domNode = $('#' + this.domId);
        $domNode.expand();
        expandedObjects[this.path] = this;
        this.getProperties();
    };


    /**
     * @event onobjectpropertiesreceived
     * @param {ObjectPropertiesReceivedEvent} propertiesReceivedEvent
     */
    ServerObject.prototype.onobjectpropertiesreceived = function crossfireClient_ServerObject_onobjectpropertiesreceived(propertiesReceivedEvent) {
        
        // crossfireClient_renderObjectProperties(this, propertiesReceivedEvent);

        var
            properties,
            propertyNames,
            innerSorters,
            $domNodes;

        window.console.info(Debugger.iframe + '> crossfireClient_ServerObject_onobjectpropertiesreceived', propertiesReceivedEvent);

        /*
        if (typeof owner.$children !== 'undefined') {
            owner.$children.empty().remove();
        }
        */

        this.properties = [];
        this.propertiesByName = {};
        properties = propertiesReceivedEvent.body.result;
        propertyNames = Object.getOwnPropertyNames(properties);

        if (propertyNames.length === 0) {
            window.console.error(
                'There shoulds always be some properties. At Least:',
                [
                    'The "__proto__" property in object properties',
                    'The "this" object in global & function scopes',
                    'The "arguments" object in function scopes'
                ]
            );
            $domNodes = $('#' + this.domId + '-Loading').children();
            $domNodes.html('// this object has no own properties');
            return;
        }

        /* innerSorters = {

            bytype: function crossfireClient_watchers_sortPropertiesByType(elem1, elem2) {
                elem1 = properties[elem1].type;
                elem2 = properties[elem2].type;
                return sorters.sortProperties(elem1, elem2);
            },

            byvalue: function crossfireClient_watchers_sortPropertiesByValue(elem1, elem2) {
                elem1 = properties[elem1].value || properties[elem1].preview;
                elem2 = properties[elem2].value || properties[elem2].preview;
                return sorters.sortProperties(elem1, elem2);
            }
        };

        if (config.sortBy === 'name') {

            if (owner.isArray || (owner.isObject && ['EntitySet', 'FolderList', 'FileList'].indexOf(owner.type) > -1)) {
                propertyNames.sort(sorters.byname.asIndex);
            } else {
                propertyNames.sort(sorters.byname.asName);
            }

        } else {
            propertyNames.sort(innerSorters['by' + config.sortBy]);
        } */

        this.propertiesData = properties;

        if (this instanceof Scope && this.isGlobal === true) {

            // Filter Global Object Properties

            this.propertyNames = [];

            propertyNames.forEach(
                function crossfireClient_watchers_filterGlobalProperties(propertyName) {

                    if (!Debugger.JSCORE_GLOBAL_PROPERTIES.hasOwnProperty(propertyName)) {
                        this.obj.propertyNames.push(propertyName);
                    }
                },
                {
                    obj: this
                }
            );

        } else {
            this.propertyNames = propertyNames;
        }

        //tools.createListPreview(this, objectOwners, propertiesReceivedEvent.request_seq, config);
        config.colorException = '';
        tools.createListPreview(this, config);
    };

    Debugger.ServerObject = ServerObject;

    WatchExpression.prototype.onobjectpropertiesreceived = ServerObject.prototype.onobjectpropertiesreceived;
    WatchExpression.prototype.expand = ServerObject.prototype.expand;


    /**
     * @class ServerException
     * @extends ServeurObject
     *
     * @constructor
     * @param {Object} exceptionData
     * @param {Frame} frame
     */
    function ServerException(exceptionData, frame) {

        ServerObject.call(this, arguments);

    }

    ServerException.prototype = Object.create(ServerObject.prototype);
    ServerException.prototype.constructor = ServerException;

	ServerException.prototype.onobjectpropertiesreceived = function crossfireClient_Exception_onobjectpropertiesreceived(event) {

		var data,
			$domNodes,
			eventError,
			properties,
			innerSorters,
			propertyNames,
			$exceptionCols,
			configException;

		if(this.hasOwnProperty("firstObjectPropertiesRequest") && this.firstObjectPropertiesRequest) {

			this.firstObjectPropertiesRequest = false;
			data = event.body.result;
			$exceptionCols = $('#' + this.objDomId)[0].cells;

			$('#' + this.objDomId).attr("propertiesData", event.body.result);
			$('#' + this.objDomId).attr("propertyNames", Object.getOwnPropertyNames(event.body.result));

			$exceptionCols[1].innerHTML = data.hasOwnProperty('name') ? data.name : 'Error';
			$exceptionCols[2].innerHTML = data.message;
			
			if(!exceptionDisplayed.hasOwnProperty(this.objDomId)) {
	    		exceptionDisplayed[this.objDomId] = true;
				eventError = {
					type : 'consoleerror',
					data : ["Exception " + $exceptionCols[1].innerHTML + " : " + $exceptionCols[2].innerHTML]
				};
				Debugger.dispatchEvent(eventError);
			}

			this.domId = this.objDomId;
			this.level = 1;
			this.empty = false;
			this.indent = config.indent;
			this.indent2 = config.indent;

		} else {

			window.console.info(Debugger.iframe + '> crossfireClient_ServerException_onobjectpropertiesreceived', event);

			this.properties = [];
			this.propertiesByName = {};
			properties = event.body.result;
			propertyNames = Object.getOwnPropertyNames(properties);

			if(propertyNames.length === 0) {
				window.console.error('There shoulds always be some properties. At Least:', ['The "__proto__" property in object properties', 'The "this" object in global & function scopes', 'The "arguments" object in function scopes']);
				$domNodes = $('#' + this.domId + '-Loading').children();
				$domNodes.html('// this object has no own properties');
				return;
			}

			this.propertiesData = properties;

			if(this instanceof Scope && this.isGlobal === true) {

				// Filter Global Object Properties

				this.propertyNames = [];

				propertyNames.forEach(function crossfireClient_watchers_filterGlobalProperties(propertyName) {

					if(!Debugger.JSCORE_GLOBAL_PROPERTIES.hasOwnProperty(propertyName)) {
						this.obj.propertyNames.push(propertyName);
					}
				}, {
					obj : this
				});

			} else {
				this.propertyNames = propertyNames;
			}

			// this.level += 1;
			configException = config;
			configException.colorException = "syntaxColor-exception";
			tools.createListPreview(this, configException);
		}

	}



    /**
     * @class Scope
     * @extends ServeurObject
     *
     * @constructor
     * @param {Object} scopeData
     * @param {Frame} frame
     */
    function Scope(scopeData, frame) {

        ServerObject.apply(this, arguments);
        this.index = scopeData.index;
        this.domId = frame.scopesTBodyId + '_scope' + scopeData.index;

    }

    Scope.prototype = Object.create(ServerObject.prototype);
    Scope.prototype.constructor = Scope;

    /**
     * @property level
     * @type Number
     * @default 1
     **/
    Scope.prototype.level = 1;

    /**
     * @method getVariables
     **/
    Scope.prototype.getVariables = function crossfireClient_Scope_getVariables() {

        this.getProperties();

    };

    Debugger.Scope = Scope;


    Frame.prototype.createScopes = function Frame_createScopes() {
        
        var
            context,
            scopes,
            scopesTBodyId,
            scope,
            exceptionScope,
            exceptionObj,
            exception,
            exceptionPath;
            
        context = this.context;
        scopes = this.scopesData;

        scopesTBodyId = 'watchers_context' + context.id + '_frame_' + this.number;
        this.scopesTBodyId = scopesTBodyId;

        this.indent = config.indent;
        this.indent2 = config.indent;

        // default scopes property values
        this.scopeType = "closure";
        this.isClosure = true;

        // specific scopes property values
        if (!scopes.hasOwnProperty('length')) {
            scopes.length = Object.getOwnPropertyNames(scopes).length;
        }
        scopes = Array.prototype.slice.call(scopes, 0);
        scopes = scopes.map(
            function scopes_map(scopeData, index) {
                if (!scopeData.hasOwnProperty('index')) {
                    scopeData.index = index;
                }
                return new Scope(scopeData, this.frame);
            },
            {
                frame: this
            }
        );
        scope = scopes[0];
        scope.isClosure = false;
        scope.isGlobal = true;
        scope.scopeType = 'global';
        if (scopes.length > 1) {
            scope = scopes[scopes.length - 1];
            scope.isClosure = false;
            scope.isLocal = true;
            scope.scopeType = 'local';
            
            scopes.reverse();
        }

        this.scopes = scopes;


        // Exception description
        if (context.hasOwnProperty('exception')) {

            // EXPERIMENTAL
            //context.exception.index = 'Exception';
            //exceptionScope = new Scope(context.exception, this);
            //exceptionObj = new ServerException(data, this);

            exception = context.exception;
            
            // TODO: update to use ServerException Constructor
            exception.domId = scopesTBodyId + '_exception';
            exception.objDomId = exception.domId + 'ThrownExpression';
            exception.isObject = true;
            //exception.hasProperties = true;
            exception.path = exception.domId + ['.thrownExpression'];
            exception.onobjectpropertiesreceived = ServerException.prototype.onobjectpropertiesreceived;
            exception.firstObjectPropertiesRequest = true;
            
            objectOwners[exception.path] = exception;
            
            this.aException = [exception];
            
        }
    };
    
    /**
     * @method renderScopes
     **/
    Frame.prototype.renderScopes = function Frame_renderScopes() {

        var
            scopesTBodyId,
            $existingTBody,
            scopes,
            $scope,
            html;

        scopesTBodyId = this.scopesTBodyId;

        // clear existing watchers
        $existingTBody = $('#' + scopesTBodyId);
        if ($existingTBody.length > 0) {

            //window.console.debug(Debugger.iframe + '> crossfireClient_onscopereceived_watchersListener - $existingTBody:', $existingTBody.length, 'stepIndexes:', $existingTBody.attr('data-stepIndex'), this.context.stepIndex);
            //if ($existingWatchers.attr('data-stepIndex') === String(this.context.stepIndex)) {
                // prevent duplicates
                //window.console.warn(Debugger.iframe + '> crossfireClient_onscopereceived_watchersListener', 'scopes alredy received!');
                //return false;
            //} else {
                // remove scopes from previous steps
            $existingTBody.empty().remove();
            //}
        }

        scopes = this.scopes;

        html = Mustache.to_html(templates.watchersScopes, this.context);
        
        $watchersEmpty.hide();
        // hide all scope tbodies from any frames and contexts
        $contentWatchers.children('.debug-scopes').hide();

        // Show the new tbody and its scopes
        $watchersEmpty[0].insertAdjacentHTML('afterend', html);
        
        Debugger.initSelectable($watchersEmpty.parent());

        // TODO: do it via an enablePanel method on the watcher module container
        $watchersContainer.removeClass('waf-disabled');
        $watchersContainer.find('input').removeProp('disabled') ;
        //$currentWatchers = $watchersEmpty.next();

        scopes[0].expand();

        // load Exception details
        if (this.hasOwnProperty('aException')) {
            this.getObjectProperties(this.aException[0]);
        }

    };

    
    /**
     * @method updateWatchers
     *
     */
    /*
    Frame.prototype.updateWatchers = function crossfireClient_watchers_update() {

        if (this.isCurrent && this.context.isCurrent) {
            if ($watchExpressions.hasClass("expanded")) {
                WatchExpression.updateAll();
            }
            if (this.context.hasOwnProperty('breakType')) {
                // TODO: update scopes while their handle is known
                if (this.hasOwnProperty('scopesData')) {
                    //this.render();
                }
                //this.updateScopes();
                
            }
        }

        $watchersContainer.removeClass('waf-disabled');

    };
    */

    if (Debugger.getScopes === undefined) {

        /**
         * Ask for the handle of a all scopes
         *
         * <p><em>scopes crossfire command</em></p>
         *
         * @method getScopes
         * @param {String} contextId
         * @param {Number} frameNumber
         */
        Debugger.getScopes = function crossfireClient_getScopes(contextId, frameNumber) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            var
                scopeReceivedEvent;

            window.console.warn(Debugger.iframe + '> FAKE getScopes');

            scopeReceivedEvent = {
                type: 'scopesreceived',
                command: 'scope',
                context_id: contextId,
                request_seq: 0,
                seq: 1,
                body: {
                    // context_id: contextId,
                    frameIndex: frameNumber,
                    scopes: {
                        1: {
                            index: 1,
                            object: {
                                handle: -1,
                                type: 'ref'
                            }
                        },
                        0: {
                            index: 0,
                            object: {
                                handle: -2,
                                type: 'ref'
                            }
                        }

                    }
                }
            };/*
            if (frameNumber === 0) {
                scopesReceivedEvent.body.object.handle = 0;
            }*/

            Debugger.dispatchEvent(scopeReceivedEvent);

        };
    }






    /*
     *  SET SORT BY COLUMN HANDLERS
     */
    /*
    function crossfireClient_watchers_onclick_nameColumn(mouseEvent) {

        mouseEvent.preventDefault();

        if (!Debugger.currentContext.hasOwnProperty('frames')) {
            return false;
        }

        if (config.sortBy === 'name') {
            config.sortOrder *= -1;
        } else {
            config.sortBy = 'name';
        }
        crossfireClient_watchers_update({contextId: Debugger.currentContext.id});
        return false;
    }
    

    function crossfireClient_watchers_onclick_typeColumn(mouseEvent) {
        
        mouseEvent.preventDefault();

        if (!Debugger.currentContext.hasOwnProperty('frames')) {
            return false;
        }

        if (config.sortBy === 'type') {
            config.sortOrder *= -1;
        } else {
            config.sortBy = 'type';
        }
        crossfireClient_watchers_update({contextId: Debugger.currentContext.id});
        return false;
    }
    */


    /*
    $columnHeads.children().slice(2, 3).click(
        function crossfireClient_watchers_valueColumnClick(mouseEvent) {
            if (config.sortBy == 'value') {
                config.sortOrder *= -1;
            } else {
                config.sortBy = 'value';
            }
            crossfireClient_updateWatchers({contextId: Debugger.currentContext.id});
        }
    );
    */


    // 29090109443853949

    /*
     *  MANAGE TOGGLE GLOBALY
     */

    /**
     * crossfireClient_watchers_onclick_expander
     *
     * @private
     * @event crossfireClient_watchers_onclick_expander
     * @param {Event} mouseEvent
     **/
    function crossfireClient_watchers_onclick_expander(mouseEvent) {

        var
            $row,
            obj,
            uuid,
            path,
            level,
            indent,
            currentContext;

        //window.console.info(Debugger.iframe + '> crossfireClient_watchers_onclick_expander', mouseEvent);

        mouseEvent.preventDefault();
        currentContext = Debugger.currentContext;

        $row = $(mouseEvent.target).parent().parent();
        uuid = $row[0].id;

        //window.console.info(Debugger.iframe + '> crossfireClient_watchers_onclick_expander - $row, objectOwners:', $row, objectOwners);

        path = $row.data('path');
        obj = objectOwners[path];

        if ($row.hasClass("collapsed")) {

            // Object properties
            $row.expand();

            // already loaded
            if ($contentWatchers.find('.child-of-' + uuid).length > 0) {
                return;
            }

            // Properties of an object

            if (!$row.hasClass('subsection')) {

                indent = parseInt($row.find('td').css('padding-left'), 10);
                $row[0].insertAdjacentHTML(
                    'afterend',
                    Mustache.to_html(
                        templates.watchersPropertiesLoading,
                        {
                            scope: uuid,
                            indent: indent + config.indent,
                            indentExpand: indent,
                            indentBackgroundPosition: indent - config.indent
                        }
                    )
                );
                
                obj.handle = $row.data('handle');

                expandedObjects[path] = obj;

                currentContext.currentFrame.getObjectProperties(obj);

                return;

            }

            // Watch expressions section

            if (uuid === 'watchExpressions') {

                if ($watchExpressions.currenContext !== currentContext && $watchExpressions.stepIndex !== currentContext.stepIndex) {
                    WatchExpression.updateAll();
                }

                return;

            }

            // Scopes sections
            expandedObjects[path] = $row;
            obj.getVariables();


        } else {

            // TODO: remove this hack
            // We shouldn't need to remove manually the 'expanded' class

            $row.collapse().removeClass('expanded');

            if ($row.hasOwnProperty('$children')) {
                $row.$children.hide();
            } else {
                window.console.warn(Debugger.iframe + '> crossfireClient_watchers_toggle_objNode -> $row.$children undefined');
            }

            if ($row.hasOwnProperty('$rows')) {
                $row.$rows.hide();
            } else {
                window.console.warn(Debugger.iframe + '> crossfireClient_watchers_toggle_objNode -> $row.$rows undefined');
            }

            delete expandedObjects[path];
        }

    }


  

    /**
     * unreferenceOwners
     *
     * @private
     * @event unreferenceOwners
     * @param {Object} owner
     **/
    function crossfireClient_watchers_unreferenceOwners(owner) {
        if (owner.properties) {
            owner.properties.forEach(crossfireClient_watchers_unreferenceOwners);
        }
        if (owner.path) {
//            $('.child-of-' + $currentWatchExpNode.attr('id')).empty().remove();
            $contentWatchers.filter('tr[data-path=' + owner.path + ']');
            delete objectOwners[owner.path];
        }
        delete owner.properties;
    }


    /**
     * remove_watchExpression_submit
     *
     * @private
     * @event remove_watchExpression_submit
     * @param {Event} event
     **/
    function crossfireClient_watchers_onsubmit_removeWatchExpressionForm(event) {

        var
            $currentWatchExpNode,
            currentWatchExpPath,
            currentWatchExp;

        //window.console.info(Debugger.iframe + '> crossfireClient_watchers_onsubmit_removeWatchExpressionForm', event);

        try {

            $currentWatchExpNode = $(event.target).parent().parent().parent();
            currentWatchExpPath = $currentWatchExpNode.data('path');
            currentWatchExp = watchExpressions[currentWatchExpPath];
            
            currentWatchExp.remove();

        } catch (e) {
            alert('BUG: ' + JSON.stringify(e));
        }

        return false;

    }


    /**
     * crossfireClient_watchers_onsubmit_newExpressionForm
     *
     * @private
     * @event crossfireClient_watchers_onsubmit_newExpressionForm
     * @param {Event} event
     **/
    function crossfireClient_watchers_onsubmit_newExpressionForm(event) {

        var
            target,
            newExpression,
            path,
            watchExpObj,
            html,
            $empty;

        //window.console.info(Debugger.iframe + '> crossfireClient_watchers_onsubmit_newExpressionForm', event);
        event.preventDefault();

        try {

            target = event.target;
            newExpression = target.newExpression.value;
            target.newExpression.value = "";

            if (newExpression === '') {

                return false;

            }
            
            
            path = '(' + newExpression.replace(/'/g, "\\'").replace(/"/g, "'") + ')';

            if (objectOwners.hasOwnProperty(path)) {

                watchExpObj = objectOwners[path];

            } else {

                watchExpObj = new WatchExpression(newExpression, path);
                
                if (watchExpressions.length === 1) {
                    $empty = $watchExpressions.$empty;
                    $watchExpressions.$empty = $watchExpressions.$empty.detach();
                }

                if ($watchExpressions.hasClass('collapsed')) {
                    $watchExpressions.first().find('.expander').click();
                }

                document.location.href = "#" + watchExpObj.uuid;

            }

            watchExpObj.update();

        } catch (e) {
            window.console.error('BUG', e);
            alert('An unexpected error happenned:' + JSON.stringify(e));
        }

        return false;

    }


    
    sorters = {

        /**
         * sortProperties
         *
         * @private
         * @method sortProperties
         * @param {String} elem1
         * @param {String} elem2
         * @return {Number}
         **/
        sortProperties: function crossfireClient_watchers_sortProperties(elem1, elem2) {

            var
                sortOrder;

            sortOrder = config.sortOrder;

            if (elem1 < elem2) {
                return -1 * sortOrder;
            }
            if (elem1 > elem2) {
                return sortOrder;
            }
            // a must be equal to b
            return 0;
        },

        /**
         * sortPropertiesAsIndexes
         *
         * @private
         * @method sortPropertiesAsIndexes
         * @param {String} elem1
         * @param {String} elem2
         * @return {Number}
         **/
        sortPropertiesAsIndexes: function crossfireClient_watchers_sortPropertiesAsIndexes(elem1, elem2) {

            return (elem1 - elem2) * config.sortOrder;

        }
    };

    sorters.byname = {
        asName: function crossfireClient_watchers_sortPropertiesByName_asNames(elem1, elem2) {
            return sorters.sortProperties(elem1, elem2);
        },
        asIndex: function crossfireClient_watchers_sortPropertiesByName_asIndexes(elem1, elem2) {
            return sorters.sortPropertiesAsIndexes(elem1, elem2);
        }
    };



    /*
     *  WATCH EXPRESSIONS
     */


    

   

    /*
     * EVENT LISTENERS
     */

    

    function crossfireClient_onstackready_watchersListener(event) {

        var
            context,
            frame;

        //window.console.info(Debugger.iframe + '> crossfireClient_onstackready_watchersListener', event);

        context = contexts['#' + event.context_id];
        //if (context.isCurrent) {
        // It should quite always be current unless the stack was heavy and the user changed of context
        frame = context.currentFrame;
        frame.createScopes();
        frame.renderScopes();
        //}

        /*
        if (!context.isCurrent) {
            window.console.log('received a stack ready event of a context which is not the current one');
        } else {
            //context.$watchers = crossfireClient_watchers_createFrameWatchers(context, context.currentFrame);
            context.updateWatchers(event);
        }
        */
       WatchExpression.updateAll();

    }


    function crossfireClient_onframechange_watchersListener(event) {
        
        var
            context,
            frame,
            $watchers;

        //window.console.info(Debugger.iframe + '> crossfireClient_onframechange_watchersListener', event);

        context = contexts['#' + event.context_id];
        if (context === undefined) {
            window.console.warn('context do not exists any more', event);
            // TODO: should we hide current watchers ? as a setting ?
            return;
        }
        
        if (Debugger.hasOwnProperty('previousContext') && Debugger.previousContext !== context) {
            $('#' + Debugger.previousContext.currentFrame.scopesTBodyId).hide();
        }
        if (context.hasOwnProperty('previousFrame')) {
            $('#' + context.previousFrame.scopesTBodyId).hide();
        }

        if (context.breakType === undefined) {
            // running context has no stack and no real currentFrame
            return;
        }

        if (!context.hasOwnProperty('frames')) {
            // stack not yet loaded
            context.loadStack();
            return;
        }

        frame = context.currentFrame;
        $watchers = $('#' + frame.scopesTBodyId);

        //window.console.log($newWatchers, 'data attr:', $newWatchers.attr('data-stepIndex'), 'stepIndex:', currentContext.stepIndex);
        if ($watchers.length > 0 && Number($watchers.data('stepIndex')) === context.stepIndex) {
            $watchersEmpty.hide();
            $watchers.show();
        } else {
            frame.getScopes();
            //crossfireClient_watchers_updateAllScopes(context, frame);
        }

        WatchExpression.updateAll();

    } 
    
	function crossfireClient_oncontextdestroyed_watchersListener(event) {
 		WatchExpression.updateAll();
	}



    function crossfireClient_onresume_watchersListener(event) {
        // DISABLE WATCHERS PANEL
        //window.console.info(Debugger.iframe + '> crossfireClient_onresume_watchersListener', event);
    }



    function crossfireClient_onenablepanels_watchersListener(event) {

        //window.console.info(Debugger.iframe + '> crossfireClient_onenablepanels_watchersListener', event);

        if (event.enabled) {
            $watchersContainer.removeClass('waf-disabled');
            $watchersContainer.find('input').removeProp('disabled');
        } else {
            $watchersContainer.addClass('waf-disabled');
            $watchersContainer.find('input').prop('disabled', 'true');
        }

    }


    function crossfireClient_watchers_onblur_newExpressionInput(event) {
        $(event.target.form).submit();
    }
    
	function crossfireClient_watchers_refresh_remove() {
		$(".removeExpression").css("right", "-"+$("#contentWatchers").parents("div.waf-content").scrollLeft()+"px");
	}

	
    
    /* INITIALISATION */

    objectOwners = {};
    expandedObjects = Debugger.expandedObjects;
    watchExpressions = [];
    watchExpressionsByName = {};
    subSections = [];
    
    
    Debugger.WatchExpression = WatchExpression;
    Debugger.ServerObject = ServerObject;
    Debugger.Scope = Scope;
    Debugger.Frame = Frame;

    evalSequences = Debugger.evalSequences;
    if (typeof evalSequences === 'undefined') {
        evalSequences = [];
    }

    $contentWatchers = $("#contentWatchers");
    $newExpressionForm = $('#newExpressionForm');
    $watchersEmpty = $('#watchers_contextEmpty');

    if ($contentWatchers && $contentWatchers.length > 0) {
        $contentWatchers.treeTable(config);
    }
    $watchersContainer = $contentWatchers.parent();
    $columnHeads = $contentWatchers.children('thead').children().first();
    $watchers = $contentWatchers.children('tbody').last();
    $currentWatchers = $watchers.first();
	
    // Init watch expessions section
    $watchExpressions = crossfireClient_watchers_initSubSection('watchExpressions', 'Watch Expression');
    $watchExpressions.$empty = $('#watchExpressionsEmpty');



    /* BIND EVENT HANDLERS */


    // remove expression
    $watchExpressions.$body.delegate('form[name=form-watchExpression-remove]', 'submit', crossfireClient_watchers_onsubmit_removeWatchExpressionForm);
    // expand an object or a sectoin
    $contentWatchers.delegate('.expander', 'click', crossfireClient_watchers_onclick_expander);
    
	//replace remove icon on scroll
	$("#contentWatchers").parents("div.waf-content").scroll(function (event) {
		crossfireClient_watchers_refresh_remove();
	});
    
    // sort columns
    //$columnHeads.children().slice(0, 1).click(crossfireClient_watchers_onclick_nameColumn);
    //$columnHeads.children().slice(1, 2).click(crossfireClient_watchers_onclick_typeColumn);

    // new expression
    $newExpressionForm.submit(crossfireClient_watchers_onsubmit_newExpressionForm);
    $newExpressionForm.find('input[type=text]').blur(crossfireClient_watchers_onblur_newExpressionInput);


    if ($watchersContainer.prop('id') !== 'hiddenComponents') {
        Debugger.addEventListener('stackready', crossfireClient_onstackready_watchersListener);
        Debugger.addEventListener('framechange', crossfireClient_onframechange_watchersListener);
        Debugger.addEventListener('contextchange', crossfireClient_onframechange_watchersListener);
        Debugger.addEventListener('scopesreceived', Frame.onscopesreceived);
        Debugger.addEventListener('resume', crossfireClient_onresume_watchersListener);
        Debugger.addEventListener('contextdestroyed', crossfireClient_oncontextdestroyed_watchersListener);
    } else {
        Debugger.addEventListener('stackready', tools.ignore);
        Debugger.addEventListener('framechange', tools.ignore);
        Debugger.addEventListener('scopesreceived', tools.ignore);
        Debugger.addEventListener('resume', tools.ignore);
        Debugger.addEventListener('enablepanels', tools.ignore);
    }

}; // End Watchers

