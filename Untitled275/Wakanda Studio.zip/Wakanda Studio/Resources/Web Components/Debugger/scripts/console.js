/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, browser: true, maxerr: 50, indent: 4 */

/*global WAF, waStudio, $, Mustache */


/**
 * MANAGE CONSOLE
 *
 * @static
 * @shared
 * @method manageConsole
 */
waStudio.Debugger.manageConsole = function crossfireClient_manageConsole() {

    var
        Debugger,
        console,
        Console,
        config,
        tools,
        $contentConsole,
        $consoleContainer,
        $consoleTBody,
        objectOwners,
        evalSequences,
        DEBUG,
        cmdHistory,
        cmdCursor,
        KEYUP_CODE,
        KEYDOWN_CODE;
    

    Debugger = waStudio.Debugger;

    DEBUG = Debugger.DEBUG && true;

    tools = Debugger.tools;
    
    Console = console = waStudio.console = waStudio.Console = {};
    
    config = Debugger.config.console = {
        //delegatedExpand: true,
        indent: 19,
        quote: ''
    };
    
    objectOwners = {};
    evalSequences = Debugger.evalSequences;

	cmdHistory = [];
	cmdCursor = -1;
	
	KEYUP_CODE = 38;
	KEYDOWN_CODE = 40;
	
	displayHistorySize = 250;


    Debugger.events.push(
        'consolelog',
        'consoledebug',
        'consolewarn',
        'consolewarning',
        'consoleerror',
        'message'
    );
    
    Debugger.templates.push(
        'consoleMessage',
        'consoleLogRun',
        'previewInLine'
    );

    $contentConsole = $("#contentConsole");
    $consoleContainer = $contentConsole.parent();
    $consoleTBody = $contentConsole.children().filter('tbody');
    
    
    /**
     * @class Command
     *
     * @constructor
     * @param {String} command
     **/
    function Command(command) {

        this.name = command;
        this.expression = command;
    
    }

    /**
     * @method onevaluated
     * @param {Event} event
     **/
    Command.prototype.onevaluated = function crossfireClient_Command_onevaluated(event) {

        var
            data,
            messageEvent;

        //window.console.info(Debugger.iframe + '> crossfireClient_onevaluated_consoleListener - On Command Evaluate: ', event);

        data = event.body;

        messageEvent = {
            format: "crossfireLike",
            data: [
                data
            ],
            webArea: Debugger.iframe //,
            //stack: tools.generateCallStack(Command.prototype.onevaluated, [])
        };
        
        evalSequences.push(messageEvent);
        messageEvent.request_seq = evalSequences.length;
        messageEvent.type = (data.type === 'exception') ? 'consoleerror' :  'consolelog';

        window.console.log(Debugger.iframe + '> Dispatching message event', messageEvent, 'from crossfireClient_onevaluated_consoleListener :');
        Debugger.dispatchEvent(messageEvent);

    };
    
    
    Command.prototype.addToHistory = function crossfireClient_Command_addToHistory() {
    	
    	cmdHistory.unshift(this.expression);
    	cmdCursor = -1;
		
    }


    /**
     * crossfireClient_console_submitNewCommand
     *
     * @event crossfireClient_console_submitNewCommand
     * @param {Event} event
     **/
    function crossfireClient_console_submitNewCommand(event) {
    
        var
            target, 
            newCommand,
            sequence,
            currentContext;

        event.preventDefault();
        
        try {
            
            target = event.target;

			if(target.newCommand.value !== "") {
				
	            newCommand = new Command(target.newCommand.value);
	            newCommand.addToHistory();
	
	            target.newCommand.value = "";
	            
	            $consoleTBody.append(
	                Mustache.to_html(Debugger.templates.consoleLogRun, newCommand)
	            );
	            console_log_history_manage();
	        	
	            if(Debugger.currentContext.currentFrame.evaluate !== undefined) {
		            Debugger.currentContext.currentFrame.evaluate(newCommand);
		        } else {
		        	window.console.info('BUG : Debugger have not the correct context', Debugger.currentContext);
		        }
			}
            
        } catch (e) {
            // clone the error before log
            window.console.error('BUG', JSON.parse(JSON.stringify(e)));
        }
        
        return false;
        
    }
    
    function crossfireClient_oncontextchange_consoleListener(event) {
    	var i,
    		contextIndex,
    		contextNotFound;
    	
    	window.console.info(Debugger.iframe + '> console On "' + event.type + '":', event, Debugger.contexts);
    	
    	i = 0;
    	contextNotFound = Debugger.contexts[i] !== undefined;
		
    	while(contextNotFound) {
    		if(Debugger.contexts[i].id == event.context_id) {
    			
    			contextNotFound = false;
    			Debugger.contexts[""+i].isCurrent = true;
    			Debugger.currentContext = Debugger.contexts[""+i];
    			
    			window.console.info(Debugger.iframe + '> console select Current "' +  '":', Debugger.contexts[""+i], Debugger.currentContext, new Date());
        		Debugger.updateMenus();
    		}
    		
    		i++;
    		contextNotFound = (contextNotFound && Debugger.contexts[i] !== undefined)
    	}
    }
    
    function crossfireClient_console_manageShortcut(event) {
    	
    	
    	if(event.keyCode === KEYUP_CODE || event.keyCode === KEYDOWN_CODE) {
    		// arrow up, arrow down
    		crossfireClient_console_getHistory(event);
    		
    	} else if(event.ctrlKey === true && event.charCode === 12) {
    		//Ctrl + l
    		crossfireClient_console_clear(event);
    	}
    	
    	return false;
    }
    
	function crossfireClient_console_getHistory(event) {
		
    	var cmd,
    		action;
    		
		if(cmdHistory.length > 0) {
			
			event.preventDefault();
			cmd = "";
			// if KEYUP action = 1 and if KEYDOWN action = -1
	    	// KEYUP_CODE = 38 & KEYDOWN_CODE = 40 => 39 is middle of those keys codes
			action = 39 - event.keyCode;
			
			if(cmdHistory.length > (cmdCursor + action) && (cmdCursor + action) >= 0) {
				
				cmdCursor = cmdCursor + action;
				cmd = cmdHistory[cmdCursor];
				
			} else if(cmdCursor === 0) {
				
				cmdCursor = cmdCursor + action;
			}
			
			if(cmdHistory.length > (cmdCursor + action) || cmd !== "") {
				event.target.value = cmd;
			}
    		event.stopPropagation();
		}
	}
        
    /**
     * crossfireClient_console_clear
     *
     * @event crossfireClient_console_clear
     * @param {Event} event
     **/
    function crossfireClient_console_clear(event) {

        //window.console.info(Debugger.iframe + '>crossfireClient_console_clear :', event);
        
        $consoleTBody.children().empty().remove();
        
    }
    
    
    // MANAGE MESSAGE EVENT

    /**
     * crossfireClient_onmessage_consoleListener_mapData
     *
     * @event crossfireClient_onmessage_consoleListener_mapData
     * @param {Mixed} value
     **/
    function crossfireClient_onmessage_consoleListener_mapData(value) {

        var
            result,
            owner,
            html;

        //window.console.info(Debugger.iframe + '> crossfireClient_onmessage_consoleListener_mapData', value);
        /*
        if (typeof data.result === 'object') {
            Debugger.tools.createPreviewLevel1(expression, data, objectOwners, config);
        } else {
            expression.value = data.result;
            expression.isScalar = true;
            expression.type = typeof data.result;
        }
        */

        result = {
            comma: ', '
        };
        owner = {
        	level: 0,
        	//frame: Debugger.contexts['#' + value.context_id].currentFrame,
        	path: 'CONSOLE',
        	domId: 'contentConsole'
        };
        //value = {result: value};

        result = tools.createPreviewLevel1(result, value, owner, config);
        result.comma = ", ";

        //window.console.debug('crossfireClient_onmessage_consoleListener_mapData - result:', result);

        html = Mustache.to_html(Debugger.templates.previewInLine, result);

        window.console.debug('crossfireClient_onmessage_consoleListener_mapData - html:', html);


        return html;
    }

    /**
     * crossfireClient_onmessage_consoleListener
     *
     * @event crossfireClient_onmessage_consoleListener
     * @param {Event} event
     **/
    function crossfireClient_onmessage_consoleListener(event) {
        
        var i,
            list,
            data,
            message,
            eventDatas;
		
		eventDatas = [];
		
		if(event.dataGrouped !== undefined && event.dataGrouped == true) {
			eventDatas = event.data.data;
		} else {
			eventDatas.push(event.data);
		}
		
		for(i = 0; i < eventDatas.length; i++) {
	        //window.console.debug('crossfireClient_onmessage_consoleListener', event);
			
	        if (event.format === 'crossfireLike') {
	            data = eventDatas[i].map(crossfireClient_onmessage_consoleListener_mapData);
	        } else {
	            data = eventDatas[i].map(tools.toCrossFireValue);
	            data = data.map(crossfireClient_onmessage_consoleListener_mapData);
	        }
	        
	        message = {
	            html: data.join(' ')
	        };
	
	        if (event.type === 'message') {
	            message.errorLevel = event.level.toLowerCase();
	        } else {
	            message.errorLevel = event.type.substr(7);
	        }
	
	        if (message.errorLevel === 'warn') {
	            message.errorLevel = 'warning';
	        }
	
	        message.title = [];
	
	        if (event.hasOwnProperty('project')) {
	            message.title.push('[' + event.project + ']');
	        }
	        if (event.hasOwnProperty('date')) {
	            message.title.push(event.date);
	        }
	
	        message.title = message.title.join(' ');
	
	        if (event.hasOwnProperty('line')) {
	            message.link = {
	                fullPath: event.fullPath,
	                fileName: event.fileName,
	                line: event.line
	            };
	        } else {
	            message.colspan = 2;
	        }
	
	        list = {
	            messages: [
	                message
	            ],
	            comma: ", "
	        };
	        
	        $consoleTBody.append(
	            Mustache.to_html(Debugger.templates.consoleMessage, list)
	        );
	        
	        /*
	        $consoleTBody.append(
	            '<tr><td>' + event.data.join(' ') + '</td></tr>\n'
	        );
	        */
		}
		console_log_history_manage();
    }

	function console_log_history_manage() {
		var tBodyChildrenLength,
		i;
		
		tBodyChildrenLength = $consoleTBody[0].children.length;
		if(tBodyChildrenLength > displayHistorySize) {
			for(i = 0; i < (tBodyChildrenLength - displayHistorySize); i++) {
				$($consoleTBody[0].children[i]).remove();
			}
		}
		
        $consoleTBody.scrollTop($consoleTBody[0].scrollHeight);
	}


    function waStudio_Console_serializeArgument(arg) {

        //window.console.info(Debugger.iframe + '> waStudio_Console_serializeArgument :', arg);

        return JSON.parse(JSON.stringify(arg));

    }

    
    /**
     * log a message
     *
     * @method log
     * @param {String|Object} message*
     */
    console.log = function waStudio_Console_log(message) {

        var
            event;

        //window.console.info(Debugger.iframe + '> waStudio_Console_log :', message);

        event = {
            type: 'consolelog',
            data: Array.prototype.map.call(arguments, waStudio_Console_serializeArgument)
        };

        window.console.log(Debugger.iframe + '> Dispatching message event', event, 'from waStudio_Console_log', message);
        Debugger.dispatchEvent(event);

    };



    /**
     * log a debug message
     *
     * @method log
     * @param {String|Object} message*
     */
    console.debug = function waStudio_Console_debug(message) {

        var
            event;
            
        //window.console.info(Debugger.iframe + '> waStudio_Console_debug :', message);

        event = {
            type: 'consoledebug',
            data: Array.prototype.slice.apply(arguments, [0])
        };

        window.console.log(Debugger.iframe + '> Dispatching message event', event, 'from waStudio_Console_debug :', message);
        Debugger.dispatchEvent(event);

    };
    
    
    
    /**
     * log an informative message
     *
     * @method info
     * @param {String|Object} message*
     */
    console.info = function waStudio_Console_info(message) {

        var
            event;

        //window.console.info(Debugger.iframe + '> waStudio_Console_info :', message);

        event = {
            type: 'consoleinfo',
            data: Array.prototype.slice.apply(arguments, [0])
        };

        window.console.log(Debugger.iframe + '> Dispatching message event', event, 'from waStudio_Console_info :', message);
        Debugger.dispatchEvent(event);

    };
    
    

    /**
     * log a warning message
     *
     * @method warn
     * @param {String|Object} message*
     */
    console.warn = function waStudio_Console_warn(message) {

        var
            event;

        //window.console.info(Debugger.iframe + '> waStudio_Console_warn :', message);

        event = {
            type: 'consolewarn',
            data: Array.prototype.slice.apply(arguments, [0])
        };

        window.console.log(Debugger.iframe + '> Dispatching message event', event, 'from waStudio_Console_warn :', message);
        Debugger.dispatchEvent(event);

    };
    
    
    
    /**
     * log an error message
     *
     * @method error
     * @param {String|Object} message*
     */
    console.error = function waStudio_Console_error(message) {

        var
            event;

        //window.console.info(Debugger.iframe + '> waStudio_Console_error :', message);

        event = {
            type: 'consoleerror',
            data: Array.prototype.slice.apply(arguments, [0])
        };

        window.console.log(Debugger.iframe + '> Dispatching message event', event, 'from waStudio_Console_error :', message);
        Debugger.dispatchEvent(event);

    };
    
    
    /*
     * 
    Console.flushBuffer = Console.flushBuffer || function Console_flushBuffer() {
        //Console.info('Context created');
    };
    */

    
    // ASSIGN EVENT HANDLERS
    
    $('#actionConsoleClear').click(crossfireClient_console_clear);
    $('#newCommandForm').submit(crossfireClient_console_submitNewCommand);
    $('#newCommandForm').keyup(crossfireClient_console_manageShortcut);
    
    $consoleTBody.delegate('.waf-debug-link', 'click', Debugger.tools.openFile_click);


    if ($consoleContainer.prop('id') !== 'hiddenComponents') {
        Debugger.addEventListener('consolelog', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('consoledebug', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('consoleinfo', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('consolewarn', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('consolewarning', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('consoleerror', crossfireClient_onmessage_consoleListener);
        Debugger.addEventListener('message', crossfireClient_onmessage_consoleListener);
    	Debugger.addEventListener('contextchange', crossfireClient_oncontextchange_consoleListener);
    	Debugger.addEventListener('currentcontextchange', crossfireClient_oncontextchange_consoleListener);
    } else {
        Debugger.addEventListener('consolelog', tools.ignore);
        Debugger.addEventListener('consoledebug', tools.ignore);
        Debugger.addEventListener('consolewarn', tools.ignore);
        Debugger.addEventListener('consolewarning', tools.ignore);
        Debugger.addEventListener('consoleerror', tools.ignore);
        Debugger.addEventListener('message', tools.ignore);
    	Debugger.addEventListener('currentcontextchange', tools.ignore);
    }
    
};

