/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
 * @module Debugger
 * @submodule Debugger.tools
 */

/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, strict: true */

// devel: true // "Assume console, alert, ..." not supported by JSLint plugin
// immed: true // "Require parens around immediate invocations" not supported by JSLint plugin

/*global WAF, waStudio, $, Mustache, window, alert */

/**
 *  LOAD TOOLS MODULE
 *
 * @static
 * @method loadTools
 * @returns {Object}
 **/
waStudio.Debugger.loadTools = function crossfireClient_loadTools() {

    // "use strict";

    var
        toolsMod,
        clearProperties,
        Debugger,
        templates,
        expandedObjects,
        DEBUG;

    toolsMod = {
        ignore: function crossfireClient_tools_ignore() {}
    };
    
    
    Debugger = waStudio.Debugger;
    DEBUG = Debugger.DEBUG && true;

    templates = Debugger.templates;
    expandedObjects = Debugger.expandedObjects;


    function waStudio_tools_toCrossFireValue_forEachObjectProperty(propertyName) {

        window.console.debug(Debugger.iframe + '> waStudio_tools_toCrossFireValue_forEachObjectProperty ', propertyName);

        if (propertyName !== '__proto__') {
            this.outValue.preview[propertyName] = toolsMod.toCrossFireValue(this.inValue[propertyName]);
        }
    }
    /*
    function waStudio_tools_toCrossFireValue_forEachArrayElement(elementValue, elementIndex) {

        window.console.debug(Debugger.iframe + '> waStudio_tools_toCrossFireValue_forEachArrayElement ', propertyName);

        this.outValue.value[elementIndex] = toolsMod.toCrossFireValue(elementValue);
    }
    */

    /**
     * crossfireClient_tools_toCrossFireValue
     *
     * @static
     * @method toCrossFireValue
     * @param {Mixed} inValue
     **/
    toolsMod.toCrossFireValue = function crossfireClient_tools_toCrossFireValue(inValue) {

        var
            outValue;

        switch (typeof inValue) {

        case 'undefined':
            outValue = "undefined";
            break;

        case 'null':
            outValue = {
                type: "null"
            }
            break;

        case 'boolean':
            outValue = {
                type: 'boolean',
                value: inValue
            };
            break;

        case 'number':
            outValue = {
                type: 'number',
                value: inValue
            };
            if (isNaN(inValue)) {
                outValue.value = 'NaN';
            } else if (inValue === Infinity) {
                outValue.value = 'Infinity';
            } else if (inValue === -Infinity) {
                outValue.value = '-Infinity';
            }

            break;

        case 'string':
            outValue = {
                type: 'string',
                value: inValue
            };
            break;

        case 'function':
            outValue = {
                type: 'function',
                value: 'function()'
            };
            break;

        default:
            if (inValue === null) {
                outValue = {
                    type: "null"
                }
            } else {
                outValue = {
                    'type': 'object',
                    'class': (inValue instanceof Array) ? 'Array' : 'Object',
                    'preview': {}
                };
                Object.getOwnPropertyNames(inValue).forEach(
                    waStudio_tools_toCrossFireValue_forEachObjectProperty,
                    {
                        inValue: inValue,
                        outValue: outValue
                    }
                );
            }

        }

        return outValue;
    };

    /**
     * htmlEntitiesDecode
     *
     * @static
     * @param {String} htmlEncodedText
     * @return String
     **/
    function htmlEntitiesDecode(htmlEncodedText) {
        var
            option;

        option = document.createElement('option');
        option.innerHTML = htmlEncodedText;
        return option.value;
    }
    toolsMod.htmlEntitiesDecode = htmlEntitiesDecode;

    /**
     * htmlEntitiesEncode
     *
     * @static
     * @param {String} text
     * @return String
     **/
    function htmlEntitiesEncode(text) {
        var
            option;

        option = document.createElement('option');
        option.value = text;
        return option.innerHTML;
    }
    toolsMod.htmlEntitiesEncode = htmlEntitiesEncode;

    /**
     * openFile_click
     *
     * @static
     * @param {MouseEvent} mouseEvent
     **/
    toolsMod.openFile_click = function crossfireClient_tools_openFile_click(mouseEvent) {

        var
            target,
            urlObj,
            fullPath,
            line;

        target = mouseEvent.target;
        urlObj = target.href.split('#line=');
        fullPath = target.title;
        line = urlObj[1];

        window.console.debug(Debugger.iframe + '> Try to open File: "' + fullPath + '" at line ' + line);

        try {
            waStudio.openFile(fullPath, line);
        } catch (e) {
            window.console.error(e);
        }
        mouseEvent.preventDefault();
        return false;

    };


    /**
     * Create preview level 2 (preview on property or element shown in preview)
     *
     * @private
     * @static
     * @method createPreviewLevel2
     * @param {String} propertyName
     * @param {Object} propertyData
     * @return {Object}
     **/
    toolsMod.createPreviewLevel2 = function crossfireClient_tools_createPreviewLevel2(propertyName, propertyData) {

        var
            result,
            type,
            property;


        property = propertyData[propertyName];

        if (property === null || property === undefined) {
            type = String(property);
        } else if (typeof property === 'object' && property.hasOwnProperty('type')) {
            type = property.type;
        } else if (typeof property === 'object' && property.hasOwnProperty('className')) {
            type = 'object';
        } else {
            type = typeof property;
        }

        switch (type) {

        case 'object':

            //window.console.log('crossfireClient_tools_createPreviewLevel2', propertyName, preview);

            if (!property.hasOwnProperty('className')) {
                property.className = 'Object';
            }

            switch (property.className) {
            case 'function':
            case 'Function':
                if (property.hasOwnProperty('name') && (property.name !== '')) {
                    result = property.name + '()';
                } else {
                    result = 'function()';
                }
                break;

            case 'Array':
                result = 'Array(' + (property.hasOwnProperty('length') ? property.length : '') + ')';
                break;

            case 'Date':
                type = 'date';
                result = new Date(property.preview).toISOString().substr(0, 10);
                break;

            default:
                result = property.className + ' {}';
            }
            break;

        case 'function':
            result = (property.name || 'function') + '()';
            break;

        case 'string':
            result = '"' + ((typeof property === 'object') ? property.value : property) + '"';
            break;

        case 'null':
            result = 'null';
            break;

        case 'undefined':
            result = 'undefined';
            break;

        default:
            result = String((typeof property === 'object') ? property.value : property);
        }

        return {
            name: propertyName,
            type: type,
            value: result
        };

    };


    clearProperties = [
        'isError',
        'isDate',
        'isFunction',
        'isArray',
        'isObject',
        'isScalar',
        'nbMore',
        'displayName',
        'message',
        'highlight', 
        'namePartBegin', 
        'namePartHighlightBegin', 
        'namePartHighlightEnd', 
        'namePartEnd'
    ];



    /**
     * Delete the named property from "this"
     *
     * @method crossfireClient_tools_deleteProperty
     * @param {String} propertyName
     **/
    function crossfireClient_tools_deleteProperty(propertyName) {
        if (this.hasOwnProperty(propertyName)) {
            delete this[propertyName];
        }
    }

    function crossfireClient_tools_createPreviewLevel1_mapFunctionParams(param) {
        return {
            value: param
        };
    }

    function crossfireClient_tools_createPreviewLevel1_mapArray(name) {
        return toolsMod.createPreviewLevel2(name, this);
    }

    function crossfireClient_tools_createPreviewLevel1_mapObject(name) {
        return toolsMod.createPreviewLevel2(name, this);
    }

    /**
     * Create preview level 1
     *
     * @method createPreviewLevel1
     * @param {String} element
     * @param {Object} data
     * @param {Object} owner
     * @param {Object} config
     **/
    toolsMod.createPreviewLevel1 = function crossfireClient_tools_createPreviewLevel1(element, data, owner, config) {

        var
            preview,
            //found,
            quote,
            paramIndex,
            maxIndex,
            name,
            result;
            
        //found = element.hasOwnProperty('$rows');
        quote = config.hasOwnProperty('quote') ? config.quote : '"';

        /*
        if (found) {
            clearProperties.forEach(crossfireClient_tools_deleteProperty, element);
        }
        */

        name = element.displayName = element.name;

        /*
        if (data === null || data.result === null) {

            element.type = 'null';
            element.value = preview = 'null';

        } else {
        */
            if (typeof data === 'object') {
                if (data.hasOwnProperty('preview')) {
                    result = data.preview;
                }
                if (data.hasOwnProperty('result')) {
                    result = data.result;
                }
                if (data.hasOwnProperty('value')) {
                    result = data.value;
                }
            }
            preview = result;

            element.type = (data && data.type) || typeof preview;

            if (element.type === 'undefined') {
                element.value = preview = 'undefined';
            } else if (element.type === 'null') {
                element.value = preview = 'null';
            }

            if (data.type === 'exception' || data.className === 'Error') {

                element.isError = true;
                element.previewStyle = 'waf-error';
                if (result !== null && typeof result === 'object') {

                    element.type = result.name || data.className;
                    element.sourceId = result.sourceId;
                    element.message = result.message;
                    element.line = result.line;

                    if (data.result.hasOwnProperty('expressionBeginOffset')) {
                        element.displayName = undefined;
                        element.highlight = true;

                        element.namePartBegin = name.substr(0, result.expressionBeginOffset - 1) || '';

                        element.namePartHighlightBegin = name.substr(
                            result.expressionBeginOffset - 1,
                            result.expressionCaretOffset - result.expressionBeginOffset
                        );

                        element.namePartHighlightEnd = name.substr(
                            result.expressionCaretOffset - 1,
                            result.expressionEndOffset - result.expressionCaretOffset
                        );

                        element.namePartEnd = element.name.substr(result.expressionEndOffset - 1) || '';
                    }
                } else {
                    element.type = typeof data.result;
                    element.message = data.result;
                }

            }

        //}

        element.hasProperties = ['string', 'number', 'boolean', 'null', 'undefined'].indexOf(element.type) === -1;

		element.isArray = false;
		element.isDate = false;
		element.isObject = false;
		element.isFunction = false;
		element.isScalar = false;
		element.isError = false;
		
        if (element.hasProperties) {

            // TODO: use new ServerObject
            element = new Debugger.ServerObject(
                {
                    handle: data.handle,
                    name: name,
                    isWatchExpProperty: element.isWatchExpProperty
            
                },
                owner.frame, //undefined ?
                owner
            );
            //objectOwners[element.path] = element;
            //element.handle = data.handle;

            // Create preview
            if (typeof preview === 'object') { // fix to handle date preview
                element.count = data.count || Object.getOwnPropertyNames(preview).length;
                if (data.count && data.count > Object.getOwnPropertyNames(preview).length) {
                    element.nbMore = data.count - Object.getOwnPropertyNames(preview).length;
                }
            }

            switch (data.className || data['class'] || data.type) {
            case 'Date':
                element.isDate = true;
                element.type = 'Date';
                element.preview = new Date(data.result).toLocaleString();
                break;

            case 'function':
            case 'Function':
                element.isFunction = true;
                element.type = 'Function';
                element.functionName = preview.name;
                maxIndex = data.params && data.params.length;
                if (data.params && data.params.length > 0) {
                    element.params = data.params.map(crossfireClient_tools_createPreviewLevel1_mapFunctionParams);
                    element.params[maxIndex - 1].comma = "";
                } else if (preview.length) {
                    element.params = [];
                    maxIndex = preview.length;
                    if (maxIndex > 0) {
                        for (paramIndex = 0; paramIndex < maxIndex; paramIndex += 1) {
                            element.params[paramIndex] = {
                                value: "arg" + (paramIndex + 1)
                            };
                        }
                        element.params[maxIndex - 1].comma = "";
                    }
                }
                break;

            case 'Array':
                element.isArray = true;
                element.type = 'Array';
                if (preview.hasOwnProperty('length')) {
                    delete preview.length;
                    //element.nbMore -= 1;
                }
                element.preview = Object.getOwnPropertyNames(preview);
                maxIndex = element.preview.length;
                if (maxIndex > 0) {
                    element.preview = element.preview.map(crossfireClient_tools_createPreviewLevel1_mapArray, preview);
                    element.preview[maxIndex - 1].comma = "";
                }
                break;

            default:
                if (!element.isError) {
                    element.isObject = true;
                    element.type = data.className;

                    // TEST WITHOUT SORT
                    //element.preview = Object.getOwnPropertyNames(preview).sort().map(crossfireClient_tools_createPreviewLevel1_mapObject, preview);
                    element.preview = Object.getOwnPropertyNames(preview).map(crossfireClient_tools_createPreviewLevel1_mapObject, preview);

                    maxIndex = element.preview.length;
                    if (maxIndex > 0) {
                        element.preview[maxIndex - 1].comma = "";
                    }
                }
            }

        } else {

            //element.handle = undefined;
            element.level = /*element.level ||*/ owner.level + 1;
            name = name || '<anonymous>';
            
            // TODO: add better path managment
            if (element.path === undefined) {
                console.warn('path undefined');
                element.path = '';
            }
            if (element.path === '') {
                element.path = "['" + name.replace("'", "\\'") + "']";
            } else if (element.ownerDomId !== 'watchExpressions') {
                element.path = /*element.path ||*/ owner.path + "['" + name.replace("'", "\\'") + "']";
            }
            

            element.isScalar = true;
            if (typeof preview === 'object') {
                preview = preview.hasOwnProperty('value') ? preview.value : preview.type;
            }
            element.value = (element.type === "string") ? (quote + preview + quote) : String(preview);
            
        }
        
        
        if (owner.hasOwnProperty('expressionDomId')) {
            element.expressionDomId = owner.expressionDomId;
        }

        return element;
        
    };


    function crossfireClient_tools_propertyAutoExpand(index, element) {
        var
            $element;

        $element = $(element);

        if (expandedObjects.hasOwnProperty($element.data('path'))) {
            $element.find('.expander').click();
        }

    }

    /**
     * createListPreview
     *
     * @static
     * @method createListPreview
     **/
    toolsMod.createListPreview = function crossfireClient_tools_createListPreview(owner, config) {

        var
            list,
            ownerId,
            $owner,
            properties,
            propertyNames,
            $parents;

        ownerId = owner.domId || owner.uuid || owner.id;// || $owner.prop('id');
        properties = owner.propertiesData;
        propertyNames = owner.propertyNames;
        $owner = $('#' + ownerId);

        list = {
            ownerDomId: ownerId,
            colspan: ' colspan="2"',
            removable: false,
            //empty: false,
            comma: ', '
        };

        list.indentExpand = (owner.level + 1) * config.indent;
        list.indent = list.indentExpand + config.indent;
        list.indentBackgroundPosition = list.indentExpand - config.indent;
        list.colorException = (config.colorException !== undefined ? config.colorException : '');

        function crossfireClient_watchers_createListPreview_forEachPropertyName(propertyName, propertyIndex) {

            var
                currentPropertyData,
                propertyValue,
                propertyValueType,
                type,
                preview;

            propertyValue = properties[propertyName];

            propertyValueType = typeof propertyValue;
            type = (propertyValue === null) ? 'null' : propertyValueType;
            if (type === 'object') {
                //type = propertyValue.type;
                type = propertyValue.className || propertyValue.type; // removed evil invisible char....
            }
            
            currentPropertyData = {
                owner: owner,
                domId: ownerId + '-' + owner.stepIndex + '_' + propertyIndex,
                name: propertyName,
                type: type
                //colspan: ' colspan="2"',
                //removable: false
            };

            if (propertyValue === null || (propertyValueType !== 'object' && propertyValueType !== 'function')) {
                preview = {
                    result: propertyValue
                };
            } else {
                preview = propertyValue;
            }
            
            currentPropertyData.isWatchExpProperty = (owner.isWatchExpProperty || owner instanceof Debugger.WatchExpression)
            currentPropertyData = toolsMod.createPreviewLevel1(currentPropertyData, preview, owner, config);
            currentPropertyData.displayName = currentPropertyData.name = propertyName;

            owner.properties.push(currentPropertyData);
            owner.propertiesByName[propertyName] = currentPropertyData;

        }

        propertyNames.forEach(crossfireClient_watchers_createListPreview_forEachPropertyName);

        list.properties = owner.properties;

        $('#' + ownerId + '-Loading').remove();
        $owner[0].insertAdjacentHTML(
            'afterend',
            Mustache.to_html(templates.watcher, list)
        );


        $parents = $owner.parent().find('.child-of-' + ownerId).filter('.parent');

        //$parents.each(crossfireClient_watchers_parentSetRows);

        $parents.each(crossfireClient_tools_propertyAutoExpand);

    };

    toolsMod.generateCallStack = function generateCallStack(func, stack) {
        stack.push(func.name + '(' + /*func.arguments.toString() +*/ ')');
        if (func.caller) {
            toolsMod.generateCallStack(func.caller, stack);
        }
        return stack;
    };

    return toolsMod;
};