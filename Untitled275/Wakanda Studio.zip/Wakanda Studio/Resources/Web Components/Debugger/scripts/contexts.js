/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*global WAF, waStudio, window, $, Mustache */

/*jslint white: true, onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, browser: true */



/**
 *  MANAGE CONTEXTS
 *
 *  and their callstack
 *
 * @static
 * @method manageContexts
 */
waStudio.Debugger.manageContexts = function Debugger_manageContexts() {

    var
        Debugger,
        config,
        templates,
        contexts,
        waitingContexts,
        $contentContexts,
        $nocontext,
        $contextsContainer,
        tools,
        evalSequences,
        waitingFrames,
        DEBUG;


    Debugger = waStudio.Debugger;
    tools = Debugger.tools;
    templates = Debugger.templates;
    evalSequences = Debugger.evalSequences;
    DEBUG = Debugger.DEBUG && true;
    waitingFrames = 2;

    Debugger.config.contexts = {
        indent: 19,
        delegatedExpand: true,
        anonymous: '<anonymous>',
        main: '<main>',
        comma: ', '
    };

    config = Debugger.config.contexts;


    templates.push(
        'contextsManager',
        'contextsList',
        'contextsFramesList'
    );

    Debugger.events.push(
        'ready',
        'contextslisted',
        'contextcreated',
        'contextdestroyed',
        'abort',
        'framechange',
        'stackloaded',
        'sourceshown',
        'exception',
        'break',
        'exception',
        'debugger',
        'pause',
        'resume'
    );

    Debugger.currentContext = {
        currentFrame: {}
    };

    contexts = Debugger.contexts;
    waitingContexts = [];

    $contentContexts = $("#contentContexts");

    if ($contentContexts.length === 0) {
        return false;
    }

    $contentContexts.treeTable(config);
    $nocontext = $contentContexts.find('.waf-empty');
    $contextsContainer = $contentContexts.parent();
    $contentContexts.main = ($contextsContainer.attr('id') !== 'hiddenComponents')



    function crossfireClient_contexts_toggleContext(mouseEvent) {

        var
            context,
            contextHashId;

        //window.console.info(Debugger.iframe + '> crossfireClient_contexts_toggleContext', mouseEvent);

        contextHashId = $(mouseEvent.target).attr('data-contextHashId');
        context = contexts[contextHashId];
        context.toggle();

        mouseEvent.preventDefault();
        return false;

    }



    function crossfireClient_contexts_selectContext(mouseEvent) {

        // Set a specific context as current and refresh all panels data

        var
            $target,
            contextHashId,
            context;

        //window.console.info(Debugger.iframe + '> crossfireClient_contexts_selectContext', mouseEvent);

        $target = $(mouseEvent.target);

        if ($target.hasClass('expander')) {

            crossfireClient_contexts_toggleContext(mouseEvent);

            return;
        }


        $target = $(mouseEvent.currentTarget);
        contextHashId = $target.attr('data-contextHashId');

        context = contexts[contextHashId];

        context.select();

        return;

    }



    function crossfireClient_contexts_selectFrame(mouseEvent) {

        // Set a specific context and a specific frame as currents and refresh all panels data
        var
            $target,
            contextHashId,
            context,
            frame,
            frameNumber;

        //window.console.info(Debugger.iframe + '> crossfireClient_contexts_selectFrame', mouseEvent);

        $target = $(mouseEvent.target);

        // The click target is a link
        if ($target.parent().hasClass('debug-frame-path')) {

            tools.openFile_click(mouseEvent);

            return false;
        }

        // The click target is the frame row
        $target = $(mouseEvent.currentTarget);

        contextHashId = $target.attr('data-contextHashId');
        frameNumber = Number($target.attr('data-frame'));

        context = contexts[contextHashId];
        frame = context.frames[frameNumber];

        return frame.select();

    }




    function crossfireClient_contexts_sortAscAsNumbers(elem1, elem2) {
        return elem1 - elem2;
    }

    /*
    function crossfireClient_contexts_sortDescAsNumbers(elem1, elem2) {
        return elem2 - elem1;
    }
    */

    function crossfireClient_contexts_sortAscByNumbers(elem1, elem2) {
        return elem1.number - elem2.number;
    }

    function crossfireClient_contexts_sortDescByNumbers(elem1, elem2) {
        return elem2.number - elem1.number;
    }


    // NEW FRAME



    function crossfireClient_contexts_mapParameters(paramIndex) {

        var
            param,
            preview;

        param = this[paramIndex];
        preview = {};

        if (param.hasOwnProperty('name')) {
            preview[param.name] = param.result;
            preview = tools.createPreviewLevel2(param.name, preview);
        } else {
            // unamed argument
            preview['?'] = param.result;
            preview = tools.createPreviewLevel2('?', preview);
            delete preview.name;
        }
        return preview;
    }


    /**
     * @class waStudio.Debugger.Frame
     *
     * @constructor
     * @param {waStudio.Debugger.Context} context
     * @param {Object} frameData
     **/
    function Frame(context, frameData) {

        var
            script,
            func,
            number,
            parameters,
            paramNames,
            maxIndex;

        /**
         * @property context
         * @type waStudio.Debugger.Context
         **/
        this.context = context;

        /**
         * @property number
         * @type Number
         **/
        this.number = number = frameData.number;

        /**
         * @property isCurrent
         * @type Boolean
         * @default false
         **/
        this.isCurrent = false;

        /**
         * @property domId
         * @type String
         **/
        this.domId = context.domId + 'Frame' + number;

        /**
         * @property $domId
         * @type String
         **/
        this.$domId = '#' + this.domId;

        // link
        script = frameData.script;

        /**
         * URL of the file in which is defined the function which provided the frame scope
         * 
         * @property script
         * @type String
         **/
        this.script = script;

        /**
         * System path of the file in which is defined the function which provided the frame scope
         *
         * TODO: fix that the "\" are escaped
         *
         * @property fullPath
         * @type String
         **/
        this.fullPath = frameData.fullPath;

        /**
         * @property fileName
         * @type String
         **/
        this.fileName = decodeURIComponent(script.substr(script.lastIndexOf('/') + 1));

        /**
         * @property line
         * @type Number
         **/
        this.line = frameData.line;

        // scope function name
        func = frameData.func;
        // Hack to clean bad format
        if (func !== '' && typeof func === 'string') {
            if (func.indexOf('(') > -1) {
                this.func = func.substr(0, func.indexOf('('));
            } else {
                this.func = frameData.func;
            }
        }

        // Global scope
        if (number === 0) {

            this.isMain = true;

        } else {
            // parameters
            parameters = frameData.parameters;
            paramNames = parameters && Object.getOwnPropertyNames(parameters);
            paramNames.sort(crossfireClient_contexts_sortAscAsNumbers);
            this.preview = paramNames.map(crossfireClient_contexts_mapParameters, parameters);
            maxIndex = this.preview.length;
            if (maxIndex > 0) {
                this.preview[maxIndex - 1].comma = "";
            }
        }
    }

    /**
     * @property isMain
     * @type Boolean|
     * @default false
     **/
    Frame.prototype.isMain = false;
    

    /**
     * <p>Set this frame as current. It is set as the currentFrame property of its Context object</p>
     *
     * <p>The selected frame is used to show the matching code with the position in this code, and
     * to show the locales of the scopes in which the function is called.</p>
     *
     * @method select
     * @type Boolean
     * @default false
     **/
    Frame.prototype.select = function Frame_select() {

        // Set a specific context and a specific frame as currents and refresh all panels data
        var
            context,
            currentFrame,
            needUpdate,
            framechangeEvent;

        needUpdate = false;
        context = this.context;
        currentFrame = context.currentFrame;
        context.previousFrame = context.currentFrame;

        if (this !== currentFrame) {
            needUpdate = true;

            currentFrame.isCurrent = false;
            $(currentFrame.$domId).removeClass('waf-active');

            context.currentFrame = this;
            this.isCurrent = true;
            $(this.$domId).addClass('waf-active');
        }


        if (context !== Debugger.currentContext) {
            needUpdate = true;
            context.select(true);
        }

        if (!needUpdate) {
            return true;
        }

        framechangeEvent = {
            type: 'framechange',
            context_id: context.id,
            frameNumber: context.currentFrame.number
        };

        Debugger.Context.dispatchEvent(framechangeEvent);

        return true;
    };

    /**
     * <p>Evaluates a JavaScript expression, either in this frame.</p>
     *
     * @method evaluate
     * @param {Object} owner
     */
    Frame.prototype.evaluate = function Frame_evaluate(owner) {

        var
            sequence,
            newSequence,
            expression;

        sequence = evalSequences.length;
        evalSequences.push(owner);

        expression = owner.hasOwnProperty('expression') ? owner.expression : owner.name;

        window.console.log(Debugger.iframe + '> evaluate ', this.context.id, this.number, expression, sequence);
        newSequence =  Debugger.evaluate(this.context.id, this.number, expression, sequence);
        
        if (typeof newSequence === 'number' && newSequence > 0) {
            delete evalSequences[sequence];
            evalSequences[newSequence] = owner;
        }
    };

    Frame.onevaluated = function Frame_onevaluated(event) {

        var
            target;

        target = evalSequences[event.request_seq];
        if (typeof target === 'object' && 'onevaluated' in target) {
            target.onevaluated(event);
        }
    };
    

    /**
     * <p>Get the properties of an object from this frame.</p>
     *
     * @method getObjectProperties
     * @param {Object} owner the object. It must have an handle number property
     */
    Frame.prototype.getObjectProperties = function Frame_getObjectProperties(owner) {
        
        var
            sequence,
            newSequence;

        sequence = evalSequences.length;
        evalSequences.push(owner);
        
        window.console.log(Debugger.iframe + '> getObjectProperties ', this.context.id, this.number, owner.handle, sequence);
        newSequence = Debugger.getObjectProperties(this.context.id, this.number, owner.handle, sequence);

        if (typeof newSequence === 'number' && newSequence > 0) {
            delete evalSequences[sequence];
            evalSequences[newSequence] = owner;
        }
        
    };

    Frame.onobjectpropertiesreceived = function Frame_onobjectpropertiesreceived(event) {

        var
            target;

        target = evalSequences[event.request_seq];
        window.console.log(Debugger.iframe + '> Frame_onobjectpropertiesreceived: ' + target, event);
        if (target !== undefined && 'onobjectpropertiesreceived' in target) {
            target.onobjectpropertiesreceived(event);
        }
    }

    Debugger.Frame = Frame;



    
    // NEW CONTEXT

    /**
     * @class waStudio.Debugger.Context
     * 
     * @constructor
     * @param {String} id
     **/
    function Context(id) {

        var
            oldContext,
            isCurrent;

        isCurrent = false;

        /**
         * @property id
         * @type String
         **/
        this.id = id;

        /**
         * @property contextId
         * @type String
         **/
        this.contextId = id; // for compatibility only

        /**
         * @property hashId
         * @type String
         **/
        this.hashId = '#' + id;

        /**
         * @property domId
         * @type String
         **/
        this.domId = 'context' + id;

        /**
         * @property $domId
         * @type String
         **/
        this.$domId = '#' + this.domId;

        /**
         * @property $domId
         * @type String | Object
         **/
        this.$node = undefined;

        /**
         * @property framesClass
         * @type String
         **/
        this.framesClass = 'child-of-context' + id;

        /**
         * @property framesClass
         * @type String
         **/
        this.$framesClass = '.' + this.framesClass;

        /**
         * @property state
         * @type String
         * @default "running"
         **/
        this.state = 'running';

        /**
         * @property stepIndex
         * @type Number
         * @default 1
         **/
        this.stepIndex = 1;

        /**
         * @property isCurrent
         * @type Boolean
         * @default false
         **/
        Object.defineProperty(
            this,
            'isCurrent',
            {
                get: function Debugger_context_isCurrent_onGet() {
                    return isCurrent;
                },
                set: function Debugger_context_isCurrent_onSet(newValue) {
                    isCurrent = newValue;
                }
            }
        );

        /**
         * @property iSNotActive
         * @type Boolean
         * @default true
         **/
        Object.defineProperty(
            this,
            'iSNotActive',
            {
                get: function Debugger_context_isNotActive_onGet() {
                    return !isCurrent;
                },
                set: function Debugger_context_isNotActive_onSet(newValue) {
                    throw new Error('This property is not writable. Value "' + newValue + '" ignored');
                }
            }
        );

        /**
         * @property collapsed
         * @type Boolean
         * @default true
         **/
        this.isCollapsed = true;

        /**
         * @property expanded
         * @type Boolean
         * @default false
         **/
        this.isExpanded = false;

        /**
         * @property stackLoaded
         * @type Boolean
         * @default false
         **/
        this.stackLoaded = false;

        /**
         * @property stackReady
         * @type Boolean
         * @default false
         **/
        this.stackReady = false;

        /**
         * @property comma
         * @type String
         * @default ", "
         **/
        this.comma = config.comma;

        /**
         * @property main
         * @type String
         * @default "<main>"
         **/
        this.main = config.main;

        // reference in contexts list
        oldContext = contexts[this.hashId];
        if (oldContext !== undefined) {
            window.console.error('A context already exist with this context id ');
            oldContext.remove();
        }
        contexts.push(this);
        contexts[this.hashId] = this;

    }

    /**
     * @property breakType
     * @type String|undefined
     * @default undefined
     **/
    Context.prototype.breakType = undefined;

    /**
     * @property currentFrame
     * @type Frame|Object
     * @default {}
     **/
    Context.prototype.currentFrame = {};


    /**
     * Return the string form "Context{id: "1355489", current, stackSize: 3}"
     *
     * @method toString
     * @return {String}
     **/
    Context.prototype.toString = function Context_contextToString() {

        return [
            'Context{id: "',
            this.id,
            'stackSize: ',
            (this.frames && this.frames.length) ||  0,
            '", ',
            (this.isCurrent ? 'is current' : ''),
            '}'
        ].join('');


    };
    
    
    /**
     * Render the view of the context
     *
     * @method render
     **/
    Context.prototype.render = function Context_render() {

        var
            data,
            markup;

        // generate and show the markup
        data = {
            func: config.anonymous,
            contexts: [this]
        };
        markup = Mustache.to_html(templates.contextsList, data);
        $nocontext[0].insertAdjacentHTML('afterend', markup);
        this.$node = $(this.$domId);
    };
    

    /**
     * Load the context's stack
     *
     * @method loadStack
     **/
    Context.prototype.loadStack = function Context_loadStack() {
        if ($contentContexts.main && !(this.stackLoaded || this.stackLoading)) {
            // TODO: should create the "loading stack row" here
            window.console.log('calling getstack from the context', this);
            this.stackLoading = true;
            Debugger.getStack(this.id);
        }
    };


    /**
     * Dispatch event if main context module
     *
     * @static
     * @method dispatchEvent
     * @param {Event} event
     **/
    Context.dispatchEvent = function Context_dispatchEvent(event) {
        if ($contentContexts.main) {
            window.console.info(Debugger.iframe + '> Dispatching "' + event.type + '" event', event);
            Debugger.dispatchEvent(event);
        }
    };


    /**
     * Show/Hide the context's stack
     *
     * @method toggle
     **/
    Context.prototype.toggle = function Context_toggle() {
        if (this.$node.hasClass('expanded')) {
            this.collapse();
        } else {
            this.expand();
        }
    };


    /**
     * Show the context's stack
     *
     * @method expand
     **/
    Context.prototype.expand = function Context_expand() {
        this.$node.expand();
        this.isExpanded = true;
        this.isCollapsed = false;
        // TODO: should show a loading line
        this.loadStack();
    };


    /**
     * Hide the context's stack
     *
     * @method collapse
     **/
    Context.prototype.collapse = function Context_collapse() {
        this.$node.collapse().removeClass('expanded').addClass('collapsed');
        this.isExpanded = false;
        this.isCollapsed = true;
    };

    function Context_delete_frame(frame, index, frames) {
        delete frames[index];
    }

    /**
     * Destroy the context's stack
     *
     * @method removeStack
     **/
    Context.prototype.removeStack = function Context_removeStack() {
        
        if (!this.stackLoaded) {
            return;
        }

        // DOM representation
        $(this.$framesClass).empty().remove();
        
        // current frame
        delete this.currentFrame;
        
        // stack
        // safely replace by "this.frames=[];" ?
        this.frames.forEach(Context_delete_frame); 

        this.stackLoaded = false;
        this.stackReady = false;
        
    };

    /**
     * Destroy the context's Markup
     *
     * @method remove
     **/
    Context.prototype.remove = function Context_remove() {

        // remove the stack
        this.removeStack();

        // remove the markup
        if (this.hasOwnProperty('$node')) {
            this.$node.empty().remove();
        } else {
            console.warn('Context has no $node property', this);
        }

        // remove the references
        delete contexts[this.hashId];
        contexts.splice(contexts.indexOf(this), 1);
        delete waitingContexts[this.hashId];
        waitingContexts.splice(waitingContexts.indexOf(this), 1);

        // set new current context
        if (this.isCurrent) {
            delete Debugger.currentContext ;
            Debugger.currentContext = {
                currentFrame: {}
            };
            Context.setCurrentContext();
        }

        // show empty line if no more context
        if (contexts.length === 0) {
            $nocontext.show();
            Debugger.currentContext = {
                currentFrame: {}
            };
        }
        
        Debugger.updateMenus();

        return;

    };


    /**
     * Abort the context
     *
     * @method abort
     **/
//    Context.prototype.abort = function Context_abort() {
        //Debugger.abortContext(this.id);
//    };


    /**
     * Destroy the context's Markup
     *
     * @method kill
     **/
    Context.prototype.kill = function Context_kill() {
        //this.abort();
        this.remove();
    };


    /**
     * Select this context
     *
     * @method setCurrent
     * @param {Boolean} silently
     **/
    Context.prototype.select = function Context_select(silently) {

        Context.setCurrentContext(this, silently);
        Debugger.updateMenus();

    };


    /**
     * show the Source of the current frame of this context
     *
     * @method showSource
	 * @param {Boolean} true if successfull
     **/
    Context.prototype.showSource = function Context_showSource() {
		var result = false;
	
        if (!$contentContexts.main) {
            return result;
        }

        if (this.breakType !== undefined) {
            window.console.info(Debugger.iframe + '> showSource', this.id, this.currentFrame.number);
            Debugger.showSource(this.id, this.currentFrame.number);
			result = true;
        } else {
            //window.console.error(Debugger.iframe + '> cleanSource');
            if (Debugger.cleanSource === undefined) {
                window.console.error(Debugger.iframe + '> cleanSource undefined');				
            } else {
                Debugger.cleanSource();
				result = true; 
            }
        }
		
		return result;
    };


    /**
     *
     * @event ondestroyed
     * @param {Event} event
     **/
    Context.prototype.ondestroyed = function Context_ondestroyed(event) {

        this.kill();
        /*
        event.breakType = 'destroyed';
        this.onbreak(event);
        */
    };


    Context.oncontextchange = function Context_oncontextchange(event) {

        var
            currentContext,
            context;

        currentContext = Debugger.currentContext;
        Debugger.previousContext = currentContext;
        context = contexts['#' + event.context_id];

        if (context === undefined) {
            console.warn("context doesn't exist anymore", event);
            return;
        }
        
        // unset previous currentContext
        if (currentContext instanceof Context) {
            currentContext.isCurrent = false;
            currentContext.$node.removeClass('waf-active');
            if (currentContext.breakType !== undefined) {
                if (currentContext.frames !== undefined && currentContext.frames.length > 0) {
                    $(currentContext.$frameClass).addClass('waf-disabled');
                }
            }
        }

        // set the new currentContext
        context.isCurrent = true;
        $(context.$domId).addClass('waf-active');

        Debugger.currentContext = context;
        Debugger.updateMenus();
        
        if ((this.breakType !== undefined) && !(this.stackLoaded || this.stackLoading)) { // TEST without contaext.main... 
        	context.loadStack();
        } else {
        	context.showSource();
        }
        
        if (context.breakType !== undefined) {
            $(currentContext.$frameClass).removeClass('waf-disabled');
        }
    }


    /**
     *
     * @event onframechange
     * @param {Event} event
     **/
    Context.prototype.onframechange = function Context_onframechange(event) {

        this.showSource();
        Debugger.updateMenus();

    };

    /**
     * 
     * @event onbreak
     * @param {Event} event
     **/
    Context.prototype.onbreak = function Context_onbreak(event) {
        
        var
            breakType,
            $this;

        breakType = event.type;

        waitingContexts[this.hashId] = this;
        waitingContexts.push(this);

        this.breakType = breakType;

        Debugger.updateMenus();
        
        $this = this.$node;
        $this.attr('data-breakType', breakType);

        switch (breakType) {
        case 'break':
            this.state = 'The context stopped on a breakpoint';
            break;
        case 'debugger':
            this.state = 'The context stopped on a debbuger statement';
            break;
        case 'exception':
            this.state = 'The context stopped because an exception was thrown: "' + event.message + '"';
            this.exception = {
                handle: event.handle,
                type: event.name,
                message: event.message
            };
            break;
        case 'pause':
            this.state = 'The context stopped because you manually asked for pause';
            break;
        case 'running':
            this.state = 'The context is running';
            break;
        case 'end':
            this.state = 'The context reached the end of the script';
            break;
        case 'destroyed':
            this.state = 'The context has been destroyed';
            break;
        case 'messagerror':
            this.state = 'The context stopped on an Error message: "' + event.message + '"';
            break;
        case 'messagewarning':
            this.state = 'The context stopped on a Warning message: "' + event.message + '"';
            break;
        default:
            window.console.warn('unknown break type:', breakType);
            this.state = 'The context stopped on a : "' + breakType + '"';
        }

        this.$node.find('.debug-context-state-icon').attr('title', this.state);

        if ((typeof Debugger.currentContext !== 'object') || !Debugger.currentContext.hasOwnProperty('id')) {
            // select this context if no other waiting context
            this.select(true);
            this.expand();

        } else if (this.isCurrent || this.isExpanded) {

            this.loadStack();

        }
        
    };


    /**
     *
     * @event onresume
     * @param {Event} event
     **/
    Context.prototype.onresume = function Context_onresume(event) {

        this.removeStack();
        this.frames = [];
        this.currentFrame = {};

        this.stepIndex += 1;

        $(this.$domId).removeAttr('data-breakType');
        delete this.breakType;
        delete this.state;

        delete waitingContexts[this.hashId];
        waitingContexts.slice(waitingContexts.indexOf(this), 1);

        if (this.isCurrent) {
            Debugger.updateMenus();
        }

    };


    function Debugger_contexts_forEachReceivedFrame(frameData, frameNumber) {
        frameData.number = Number(frameNumber);
        return new Frame(this, frameData);
    }


    /**
     * @event onstackloaded
     * @param {Event} event
     **/
    Context.prototype.onstackloaded = function Context_onstackloaded(event) {

        var
            newStack,
            stackView,
            stackreadyEvent;

        newStack = event.body.frames;

        //window.console.info(Debugger.iframe + '> crossfireClient_onstackloaded_contextListener ', event, contexts);
        if (this.stackLoaded) {
            return;
        }
        this.stackLoading = false;
        this.stackLoaded = true;

        // remove all children of the context (loading stack row adn potential frame rows)
        if (this.hasOwnProperty('frames') && this.frames.length > 0) {
            $(this.frameClass).empty().remove();
        }

        if (typeof newStack['0'] === 'undefined') {
            window.console.warn(Debugger.iframe + "> crossfireClient_onstackloaded_contextListener - context doesn't have any frame:", event);
            // TODO: show a 'no stack' message instead of the missing stack
            return;
        }

        newStack.length = Object.getOwnPropertyNames(newStack).length;
        newStack = Array.prototype.slice.call(newStack, 0);
        //newStack.sort(crossfireClient_contexts_sortDescByNumbers);
        this.frames = newStack;
        this.frames = this.frames.map(Debugger_contexts_forEachReceivedFrame, this);
        this.frames.sort(crossfireClient_contexts_sortDescByNumbers);
        this.frames[0].isCurrent = true;
        this.currentFrame = this.frames[0];
        this.func = config.anonymous;

        // Apply template
        stackView = Mustache.to_html(templates.contextsFramesList, this);
        this.frames.sort(crossfireClient_contexts_sortAscByNumbers);

        this.$node[0].insertAdjacentHTML('afterend', stackView);

        this.currentFrame.scopesData = event.body.scopes;
        if (this.showSource()) {
			stackreadyEvent = {
				type: 'stackready',
				context_id: this.id,
				webArea: Debugger.iframe
				//stack: tools.generateCallStack(Context.prototype.onstackloaded, [])
			};
			evalSequences.push(stackreadyEvent);
			stackreadyEvent.request_seq = evalSequences.length;

			Debugger.onstackready(stackreadyEvent);
		}
    };


    /**
     * @event onstackready
     **/
    Context.prototype.onstackready = function Context_onstackready() {

        if (this.stackReady) {
            return;
        }
        this.stackReady = true;
        
        if (this.isCurrent) {
            if (this.frames.length > 0) {
                $(this.className).show();
            }
            this.showSource();
        }

    };

    /**
     * <p>Try to suspend any currently running JavaScript in this context.</p>
     *
     * <p><em>Only exposed in emulated mode</em></p>
     *
     * @private
     * @method pause
     */
    Context.prototype.pause = function crossfireClient_Context_pause() {
        Debugger.pause(this.id);
    };


    /**
     * <p>Continue execution of javascript if suspended, if no stepaction is
     * passed, simply resumes execution.</p>
     *
     * <p><em>Only exposed in emulated mode</em></p>
     *
     * <p>Note: not called "continue" because it is a reserved word</p>
     *
     * @method resume
     */
    Context.prototype.resume = function crossfireClient_Context_resume() {
        Debugger.resume(this.id);
    };


    /**
     * <p>Executes the current statement and pauses at the following statement in the current frame.</p>
     *
     * <p><em>Only exposed in emulated mode</em></p>
     *
     * @method stepIn
     */
    Context.prototype.stepIn = function crossfireClient_Context_stepIn() {
        Debugger.stepIn(this.id);
    };


    /**
     * <p>Executes the current statement. If the line of code calls a function or method, the function
     * or method is executed in the background and the debugger pauses at the statement that follows
     * the original one.</p>
     *
     * <p><em>Only exposed in emulated mode</em></p>
     *
     * @method stepOver
     */
    Context.prototype.stepOver = function crossfireClient_Context_stepOver() {
        Debugger.stepOver(this.id);
    };


    /**
     * <p>When the debugger is within a function or method, Step Out will execute the code without stepping
     * through the code line by line. The debugger will stop on the line of code following the function or
     * method call in the calling program.</p>
     *
     * <p><em>NOT EXPOSED</em></p>
     *
     * @method stepOut
     */
    Context.prototype.stepOut = function crossfireClient_Context_stepOut() {
        Debugger.stepOut(this.id);
    };


    /**
     * <p>When the debugger is within a function or method, Step Out will execute the code without stepping
     * through the code line by line. The debugger will stop on the line of code following the function or
     * method call in the calling program in the selected frame.</p>
     *
     * <p><em>NOT IMPLEMENTED</em></p>
     *
     * @private
     * @method stepNext
     */
    Context.prototype.stepNext = function crossfireClient_Context_stepNext() {
        Debugger.stepNext(this.id);
    };


    /**
     * <p>The debugger runs until it reaches the line where the cursor is currently located.</p>
     *
     * <p><em>NOT IMPLEMENTED (Lot 3)</em></p>
     *
     * @private
     * @method stepTo
     * @param {Number} position
     * @param {String} url
     */
    Context.prototype.stepTo = function crossfireClient_Context_stepTo(position, url) {
        Debugger.stepto(this.id, position, url);
    };



    /**
     * Select a context to set as current
     *
     * @static
     * @method setCurrentContext
     * @param {waStudio.Debugger.Context|String|undefined} context
     * @param {Boolean} silently
     **/
    Context.setCurrentContext = function Context_setCurrentContext(context, silently) {

        var	currentContext,
        	contextchangeEvent,
        	currentChangeEvent;

        currentContext = Debugger.currentContext;

        // check for new currentContext
        switch (typeof context) {
        case 'undefined':
            context = (waitingContexts.length > 0) ? waitingContexts[0] : contexts[0];
            break;
        case 'string':
            context = contexts['#' + context];
            break;
        default:
            // context is already the targeted object
        }

        if (context !== undefined && context instanceof Context) {
            if (!context.stackLoaded) {
                context.loadStack();
            }
        }

        if (context === currentContext) {
            return;
        }

        if (/*!silently && */$contentContexts.main) {
            contextchangeEvent = {
                type: 'contextchange',
                context_id: context.id
            };

            Context.dispatchEvent(contextchangeEvent);
        } else {
        	
        	currentChangeEvent = {
                type: 'currentcontextchange',
                context_id: context.id
            };
            //Do not replace by Context.dispatchEvent !!! We need to dispatch this event even if the current context is not the main
            Debugger.dispatchEvent(currentChangeEvent);
        }

    };

    Debugger.Context = Context;






    /**
     * @param {waStudio.Debugger.ReadyEvent} readyEvent
     */
    Context.onready = function crossfireClient_onready_contextsListener(readyEvent) {

        if ($contentContexts.main) {
            Debugger.getContexts();
        }

    }


    /**
     * @param {waStudio.Debugger.ContextListedEvent_context} context
     */
    function crossfireClient_oncontextslisted_forEachContext(context) {

        var
            contextcreatedEvent,
            breakEvent;

        // generate the created event
        contextcreatedEvent = {
            type: "contextcreated",
            context_id: context.id
        };

        Debugger.oncontextcreated(contextcreatedEvent);

        if (context.state === "running") {
            return;
        }

        // if paused, generate a break event
        breakEvent = {
            type: (Debugger.contexts["#"+context.id].breakType === undefined) ? "break" : Debugger.contexts["#"+context.id].breakType,
            context_id: context.id
        };

        Debugger.onbreak(breakEvent);
    }


    /**
     * @param {waStudio.Debugger.ContextListedEvent} contextsListedEvent
     */
    Context.onlisted = function crossfireClient_oncontextslisted_contextsListener(contextsListedEvent) {

        var
            contexts;

        // conversion into an array
        contexts = contextsListedEvent.body;
        contexts.length = Object.getOwnPropertyNames(contexts).length;
        contexts = Array.prototype.slice.call(contexts, 0);

        contexts.forEach(crossfireClient_oncontextslisted_forEachContext);
    }

    
    /**
     * @param {waStudio.Debugger.ContextCreatedEvent} contextCreatedEvent
     */
    Context.oncreated = function crossfireClient_oncontextcreated_contextsListener(contextCreatedEvent) {

        var
            context;
        //window.console.info(Debugger.iframe + '> crossfireClient_oncontextcreated_contextsListener', event);

        if (contexts.hasOwnProperty('#' + contextCreatedEvent.context_id)) {
            console.error('contextcreated already received with this id');
            return;
        }
        if (contexts.length === 0) {
            $nocontext.hide();
        }
        context = new Context(contextCreatedEvent.context_id);
        context.render();

        if (contextCreatedEvent.hasOwnProperty('breakEvent') ) {
            context.onbreak(contextCreatedEvent.breakEvent);
        }
        
    }


    /**
     * @param {waStudio.Debugger.BreakEvent} breakEvent
     */
    Context.onbreak = function crossfireClient_onbreak_contextsListener(breakEvent) {

        var
            context,
            contextCreatedEvent;

        window.console.info(Debugger.iframe + '> crossfireClient_onbreak_contextsListener', breakEvent);

        context = contexts['#' + breakEvent.context_id];

        if (context !== undefined) {

            context.onbreak(breakEvent);
            
        } else {

            window.console.warn(Debugger.iframe + '> Received a "break" event without "contextcreated" event', breakEvent.context_id);

            contextCreatedEvent = {
                type: 'contextcreated',
                context_id: breakEvent.context_id,
                breakEvent: breakEvent
            };
            Debugger.oncontextcreated(contextCreatedEvent);
        }

    }



    // CONTEXT DESTROYED

    /**
     * @param {waStudio.Debugger.ContextDestroyedEvent} contextDestroyedEvent
     */
    Context.oncontextdestroyed = function crossfireClient_oncontextdestroyed_contextsListener(contextDestroyedEvent) {

        var
            context;

        context = contexts['#' + contextDestroyedEvent.context_id];

        if (context === undefined) {
            window.console.warn("crossfireClient_oncontextdestroyed_contextsListener - context unknown or already destroyed:", contextDestroyedEvent);
        } else {
            context.ondestroyed(contextDestroyedEvent);
        }

    }




    /**
     * @static
     * @method onstackloaded
     * @param {waStudio.Debugger.StackLoadedEvent} stackLoadedEvent
     */
    Context.onstackloaded = function crossfireClient_onstackloaded_contextListener(stackLoadedEvent) {

        var
            context;

        context = contexts['#' + stackLoadedEvent.context_id];

        if (context === undefined) {
            window.console.warn("crossfireClient_onstackloaded_contextListener - context doesn't exist anymore:", stackLoadedEvent);
        } else {
            context.onstackloaded(stackLoadedEvent);
        }
    };





    /**
     * @param {waStudio.Debugger.StackReadyEvent} stackReadyEvent
     */
    Context.onstackready = function crossfireClient_onstackready_contextListener(stackReadyEvent) {

        contexts['#' + stackReadyEvent.context_id].onstackready();

    }




    /**
     * @param {waStudio.Debugger.ResumeEvent} resumeEvent
     */
    Context.onresume = function crossfireClient_onresume_contextsListener(resumeEvent) {

        // window.console.info(Debugger.iframe + '> crossfireClient_onresume_contextsListener', event.type, event);
        var
            context;

        if (resumeEvent.context_id === undefined) {
            //window.console.log('onresume_contextsListener > The event doesn\'t give the context_id');
            context = Debugger.currentContext;
        } else {
            context = contexts['#' + resumeEvent.context_id];
        }

        if (context instanceof Context) {
            context.onresume(resumeEvent);
        }

    }



    function crossfireClient_onenablepanels_contextsListener(event) {

        var
            action;

        // ENABLE / DISABLE WATCHERS PANEL
        action = event.enabled ? 'removeClass' : 'addClass';
        $contextsContainer[action]('waf-disabled');

    }



    Context.onframechange = function crossfireClient_onframechange_contextsListener(event) {

        contexts['#' + event.context_id].onframechange(event);
        
    }




    function crossfireClient_onsourceshown_contextListener(event) {

        // no code

    }
	
	function crossfireClient_contexts_showMenu(event) {
		
		if($("#debugger_stack_params_menu").css("display") === "none") {
			
			event.stopPropagation();
			$("#debugger_stack_params_menu").show();
			$("body").bind("click", crossfireClient_contexts_hideMenu);
		}
	}
	
	function crossfireClient_contexts_hideMenu(event) {
		$("#debugger_stack_params_menu").hide();
		$("body").unbind("click", crossfireClient_contexts_hideMenu);
	}


    $contentContexts.delegate('#contentContexts .debug-context', 'click', crossfireClient_contexts_selectContext);
    $contentContexts.delegate('#contentContexts .debug-frame', 'click', crossfireClient_contexts_selectFrame);
	
	$("#debugger_stack_params").bind("click", crossfireClient_contexts_showMenu);
	$("#refresh_debugger_contexts").bind("click", function(event) {
		Debugger.getContexts();
	});
	
    Debugger.addEventListener('ready', Context.onready);

    Debugger.addEventListener('contextslisted', Context.onlisted);
    Debugger.addEventListener('contextcreated', Context.oncreated);

    Debugger.addEventListener('exception', Context.onbreak);
    Debugger.addEventListener('break', Context.onbreak);
    Debugger.addEventListener('pause', Context.onbreak);
    Debugger.addEventListener('debugger', Context.onbreak);
    Debugger.addEventListener('errormessage', Context.onbreak); // TODO: via console.error()
    Debugger.addEventListener('warningmessage', Context.onbreak); // TODO: via console.warning()

    Debugger.addEventListener('abort', Context.oncontextdestroyed);
    Debugger.addEventListener('contextdestroyed', Context.oncontextdestroyed);

    Debugger.addEventListener('stackloaded', Context.onstackloaded);
    Debugger.addEventListener('stacksloaded', Context.onstackloaded);

    Debugger.addEventListener('stackready', Context.onstackready);

    Debugger.addEventListener('evaluated', Frame.onevaluated);
    Debugger.addEventListener('objectpropertiesreceived', Frame.onobjectpropertiesreceived);

    Debugger.addEventListener('resume', Context.onresume);
    Debugger.addEventListener('contextchange', Context.oncontextchange);
    Debugger.addEventListener('framechange', Context.onframechange);
    Debugger.addEventListener('sourceshown', crossfireClient_onsourceshown_contextListener);
    Debugger.addEventListener('enablepanels', crossfireClient_onenablepanels_contextsListener);

    return true;

}; // End Scope_CallStacks
