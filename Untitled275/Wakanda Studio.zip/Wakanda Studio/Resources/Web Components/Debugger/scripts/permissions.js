/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
 * MANAGE DEBUGGER PERMISSION
 *
 * @static
 * @shared
 * @method manage
 */
waStudio.Debugger.managePermission = function Debugger_managePermissions() {

    var
        Debugger,
        console,
        accessGroup,
        userGroups,
        $contentPermission,
        $permissionContainer;
    
    
    Debugger = waStudio.Debugger;
    
    console = waStudio.console;
    
    accessGroup = Debugger.getAccessGroup();
    userGroups = Debugger.getUserGroups();
    
	Debugger.templates.push(
		'permissions'
	);

    $contentPermission = $("#contentPermission");
    $permissionContainer = $("#permissionContainer");

    function crossfireClient_permision_init(event) {
    	
		$("#actionPermission").bind("click", crossfireClient_permision_show);
    }
    
    function crossfireClient_permision_show(event) {
    	var i,
            html,
            startIndex;
		
		event.stopPropagation();
		
		if($permissionContainer.css("display") === "none") {
			
			userGroups = Debugger.getUserGroups();
			if(userGroups.length > 0) {
				
				permissionData = {};
				permissionData.list = [];
				startIndex = 0;
				
				accessGroup = Debugger.getAccessGroup();
				
				if(accessGroup.groupUUID !== "") {
					startIndex = 1;
					permissionData.list[0] = {
						groupName : accessGroup.groupName,
						groupUUID : accessGroup.groupUUID,
						selected : 'permissionSpan-selected'
					};
				}
				
				for(i = 0; i<userGroups.length; i++) {
					if(accessGroup.groupUUID !== userGroups[i].groupUUID) {
						permissionData.list[startIndex] = {
							groupName : userGroups[i].groupName,
							groupUUID : userGroups[i].groupUUID,
							selected : ''
						};
						startIndex++;
					}
		        }
				
		        html = Mustache.to_html(Debugger.templates.permissions, permissionData);
		        $contentPermission.html(html);
		        // $contentPermission.html(html);
	    		
	    		// $permissionContainer.height("100%");
	    		$permissionContainer.show();
	    		
	    		$("#contentPermission span.permissionSpan").each(function(index) {
	    			$(this).bind("mouseover", function () {
	    				$(this).addClass("permissionSpan-hover");
	    				
	    			});
	    			$(this).bind("mouseout", function () {
	    				$(this).removeClass("permissionSpan-hover");
	    				
	    			});
	    			$(this).bind("click", crossfireClient_permision_save);
	    			
	    		});
	
			} else {
	    		$permissionContainer.show();
			}
	    	
			$permissionContainer[0].style.top = (event.clientY + 10) + "px";
			$permissionContainer[0].style.left = (event.clientX - $permissionContainer.width()) + "px";
			
 			
			if((event.clientY + 10 + $permissionContainer.height()) > $permissionContainer.parent().height()) {
				
				$permissionContainer.height(($permissionContainer.parent().height() - (event.clientY + 10)));
				
			} else if($permissionContainer[0].scrollHeight > $permissionContainer.innerHeight() && $permissionContainer.innerHeight() < ($permissionContainer.parent().height() - (event.clientY + 10))) {
				
				$permissionContainer.height(
					Math.min(
						($permissionContainer.parent().innerHeight() - (event.clientY + 10)),
						($permissionContainer[0].scrollHeight + 5)
					)
				);
			}
			
			$permissionContainer.bind("click", function(event) {
				event.stopPropagation();
			});
			
			$(document.body).bind("click", crossfireClient_permision_hide);
			$(window).bind("resize", crossfireClient_permision_hide);
			
		} else {
			crossfireClient_permision_hide(event);
		}
    }
    
    function crossfireClient_permision_hide(event) {
		
		event.stopPropagation();
		$permissionContainer.hide();
		$(document.body).unbind("click", crossfireClient_permision_hide);
		$(window).unbind("resize", crossfireClient_permision_hide);
    }
    
    
	/**
	 * crossfireClient_console_submitNewCommand
	 *
	 * @event crossfireClient_console_submitNewCommand
	 * @param {Event} event
	 **/
	function crossfireClient_permision_save(event) {
		
		var selectedGroupUUID;
		
		event.preventDefault();
		
		try {
			
			accessGroup = Debugger.getAccessGroup();
			selectedGroupUUID = $(this).attr("group-uuid");
			
			if(accessGroup.groupUUID === selectedGroupUUID) {
				//delete accessGroup
				if(Debugger.disableAccessGroup()) {
					
					$(this).removeClass("permissionSpan-selected");
				}
			} else {
				
				if(Debugger.setAccessGroup(selectedGroupUUID)) {
					$(".permissionSpan-selected").each(function(index) {
						$(this).removeClass("permissionSpan-selected");
					});
					$(this).addClass("permissionSpan-selected");
				}
			}
			
		} catch (e) {
			// clone the error before log
			window.console.error('BUG', JSON.parse(JSON.stringify(e)));
		}
		
		setTimeout(crossfireClient_permision_hide, 100, event);
		
		return false;

	}
	
	Debugger.addEventListener('ready', crossfireClient_permision_init);

};

