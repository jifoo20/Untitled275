/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/* 
 * @module waStudioDebuggerEvents
 */

(function scope_DebuggerEvents(){

    /**
     * This event is dispacthed when a context is created
     *
     * @class waStudio.Debugger.ReadyEvent
     *
     * @constructor
     */
    Debugger.ReadyEvent = function ReadyEvent() {

        /**
         * @property type
         * @type String
         * @default "ready"
         */
        this.type = "ready";

    };


    /**
     * This event is dispacthed when a context is created
     *
     * @class waStudio.Debugger.ContextCreatedEvent
     *
     * @constructor
     * @param {String} contextId
     * @param {waStudio.Debugger.ContextCreatedEventBody} body
     */
    Debugger.ContextCreatedEvent = function ContextCreatedEvent(contextId, body) {

        /**
         * @property type
         * @type String
         * @default "contextcreated"
         */
        this.type = "contextcreated";

        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        /**
         *
         *
         * @property body
         * @type ContextCreatedEventBody
         */
        this.body = body;
    };


    /**
     *
     * @class waStudio.Debugger.ContextCreatedEventBody
     *
     * @constructor
     * @param {String} href
     */
    Debugger.ContextCreatedEventBody = function (href) {

        /**
         *
         * @property href
         * @type String
         */
        this.href = href;

    };


    /**
     * This event is dispacthed when a context is destroyed
     *
     * @class waStudio.Debugger.ContextDestroyedEvent
     *
     * @constructor
     * @param {String} contextId
     */
    Debugger.ContextDestroyedEvent = function (contextId) {

        /**
         * @property type
         * @type String
         * @default "contextdestroyed"
         */
        this.type = "contextdestroyed";

        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;
    };


    /**
     * This event is dispacthed when a running context is stopped
     *
     * @class waStudio.Debugger.BreakEvent
     * 
     * @constructor
     * @param {String} breakType
     * @param {String} contextId
     * @param {String} handle
     * @param {String} name
     * @param {String} message
     */
    Debugger.BreakEvent = function (breakType, contextId, handle, name, message) {

        /**
         * The type of the event match a kind of break. It can be:
         *
         *   "break": the context stopped on a breakpoint
         *   "debugger": the context stopped on a debugger statement
         *   "exception": the context stopped while an exception was thrown
         *   "pause": the context stopped because the pause button was cliked on it
         *
         * @property type
         * @type String
         */
        this.type = breakType;

        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        if (typeof handle !== undefined) {

            /**
             * Identifier of the thrown object
             * (only when type is "exception")
             *
             * @property handle
             * @type String
             */
            this.handle = handle;

            /**
             * Name, if any, of the thrown object
             * (only when type is "exception")
             *
             * @property name
             * @type String
             */
            this.name = name;

            /**
             * Message, if any, available in the thrown object
             * (only when type is "exception")
             *
             * @property message
             * @type String
             */
            this.message = message;
        }
    };



    /**
     * This event is dispacthed when the current context is resumed
     *
     * @class waStudio.Debugger.ResumeEvent
     *
     * @constructor
     */
    Debugger.ResumeEvent = function () {

        /**
         * @property type
         * @type String
         * @default "resume"
         */
        this.type = "resume";
    };



    /**
     * This event is dispacthed when the current context is aborted
     *
     * @class waStudio.Debugger.AbortEvent
     *
     * @constructor
     */
    Debugger.AbortEvent = function () {

        /**
         * @property type
         * @type String
         * @default "abort"
         */
        this.type = "abort";
    };






    /**
     * This event is dispacthed when a context stack is loaded
     *
     * @class waStudio.Debugger.StackLoadedEvent
     *
     * @constructor
     * @param {String} contextId
     * @param {Number} requestSeq
     * @param {waStudio.Debugger.StackLoadedEventBody} stackBody
     */
    Debugger.StackLoadedEvent = function (contextId, requestSeq, stackBody) {

        /**
         * @property type
         * @type String
         * @default "stackloaded"
         */
        this.type = "stackloaded";

        /**
         * Crossfire matching command
         *
         * @property command
         * @type String
         * @default "backtrace"
         */
        this.command = "backtrace";

        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        /**
         * The sequence index autogenerated by the getStack() method
         *
         * @property request_seq
         * @type Number
         */
        this.request_seq = requestSeq;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property seq
         * @type Number
         */
        this.seg = requestSeq + 1;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property body
         * @type waStudio.Debugger.StackLoadedEventBody
         */
        this.body = stackBody;
    };


    /**
     * This event is dispacthed when a context stack is loaded
     *
     * @class waStudio.Debugger.StackLoadedEventBody
     *
     * @constructor
     * @param {waStudio.Debugger.StackLoadedEventFrameList} frameList
     */
    Debugger.StackLoadedEventBody = function (frameList) {

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property seq
         * @type Number
         */
        this.frames = frameList;
        
    }

    /**
     *
     * @class waStudio.Debugger.StackLoadedEventFrameList
     *
     * @constructor
     * @param {waStudio.Debugger.StackLoadedEventFrame} frame*
     */
    Debugger.StackLoadedEventFrameList = function (frame) {

        var
            frameNumber;

        for (frameNumber = arguments.length -1; frameNumber > -1; frameNumber -= 1) {

            /**
             * @property [frameNumber]
             * @type waStudio.Debugger.StackLoadedEventFrame
             */
            this[String(frameNumber)] = arguments[frameNumber];

        }
    };


    /**
     *
     * @class waStudio.Debugger.StackLoadedEventFrame
     *
     * @constructor
     * @param {String} funcName
     * @param {String} script
     * @param {Number} line
     * @param {Number} handle
     * @param {waStudio.Debugger.StackLoadedEventFrameParameters} parameters
     */
    Debugger.StackLoadedEventFrame = function (funcName, script, line, handle, parameters) {

        /**
         *
         *
         * @property func
         * @type String
         */
        this.func = funcName;

        /**
         *
         *
         * @property script
         * @type Number
         */
        this.script = script;

        /**
         *
         *
         * @property line
         * @type Number
         */
        this.line = line;

        /**
         *
         *
         * @property handle
         * @type Number
         */
        this.handle = handle;

        /**
         *
         *
         * @property parameters
         * @type waStudio.Debugger.StackLoadedEventFrameParameterList
         */
        this.parameters = parameters;

    };


    /**
     *
     * @class waStudio.Debugger.StackLoadedEventFrameParameterList
     *
     * @constructor
     * @param {waStudio.Debugger.StackLoadedEventFrameParameter} parameter*
     */
    Debugger.StackLoadedEventFrameParameterList = function (parameter) {

        var
            parameterIndex;

        for (parameterIndex = arguments.length -1; parameterIndex > -1; parameterIndex -= 1) {

            /**
             * @property [parameterIndex]
             * @type waStudio.Debugger.StackLoadedEventFrameParameter
             */
            this[String(parameterIndex)] = arguments[parameterIndex];

        }
    };


    /**
     *
     * @class waStudio.Debugger.StackLoadedEventFrameParameter
     *
     * @constructor
     * @param {String} name
     * @param {String | Number | Boolean | null | undefined | waStudio.Debugger.EventPreview} result
     */
    Debugger.StackLoadedEventFrameParameter = function (name, result) {

        /**
         *
         *
         * @property name
         * @type String
         */
        this.name = name;

        /**
         *
         *
         * @property result
         * @type String | Number | Boolean | null | undefined | waStudio.Debugger.EventPreview
         */
        this.result = result;

    };


    /**
     *
     * @class waStudio.Debugger.EventPreview
     *
     * @constructor
     * @param {String} type
     * @param {String | Number | Boolean | null | undefined | waStudio.Debugger.EventPreviewLevel2} valueOrResult
     * @param {String} className
     * @param {Number} handle
     */
    Debugger.EventPreview = function(type, valueOrResult, className, handle) {

        /**
         *
         *
         * @property name
         * @type String
         */
        this.type = type;

        if (["object", "function", "exception"].indexOf(type) !== -1) {

            /**
             *
             *
             * @property className
             * @type String
             */
            this.className = className;

            /**
             *
             *
             * @property handle
             * @type Number
             */
            this.handle = handle;

            /**
             *
             *
             * @property preview
             * @type waStudio.Debugger.EventPreviewLevel2
             */
            this.result = valueOrResult;

        } else if (arguments.length > 1) {

            /**
             *
             *
             * @property value
             * @type String | Number | Boolean | null | undefined
             */
            this.value = valueOrResult;
        }
    };




    /**
     *
     * @class waStudio.Debugger.EventPreviewLevel2
     *
     * @constructor
     * @param {String} type
     * @param {String | Number | Boolean | null | undefined} value
     * @param {String} className
     * @param {Number} length
     */
    Debugger.EventPreviewLevel2 = function(type, value, className, length) {

        /**
         *
         *
         * @property type
         * @type String
         */
        this.type = type;

        if (["object", "function", "exception"].indexOf(type) !== -1) {

            /**
             *
             *
             * @property className
             * @type String
             */
            this.className = className;

            if (className === 'Array') {

                /**
                 *
                 *
                 * @property length
                 * @type Number
                 */
                this.length = length;

            }

        } else if (arguments.length > 1) {

            /**
             *
             *
             * @property value
             * @type String | Number | Boolean | null | undefined
             */
            this.value = value;
        }
    };






    /**
     *
     * @class waStudio.Debugger.EvaluatedEvent
     *
     * @constructor
     * @param {String} contextId
     * @param {Number} requestSeq
     * @param {waStudio.Debugger.EvaluatedEventBody} body
     */
    Debugger.EvaluatedEvent = function(contextId, requestSeq, body) {

        /**
         *
         *
         * @property type
         * @type String
         */
        this.type = "evaluated";

        /**
         * Crossfire command
         *
         * @property command
         * @type String
         */
        this.command = "evaluate";


        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        /**
         * The sequence index autogenerated by the getStack() method
         *
         * @property request_seq
         * @type Number
         */
        this.request_seq = requestSeq;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property seq
         * @type Number
         */
        this.seg = requestSeq + 1;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property body
         * @type waStudio.Debugger.StackLoadedEventBody
         */
        this.body = body;


    };

    /**
     *
     * @class waStudio.Debugger.EvaluatedEventBody
     * @extend waStudio.Debugger.EventPreview
     *
     * @constructor
     * @param {String} contextId
     * @param {String} type
     * @param {Number} valueOrResult
     * @param {String} className
     * @param {Number} handle
     */
    Debugger.EvaluatedEventBody = function(contextId, type, valueOrResult, className, handle) {

        Debugger.EventPreview.call(this, type, valueOrResult, className, handle)

        /**
         *
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

    };
    Debugger.EvaluatedEventBody.prototype = Object.create(Debugger.EventPreview.prototype);



/**
     *
     * @class waStudio.Debugger.ObjectPropertiesReceivedEvent
     *
     * @constructor
     * @param {String} contextId
     * @param {Number} requestSeq
     * @param {waStudio.Debugger.ObjectPropertiesReceivedEventBody} body
     */
    Debugger.ObjectPropertiesReceivedEvent = function(contextId, requestSeq, body) {

        /**
         *
         *
         * @property type
         * @type String
         */
        this.type = "objectpropertiesreceived";

        /**
         * Crossfire command
         *
         * @property command
         * @type String
         */
        this.command = "lookup";


        /**
         * Crossfire compliant property identifying the concerned JavaScript context
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        /**
         * The sequence index autogenerated by the getStack() method
         *
         * @property request_seq
         * @type Number
         */
        this.request_seq = requestSeq;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property seq
         * @type Number
         */
        this.seg = requestSeq + 1;

        /**
         * The response sequence index it should be the request index incremented by one
         *
         * @property body
         * @type waStudio.Debugger.ObjectPropertiesReceivedEventBody
         */
        this.body = body;


    };

    /**
     *
     * @class waStudio.Debugger.ObjectPropertiesReceivedEventBody
     * @extend waStudio.Debugger.EventPreview
     *
     * @constructor
     * @param {String} contextId
     * @param {Number} count
     * @param {Number} valueOrResult
     */
    Debugger.ObjectPropertiesReceivedEventBody = function(contextId, count, valueOrResult) {

        Debugger.EventPreview.call(this, "object", valueOrResult);

        /**
         *
         *
         * @property context_id
         * @type String
         */
        this.context_id = contextId;

        /**
         *
         *
         * @property count
         * @type Number
         */
        this.count = count;

    };
    Debugger.ObjectPropertiesReceivedEventBody.prototype = Object.create(Debugger.EventPreview.prototype);





















    if (typeof Debugger.onframechange !== 'function') {

        /**
         *
         *
         * @static
         * @protected
         * @event onframechange
         * @param {waStudio.Debugger.frameEvent} frameEvent
         */
        Debugger.onframechange = function crossfireClient_onframechange(frameEvent) {

        };

    }


    if (typeof Debugger.oncontextcreated !== 'function') {

        /**
         * <p>Fired when a new execution is going to be launched in a context</p>
         *
         * <pre name="code" class="js">
         * // on Debugger Window open, declare a "willexecuteprogram" event handler
         * function oncontextcreated(event) {
         * &nbsp;   Debugger.getStacks();
         * }
         * &nbsp;
         * // Using the "oncontextcreated" property
         * Debugger.oncontextcreated = oncontextcreated;
         * &nbsp;
         * // Or using the EventTarget API on the "willexecuteprogram" event (allow to add several handlers)
         * Debugger.addEventListener("contextcreated", oncontextcreated);
         * </pre>
         *
         * @static
         * @event oncontextcreated
         * @param {Event} event
         **/
        Debugger.oncontextcreated = function crossfireClient_oncontextcreated(event) {

        };

    }
    Debugger.oncontextcreated.name = "crossfireClient_oncontextcreated";


    if (typeof Debugger.oncontextdestroyed !== 'function') {

        /**
         * <p>Fired when an execution is done</p>
         *
         * <pre name="code" class="js">
         * // update the panels when a program ends
         * function oncontextdestroyed(event) {
         * &nbsp;   if (event.data.id === currenContext) {
         * &nbsp;       cleanWatchers();
         * &nbsp;   }
         * &nbsp;   Debugger.getStack();
         * }
         * &nbsp;
         * // Using the "oncontextdestroyed" property
         * Debugger.oncontextdestroyed = oncontextdestroyed;
         * &nbsp;
         * // Or using the EventTarget API on the "didexecuteprogram" event (allow to add several handlers)
         * Debugger.addEventListener("contextdestroyed", oncontextdestroyed);
         * </pre>
         *
         * @static
         * @event oncontextdestroyed
         * @param {Event} event
         **/
        Debugger.oncontextdestroyed = function crossfireClient_oncontextdestroyed(event) {

        };

    }
    Debugger.oncontextdestroyed.name = "crossfireClient_oncontextdestroyed";


    /**
     * <p>The Debugger.Event interface provides specific contextual information associated with Debugger events.</p>
     *
     *
     * @class waStudio.Debugger.Event
     * @extends Event
     */
    Debugger.Event = function crossfireClient_Event() {};

    //Debugger.Event.prototype = Object.create(Event.prototype);

    Debugger.Event.prototype.canBubble = false;
    Debugger.Event.prototype.cancelable = false;

    /**
     * The initDebuggerEvent method is used to initialize the value of a DebuggerEvent created through the ApplicationEvent
     * interface. This method may only be called before the DebuggerEvent has been dispatched via the dispatchEvent
     * method, though it may be called multiple times during that phase if necessary. If called multiple times,
     * the final invocation takes precedence.
     *
     * @method initDebuggerEvent
     * @param {String} typeArg Specifies the event type.
     * @param {Boolean} canBubbleArg Specifies whether or not the event can bubble.
     * @param {Boolean} cancelableArg Specifies whether or not the event's default action can be prevented.
     */
    Debugger.Event.prototype.initDebuggerEvent = function crossfireClient_Event_initDebuggerEvent(typeArg, contextIdArg, sequenceArg) {
        this.type = typeArg;
        this.timestamp = (new Date()).getTime();

        // crossfire properties
        this.context_id = contextIdArg;
        this.request_seq = sequenceArg;
        this.seq = sequenceArg + 1;
        return this;
    };





}());