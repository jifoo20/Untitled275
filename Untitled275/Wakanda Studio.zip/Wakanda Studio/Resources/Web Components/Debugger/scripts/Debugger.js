/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, devel: true, evil: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true */

/*global $ */



/**
 * <p>Debugger API</p>
 *
 * @module Debugger
 * 
 * @see http://getfirebug.com/wiki/index.php/Crossfire_Protocol_Reference
 */



/**
 * @class CrossfireClient
 * @extends Object
 */
function CrossfireClient() {
    "use strict";
}

waStudio.Debugger = waStudio.hasOwnProperty('Debugger') ? waStudio.Debugger : new CrossfireClient();




(function Scope_CrossfireClient() {

    "once tested on Windows -> use strict";

    var

        regExFunctionParams,
        regExType,
        maxInPreview,
        stringMaxSize,
        previewLength,
        objectStack,
        Debugger,
        frames,
        //$contextsContainer,
        waitingFrames;

    Debugger = waStudio.Debugger;
    Debugger.LOG_TARGET_C_OUTPUT = 'C_OUTPUT';
    Debugger.LOG_TARGET_JS_CONSOLE = 'JS_CONSOLE';
    
    Debugger.LOG_TARGET = Debugger.LOG_TARGET_C_OUTPUT;


    if (!window.hasOwnProperty('console')) {
        window.console = {
            log: function() { },
            debug: function() { },
            info: function() { },
            warn: function() { },
            error: function(msg) {
                alert(msg);
            }
        };
    }


    if (Debugger.logMsg && Debugger.LOG_TARGET === Debugger.LOG_TARGET_C_OUTPUT) {
        window.console.log = function() {
            Debugger.logMsg("LOG", Array.prototype.join.call(arguments));
        };
        window.console.debug = function() {
            Debugger.logMsg("DEBUG", Array.prototype.join.call(arguments));
        };
        window.console.warn = function() {
            Debugger.logMsg("WARNING", Array.prototype.join.call(arguments));
        };
        window.console.error = function() {
            Debugger.logMsg("ERROR", Array.prototype.join.call(arguments));
        };
        window.onerror = function(error) {
            Debugger.logMsg("EXCEPTION", error.toString() + " " + error.line + " " + error.lineNumber);
        };
    }

    regExFunctionParams = /^function\s*\w*\s*\(([\w, ]*)\)/;
    regExType = /^\[object (\w*)\]$/;

    maxInPreview = 3;
    stringMaxSize = 500;

    // FAKE DATA
    objectStack = [window];
    objectStack[-1] = [
        {
            name: 'big corp',
            employees: ['john', 'mary', 'steeve'],
            city: 'Paris'
        },
        {
            name: 'very big corp',
            employees: ['john', 'mary', 'steeve'],
            city: 'London'
        }
    ];
    objectStack[-2] = [
        {
            name: 'big corp',
            employees: ['john', 'mary', 'steeve'],
            city: 'Paris'
        },
        {
            name: 'very big corp',
            employees: ['john', 'mary', 'steeve'],
            city: 'London'
        }
    ];

    //$contextsContainer = $('contentContexts').parent();
    waitingFrames = window.frames.length;
    if (waitingFrames === 0) {
        waitingFrames = 1;
    }

    Debugger = waStudio.Debugger;

    Debugger.expandedObjects = {};

    if (Debugger.updateMenus === undefined) {
        Debugger.updateMenus = function Debugger_updateMenus() {};
    }


    Debugger.JSCORE_GLOBAL_PROPERTIES = {
        'Infinity': 0,
        'Array': {},
        'Boolean': {},
        'Date': {},
        'Error': {},
        'EvalError': {},
        'Function': {},
        'JSON': {},
        'Math': {},
        'NaN': 0,
        'Number': {},
        'Object': {},
        'RangeError': {},
        'ReferenceError': {},
        'RegExp': {},
        'String': {},
        'SyntaxError': {},
        'TypeError': {},
        'URIError': {},
        'XMLHttpRequest': {},
        'decodeURI':  {},
        'decodeURIComponent':  {},
        'encodeURI': {},
        'encodeURIComponent': {},
        'escape': {},
        'eval': {},
        'isFinite': {},
        'isNaN': {},
        'parseFloat': {},
        'parseInt': {},
        'undefined': {},
        'unescape': {},
        'TEMPORARY' : 0,
        'PERSISTENT' : 1,
        /*
    };

    Debugger.STANDARD_APIS = {
        */
       
        'Blob': {},
        'Buffer': {},
        'File': {},
        'Folder': {},
        'SharedWorker': {},
        'Worker': {},
        'clearInterval': {},
        'clearTimeout': {},
        'console': {},
        'name': '',
        'require': {},
        'sessionStorage': {},
        'setInterval': {},
        'setTimeout': {},
        
        /*
    };

    Debugger.WAKANDA_GLOBAL_PROPERTIES = {
        */
        'BinaryStream': {},
        'EndPoint': {},
        'JSONToXml': {},
        'Module': {},
        'Mutex': {},
        'ProgressIndicator': {},
        'RestDirectoryAccess': {},
        'SyncEvent': {},
        'SystemWorker': {},
        'TextStream': {},
        'XmlToJSON': {},
        '_syntaxTester': {},
        'addHttpRequestHandler': {},
        'administrator': false,
        'application': {},
        'close': {},
        'compactDataStore': {},
        'createDataStore': {},
        'dataService': {},
        'currentSession': {},
        'currentUser': {},
        'dateToIso': {},
        'db': {},
        'directory': {},
        'displayNotification':  {},
        'ds': {},
        'exitWait': {},
        'fileService': {},
        'garbageCollect': {},
        'generateUUID': {},
        'getDataStore': {},
        'getFolder': {},
        'getItemsWithRole': {},
        'getProgressIndicator': {},
        'getSettingFile': {},
        'getURLPath': {},
        'getURLQuery': {},
        'getWalibFolder': {},
        'guidedModel': {},  // WARNING ! IT SHOULD NOT BE EXPOSED
        'httpServer': {},
        'include': {},
        'internal': {},
        'isoToDate': {},
        'jscprint': {},
        'loadImage': {},
        'loadText': {},
        'loginByKey': {},
        'loginByPassword': {},
        'logout': {},
        'methods': {}, // WARNING ! IT SHOULD NOT BE EXPOSED
        'oldSessionStorage': {},
        'open4DBase': {},
        'openDataStore': {},
        'os': {},
        'pattern': '',
        'process': '',
        'removeHttpRequestHandler': {},
        'repairDataStore': {},
        'requireNative': {}, // WARNING ! IT SHOULD NOT BE EXPOSED
        'rpcService': {},
        'saveText': {},
        'setCurrentUser': {},
        'settings': {},
        'solution': {},
        'storage': {},
        'trace': {},
        'verifyDataStore': {},
        'wait': {},
        'webAppService': {},
        'permissions': {},
        'requestFileSystem': {},
        'resolveLocalFileSystemURL': {},
        'requestFileSystemSync': {},
        'resolveLocalFileSystemSyncURL': {},
        'RestImpExpAccess': {},
    };

    /**
     * @static
     * @property name
     * @type String
     * @default wakandaCrossfireClient
     */
    Debugger.name = "wakandaCrossfireClient";

    /**
     * @static
     * @property ready
     * @type Boolean
     * @default false
     */
    Debugger.ready = false;

    /**
     * The "config" property is used by each Debugger component to store their
     * configuration values
     * 
     * @static
     * @property config
     * @type Object
     * @default {}
     */
    Debugger.config = {};

    /**
     * Array in which each component of the debugger add the name of the templates
     * they require
     *
     * @static
     * @property templates
     * @type Array
     * @default []
     */
    Debugger.templates = [];

    /**
     *
     * @static
     * @property events
     * @type Array
     * @default []
     */
    Debugger.events = [];


    /**
     * Collection of the Constructors of the Debugger modules
     *
     * @static
     * @property managers
     * @type Object
     * @default {}
     */
    Debugger.managers = {};


    /**
     * Collection of the instances of the Debugger modules
     *
     * @static
     * @property modules
     * @type Object
     * @default {}
     */
    Debugger.modules = {};

    /**
     * Collection of the panels of the Debugger modules
     *
     * @static
     * @property panels
     * @type Array
     * @default []
     */
    Debugger.panels = [];

    /**
     * @static
     * @property evalSequences
     * @type Array
     * @default []
     */
    Debugger.evalSequences = [];

    /**
     * @static
     * @property contexts
     * @type Array
     * @default []
     */
    Debugger.contexts = [];

    /**
     * <p>Base sequence number of the SSJS Interpreter module</p>
     *
     * <p>It is used to identify the destination of the evaluate result</p>
     *
     * @static
     * @property RUN_SSJS
     * @type String
     * @default "RUN_SSJS"
     */
    Debugger.RUN_SSJS = "RUN_SSJS";

    /**
     * <p>Base sequence number of the Command Line interpreter of the console module</p>
     *
     * <p>It is used to identify the destination of the evaluate result</p>
     *
     * @static
     * @property EVAL_COMMAND
     * @type String
     * @default "EVAL_COMMAND"
     */
    Debugger.EVAL_COMMAND = "EVAL_COMMAND";

    /**
     * <p>Base sequence number of the Watchers module</p>
     *
     * <p>It is used to identify the destination of the evaluate result</p>
     *
     * @static
     * @property EVAL_WATCHERS
     * @type String
     * @default "EVAL_WATCHERS"
     */
    Debugger.EVAL_WATCHERS = "EVAL_WATCHERS";

    /**
     * <p>It is used to identify the destination of the getObject result</p>
     *
     * @static
     * @property GET_OBJECTS_WATCHERS
     * @type String
     * @default "GET_OBJECTS_WATCHERS"
     */
    Debugger.GET_OBJECTS_WATCHERS = "GET_OBJECTS_WATCHERS";

    /**
     * <p>It is used to identify the destination of the getObject result</p>
     *
     * @static
     * @property GET_OBJECTS_OUTPUT
     * @type String
     * @default "GET_OBJECTS_OUTPUT"
     */
    Debugger.GET_OBJECTS_OUTPUT = "GET_OBJECTS_OUTPUT";

    /**
     * <p>It is used to identify the destination of the getObject result</p>
     *
     * @static
     * @property GET_OBJECTS_CONSOLE
     * @type String
     * @default "GET_OBJECTS_CONSOLE"
     */
    Debugger.GET_OBJECTS_CONSOLE = "GET_OBJECTS_CONSOLE";

    if (typeof Debugger.crossFireVersion !== 'function') {

        /**
         * <p>Returns the Crossfire protocol version.</p>
         *
         *
         * @static
         * @property crossfireVersion
         * @type String
         * @default "0.3"
         */
        Debugger.crossfireVersion = "0.3";

    }

/*
    
*/
    if (typeof Debugger.dispatchEvent !== 'function') {

        if (window.parent === window) {
            frames = [window];
        } else {
            frames = Array.prototype.slice.call(window.parent.frames, 0);
        }

        /**
         * Tell the server that de Debugger interface is ready to receive events
         *
         * @static
         * @method dispatchEvent
         * @param {Event} event
         */
        Debugger.dispatchEvent = function crossfireClient_dispatchEvent(event) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE

            window.console.warn(Debugger.iframe + '> FAKE Debugger.dispatchEvent', event.type, event);

            frames.forEach(
                function crossfireClient_dispatchEvent_forEachFrame(frame) {

                    var
                        Debugger,
                        event;

                    event = this;

                    if (frame.hasOwnProperty('waStudio')) {
                        Debugger = frame.waStudio.Debugger;
                        //if (typeof Debugger.dispatchEvent')) {
                        Debugger['on' + event.type](event);
                        //}
                    }
                },
                event
            );
        };

    }




    if (typeof Debugger.setReady !== 'function') {

        /**
         * Tell the server that de Debugger interface is ready to receive events
         *
         * @static
         * @method setReady
         */
        Debugger.setReady = function crossfireClient_setReady() {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE

            window.console.warn(Debugger.iframe + '> FAKE setReady');

            waitingFrames -= 1;

            if (waitingFrames === 0) {
                Debugger.dispatchEvent(
                    {
                        type: "ready"
                    }
                );

                Debugger.dispatchEvent(
                    {
                        type: "exception",
                        context_id: "4428590001",
                        handle: 123,
                        name: "ReferenceError",
                        message: "Can't find variable: employer"
                    }
                );
                /*
                Debugger.dispatchEvent(
                    {
                        type: "break",
                        context_id: "4428590002"
                    }
                );

                Debugger.dispatchEvent(
                    {
                        type: "pause",
                        context_id: "4428590003"
                    }
                );
                */
                Debugger.dispatchEvent(
                    {
                        type: "debugger",
                        context_id: "4428590004"
                    }
                );
                    /*
                Debugger.dispatchEvent(
                    {
                        type: "errormessage",
                        context_id: "4428590005"
                    }
                );
                Debugger.dispatchEvent(
                    {
                        type: "warningmessage",
                        context_id: "4428590006"
                    }
                );
                Debugger.dispatchEvent(
                    {
                        type: "contextcreated",
                        context_id: "4428590007"
                    }
                );
                    */
            }
        };
    }


    if (typeof Debugger.getContexts !== 'function') {

        /**
         * Tell the server that de Debugger interface is ready to receive events
         *
         * @static
         * @method getContexts
         */
        Debugger.getContexts = function crossfireClient_getContexts() {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE

            window.console.warn(Debugger.iframe + '> FAKE getContexts');

            Debugger.dispatchEvent(
                {
                    "type" : "contextslisted",
                    "command" : "listcontexts",
                    "seq" : 20,
                    "request_seq" : 19,
                    "body" : {
                        "0" : {
                            "id" : "251377296",
                            "state" : "paused"
                        },
                        "1" : {
                            "id" : "251514984",
                            "state" : "running"
                        }
                    }
                }
            );
        };

    }


    if (typeof Debugger.showSource !== 'function') {

        /**
         * Tell the server that de Debugger interface is ready to receive events
         *
         * @static
         * @method showSource
         * @param {String} contextId
         * @param {Number} frameNumber
         */
        Debugger.showSource = function crossfireClient_showSource(contextId, frameNumber) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            window.console.warn(Debugger.iframe + '> FAKE showSource');

            if (window.parent === window || $('contentSource').length > 0) {
                Debugger.dispatchEvent(
                    {
                        type: "sourceshown",
                        context_id: contextId,
                        frame: frameNumber
                    }
                );
            }

        };

    }


    if (typeof Debugger.getStack !== 'function') {


        /**
         * <p>Return an array with the  list of frames in creation order.</p>
         *
         * <p>The array index is the number of the frame in which the function was invocated.</p>
         *
         * <p><em>provided by the 'backtrace' crossfire command</em></p>
         *
         * @method getStack
         * @param {String} contextId
         */
        Debugger.getStack = function crossfireClient_getStack(contextId) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            var
                stacksLoadedEvent,
                basePath,
                baseURL;

            window.console.warn(Debugger.iframe + '> FAKE getStack');

            baseURL = "file://" + document.location.host + document.location.pathname;
            baseURL = "file://C:/pokpok/fran%C3%A7ois/walib/WAF/Tag/";
            basePath = "C:\\pokpok\\françois\\walib\\WAF\\Tag\\";
            stacksLoadedEvent = {
                type: 'stacksloaded',
                context_id: contextId,
                body: {
                    context_id: contextId,
                    scopes: {
                        1: {
                            index: 1,
                            object: {
                                handle: -1,
                                type: 'ref'
                            }
                        },
                        0: {
                            index: 0,
                            object: {
                                handle: -2,
                                type: 'ref'
                            }
                        }

                    },
                    frames: {
                        "0": {
                            line: 4,
                            //fileName: 'Loader.js',
                            //url: '/base/pop/foo/run.js',
                            fullPath: basePath + 'base/pop/foo/Loader.js',
                            script: baseURL + 'Loader.js'
                        },
                        "1": {
                            func: 'applyHandler',
                            parameters: {
                                "0": {
                                    name: "bar",
                                    result: true
                                },
                                "1": {
                                    name: "last",
                                    result: {
                                        type: "object",
                                        className: "Date",
                                        preview: (new Date()).toString()
                                    }
                                },
                                "2": {
                                    result: null
                                },
                                "3": {
                                    result: {
                                        type: "object",
                                        className: "Array",
                                        length: 5
                                    }
                                }
                            },
                            line: 7,
                            //fileName: 'Loader.js',
                            //url: '/base/pop/foo/run.js',
                            fullPath: basePath + 'base/pop/foo/Loader.js',
                            script: baseURL + 'Loader.js'
                        },
                        "2": {
                            parameters: {
                                "0": {
                                    result: 51
                                },
                                "1": {
                                    result: {
                                        type: "object",
                                        className: "Array",
                                        length: 10
                                    }
                                }
                            },
                            line: 8,
                            //fileName: 'run.js',
                            //url: '/base/pop/foo/run.js',
                            script: basePath + 'base/pop/foo/run.js',
                            fullPath: basePath + 'base/pop/foo/run.js'
                        }
                    }
                }
            };

            Debugger.dispatchEvent(stacksLoadedEvent);
            Debugger.dispatchEvent(
                {
                    type: "enablepanels",
                    enabled: true
                }
            );

        };

        // HACKS FOR COMPATIBILITY
        if (typeof Debugger.getStacks === 'function') {
            window.console.warn(Debugger.iframe + '> getStacks() should be named getStack()');
            Debugger.getStack = Debugger.getStacks;
        }
    }


    /**
     *
     * @private
     * @method formatPreviewProperty
     * @param {String|Number|Boolean|undefined|null|Object|Array|Function|Date} value
     * @return {String|Number|Boolean|undefined|null|Object}
     **/
    function formatPreviewProperty(value) {

        var
            result,
            typeMatch,
            type;

        type = (value === null) ? 'null' : typeof value;

        switch (type) {
        case 'string':
        case 'number':
        case 'boolean':
        case 'undefined':
        case 'null':
            result = value;
            break;

        case 'function':
            result = {
                type: "object",
                className: "Function",
                name: value.name
            };
            break;

        default:
            result = {
                type: "object",
                className: value.constructor.name
            };
            typeMatch = regExType.exec(Object.prototype.toString.apply(value)); // should be this form "[object ConstructorName]"
            if (typeMatch !== null && typeMatch.length === 2) {
                result.className = typeMatch[1];
            }

            switch (result.className) {
            case 'Array':
                result.length = value.length;
                break;

            case 'Date':
                result.preview = value.toString().substr(0, 10);
                break;

            default:
                // no additional properties
            }
        }

        return result;
    }

    if (typeof Debugger.getObjectProperties !== 'function') {

        /**
         * <p>This method is used to get the list of the properties of a specific object</p>
         *
         * <p>The <code>owner</code> parameter represent an object from which will be returned
         * a <code>Debugger.ObjectStream</code> of its properties.</p>
         *
         * <pre name="code" class="js">
         * fooProperties = Debugger.getObjectProperties(contextId, frameNumber, owner, sequence, first);
         * if (fooProperties.count >  fooProperties.list.length) {
         * &nbsp;   // there is more than 100 properties
         * &nbsp;   // handle the streaming on scroll 
         * }
         * </pre>
         *
         * @method getObjectProperties
         * @param {Number|String} contextId Context
         * @param {Number|String} frameNumber Frame
         * @param {Number|String} handle Reference to the owner of these objects
         * @param {Number|String} sequence request sequence number
         * @param {Number|undefined} first The expected index of the first returned object in each <code>Debugger.ObjectStream</code>
         * (0 by default). This parameter can be changed to get a list a properties starting from another position.
         */
        Debugger.getObjectProperties = function crossfireClient_getObjectProperties(contextId, frameNumber, handle, sequence, first) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            var
                objectsReceivedEvent,
                type,
                body,
                owner,
                list;

            //objects = new Debugger.ObjectStreams();

            sequence = Number(sequence);
            contextId = String(contextId);

            objectsReceivedEvent = {

                type: 'objectpropertiesreceived',
                command: 'lookup', // crossfire command name
                context_id: contextId,
                seq: sequence + 1,
                request_seq: sequence,

                body: {

                    context_id: contextId,
                    first: first || 0,      // index de la premiere propriete ou du premier evenement retourne de l'objet ou du tableau
                    result: {

                        // le format des objets ou Evenement est le meme que le retour du evaluate

                        /*

                        "name": "main43",

                        "enabled": true,

                        "children": {
                            
                            context_id: String(contextId),
                            count: 51,
                            handle: 5,
                            className: "EntitySet",
                            type: "object",
                            result: {
                                "0": {
                                    handle: 6,
                                    className: "Entity",
                                    type: "object"
                                },
                                "1": {
                                    handle: 7,
                                    className: "Entity",
                                    type: "object"
                                },
                                    handle: 8,
                                    className: "Entity",
                                    type: "object"
                                }
                            }
                        }
                        
                        */
                    }
                }
            };

            body = objectsReceivedEvent.body;

            if (!objectStack.hasOwnProperty(handle)) {
                objectsReceivedEvent.error = 'invalid handle: ' + handle;
                // error object does not exist
                Debugger.dispatchEvent(objectsReceivedEvent);
            }

            owner = objectStack[handle];
            type = typeof owner;

            body.count = Object.getOwnPropertyNames(owner).length;  // nombre total de propriétés ou d'éléments de l'objet ou du tableau

            // Format the object property value
            function crossfireClient_getObjectPropertis_forEachPropertyLevel1(element, propertyName) {
                        
                var
                    type,
                    typeMatch,
                    handle,
                    result;
                    
                type = typeof element;
                if (element === null) {
                    type = 'null';
                }
                
                if (type === 'object' || type === 'function') {
                    
                    // Parse first properties for preview
                    handle = objectStack.indexOf(element);
                    if (handle === -1) {
                        handle = objectStack.length;
                        objectStack.push(element);
                    }
                    
                    result = {
                        context_id: contextId,
                        handle: handle,
                        className: 'unknown',
                        type: type,
                        result: {}
                    };
                    
                    typeMatch = regExType.exec(Object.prototype.toString.apply(element)); // should be this form "[object ConstructorName]"
                    if (typeMatch !== null && typeMatch.length === 2) {
                        result.className = typeMatch[1];
                    }
                    
                    if (element.constructor === Array) {
            
                        element.every(
                            function getObjects_forEachPropertyLevel2(element, index) {
                                result.result[String(index)] = formatPreviewProperty(element);
                                return (index <= maxInPreview);
                            }
                        );
                        
                    } else {
                    
                        Object.getOwnPropertyNames(element).every(
                            function getObjects_forEachPropertyNameLevel2(propertyName, index) {
                                result.result[propertyName] = formatPreviewProperty(element[propertyName]);
                                return (index <= maxInPreview);
                            }
                        );
                        
                    }
                    
                
                } else {
                    result = element;
                }
                
                body.result[propertyName] = result;
            }
            
            // Parse the properties of the object
            if (owner === null || (type !== 'object' && type !== 'function')) {
                
                body.result = undefined;
                
            } else if (owner.constructor === Array) {
            
                owner.forEach(crossfireClient_getObjectPropertis_forEachPropertyLevel1);
                
            } else {
            
                list = Object.getOwnPropertyNames(owner);
                if (owner.hasOwnProperty('constructor') && (list.indexOf(owner.constructor) === -1)) {
                    list.push('constructor');
                }
                list.forEach(
                    function crossfireClient_getObjectproperties_forEachPropertyName(propertyName) {
                        
                        crossfireClient_getObjectPropertis_forEachPropertyLevel1(owner[propertyName], propertyName);
                    
                    }
                );
                
            }
            
            // send the result
            Debugger.dispatchEvent(objectsReceivedEvent);
             
        };
    }
    

    
    /**
     * @private
     * @method evaluate_trimParam
     * @param {String} element
     * @param {Number} index
     * @param {Array} params
     */
    function evaluate_trimParam(element, index, params) {
        params[index] = element.trim();
    }

    
    if (typeof Debugger.evaluate !== 'function') {

        /**
         * <p>Evaluates a JavaScript expression, either in the global scope, or
         * optionally in a given frame if it exists.</p>
         *
         * @method evaluate
         * @param {String} contextId
         * @param {Number} frameNumber
         * @param {String} expression
         * @param {Number} sequence
         */
        Debugger.evaluate = function crossfireClient_evaluate(contextId, frameNumber, expression, sequence) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            var 
                evaluateEvent, 
                data, 
                type,
                result, 
                preview, 
                properties, 
                mainProperties,
                typeMatch;
            
            evaluateEvent = {
                type: "evaluated",
                command: "evaluate",
                request_seq: sequence,
                seq: sequence + 1,
                body: {
                    context_id: contextId
                }
            };
            data = evaluateEvent.body;
            
            try {
                
                result = eval(expression);
                
                // No exception thrown on evaluation
                
                if (result === null) {
                    data.type = type = "null";
                } else {
                    data.type = type = typeof result;
                    type = (type === 'object') ? result.constructor.name : type;
                }
                
                switch (type) {
                
                case "undefined":
                    data.type = "undefined";
                    data.result = {};
                    break;
                    
                case "null":
                    delete data.type;
                    data.result = null;
                    break;
                    
                case "boolean":
                    delete data.type;
                    data.result = result;
                    break;
                    
                case "number":
                    delete data.type;
                    data.result = result;
                    break;
                
                case "string":
                    delete data.type;
                    data.result = result.substr(0, stringMaxSize);
                    break;
                
                case 'Date':
                    data.handle = objectStack.length;
                    objectStack.push(result);
                    data.className = 'Date';
                    data.result = result.toString();
                    break;
                
                case 'function':
                    data.handle = objectStack.length;
                    objectStack.push(result);
                    data.type = 'object';
                    data.className = 'Function';
                    data.result = {};
                    if (result.hasOwnProperty('name')) {
                        data.result.func = result.name;
                    }
                    
                    data.params = regExFunctionParams.exec(result.toString());
                    data.params = data.params[1];
                    if (data.params) {
                        data.params = data.params.split(',');
                        data.params.forEach(evaluate_trimParam);
                    } else {
                        data.params = [];
                    }
                    data.result.length = result.length;
                    data.count = Object.getOwnPropertyNames(result).length;
                    break;
                
                case 'Array':
                    data.handle = objectStack.length;
                    objectStack.push(result);
                    data.className = 'Array';
                    preview = {};
                    previewLength = 0;
                    result.splice(0, maxInPreview).forEach(
                        function (element, index) {
                            preview[index] = formatPreviewProperty(element);
                            previewLength += 1;
                        }
                    );
                    data.result = preview;
                    data.count = Object.getOwnPropertyNames(preview).length;
                    break;
                
                default:
                    data.handle = objectStack.length;
                    objectStack.push(result);
                    data.type = 'object';
                    
                    typeMatch = regExType.exec(Object.prototype.toString.apply(result)); // should be this form "[object ConstructorName]"
                    if (typeMatch !== null && typeMatch.length === 2) {
                        type = typeMatch[1];
                    }
                    data.className = type;
                    
                    properties = Object.getOwnPropertyNames(result);
                    data.count = properties.length;
                    
                    preview = {};
                    previewLength = 0;
                    
                    mainProperties = ['id', 'ID', 'name', 'NAME', 'version', 'VERSION'];
                    mainProperties.forEach(
                        function crossfireClient_evaluate_forEachMainProperty(propertyName) {
                            if (result.hasOwnProperty(propertyName)) {
                                preview[propertyName] = formatPreviewProperty(propertyName, result[propertyName]);
                                previewLength += 1;
                                properties.splice(properties.indexOf(propertyName), 1);
                            }
                        }
                    );
                    properties.some(
                        function crossfireClient_evaluate_someOwnProperty(propertyName) {
                            if (previewLength >= maxInPreview) {
                                return false;
                            }
                            if (!result.hasOwnProperty(propertyName)) {
                                return true;
                            }
                            preview[propertyName] = formatPreviewProperty(result[propertyName]);
                            previewLength += 1;
                            properties.splice(properties.indexOf(propertyName), 1);

                            return true;
                        }
                    );
                    properties.some(
                        function crossfireClient_evaluate_somePrototypeProperty(propertyName) {
                            if (previewLength >= maxInPreview) {
                                return false;
                            }
                            preview[propertyName] = formatPreviewProperty(result[propertyName]);
                            previewLength += 1;
                            
                            return true;
                        }
                    );
                    data.result = preview;
                }
                
            } catch (exception) {
                
                
                data.handle = objectStack.length;
                objectStack.push(exception);
                data.className = exception.constructor.name;
                data.type = "exception";
                data.result = exception;
                
            }
            
            Debugger.dispatchEvent(evaluateEvent);
            
        };
    }





    if (typeof Debugger.selectFrame !== 'function') {
        
        /**
         * <p>Select the frame and the context to inspect.</p>
         *
         * @static
         * @protected
         * @method selectFrame
         * @param {String} contextId
         * @param {Number} frameNumber
         * @return {Boolean}
         */
        Debugger.selectFrame = function crossfireClient_selectFrame(contextId, frameNumber) {
            alert('Frame "' + frameNumber + '" selected in context "' + contextId + '"');
        };

    }
 


    if (typeof Debugger.suspend !== 'function') {

        /**
         * <p>Try to suspend any currently running JavaScript (breakAll).</p>
         *
         * @static
         * @private
         * @method suspend
         * @return {Boolean}
         */
        Debugger.suspend = function crossfireClient_suspend() {
            var 
                event;
            
            event = {
                type: 'pause',
                context_id: 'context1',
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
            return true;
        };
        
        Debugger.pause = Debugger.suspend;
        
    }


    if (typeof Debugger.resume !== 'function') {

        /**
         * <p>Continue execution of javascript if suspended, if no stepaction is
         * passed, simply resumes execution.</p>
         *
         * <p>Note: not called "continue" because it is a reserved word</p>
         *
         * @static
         * @method resume
         * @param {String} contextId
         */
        Debugger.resume = function crossfireClient_resume(contextId) {
            var 
                event;

            window.console.log('crossfireClient_resume', contextId);
            
            event = {
                type: 'resume',
                context_id: contextId
            };
            
            Debugger.dispatchEvent(event);
            return true;
        };
        
    }
    
    

    if (typeof Debugger.stepIn !== 'function') {

        /**
         * <p>Executes the current statement and pauses at the following statement in the current frame.</p>
         *
         * @static
         * @method stepIn
         */
        Debugger.stepIn = function crossfireClient_stepIn() {
            var 
                event;
            
            Debugger.resume(Debugger.currentContext.id);
            
            event = {
                type: 'enablepanels',
                enabled: true
            };
            
            Debugger.dispatchEvent(event);
            
            event = {
                type: 'pause',
                context_id: Debugger.currentContext.id,
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
        };
    }
    

    if (typeof Debugger.stepOver !== 'function') {

        /**
         * <p>Executes the current statement. If the line of code calls a function or method, the function 
         * or method is executed in the background and the debugger pauses at the statement that follows 
         * the original one.</p>
         *
         * @static
         * @method stepOver
         */
        Debugger.stepOver = function crossfireClient_stepOver() {
            var 
                event;
            
            Debugger.resume(Debugger.currentContext.id);
            
            event = {
                type: 'enablepanels',
                enabled: true
            };
            
            Debugger.dispatchEvent(event);
            
            event = {
                type: 'pause',
                context_id: Debugger.currentContext.id,
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
        };
        
    }
    
    
    if (typeof Debugger.stepOut !== 'function') {

        /**
         * <p>When the debugger is within a function or method, Step Out will execute the code without stepping
         * through the code line by line. The debugger will stop on the line of code following the function or
         * method call in the calling program.</p>
         *
         * @static
         * @method stepOut
         */
        Debugger.stepOut = function crossfireClient_stepOut() {
            var 
                event;
            
            Debugger.resume(Debugger.currentContext.id);
            
            event = {
                type: 'enablepanels',
                enabled: true
            };
            
            Debugger.dispatchEvent(event);
            
            event = {
                type: 'pause',
                context_id: Debugger.currentContext.id,
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
        };
        
    }
    

    if (typeof Debugger.stepNext !== 'function') {

        /**
         * <p>When the debugger is within a function or method, Step Out will execute the code without stepping
         * through the code line by line. The debugger will stop on the line of code following the function or
         * method call in the calling program in the selected frame.</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @static
         * @method stepNext
         */
        Debugger.stepNext = function crossfireClient_stepNext() {
            var 
                event;
            
            Debugger.resume(Debugger.currentContext.id);
            
            event = {
                type: 'enablepanels',
                enabled: true
            };
            
            Debugger.dispatchEvent(event);
            
            event = {
                type: 'pause',
                context_id: Debugger.currentContext.id,
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
        };
        
    }

    
    if (typeof Debugger.stepTo !== 'function') {

        /**
         * <p>The debugger runs until it reaches the line where the cursor is currently located.</p>
         *
         * <p><em>NOT IMPLEMENTED (Lot 3)</em></p>
         *
         * @private
         * @method stepTo
         * @param {Number} position
         * @param {String} url
         */
        Debugger.stepTo = function crossfireClient_stepTo(position, url) {
            var 
                event;
            
            Debugger.resume(Debugger.currentContext.id);
            
            event = {
                type: 'pause',
                context_id: Debugger.currentContext.id,
                frameNumber: 0
            };
            
            Debugger.dispatchEvent(event);
            
            event = {
                type: 'enablepanels',
                enabled: true
            };
            
            Debugger.dispatchEvent(event);
        };
        
    }
    
	if (typeof Debugger.getAccessGroup !== 'function') {
	
		/**
		 * Return Group authorized to access Debugger
		 *
		 * @static
		 * @method getAccessGroup
		 */
		Debugger.getAccessGroup = function crossfireClient_getAccessGroup() {
			
			// FAKE CODE FOR SIMULATION OF SERVER RESPONSE
			window.console.warn(Debugger.iframe + '> FAKE getAccessGroup');
			
		    return {
	            groupName: "testGr1",
				groupUUID: "85E6BC2BF84345A7965BF18261427362"
	        };
		};
	    
	}


	if (typeof Debugger.setAccessGroup !== 'function') {

        /**
         * <p>Save Debugger permission.</p>
         *
         * @method setAccessGroup
         * @param {String} UserGroup (UUID)
         */
        Debugger.setAccessGroup = function crossfireClient_savePermission(userGroup) {
        	
        	//TODO simulate save
        	return true;
        }
	}
	
	if(typeof Debugger.disableAccessGroup !== "function") {
		
		Debugger.disableAccessGroup = function crossfireClient_disableAccessGroup() {
			//Simulate permission reset
			return true;
		}
	}


	if (typeof Debugger.getUserGroups !== 'function') {
	
		/**
		 * Return existant UserGroups
		 *
		 * @static
		 * @method getAccessGroup
		 */
		Debugger.getUserGroups = function crossfireClient_getUserGroups() {
			
			// FAKE CODE FOR SIMULATION OF SERVER RESPONSE
			window.console.warn(Debugger.iframe + '> FAKE getUserGroups');
			
		    return [
				{
					groupName: "testGr1",
					groupUUID: "85E6BC2BF84345A7965BF18261427362"
				},
				{
					groupName: "TestGr2",
					groupUUID: "5348DD06B66E4809AF23561F24B814CB"
				},
				{
					groupName: "testGr3",
					groupUUID: "4BA3D12EE9EA48CB91D79B501F100437"
				},
				{
					groupName: "testGr4",
					groupUUID: "FBF2B22D2E8343A198C0D74EDCE56F59"
				}
			];
		};
	    
	}
    
    
    
__proto__: Object
    if (typeof Debugger.showSource !== 'function') {

        /**
         * Tell the server that de Debugger interface is ready to receive events
         *
         * @static
         * @method showSource
         * @param {String} contextId
         * @param {Number} frameNumber
         */
        Debugger.showSource = function crossfireClient_showSource(contextId, frameNumber) {

            // FAKE CODE FOR SIMULATION OF SERVER RESPONSE
            window.console.warn(Debugger.iframe + '> FAKE showSource');

            if (window.parent === window || $('contentSource').length > 0) {
                Debugger.dispatchEvent(
                    {
                        type: "sourceshown",
                        context_id: contextId,
                        frame: frameNumber
                    }
                );
            }

        };

    }





    /**
     * list of variables and paging informations
     *
     * @class waStudio.Debugger.ObjectStreams
     * @extends Object
     *
     **/
    Debugger.ObjectStreams = Debugger.ObjectStreams || function crossfireClient_ObjectStreams() {

        /**
         * <p>The list of the parameters of the current function</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * <p>Its value is undefined is the current scope is the global scope</p>
         *
         * @property parameters
         * @type waStudio.Debugger.ObjectList|undefined
         */
        this.parameters = new Debugger.ObjectList();

        /**
         * <p>A stream on the list of variables in the current local scope</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property local
         * @type waStudio.Debugger.ObjectStream
         */
        this.local = new Debugger.ObjectStream();

        /**
         * <p>A stream on the list of variables in the current closure scope</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property closure
         * @type waStudio.Debugger.ObjectStream
         */
        this.closure = new Debugger.ObjectStream();

        /**
         * <p>A stream on the list of variables in the global scope</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property global
         * @type waStudio.Debugger.ObjectStream
         */
        this.global = new Debugger.ObjectStream();
    };


    /**
     * list of variables and paging informations
     *
     * @class waStudio.Debugger.ObjectStream
     * @extends Object
     *
     **/
    Debugger.ObjectStream = function () {
        /**
         * <p>The total number of objects in the frame context</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property count
         * @type Number
         */
        this.count = 0;
        
        /**
         * <p>the real index of the first element</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property firstIndex
         * @type Number
         */
        this.firstIndex = 0;
        
        /**
         * <p>The list of objects in the current range</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property list
         * @type ObjectList
         */
        this.list = new Debugger.ObjectList();
    };


    /**
     * list of variables
     *
     * @class waStudio.Debugger.ObjectList
     * @extends Array
     *
     **/
    Debugger.ObjectList = function () {
    
        var index;
        
        /**
         * <p>Description of an object</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property [index]
         * @type waStudio.Debugger.ObjectDescription
         */
        this[index] = new Debugger.ObjectDescription();
    };



    /**
     * Description of an object
     *
     * @class waStudio.Debugger.ObjectDescription
     * @extends Object
     **/
    Debugger.ObjectDescription = function () {

        /**
         * <p>The name of the object or its path</p>
         *
         * <p>ex: "ds" or "ds['emps']" or "ds['emps'][5]"</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property path
         * @type String
         */
        this.path = '';

        /**
         * <p>The type is either a scalar type of a class name</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property type
         * @type String
         */
        this.type = '';
        
        /**
         * <p>The value of the object if it is  a scalar, a preview of its value otherwise</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @property value
         * @type String|Number|Boolean|Null|Object|Array|undefined
         */
        this.value = undefined;
    };







}());
