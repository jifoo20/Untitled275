/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, browser: true, maxerr: 50, indent: 4 */
/*global WAF, waStudio, $, Mustache, alert */


/**
 * Set the debugger skin
 *
 * @param {String} skinName
 * @param {String} skinBackColor
 */
waStudio.onskinchange = function setSkin(skinName, skinBackColor) {
	$('html').css({
		backgroundColor: skinBackColor
	});
};
window.setSkin = waStudio.onskinchange;


$(window.document).ready(function TagParse_Scope() {
	
    // "use strict";

    var
        body,
        Debugger,
        evalSequences,
        eventListeners,
        events,
        crossfireClient_createEvent,
        //fileLogger,
        DEBUG;
    /* ------------------------------------------
     *                    D&D
     * ------------------------------------------
     */
	body = document.body;
	
	$(body).bind("drop", function(e) {
		
		var dropValue;
		
		e.stopPropagation();
		e.preventDefault();
		
		eDrop = e;
		
		if(e.originalEvent.target !== null && e.originalEvent.target.type === "text" && (e.originalEvent.dataTransfer.effectAllowed === 'copy' || e.originalEvent.dataTransfer.effectAllowed === 'all')) {
			dropValue = e.originalEvent.dataTransfer.getData("text/plain");
			
			if(dropValue !== undefined) {
				$(e.originalEvent.target).val($(e.originalEvent.target).val() + dropValue);
			}
			return false;
		}
		
		return false;
	});
	
	var cancel = function(e) {
        if (e.preventDefault) {
            e.preventDefault(); // required by FF + Safari
        }
        e.dataTransfer.dropEffect = 'copy'; // tells the browser what drop effect is allowed here
        
        return false; // required by IE
    }
	
	document.body.ondragenter = function(e) {
		return cancel(e)
	};
	document.body.ondragover = function(e) {
		return cancel(e)
	};


    /**
     * get the current skin from the client & set the debugger skin
     */
    if (typeof waStudio.getSkin === 'function' && typeof waStudio.getSkinBackColor === 'function') {
        window.setSkin(waStudio.getSkin(), waStudio.getSkinBackColor());
    }
    /*
    fileLogger = waStudio.File();
    Debugger.log = function Debugger_log() {

    };
    */
    
    Debugger = waStudio.Debugger;
    Debugger.DEBUG = true;
    Debugger.iframe = window.location.pathname;
    Debugger.iframe = Debugger.iframe.substr(Debugger.iframe.lastIndexOf('/') + 1);
    Debugger.iframe = Debugger.iframe.substr(0, Debugger.iframe.lastIndexOf('.html'));
    Debugger.iframe = Debugger.iframe.substr(5);
    //Mustache = Mustache2;
    //Mustache.to_html = Mustache.toHtml;

    DEBUG = Debugger.DEBUG && true;

    
    evalSequences = Debugger.evalSequences;
    if ($(document.body).hasClass('layout-right')) {
        // to prevent conflicts with the Bottom web area
        evalSequences.length = 100000; 
    }

    Debugger.eventListeners = eventListeners = {};
    Debugger.events = events = [];
    
    /**
     * Set "Debugger" as an "EventTarget" object
     */



    function crossfireClient_dispatchEvent_forEachEventListener(listener, index, listeners) {
        listener(this);
        //listeners.dispatchCount += 1;
    }

    function crossfireClient_dispatchEvent(event) {

        var
            eventName;

        eventName = event.type;

        window.console.log(Debugger.iframe + '> Dispatch received ', eventName, 'event internally:', event, '(request_seq: ' + event.request_seq + ')');

        if (Debugger.events.indexOf(eventName) === -1) {
            crossfireClient_createEvent(eventName);
            return false;
        }

        eventListeners[eventName].forEach(crossfireClient_dispatchEvent_forEachEventListener, event);
        return true;

    }

    crossfireClient_createEvent = function crossfireClient_createEvent(eventName) {

        var
            dom0PropertyName;
            
        if (Debugger.events.indexOf(eventName) === -1) {
            Debugger.events.push(eventName);
        }

        if (!eventListeners.hasOwnProperty(eventName)) {
            eventListeners[eventName] = [];
        }

        dom0PropertyName = 'on' + eventName;

        Debugger[dom0PropertyName] = function crossfireClient_eventHandler(event) {

            window.console.info(Debugger.iframe + '> On "' + event.type + '":', event);

            // TODO: remove this hack
            // actually used to handle oncontextdestroyed before it is fixed
            if (event.type === "event") {
                window.console.warn('the event type "contextcreated" was given througt the "event" property instead of the "type" property');
                event.type = event.event;
                delete event.event;
            }

            crossfireClient_dispatchEvent(event);

        };

        //Debugger[dom0PropertyName].name = 'crossfireClient_' + dom0PropertyName;

    };
    
    Debugger.addEventListener = function crossfireClient_addEventListener(eventName, listener) {
        
        if (!eventListeners.hasOwnProperty(eventName)) {
            crossfireClient_createEvent(eventName);
        }
        eventListeners[eventName].push(listener);
        
    };
    
    Debugger.removeEventListener = function crossfireClient_removeEventListener(eventName, listener) {
        
        var
            listeners,
            index;
        
        if (eventListeners.hasOwnProperty(eventName)) {
            listeners = eventListeners[eventName];
            index = listeners.indexOf(listener);
            if (index !== -1) {
                listeners.splice(index, 1);
            }
        }
        
    };
    
     
    // MANAGE SEQUENCE NUMBER OF "EVALUATED" LISTENERS
    
    Debugger.onevaluate = Debugger.onevaluated = function crossfireClient_onevaluated(event) {
        
        //window.console.info(Debugger.iframe + '> On "' + event.type + '":', event);

        event.relatedTarget = evalSequences[event.request_seq] || {};
        event.target = event.relatedTarget.target;
        
        crossfireClient_dispatchEvent(event);
        
        evalSequences[event.request_seq] = undefined;
        
    };
    
    Debugger.initSelectable = function crossfireClient_initSelectable(parent) {
    	
    	var $selectable,
    		$notSelectable;
    	
    	if(parent === undefined) {
    		
			$notSelectable = $(".not-selectable");
			$selectable = $(".selectable");
		} else {
			
			$notSelectable = $(parent).children(".not-selectable");
			$selectable = $(parent).children(".selectable");
		}
		
		$notSelectable.each(function (index) {
			$(this).bind("selectstart", function(event) {
				return false;
			});
			$(this).bind("select", function(event) {
				return false;
			});
		});
		
		$selectable.each(function (index) {
			$(this).bind("selectstart", function(event) {
				event.stopPropagation();
				return true;
			});
			$(this).bind("select", function(event) {
				event.stopPropagation();
				return true;
			});
		});
    }



    /**
     *  START DEBUGGER COMPONENTS MANAGERS
     **/
    Debugger.tools = Debugger.loadTools();

    // UPCOMING
    /*
    Debugger.modules = {
        tools: Debugger.tools,
        breakpoints: Debugger.loadBreakpoints(),
        contexts: Debugger.loadContexts(),
        watchers: Debugger.loadWatchers(),
        console: Debugger.loadConsole(),
        interpreter: Debugger.loadInterpreter(),
        output: Debugger.loadOutput()
    }
    */

    Debugger.modules.breakpoints = new Debugger.Breakpoints();
    Debugger.manageContexts();
    Debugger.manageWatchers();
    Debugger.manageConsole();
    Debugger.managePermission();
    Debugger.manageInterpreter();
    Debugger.manageOutput();
    
    
    /**
     *  ACTIVATE WAF WIDGETS
     **/
     
    WAF.parseWidgets();
    
    /**
     *  LOAD TEMPLATES
     **/
    
    WAF.ontemplatesloaded = function crossfireClient_ontemplatesloaded() {
    
        Debugger.ready = true;

        /*
        Debugger.dispatchEvent(
            {
                type: 'ready',
                frame: Debugger.iframe
            }
        );
        */

        window.console.log(Debugger.iframe + '> setReady from crossfireClient_ontemplatesloaded');
        Debugger.setReady();
        
    };
    
    WAF.loadTemplates(Debugger.templates);
    
    Debugger.initSelectable();

}); // TagParse_Scope
