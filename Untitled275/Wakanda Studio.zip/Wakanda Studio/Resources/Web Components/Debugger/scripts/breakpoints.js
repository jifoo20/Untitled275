/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true */

// strict: true  // "Require // "use strict";" not updated by JSLint plugin
// devel: true // "Assume console, alert, ..." not supported by JSLint plugin 
// immed: true // "Require parens around immediate invocations" not supported by JSLint plugin

/*global WAF, waStudio, $, Mustache, window, alert */

/**
 * @module Debugger
 * @submodule Breakpoints
 */


// required templates
waStudio.Debugger.templates.push(
    'breakpoint',
    'breakpointManager'
);

// required events
waStudio.Debugger.events.push(
    'ready',
    'scopesreceived',
    'breakpointsupdate',
    'breakpointsloaded',
    'breakpointsdelete',
    'stackready',
    'resume',
    'framechange',
    'ready'
);


/**
 * BREAKPOINTS MANAGER
 *
 * @class waStudio.Debugger.Breakpoints
 * @constructor
 */
waStudio.Debugger.Breakpoints = function Studio_Debugger_Breakpoints() {

    "use strict";
    
    var 
    
        /**
         * A shortcut to the Debugger property of the waStudio
         * 
         * @private
         * @property Debugger
         * @type Debugger
         **/
        Debugger,
        
        /**
         * The list of the breakpoints
         * 
         * @private
         * @property breakpointList
         * @type Array
         **/
        breakpointList, 
        
        /**
         * A DOM table, not exposed in the body, used to receive the result of the template engine
         * 
         * @private
         * @property tmpBreakpointsTable
         * @type HTMLTableElement
         **/
        tmpBreakpointsTable,

        /**
         * A jQuery object referencing the breakpoint panel
         * 
         * @private
         * @property $contentBreakpoints
         * @type Object
         **/
        $contentBreakpoints,

        /**
         * An hidden div container in which is stored the breakpoints panel 
         * when it is not displayed
         * 
         * @private
         * @property hiddenContainer
         * @type HTMLDivElement
         **/
        hiddenContainer,


        /**
         * A jQuery object referencing the hidden container of the breakpoints
         * panel
         * 
         * @private
         * @property $hiddenContainer
         * @type Object
         **/
        $hiddenContainer,
        
        /**
         * A jQuery object referencing the "Enable/Disable All" HTML Checkbox
         * 
         * @private
         * @property $breakpointEnableAll
         * @type Object
         **/
        $breakpointEnableAll,
        
        /**
         * A jQuery object referencing the "Remove All" HTML Form
         * 
         * @private
         * @property $breakpointRemoveAll
         * @type Object
         **/
        $breakpointRemoveAll,
        
        /**
         * A jQuery object referencing the HTML Table Header of the breakpoint list
         * 
         * @private
         * @property $breakpointThead
         * @type Object
         **/
        $breakpointThead, 
        
        /**
         * A jQuery object referencing the HTML Table bodies representing each breakpoint
         * 
         * @private
         * @property $breakpoints
         * @type Object
         **/
        $breakpoints,
        
        /**
         * A jQuery object referencing the "enable/disable" HTML Checkbox of each breakpoint
         * 
         * @private
         * @property $enableCheckboxes
         * @type Object
         **/
        $enableCheckboxes,
        
        /**
         * A jQuery object referencing the "remove" HTML Form of each breakpoint
         * 
         * @private
         * @property $enableCheckboxes
         * @type Object
         **/
        $removeForms,
        
        /**
         * A jQuery object referencing the "remove" HTML Button of each breakpoint
         * 
         * @private
         * @property $removeButtons
         * @type Object
         **/
        $removeButtons, 
        
        /**
         * A jQuery object referencing the "open file" HTML Link of each breakpoint
         * 
         * @private
         * @property $openLinks
         * @type Object
         **/
        $openLinks,

        /**
         * A jQuery object referencing the "empty" HTML Table Body telling there
         * is no breakpoint defined.
         *
         * @private
         * @property $empty
         * @type Object
         **/
        $empty,

        tools,

        contexts,

        isActive,

        DEBUG;


    Debugger = waStudio.Debugger;
    
    DEBUG = waStudio.DEBUG && true;
    
    tools = Debugger.tools;

    contexts = Debugger.contexts;
    
    hiddenContainer = document.createElement('div');
    $hiddenContainer = $(hiddenContainer);
    
    $contentBreakpoints = $("#contentBreakpoints");

    isActive = ($contentBreakpoints.parent().prop('id') !== 'hiddenComponents');
    
    if ($contentBreakpoints.length === 0) {
        hiddenContainer.innerHTML = Mustache.to_html(Debugger.templates.breakpointManager, {});
        $contentBreakpoints = $hiddenContainer.children('#$contentBreakpoints');
    }

    $empty = $contentBreakpoints.find('.waf-empty');


    /**
     * enable_breakpoint_click
     *
     * @private
     * @event enable_breakpoint_click
     * @param {MouseEvent} mouseEvent
     **/
    function enable_breakpoint_click(mouseEvent) {
        
        var 
            target, 
            form;
        
        target = mouseEvent.target;
        form = target.parentNode;
        
        Debugger.enableBreakpoint(form.url.value, Number(form.line.value), target.checked);
        
        // If propagation not stopped, "click" event also catched by tBody calling this handler a second time
        event.stopPropagation();
    }
    
    
    /**
     * enableAll_breakpoint_click
     *
     * @event enableAll_breakpoint_click
     * @param {MouseEvent} mouseEvent
     **/
    function enableAll_breakpoint_click(mouseEvent) {
    
        var
            target,
            enabled;
        
        target = mouseEvent.target;
        enabled = target.checked;
        
        $.each(
            breakpointList,
            function each_enableDisableAll_breakpoint(index, breakpoint) {
                
                Debugger.enableBreakpoint(breakpoint.url, Number(breakpoint.line), enabled);
                
            }
        );
        
        // If propagation not stopped, "click" event also calling enable_breakpoint_click
        mouseEvent.stopPropagation();
    }
    
    
    /**
     * remove_breakpoint_click
     *
     * @event remove_breakpoint_click
     * @param {Event} event
     **/
    function remove_breakpoint_click(event) {
    
        var
            target;
        
        try {
        
            target = event.target.form;
            
            $(target.tBody).remove();
            
            //window.console.error('remove_breakpoint_click', event);
            Debugger.removeBreakpoint(target.url.value, Number(target.line.value));
            
        } catch (e) {
            alert('BUG: ' + JSON.stringify(e));
        }
        
        event.stopPropagation();
        //return false;
        
    }
    
    
    /**
     * removeAll_breakpoint_each
     *
     * @event removeAll_breakpoint_each
     * @param {Number} index
     * @param {Object} breakpoint
     **/
    function removeAll_breakpoint_each(index, breakpoint) {
    
        //window.console.info('removeAll_breakpoint_each', breakpoint);
        Debugger.removeBreakpoint(breakpoint.url, Number(breakpoint.line));
        
    }
    
    
    /**
     * removeAll_breakpoint_submit
     *
     * @event removeAll_breakpoint_submit
     * @param {Event} event
     **/
    function removeAll_breakpoint_submit(event) {
    
        var
            target, 
            enabled;
        
        try {
        
            target = event.target;
            enabled = target.checked;
            
            $breakpoints.remove();
            
            $.each(breakpointList, removeAll_breakpoint_each);
            
        } catch (e) {
            alert('BUG: ' + JSON.stringify(e));
        }
        
        return false;
        
    }
    
    
    
    /**
     * enable_breakpoint_tbody_click
     *
     * @event enable_breakpoint_tbody_click
     * @param {MouseEvent} mouseEvent
     **/
    function enable_breakpoint_tbody_click(mouseEvent) {
    
        mouseEvent.currentTarget.enableCheckbox.click();
        
    }
    
    
    /**
     * Sort breakpoints by Path and by line number
     *
     * @private
     * @method sort_breakpoints
     * @param {Object} x first element to sort
     * @param {Object} y second element to sort
     **/
    function sort_breakpoints(x, y) {
    
        if (x.fullPath > y.fullPath) {
            return 1;
        } else if (x.fullPath < y.fullPath) {
            return -1;
        } else {
            if (x.line > y.line) {
                return 1;
            } else if (x.line < y.line) {
                return -1;
            } else {
                window.console.error('Two breakpoints have the same path and the same line number:', x, y);
                return 0;
                // throw new Error('Two breakpoints have the same path and the same line number');
            }
        }
        
    }



    /**
     * Define a breakpoint as active when the execution is stopped by it
     *
     * @private
     * @method crossfireClient_highlightBreakpoint
     * @param {String} fullPath
     * @param {Number} line
     **/
    function crossfireClient_highlightBreakpoint(fullPath, line) {

        //window.console.info(Debugger.iframe + '> waStudio_crossfireClient_highlightBreakpoint', fullPath, line);

        $breakpoints.each(
            function each_highlight_breakpoint(index, breakpointNode) {

                var
                    breakpoint;

                breakpoint = breakpointList[index];

                if (breakpoint.fullPath === fullPath) {
                    $(breakpointNode).addClass('waf-row-group');
                    if (breakpoint.line === line) {
                        $(breakpointNode).addClass('waf-active');
                    }
                }
            }
        );

    }

    /**
     * crossfireClient_onstackready_breakpointListener
     *
     * @event stackready
     * @param {Event} event
     **/
    function crossfireClient_onstackready_breakpointListener(event) {

        //window.console.info(Debugger.iframe + '> crossfireClient_onstackready_breakpointListener', event);

        var
            context,
            frame;

        context = contexts['#' + event.context_id];

        if (context.isCurrent && context.currentFrame !== undefined) {
            frame = context.currentFrame;
            crossfireClient_highlightBreakpoint(frame.fullPath, frame.line);
        }
    }

    
    
    /**
     * Update the breakpoint list
     *
     * @event breakpointsloaded
     * @param {Event} event first element to sort
     **/
    function crossfireClient_onbreakpointsloaded(event) {

        //window.console.info(Debugger.iframe + '> crossfireClient_onbreakpointsloaded', event);
    
        var
            data,
            nbChecked,
            $tmpBreakpointsTable;
        
        /*
        breakpoints = new Debugger.BreakpointList(data.list);
        */
        
        data = event;
        
        if (data.list && data.list.length) {
            if (data.list[0].scope === "") {
                window.console.warn('Breakpoints: Scope unknown: ', data);
            }
        }
        
        // convert BreakpointList into a sorted Array
        breakpointList = data.list = data.list.slice(0).sort(sort_breakpoints);
        
        // Apply template
        tmpBreakpointsTable.innerHTML = Mustache.to_html(Debugger.templates.breakpoint, data);
        $tmpBreakpointsTable = $(tmpBreakpointsTable);
        // Remove old data
        $breakpoints.remove();
        
        // Get nodes to add interaction
        $breakpoints = $tmpBreakpointsTable.children('tbody');
        // $enableForms = $('form[name=form-breakpoint-enable]', tmpBreakpointsTable);
        $enableCheckboxes = $breakpoints.find('input[name=breakpoint-enable]');
        $removeForms = $breakpoints.find('form[name=form-breakpoint-remove]');
        $removeButtons = $removeForms.find('input[name=breakpoint-remove]');
        $openLinks = $breakpoints.find('td.breakpoint-path > a');

        if ($breakpoints.length === 0) {
            
            $empty.show();

            $breakpointEnableAll.removeClass('indeterminate');
            $breakpointEnableAll[0].checked = false;

            // Activate interaction
            $enableCheckboxes.prop('disabled', true);
            $removeButtons.prop('disabled', true);

        } else {


            $empty.hide();
            
            $breakpoints.each(
                function append_each_breakpoint(index, tBody) {

                    var
                        enableCheckbox,
                        removeForm;

                    enableCheckbox = $enableCheckboxes[index];
                    removeForm = $removeForms[index];

                    tBody.enableCheckbox = enableCheckbox;

                    enableCheckbox.tBody = tBody;
                    removeForm.tBody = tBody;

                    if (enableCheckbox.checked) {
                        $(tBody).removeClass('waf-disabled');
                    } else {
                        $(tBody).addClass('waf-disabled');
                    }

                    $contentBreakpoints.append(tBody);

                }
            );

            nbChecked = $enableCheckboxes.filter(':checked').length;
            if ((nbChecked > 0) && (nbChecked < $enableCheckboxes.length)) {
                $breakpointEnableAll.addClass('indeterminate');
            } else {
                $breakpointEnableAll.removeClass('indeterminate');
                $breakpointEnableAll[0].checked = (nbChecked > 0);
            }

            // Activate interaction
            $enableCheckboxes.removeProp('disabled');
            $removeButtons.removeProp('disabled');
        }

        if (Debugger.hasOwnProperty('currentContext') && Debugger.currentContext.hasOwnProperty('currentFrame') && Debugger.currentContext.id !== undefined) {
            crossfireClient_onstackready_breakpointListener({type: 'stackready', context_id: Debugger.currentContext.id});
        }

    }
    

    function crossfireClient_onresume_breakpointListener(event) {

        //window.console.info(Debugger.iframe + '> crossfireClient_onresume_breakpointListener', event);

        $breakpoints.removeClass('waf-active');
        $breakpoints.removeClass('waf-row-group');

    }

    function crossfireClient_onready_breakpointListener(event) {

        //window.console.info(Debugger.iframe + '> crossfireClient_onready_breakpointListener', event);

        window.console.log(Debugger.iframe + '> getBreakpoints from crossfireClient_onready_breakpointListener', event);
        if (isActive) {
            Debugger.getBreakpoints();
        }

    }

    $breakpoints = $contentBreakpoints.children("tbody").not('.waf-empty');
    $breakpointThead = $contentBreakpoints.children("thead");

    $breakpointEnableAll = $breakpointThead.find("input[name=breakpoint-enable]");
    $breakpointRemoveAll = $breakpointThead.find("input[name=breakpoint-remove]");

    // add event handlers

    $breakpointEnableAll.click(enableAll_breakpoint_click);
    $breakpointRemoveAll.click(removeAll_breakpoint_submit);

    $contentBreakpoints.delegate('breakpoint', 'click', enable_breakpoint_tbody_click);
    $contentBreakpoints.delegate('input[name=breakpoint-enable]', 'click', enable_breakpoint_click);
    $contentBreakpoints.delegate('input[name=breakpoint-remove]', 'click', remove_breakpoint_click);
    $contentBreakpoints.delegate('td.breakpoint-path > a', 'click', tools.openFile_click);

    tmpBreakpointsTable = document.createElement('table');

    if (isActive) {
        Debugger.addEventListener('breakpointsloaded', crossfireClient_onbreakpointsloaded);
        Debugger.addEventListener('breakpointsdelete', crossfireClient_onbreakpointsloaded);
        Debugger.addEventListener('breakpointsupdate', crossfireClient_onbreakpointsloaded);
        Debugger.addEventListener('stackready', crossfireClient_onstackready_breakpointListener);
        Debugger.addEventListener('framechange', crossfireClient_onstackready_breakpointListener);
        Debugger.addEventListener('resume', crossfireClient_onresume_breakpointListener);
        Debugger.addEventListener('ready', crossfireClient_onready_breakpointListener);
    } else {
        Debugger.addEventListener('breakpointsloaded', tools.ignore);
        Debugger.addEventListener('breakpointsdelete', tools.ignore);
        Debugger.addEventListener('breakpointsupdate', tools.ignore);
        Debugger.addEventListener('stackready', tools.ignore);
        Debugger.addEventListener('framechange', tools.ignore);
        Debugger.addEventListener('resume', tools.ignore);
        Debugger.addEventListener('ready', tools.ignore);
    }

    Debugger.panels.push($contentBreakpoints);
    Debugger.panels.breakpoints = $contentBreakpoints;
    
}; // End Scope_Breakpoints








/* FAKE BREAKPOINT INTERFACE */
(function FakeBrepointsInterface_Scope() {

    var

        Debugger,
        fakeBreakpointList,
        fakeBreakpointId;

    Debugger = waStudio.Debugger;
    fakeBreakpointId = 0;

    if (typeof Debugger.getBreakpoints !== 'function') {

        /**
         * <p>Ask to load the breakpoints.</p>
         *
         * @static
         * @method getBreakpoints
         */
        Debugger.getBreakpoints = function crossfireClient_getBreakpoints() {

            var
                breakpointEvent;

            fakeBreakpointList = new Debugger.BreakpointList(
                // new Debugger.Breakpoint(id, url, line, enabled, condition, lineContent, scope),
                {
                    url: "../walib/WAF/Tag/tag.js",
                    fullPath: "C:\\pokpok\\françois\\walib\\WAF\\Tag\\tag.js",
                    line: 12,
                    lineContent: "i += 1 / 5;"
                },
                {
                    url: "../walib/WAF/Tag/Loader.js",
                    fullPath: "C:\\pokpok\\françois\\walib\\WAF\\Tag\\Loader.js",
                    line: 37,
                    enabled: false,
                    condition: "a === 5",
                    lineContent: "Debugger.onbreakpointsloaded = function onbreakpointsloaded(event) { ",
                    scope: "TagParse_Scope()"
                },
                {
                    url: "../walib/WAF/Tag/Loader.js",
                    fullPath: "C:\\pokpok\\françois\\walib\\WAF\\Tag\\Loader.js",
                    line: 51,
                    enabled: false,
                    lineContent: "Debugger.onbreakpointsloaded = function onbreakpointsloaded(event) { ",
                    scope: "TagParse_Scope()"
                },
                {
                    url: "../walib/WAF/Tag/Loader.js",
                    fullPath: "C:\\pokpok\\françois\\walib\\WAF\\Tag\\Loader.js",
                    line: 83,
                    enabled: false,
                    condition: "a === 5",
                    lineContent: "Debugger.onbreakpointsloaded = function onbreakpointsloaded(event) { ",
                    scope: "TagParse_Scope()"
                },
                {
                    url: "./panel.js",
                    fullPath: "C:\\pokpok\\françois\\test\\panel.js",
                    line: 42,
                    lineContent: "function (index, element) {",
                    scope: "init(config)"
                },
                {
                    url: "./mustache.js",
                    fullPath: "C:\\pokpok\\françois\\test\\mustache.js",
                    line: 51,
                    enabled: false,
                    lineContent: "return template.replace(regex, function(match, pragma, options) {",
                    scope: "render_pragmas(config)"
                }
            );

            /*
            breakpointEvent = new Debugger.Event();
            breakpointEvent = breakpointEvent.initDebuggerEvent("breakpointsloaded", false, false);
            breakpointEvent.list = fakeBreakpointList;
            */

            breakpointEvent = {
                type: "breakpointsloaded",
                list: fakeBreakpointList
            }

            Debugger.dispatchEvent(breakpointEvent);
        };
    }



    if (typeof Debugger.removeBreakpoint !== 'function') {

        /**
         * <p>Ask to remove a breakpoint.</p>
         *
         * @static
         * @method removeBreakpoint
         * @param {String} url
         * @param {Number} line
         **/
        Debugger.removeBreakpoint = function crossfireClient_removeBreakpoint(url, line) {

            var
                breakpointEvent;

            $.each(
                fakeBreakpointList,
                function crossfireClient_eachRemoveBreakpoint(index, element) {

                    if (element.url === url && element.line === line) {
                        fakeBreakpointList.splice(index, 1);
                        return false;
                    }
                    return true;

                }
            );

            breakpointEvent = new Debugger.Event();
            breakpointEvent = breakpointEvent.initDebuggerEvent("breakpointsloaded", false, false);
            breakpointEvent.list = fakeBreakpointList;

            Debugger.dispatchEvent(breakpointEvent);
        };

    }
    Debugger.removeBreakpoint.name = "crossfireClient_removeBreakpoint";


    if (typeof Debugger.enableBreakpoint !== 'function') {

        /**
         * <p>Ask to enable/disable a breakpoint.</p>
         *
         * @static
         * @method enableBreakpoint
         * @param {String} url
         * @param {Number} line
         * @param {Boolean} enabled
         **/
        Debugger.enableBreakpoint = function crossfireClient_enableBreakpoint(url, line, enabled) {

            var
                breakpointEvent;

            $.each(
                fakeBreakpointList,
                function enableBreakpoint_each(index, element) {

                    if (element.url === url && element.line === line) {
                        element.enabled = enabled;
                        return false;
                    }
                    return true;

                }
            );

            breakpointEvent = new Debugger.Event();
            breakpointEvent = breakpointEvent.initDebuggerEvent("breakpointsloaded", false, false);
            breakpointEvent.list = fakeBreakpointList;

            Debugger.dispatchEvent(breakpointEvent);

        };

    }
    Debugger.enableBreakpoint.name = "crossfireClient_enableBreakpoint";


    if (typeof Debugger.setBreakpointCondition !== 'function') {

        /**
         * <p>Ask to set a condition to a breakpoint.</p>
         *
         * <p><em>NOT IMPLEMENTED</em></p>
         *
         * @static
         * @method setBreakpointCondition
         * @param {String} url
         * @param {Number} line
         * @param {String} condition
         */
        Debugger.setBreakpointCondition = function crossfireClient_setBreakpointCondition(url, line, condition) {

            var
                breakpointEvent;

            $.each(
                fakeBreakpointList,
                function (index, element) {

                    if (element.url === url && element.line === line) {
                        element.condition = condition;
                        return false;
                    }
                    return true;

                }
            );

            breakpointEvent = new Debugger.Event();
            breakpointEvent = breakpointEvent.initDebuggerEvent("breakpointsloaded", false, false);
            breakpointEvent.list = fakeBreakpointList;

            Debugger.dispatchEvent(breakpointEvent);

        };
    }
    Debugger.setBreakpointCondition.name = "crossfireClient_setBreakpointCondition";


    if (typeof Debugger.onbreakpointsloaded !== 'function') {

        /**
         * <p>Fired when the list of breakpoints has been received</p>
         *
         * <pre name="code" class="js">
         * // on Debugger Window open, declare a "willexecuteprogram" event handler
         * function onWillExecuteProgram(event) {
         * &nbsp;   var context;
         * &nbsp;   context = new Debugger(event.data.id);
         * &nbsp;   DEBUG.addContext(context);
         * }
         * &nbsp;
         * // Using the "onbreakpointsloaded" property
         * Debugger.onwillexecuteprogram = onWillExecuteProgram;
         * &nbsp;
         * // Or using the EventTarget API on the "willexecuteprogram" event (allow to add several handlers)
         * Debugger.addEventListener("willexecuteprogram", onWillExecuteProgram);
         * </pre>
         *
         * @static
         * @protected
         * @event onbreakpointsloaded
         * @param {waStudio.Debugger.Event} event
         **/
        Debugger.onbreakpointsloaded = function crossfireClient_onbreakpointsloaded(event) {

        };

    }



    if (typeof Debugger.onbreakpointsupdate !== 'function') {

        /**
         * <p>Returns a list of breakpoints if any is updated.</p>
         *
         * @static
         * @protected
         * @event onbreakpointsupdate
         * @param {waStudio.Debugger.Event} event
         */
        Debugger.onbreakpointsupdate = function crossfireClient_onbreakpointsupdate(event) {

        };

    }


    if (typeof Debugger.onbreakpointsdelete !== 'function') {

        /**
         * <p>Returns a list of breakpoints if any is deleted.</p>
         *
         * @static
         * @protected
         * @event onbreakpointsdelete
         * @param {waStudio.Debugger.Event} event
         */
        Debugger.onbreakpointsdelete = function crossfireClient_onbreakpointsdelete(event) {

        };

    }


    if (typeof Debugger.BreakpointList === "undefined") {

        /**
         * <p>Create a breakpoint and return it.</p>
         *
         * <p><em>(use the setBreakpoint crossfire command)</em></p>
         *
         * <p>The breakpoint is automatically update if one of these properties is changed:
         * <code>line</code>, <code>enabled</code>, <code>condition</code> (other properties
         * are read-only)</p>
         *
         * <p>An <code>update</code> event is dispatched if the breakpoint is somehow modified from
         * anyone</p>
         *
         *
         * @class waStudio.Debugger.Breakpoint
         * @extends EventTarget
         *
         * @constructor
         * @param {String} id
         * @param {String|waStudio.File|Object} url Path of the file in witch is defined the breakpoint (if in a file)
         * @param {Number} line Line number on which the breakpoint is set in the targeted source code
         * @param {Boolean} enabled Initial status of the breakpoint
         * @param {String} condition JavaScript Boolean expression
         * @param {String} lineContent Content of the line of the script where the breakpoint has been set
         * @param {String} scope Signature of the function in which scope has been set the breakpoint
         * @param {String} fullPath
         **/
        Debugger.Breakpoint = function Debugger_Breakpoint(id, url, line, enabled, condition, lineContent, scope, fullPath) {

            fakeBreakpointId += 1;

            /**
             * <p>Unique id of the breakpoint</p>
             *
             * <p>Read-Only</p>
             *
             * <p><em>NOT IMPLEMENTED</em></p>
             *
             * @property id
             * @type String
             */
            this.id = id || String(fakeBreakpointId);

            /**
             * <p>This property is set to "false" if the breakpoint is disabled</p>
             *
             * <p>Read-Write (using to the changeBreakpoint crossfire command)</p>
             *
             *
             * @property enabled
             * @type Boolean
             */
            this.enabled = typeof enabled === "boolean" ? enabled : true;

            /**
             * <p>This property is a Javscript expression which Boolean result is tested before pausing the execution on this breakpoint</p>
             *
             * <p>Read-Write (using to the changeBreakpoint crossfire command)</p>
             *
             * <p><em>NOT IMPLEMENTED (Lot 3)</em></p>
             *
             * @property condition
             * @type String
             */
            this.condition = condition || "";

            /**
             * <p>This path specify in which file the breakpoint has been set</p>
             *
             * <p>Read-Only</p>
             *
             *
             * @property url
             * @type String
             */
            this.url = url || "";

            /**
             * <p>The name of the file in which the breakpoint has been set</p>
             *
             * <p>Read-Only</p>
             *
             * <p><em>NOT IMPLEMENTED</em></p>
             *
             * @property fileName
             * @type String
             */
            this.fileName = this.url.substr(this.url.lastIndexOf('/') + 1);

            /**
             * <p>This fullPath specify in which file the breakpoint has been set</p>
             *
             * <p>Read-Only</p>
             *
             *
             * @property fullPath
             * @type String
             */
            this.fullPath = fullPath || this.fileName;

            /**
             * <p>This number specify on which line the breakpoint has been set</p>
             *
             * <p>Read-Write (using to the changeBreakpoint crossfire command)</p>
             *
             *
             * @property line
             * @type Number
             */
            this.line = line || 0;

            /**
             * <p>This string is the content of the line on which the breakpoint is set</p>
             *
             * <p>Read-Only</p>
             *
             * <p><em>NOT IMPLEMENTED</em></p>
             *
             * @property lineContent
             * @type String
             */
            this.lineContent = lineContent || "";

            /**
             * <p>If the breakpoint is set in the scope of a function, this property gives its signature.</p>
             *
             * <p>Read-Only</p>
             *
             * <p><em>NOT IMPLEMENTED</em></p>
             *
             * @property scope
             * @type String
             */
            this.scope = scope || "[Global Scope]";

        };


        /**
         * <p>Event dispatched when a breakpoint as been modified</p>
         *
         * <p>The <code>event</code> parameter is an Event object with these properties:</p>
         * <dl>
         *   <dt>type</dt><dd>A String which value is "update"</dd>
         *   <dt>data</dt><dd>An instance with updated data of the Breackpoint object which properties are the new values</dd>
         * </dl>
         *
         * @event onupdate
         * @param {Event} event
         */
        Debugger.Breakpoint.prototype.onupdate = function Debugger_Breakpoint_onupdate(event) {};




        /**
         * list of variables
         *
         * @class waStudio.Debugger.BreakpointList
         * @extends Array
         *
         *
         * @constructor
         * @param {waStudio.Debugger.Breakpoint} breakpoints
         **/
        Debugger.BreakpointList = function Debugger_BreakpointList(breakpoints) {

            var self, list;

            self = this;
            this.length = 0;

            list = arguments[0].constructor === Array ? arguments[0] : arguments;

            /**
             * <p>Description of an object</p>
             *
             * <p><em>NOT IMPLEMENTED</em></p>
             *
             * @property [index]
             * @type waStudio.Debugger.Breakpoint
             */
            $.each(
                arguments,
                function (index, element) {
                    self.push(
                        // id, url, line, enabled, condition, lineContent, scope
                        new Debugger.Breakpoint(element.id, element.url, element.line, element.condition, element.enabled, element.lineContent, element.scope, element.fullPath)
                    );
                    this.length += 1;
                }
            );
        };
        Debugger.BreakpointList.prototype = [];
        Debugger.BreakpointList.prototype.constructor = Debugger.BreakpointList;

    }



    /**
     * <p>Remove the breakpoint object with the specified id.</p>
     *
     * <p><em>NOT IMPLEMENTED</em></p>
     *
     * <p><em>NOTE: using to the clearBreakpoint crossfire command</em></p>
     *
     * @method remove
     * @param {waStudio.Debugger.Breakpoint|String} breakpoint breakpoint id or DebugerBreapoint object
     * @return {Boolean} true if the breakpoint was successfuly removed
     */
    Debugger.Breakpoint.prototype.remove = function Debugger_Breakpoint_remove(breakpoint) {
        return true;
    };




}());