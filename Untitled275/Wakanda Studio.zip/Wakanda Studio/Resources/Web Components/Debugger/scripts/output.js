/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*global WAF, waStudio, $, Mustache */


/**
 * MANAGE CONSOLE
 *
 * @static
 * @shared
 * @method manageConsole
 */
waStudio.Debugger.manageOutput = function crossfireClient_manageOutput() {

    var
        Debugger,
        console,
        config,
        evalSequences,
        //$consoleTBody,
        objectOwners,
        $contentOutput,
        $outputContainer;
    
    
    Debugger = waStudio.Debugger;
    
    console = waStudio.console;
    
    config = Debugger.config.output = {
        //delegatedExpand: true,
        indent: 19
    };
    
    evalSequences = Debugger.evalSequences;
    
    objectOwners = {};

    /*
    Debugger.templates.push(
        'consoleMessage',
        'consoleLogRun',
        'previewInLine'
    );
    */
    
    $contentOutput = $('#contentOutput');
    $outputContainer = $contentOutput.parent();
    //$consoleTBody = $contentConsole.children().filter('tbody');


    function crossfireClient_output_fillHtml(obj, level, pos, inarray, params) {
        
        var
            html,
            prop,
            subobj;

        html = "";

        function crossfireClient_output_fillHtml_forEachArrayRow(subobj, index, obj) {

            html += '  <tr>';
            html += '    <td>';
            html += '      <div class="arrayelem">';
            html += crossfireClient_output_fillHtml(subobj, level + 1, 0, true, params);
            html += '      </div>';
            html += '    </td>';
            html += '  </tr>';
            
        }

        

        if (obj === null) {

            html += '<b>null</b>' + '   ';

        } else {

            switch (typeof obj) {

            case 'object':

                if (obj.constructor === Array) {

                    html += '<table class="array" border="1" cellspacing=3" cellpadding="3">';

                    obj.forEach(crossfireClient_output_fillHtml_forEachArrayRow);

                    html += '</table>';

                } else {

                    if (!inarray) {
                        html += '<table class="objet" border="0">';
                    }

                    for (prop in obj) {

                        if (obj.hasOwnProperty(prop)) {
                            
                            if (inarray) {

                                html += '<td>';

                            } else {

                                html += '<tr>';
                                html += '<td>';

                            }

                            params.curid += 1;

                            html += '<table class="prop" border="0">';
                            html += '  <tr valign="top">';
                            html += '    <td>';
                            html += '      <div class="prop" xprop="propval' + params.curid + '"> <b>' + prop + ': </b></div>';
                            html += '    </td>';
                            html += '    <td>';

                            subobj = obj[prop];

                            if (typeof subobj === 'object' && subobj !== null) {
                                if (subobj.constructor === Array) {

                                    html += '<div id="propval' + params.curid + '" class="subarray">';

                                } else {

                                    html += '<div id="propval' + params.curid + '" class="subobject">';

                                }
                            } else {

                                html += '<div id="propval' + params.curid + '" class="subelem">';

                            }

                            html += crossfireClient_output_fillHtml(subobj, level + 1, 0, false, params);

                            html += '      </div>';
                            html += '    </td>';
                            html += '  </tr>';
                            html += '</table>';

                            if (inarray) {
                                html += '</td>';
                            } else {
                                html += '</td>';
                                html += '</tr>';
                            }
                        }

                    }

                    if (!inarray) {
                        html += '</table>';
                    }
                }
                break;

            case "string":
                html += '"' + obj + '"' + '   ';
                break;

            case "number":
                html += '<i>' + obj + '</i>' + '   ';
                break;

            default:
                html += obj + '   ';
            }
        }

        return html;
    }


    function crossfireClient_output_property_click(event) {

        var
            objclick,
            target;

        objclick = this; //event.target;
        target = objclick.getAttribute("xprop");

        $('#' + target).toggle();

    }

    $contentOutput.delegate('.debug-output-prop', 'click', crossfireClient_output_property_click);

    
    function crossfireClient_output_displayDataToOutput(data) {
        
        var 
            html;

        html = crossfireClient_output_fillHtml(data, 0, 0, false, {curid : 0});

        $contentOutput.children().remove();
        $contentOutput.html(html);


    }
    
    
    
    
    /**
     * onevaluated
     *
     * @static
     * @method onevaluated
     * @param {Event} event
     **/
    function crossfireClient_onevaluated_outputListener(event) {
        
        var
            data;
           
        
        // result router
        switch (event.target) {

        case Debugger.RUN_SSJS:
        case Debugger.EVAL_COMMAND:
            
            //window.console.info(Debugger.iframe + '> crossfireClient_onevaluated_outputListener : ', event);
            
            data = event.body;
            
            crossfireClient_output_displayDataToOutput(data);
            break;
            
        default:
            // nothing
            
        }
        
        return false;
        
    }
    

    if ($outputContainer.prop('id') !== 'hiddenComponents') {
        Debugger.addEventListener('evaluated', crossfireClient_onevaluated_outputListener);
    } else {
        Debugger.addEventListener('evaluated', Debugger.tools.ignore);
    }
    
    
};

