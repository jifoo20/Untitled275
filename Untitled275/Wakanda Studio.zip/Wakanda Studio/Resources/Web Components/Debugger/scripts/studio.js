/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, devel: true, evil: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, immed: true */

var
    waStudio;



(function scope_waStudio() {

    // "use strict";

    /**
     * @class WakandaStudio
     * @extends Object
     *
     * @constructor
     * @param {DOMWindow} window
     */
    function WakandaStudio(window) {

        /**
         * @property window
         * @type DOMWindow
         */
        this.window = window;

        /**
         * @property console
         * @type Console
         */
        this.console = window.console;
    }


    /**
     * @method openFile
     * @param {String} path
     * @param {Number} line
     */
    WakandaStudio.prototype.openFile = function waStudio_openFile(path, line) {

        // "use strict";

        this.log(Debugger.iframe + '> Open File: "' + path + '" at line ' + line);

    };


    /**
     * @method log
     * @param {Mixed} message
     */
    WakandaStudio.prototype.log = function waStudio_log(message) {

        // "use strict";

        this.console.log.apply(this.console, arguments);

    };

    /**
     * @method debug
     * @param {Mixed} message
     */
    WakandaStudio.prototype.debug = function waStudio_debug(message) {

        // "use strict";

        this.console.debug.apply(this.console, arguments);

    };


    /**
     * @method debug
     * @param {Mixed} message
     */
    WakandaStudio.prototype.debug = function waStudio_debug(message) {

        // "use strict";

        this.window.console.debug.apply(this.window.console, arguments);

    };

    /**
     * @method openFile
     * @param path
     * @param line
     */
    WakandaStudio.prototype.openFile = function waStudio_openFile(path, line) {

        // "use strict";

        this.window.console.log(Debugger.iframe + '> Open File: "' + path + '" at line ' + line);

    };



    waStudio = (typeof studio !== 'undefined') ? studio : new WakandaStudio(window);
    

    /**
     * @class waStudio.EventTarget
     * @extends Object
     *
     * @constructor
     */
    waStudio.EventTarget = function EventTarget() {

    };

    /**
     * @method addEventListener
     * @param {String} type
     * @param {Function} listener
     */
    waStudio.EventTarget.prototype.addEventListener = function waStudio_EventTarget_addEventListener(type, listener) {

    };

    /**
     * @method dispatchEvent
     * @param {Object} event
     */
    waStudio.EventTarget.prototype.dispatchEvent = function waStudio_EventTarget_dispatchEvent(event) {

    };

    /**
     * @method removeEventListener
     * @param {String} type
     * @param {Function} listener
     */
    waStudio.EventTarget.prototype.removeEventListener = function waStudio_EventTarget_removeEventListener(type, listener) {

    }

}());

