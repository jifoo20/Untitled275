/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*jslint white: true, browser: true, onevar: true, undef: true, nomen: true, eqeqeq: true, plusplus: true, bitwise: true, regexp: true, newcap: true, strict: true */

// devel: true // "Assume console, alert, ..." not supported by JSLint plugin 
// immed: true // "Require parens around immediate invocations" not supported by JSLint plugin

/*global WAF, waStudio, $, Mustache, window, alert */

/**
 *  MANAGE GLOBAL OBJECT
 *
 * @static
 * @method manageGlobalObject
 **/
waStudio.Debugger.manageGlobalObject = function Debugger_manageGlobalObject() {
    
    // "use strict";

    var
        Debugger,
        config,
        $contentGlobalObject,
        $globalObjectContainer,
        objectOwners,
        expandedObjects,
        $watchers,
        tmpGlobalObjectTable,
        $tmpGlobalObjectTable,
        tmpGlobalObjectPropertiesTable,
        $tmpGlobalObjectPropertiesTable,
        $emptyElementsTable,
        $columnHeads,
        $globalObject,
        evalSequences,
        sorters,
        path;
    
    Debugger = waStudio.Debugger;
    
    Debugger.config.watchers = {
        indent: 19,
        delegatedExpand: true,
        groupFunctions: true,
        groupOwnProperties: true,
        sortBy: "name",
        sortOrder: 1
    };
    config = Debugger.config.watchers;


    Debugger.templates.push(
        'watcher'
    );

    Debugger.events.push();

    
    objectOwners = {};
    expandedObjects = {};

    evalSequences = Debugger.evalSequences;
    if (typeof evalSequences === 'undefined') {
        evalSequences = [];
    }

    $contentGlobalObject = $("#contentGlobalObject");
    if ($contentGlobalObject && $contentGlobalObject.length > 0) {
        $contentGlobalObject.treeTable(config);
    }
    $globalObjectContainer = $contentGlobalObject.parent();
    $columnHeads = $contentGlobalObject.children('thead').children().first();

    $globalObject = $('#globalObject');
    $globalObject.path = '(application)';
    $globalObject.data('path', $globalObject.path);

    $globalObject.target = Debugger.GLOBAL_WATCHER;
    $globalObject.name = 'application';
    $globalObject.uuid = 'globalObject';
    $globalObject.$rows = $($globalObject);
    $globalObject.$children = $('.child-of-' + sectionId);
    $globalObject.$rows.add($globalObject.$children);
    $globalObject.$expander = $globalObject.find('.expander');
    $globalObject.$loading = $globalObject.$children.filter('.waf-loading');
    $globalObject.$empty = $globalObject.$children.filter('.waf-empty');

    objectOwners[$globalObject.path] = $globalObject;

    
    /*
     *  SET SORT BY COLUMN HANDLERS
     */
    $columnHeads.find('nth-child(0)').click(
        function watcherNameColumnClick(mouseEvent) {}
    );
    
    
    
    /**
     * updateGlobalObject
     *
     * @private
     * @method updateGlobalObject
     **/
    function updateGlobalObject() {
        var
            expression;
        
        window.console.debug('update Global Object');
        
        expression = {
            name: $globalObject.path,
            target: Debugger.GLOBAL_OBJECT
        }
        
        Debugger.currentContext.currentFrame.evaluate(expression);
        
    }
    
    
    /*
     *  MANAGE TOGGLE GLOBALY
     */

    /**
     * toggle_objNode
     *
     * @private
     * @event toggle_objNode
     * @param {Event} mouseEvent
     **/
    function toggle_objNode(mouseEvent) {
    
        var
            $row,
            obj,
            uuid,
            path;
        
        mouseEvent.preventDefault();
        
        window.console.info('Global Object - toggle objNode:', mouseEvent);
        
        $row = $(mouseEvent.target).parent().parent();
        
        window.console.info('Global Object - toggle objNode - $row, objectOwners:', $row, objectOwners);
        
        path = $row.data('path');
        obj = objectOwners[path];
        
        if ($row.hasClass("collapsed")) {
            
            // Object properties
            $row.expand();

            // Hide empty row
            if (!('$empty' in obj)) {
                uuid = $row.prop('id');
                obj.$empty = $watchers.children('.child-of-' + uuid).filter('.empty');
            }
            obj.$empty.hide();
                
            if ($row.prop('id') !== 'globalObject') {
                
                obj.handle = $row.data('handle');
                expandedObjects[path] = obj;
                
                Debugger.currentContext.currentFrame.getObjectProperties(obj);
                
                return;
            
            }
                
            // Global Object
            
            updateGlobalObject();
            
            
        } else {

            // TODO: remove this hack
            // We shouldn't need to remove manually the 'expanded' class
            $row.collapse().removeClass('expanded');
            $row.$children.hide();
            $row.$rows.hide();

            delete expandedObjects[path];
        }
        
    }
    
    $contentGlobalObject.delegate('.expander', 'click', toggle_objNode);

    
    /*
     *  MANAGE WATCH EXPRESSION
     */
     
    tmpGlobalObjectTable = document.createElement('table');
    $tmpGlobalObjectTable = $(tmpGlobalObjectTable);
    tmpGlobalObjectPropertiesTable = document.createElement('table');
    $tmpGlobalObjectPropertiesTable = $($tmpGlobalObjectPropertiesTable);
    $emptyElementsTable = $(document.createElement('table'));
    
    
    
    /**
     * unreferenceOwners
     *
     * @private
     * @event unreferenceOwners
     * @param {Object} owner
     **/
    function unreferenceOwners(owner) {
        if (owner.properties) {
            owner.properties.forEach(unreferenceOwners);
        }
        if (owner.path) {
            delete objectOwners[owner.path];
        }
    }
    
    
    
    

    
    sorters = {
    
        /**
         * sortProperties
         *
         * @private
         * @method sortProperties
         * @param {String} elem1
         * @param {String} elem2
         * @return {Number}
         **/
        sortProperties: function sortProperties(elem1, elem2) {
            var
                sortOrder;

            sortOrder = config.sortOrder;

            if (elem1 < elem2) {
                return -1 * sortOrder;
            }
            if (elem1 > elem2) {
                return 1 * sortOrder;
            }
            // a must be equal to b
            return 0;
        },

        /**
         * sortPropertiesAsIndexes
         *
         * @private
         * @method sortPropertiesAsIndexes
         * @param {String} elem1
         * @param {String} elem2
         * @return {Number}
         **/
        sortPropertiesAsIndexes: function sortPropertiesAsIndexes(elem1, elem2) {

            return (elem1 - elem2) * config.sortOrder;

        }
    };

    sorters.byname = {
        asName: function sortPropertiesByName(elem1, elem2) {
            return sorters.sortProperties(elem1, elem2);
        },
        asIndex: function sortPropertiesByName(elem1, elem2) {
            return sorters.sortPropertiesAsIndexes(elem1, elem2);
        }
    };


    
    /*
     *  LOAD WATCH EXPRESSIONS
     */
    
    /**
     * onevaluated
     *
     * @static
     * @method onevaluated
     * @param {Object} event
     **/
    function crossfireClient_onevaluated_globalObjectListener(event) {
        
        var
            $rows,
            list,
            found;

        window.console.info('watchers Evaluated: ', event);

        // result router
        if (event.target === Debugger.GLOBAL_WATCHERS) {
            
            window.console.info('On Global Object Evaluate: ', event);
            
            found = ('$rows' in $globalObject);
            
            Debugger.tools.createPreviewLevel1($globalObject, event.body, objectOwners, config);
                        
            if (found) {
                $globalObject.$rows.empty().remove();
                $globalObject.empty().remove();
            }
            
            list = {
                objects: [$globalObject],
                empty: false,
                indent: config.indent,
                comma: ', '
            };
            
            // Apply template
            tmpGlobalObjectTable.innerHTML = Mustache.to_html(Debugger.templates.watcher, list);
            
            // Create references

            $rows =
            $globalObject.$rows = $tmpGlobalObjectTable.children().children();

            $globalObject.add($globalObject.$rows.first());

            $globalObject.$loading = $rows.filter('.waf-loading');
            $globalObject.$empty = $rows.filter('.waf-empty');
            $globalObject.$expander = $rows.first().find('.expander');
            
            // restore expanded status
            if ($globalObject.hasProperties && ($globalObject.path in expandedObjects)) {
                $globalObject.$expander.click();
            }
            
        }
        
        return false;
        
    }


    
    /*
     *  LOAD OBJECT PROPERTIES
     */
    
    function parentSetRows(index, element) {
        var
            $element,
            $children,
            obj,
            path;
        
        $element = $(element);
        
        path = $element.data('path');
        if (!path) {
            window.console.error('path not available:', element);
            return false;
        } 
        
        obj = objectOwners[path];
        element.obj = obj;
        $children = $tmpGlobalObjectPropertiesTable.$rows.filter('.child-of-' + element.id);
        
        obj.$rows = $element;
        obj.$rows.add($children);
        obj.$loading = $children.filter('.waf-loading');
        obj.$empty = $children.filter('.waf-empty');
        obj.$expander = $element.find('.expander');
        
        return true;
        
    }
    
    function propertyAutoExpand(index, element) {
        var
            obj;
        
        obj = element.obj;
        
        if (obj.path in expandedObjects) {
            obj.$expander.click();
        }
        
    }
    
    
    
    

    function crossfireClient_onobjectpropertiesreceived_globalObjectListener(event) {

        var
            list,
            owner,
            properties,
            propertyNames,
            // data,
            $last,
            $children,
            $parents,
            // oldPropertyNames,
            sorter,
            innerSorters;

        owner = evalSequences[event.request_seq] || {};
        
        if (owner.target === Debugger.GLOBAL_WATCHERS) {


            window.console.info('On Object properties received from watchers (event, owner): ', event, owner);

            if (typeof owner.$children !== 'undefined') {
                owner.$children.empty().remove();
            }
            owner.properties = [];
            owner.propertiesByName = {};
            properties = event.body.result;
            propertyNames = Object.getOwnPropertyNames(properties);

            innerSorters = {

                bytype: function sortPropertiesByType(elem1, elem2) {
                    elem1 = properties[elem1].type;
                    elem2 = properties[elem2].type;
                    return sorters.sortProperties(elem1, elem2);
                },

                byvalue: function sortPropertiesByType(elem1, elem2) {
                    elem1 = properties[elem1].value || properties[elem1].preview;
                    elem2 = properties[elem2].value || properties[elem2].preview;
                    return sorters.sortProperties(elem1, elem2);
                }
            }

            if (config.sortBy === 'name') {

                if (owner.isArray || owner.isObject && ['EntitySet', 'FolderList', 'FileList'].indexOf(owner.type) > -1) {
                    propertyNames.sort(sorters.byname.asIndex);
                } else {
                    propertyNames.sort(sorters.byname.asName);
                }

            } else {
                propertyNames.sort(innerSorters['by' + config.sortBy]);
            }


            list = {
                scope: owner.scope + '-' + owner.uuid,
                empty: false,
                indent: config.indent,
                comma: ', '
            };

            if (!('scope' in owner)) {
                list.scope = owner.uuid;
            }

            propertyNames.forEach(
                function objects_list_forEach(propertyName, index) {

                    var
                        currentProperty,
                        propertyValue,
                        type,
                        preview;

                    propertyValue = properties[propertyName];

                    type = (propertyValue === null) ? 'null' : typeof propertyValue;
                    if (type === 'object') {
                        type = propertyValue.type;
                    }


                        // TODO
                        // Clear old properties
                    /*
                    oldPropertyNames = Object.getOwnPropertyNames(owner.propertiesByName);
                    if (oldPropertyNames.length > 0) {

                        oldPropertyNames.forEach(
                            function () {
                            }
                        );


                    }
                    */

                    currentProperty = {
                        target: Debugger.EVAL_WATCHERS,
                        scope: list.scope,
                        uuid: event.request_seq + '_' + index,
                        owner: owner,
                        level: owner.level + 1,
                        name: propertyName,
                        path: owner.path + "['" + propertyName.replace("'", "\\'") + "']",
                        removable: false
                    };


                    if (!('scope' in currentProperty)) {
                        currentProperty.scope = owner.uuid;
                    }

                    owner.properties.push(currentProperty);
                    owner.propertiesByName[propertyName] = currentProperty;

                    if (propertyValue === null || (typeof propertyValue !== 'object' && typeof propertyValue !== 'function')) {
                        preview = {
                            result: propertyValue
                        };
                    } else {
                        preview = propertyValue;
                    }

                    Debugger.tools.createPreviewLevel1(currentProperty, preview, objectOwners, config);

                }
            );

            list.objects = owner.properties;


            // Apply template
            tmpGlobalObjectPropertiesTable.innerHTML = Mustache.to_html(Debugger.templates.watcher, list);

            $children =
            owner.$children =
            $tmpGlobalObjectPropertiesTable.$rows =
            $tmpGlobalObjectPropertiesTable.children().children();

            owner.$rows.add($children);
            owner.$children.add($children);
            $parents = $children.filter('.parent');

            $parents.each(parentSetRows);

            $last = owner.$rows.last();
            $last.after($children);

            owner.$loading.hide();
            if (properties.length === 0) {
                owner.$empty.show();
            } else {
                owner.$empty.hide();
            }

            $parents.each(propertyAutoExpand);

        }

    }


    
    function crossfireClient_onstackready_globalObjectListener(event) {

        updateGlobalObject();
        
        $globalObjectContainer.removeClass('waf-disabled');

    }



    
    function crossfireClient_onresume_globalObjectListener(event) {

        // DISABLE WATCHERS PANEL

        $globalObjectContainer.addClass('waf-disabled');

    }

    
    
    function crossfireClient_onenablepanels_globalObjectListener(event) {

        var
            action;

        // ENABLE / DISABLE GLOBAL OBJECT PANEL
        action = event.enabled ? 'removeClass' : 'addClass';
        $globalObjectContainer[action]('waf-disabled');

    }


    
    if ($globalObjectContainer.prop('id') !== 'hiddenComponents') {
        Debugger.addEventListener('scopereceived', Debugger_onscopereceived_watchers);
        Debugger.addEventListener('evaluated', crossfireClient_onevaluated_watcherListener);
        Debugger.addEventListener('objectpropertiesreceived', crossfireClient_onobjectpropertiesreceived_watcherListener);
        Debugger.addEventListener('stackready', crossfireClient_onstackready_globalObjectListener);
        Debugger.addEventListener('framechange', updateGlobalObject);
        Debugger.addEventListener('resume', crossfireClient_onresume_globalObjectListener);
        Debugger.addEventListener('enablepanels', crossfireClient_onenablepanels_globalObjectListener);
    }

    
    
}; // End Watchers

