/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/*global WAF, waStudio, $, Mustache */


/**
 * MANAGE INTERPRETER
 *
 * @static
 * @shared
 * @method manageComanageInterpreternsole
 */
waStudio.Debugger.manageInterpreter = function crossfireClient_manageInterpreter() {

    var
        Debugger,
        config,
        evalSequences,
        console,
        $contentInterpreter,
        $interpreterContainer,
        scriptArea,
        DEBUG;
    
    
    Debugger = waStudio.Debugger;
    console = waStudio.Console;

    DEBUG = Debugger.DEBUG && true;
    
    config = 
    Debugger.config.interpreter = {};
    
    //Debugger.templates.push('interpreterManager');
    $contentInterpreter = $('#contentEval');

    if ($contentInterpreter.length === 0) {
        return;
    }

    evalSequences = Debugger.evalSequences;
    
    $interpreterContainer = $contentInterpreter.parent();
    scriptArea = $contentInterpreter.children('[name=script]')[0];
    scriptArea.target = Debugger.RUN_SSJS;
    
    /**
     * interpreter_submit
     *
     * @event interpreter_submit
     * @param {Event} submitEvent
     **/
    function crossfireClient_interpreter_submit(submitEvent) {
        var
            script,
            sequence;
        
        try {
        
            script = scriptArea.value;

            Debugger.dispatchEvent(
                {
                       type: "message",
                       level: "RUN",
                       data: [
                           script
                       ]
                }
            );
            
            scriptArea.expression = scriptArea.value;

            Debugger.dispatchEvent(
                {
                       type: "message",
                       context_id: Debugger.currentContext.id,
                       level: "LOADING",
                       sequence: sequence
                }
            );
            
            Debugger.currentContext.currentFrame.evaluate(scriptArea);
            

        } catch (e) {
            // clone the error before log
            DEBUG && window.console.error('BUG', JSON.parse(JSON.stringify(e)));
        }
        
    }
    
    
    /**
     * interpreter_clear
     *
     * @event interpreter_clear
     * @param {Event} event
     **/
    function crossfireClient_interpreter_clear(event) {
        
        scriptArea.value = '';
        
    }
    
    
    // ASSIGN EVENT HANDLERS
    
    $('#actionEvalClear').click(crossfireClient_interpreter_clear);
    $('#actionEvalRun').click(crossfireClient_interpreter_submit);
    
    
};