/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    /**
    * handler select behavior
    * @param {html object} sel 
    */
    _o.manageSelect = function(sel){ 
 
        var tb      = YAHOO.util.Dom.getAncestorByTagName(sel, "table"),
            attN    = emEditor.uD.getWafData( emEditor.selectedItems.item ),
            selElem, 
            pAttKey, 
            selType = emEditor.uD.getWafData( sel );
            isMeth = false;
      
        switch (true) {
        case $(emEditor.selectedItems.item).hasClass("meth"): 
        case $(emEditor.selectedItems.item).hasClass("methodInherited"):
            isMeth = true;
            _u.methodProperty(emEditor.selectedItems.emName, selType, sel.value, null, attN, false, emEditor.selectedItems.isInherited);
        break;
        case $(emEditor.selectedItems.item).hasClass("scal"): 
        case $(emEditor.selectedItems.item).hasClass("rel"):
        case $(emEditor.selectedItems.item).hasClass("calculated"):

            if (tb.id != "currentAttProperties") { 
                if (sel.value === null || sel.value === "") { 
                    _u.remove.typeProperty(emEditor.selectedItems.types, selType);
                } else {
                    _u.typeProperty(emEditor.selectedItems.types, selType, sel.value);
                }
            } else { 
                if (sel.value === null || sel.value === "") { 
                    _u.remove.attributeProperty(emEditor.selectedItems.emName, selType, attN); 
                } else { 
                    if (emEditor.selectedItems.isInherited) {
                        _u.inheritedAttributeProperty(emEditor.selectedItems.emName, selType, attN, sel.value);
                    } else { 
                        _u.attributeProperty(emEditor.selectedItems.emName, selType, attN, sel.value, "storage");
                    }
                }
            }
            break;
        default:
            if (emEditor.selectedItems.emName) {
                _u.property( emEditor.selectedItems.emName, "scope", sel.value );
            }
        }
            
        if (selType === "scope") {
            selElem = $(emEditor.selectedItems.item);
            pAttKey = selElem.find(".privateAttKey");
            
            switch (sel.value) {
            case "public" : 
                pAttKey.removeClass("private");
                pAttKey.removeClass("protected");
                pAttKey.removeClass("publicOnServer");
                break;
            case "private" : 
                pAttKey.addClass("private");
                pAttKey.removeClass("protected");
                pAttKey.removeClass("publicOnServer");
                break;
            case "protected" : 
                pAttKey.addClass("protected");
                pAttKey.removeClass("private");
                pAttKey.removeClass("publicOnServer");
                break;
            case "publicOnServer" : 
                pAttKey.addClass("publicOnServer");
                pAttKey.removeClass("protected");
                pAttKey.removeClass("private");
                break;
            default:
            }

            _b.entity.methods(emEditor.selectedItems.emName, null, null, true);
            
            if (emEditor.selectedItems.isInherited) {
                if (isMeth) {
                    _b.properties.methods("DataClass2", "method1", false, false, true);
                } else { 
                    _b.properties.attribute(emEditor.selectedItems.emName, attN, false, true); 
                }
               
            }
        }
    };
    _o.manageScope = function(elem, sc){

        var attN = emEditor.uD.getWafData( emEditor.selectedItems.item ),
            met = $(emEditor.selectedItems.item).hasClass("meth"),
            state,
            storage;
            
        switch (sc){
        case "private": //switch to protected
            elem.removeClass("private");
            elem.addClass("protected");
            state = "protected";
            storage = "storage";
            break;
        case "protected": //switch to publicOnServer
            elem.addClass("publicOnServer");
            elem.removeClass("protected");
            state = "publicOnServer";
            storage = "storage";
            break;
        case "publicOnServer": //switch to public
            elem.removeClass("private");
            elem.removeClass("protected");
            elem.removeClass("publicOnServer");
            state = null;
            storage = null;
            break;  
        default: //switch to private
            elem.addClass("private");
            elem.removeClass("publicOnServer");
            state = "private";
            storage = "storage";   
        }
        
        if (met) {
            if (state === null) {
                state = "public";
            }
            _u.methodProperty(emEditor.selectedItems.emName, "scope", state, null, attN, false);
        } else {

            if (emEditor.selectedItems.isInherited) { 
                _u.inheritedAttributeProperty(emEditor.selectedItems.emName, "scope", attN, state);
            } else {
                _u.attributeProperty(emEditor.selectedItems.emName, "scope", attN, state, storage);
            }
           
        }
        
        if (emEditor.proMessage) {
            elem.btOff();
            clearTimeout(emEditor.proMessage);
        }
        elem.btOn();
        //$(".scopeStatusMEssage").innerHTML = sc;
        var tot = elem;
        emEditor.proMessage = setTimeout(function(){ //have to wait the end of the flip effect to set the focus
            tot.btOff();
        }, 800);
        
        if(met){
            _b.properties.methods(emEditor.selectedItems.emName, attN, false);
        }else{
            _b.properties.attribute(emEditor.selectedItems.emName, attN, false, emEditor.selectedItems.isInherited);
        }
    };
    /**
    * handle specific behavior for the menu's text boxes (dock)
    * @param {html input element} elem
    * @param {html input element} key   ==> to remove !
    */
    _o.manageDockTextBoxes = function(key, elem){  
        var value = elem.firstChild.nodeValue;
        var open = true, keepFocus = false; 

            if(emEditor.onEditBox.oldValue!=value || emEditor.onEditBox.oldValue==value || emEditor.onEditBox.oldValue==null){ 
                    var newValue = elem.firstChild.nodeValue;               
                    if(emEditor.onEditBox.oldValue != newValue || YAHOO.util.Dom.hasClass(elem, "notSaved")){  
                            var emPos = _g.entityModel(newValue);
                            if(emPos == null){
                                var tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                                emEditor.uD.setWafData( tr,newValue );
                                
                                //save or update the name                                           
                                if(!YAHOO.util.Dom.hasClass(elem, "notSaved")){ //emEditor.onEditBox.oldValue != null || 
                               
                                    //update other em and get panel to refresh
                                    var panToReload = _u.emName(emEditor.onEditBox.oldValue, newValue);
                                    
                                    //update data
                                    
                                    _u.property(emEditor.onEditBox.oldValue, "name", newValue);
                                    
                                    //refresh UI
                                    var pan = _windows.getPanel(emEditor.onEditBox.oldValue+'-'+_conf .htmlData.classEm);
                                    if(pan){
                                        _windows.updatePanelID(emEditor.onEditBox.oldValue+'-'+_conf .htmlData.classEm, newValue);
                                        setTimeout(function() { _windows.reLoad(newValue, false); },0);
                                    }
                                    for(var k in panToReload){
                                        setTimeout(function() { _windows.reLoad(panToReload[k], true, false, true); },0);
                                    }
                                    
                                }else{  
                                    YAHOO.util.Dom.removeClass(elem, "notSaved");
                                    YAHOO.util.Dom.removeClass(elem, "errorText"); 
                                    _u.entity(newValue);
                                    open = false;
                                    
                                    //reload ui if needed
                                    if(emEditor.emToUpdateForUI.length > 0){
                                        for(var k in emEditor.emToUpdateForUI){
                                                _windows.reLoad(emEditor.emToUpdateForUI[k], false, false);
                                        }
                                        emEditor.emToUpdateForUI = [];
                                    }
                                    
                                    //add focus or open
                                    if(emEditor.enterKey){ 
                                        setTimeout(function() { //keep
                                            var pRef = emEditor.editorUI.panel.getPanelRef(newValue); 
                                            emEditor.editorUI.panel.addFocusOrOpen(null, newValue, pRef.id, true); 
                                            emEditor.enterKey = false;
                                        },0);
                                    }
                                    
                                } 
                                YAHOO.util.Dom.removeClass(elem, "notSaved");
                                //check click listener
                                var row = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                                var clickListener = YAHOO.util.Event.getListeners(row, "click");    
                                if(clickListener == null){ 
                                    YAHOO.util.Event.addListener(row, "click", function(event){event.stopPropagation(); event.preventDefault(); emEditor.editorUI.panel.addFocusOrOpen(this);});        
                                }       
                               
                            }else{  //update 
                        
                                elem.focus();
                                emEditor.editorUI.panel.manageToolTip("10px", elem.offsetParent.offsetTop+70+"px", _conf .langage.en.nameAlreadyExist);
                                keepFocus = true;
                                if(!emEditor.enterKey){
                                    YAHOO.util.Dom.addClass(elem, "errorText");
                                    YAHOO.util.Dom.addClass(elem, "notSaved");
                                }else{
                                    elem.id="";
                                }
                            }                       
                    }else{
                        elem.id="";
                    }
            }else{
                                        
                if(emEditor.enterKey){ 
                    emEditor.enterKey= false; 
                    emEditor.editorUI.panel.addFocusOrOpen(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"));
                }
            }
    
        if(!keepFocus){
            elem.contentEditable=false;
            YAHOO.util.Event.removeListener(elem, "click");
            emEditor.onEditBox={oldValue:null, ref:null};
        }


    };
    /**
    * handle behavior for the text boxes ONLY FOR NOT SAVED ITEMS
    * @param {html input element} elem
    * 
    */
    _o.manageBox4NewItems = function(elem){   

        var 
        newValue, 
        destination,
        tr              = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
        isReserved      = false,
        reservedList    = _conf.reservedForAttributs,
        emName;
        
        if (elem.firstChild) {
            newValue = elem.textContent;
            newValue = emEditor.editorUI.validate.makeJSCompliant(newValue);
            elem.textContent = newValue;
        } else {
            newValue = " ";
        }

        switch ( emEditor.uD.getElementType(elem) ){
            case _conf.htmlData.newEmProperty: 
                var props = _g.emPropertiesList();
                if (_o.isInDataList(newValue, props)) {
                    //destroy old
                    var cont = elem.parentNode.parentNode.parentNode;
                    cont.removeChild(elem.parentNode.parentNode);
                    //right new value and go to value box
                    cont.innerHTML = newValue;
                    var valueBox = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", cont.parentNode)[0];
                    valueBox.contentEditable = true;
                    emEditor.uD.setElementType(valueBox, newValue);
                    var defaultValue = _g.defaultValue(newValue);
                    if(!defaultValue){
                        defaultValue = "...";
                    }
                    valueBox.innerHTML=defaultValue;
                    YAHOO.util.Event.addListener(valueBox, "focus", function (e) {_o.switchToEditMode(this);});
                    valueBox.id=emEditor.ids++;
                    var autoc = _aC.init(emEditor.uD.getElementType(valueBox), valueBox.id);
                    YAHOO.util.Event.addListener(valueBox, "keydown", function (e) {_h.key.press(e, this);});
                    YAHOO.util.Event.addListener(valueBox, "blur", function (e) { _h.blur.main(e, this);});
                    setTimeout(function() { valueBox.focus(); },0);
                } else {                      
                    if (newValue == " ") {
                        elem.firstChild.nodeValue = "...";
                    } else {
                        if (emEditor.enterKey) {
                            elem.focus();
                            emEditor.enterKey = false;
                        } else {
                            YAHOO.util.Dom.addClass(elem, "errorText");
                            YAHOO.util.Dom.addClass(elem, "notSaved");
                        }
                    }
                }
                break;
            case "name":     
                var is; 
                if (newValue != " " && newValue != "" && newValue != null) {  
                    if (emEditor.uD.getWafData( tr ) == "newType") {  
                        //
                    } else { //new em 
                        
                        emName = emEditor.selectedItems.emName;
                        
                        is = this.isInDataList(newValue, _g.emAttributesList(emName));
                        ex =  _check.doesExtends(emName);

                        if (!is) {
                            while (ex != null) {
                                is = this.isInDataList(newValue, _g.emAttributesList(ex), false);
                                ex =  _check.doesExtends(ex);
                            }
                        }

                        $.each(reservedList, function(index, value) { 
                           if(value === newValue || value === newValue.toLowerCase() ) { 
                               isReserved = true;
                               return false;
                           }
                       });

                        if (is || isReserved) {
                            //display alert, the name already exist
                            elem.focus(); 
                            setTimeout( function() { /* keep this timeout */
                                $("#"+tr.id).btOn();
                            },100 );

                            if( emEditor.enterKey ) {
                                elem.focus();
                                emEditor.enterKey = false;
                            }            
                                               
                        }else{
                        
                            $(tr).btOff();
                            YAHOO.util.Dom.removeClass(elem, "addNew");
                            tr.id = _conf .htmlData.classEm+"-"+emEditor.editorUI.panel.getActiveElemName()+"-"+_conf .htmlData.classAttribute+"-"+newValue;
                            emEditor.uD.setWafData( tr , newValue);
                            if(emEditor.enterKey){ 
                                emEditor.enterKey = false;
                                //go to next step : edit type
                                this.switchToEditType(tr);
                            }else{
                                this.switchToEditType(tr, true);
                            }
                            
                        }
                    }
            }else{ 
                YAHOO.util.Dom.getAncestorByTagName(elem, "table").deleteRow(tr.rowIndex);
            }
            break;
            case "type":   
                if(newValue != " "){
                    this.switchToEditKind(tr);      
                }else{  
                    if ( !elem.firstChild ) { elem.innerHTML = "..."; } else { elem.firstChild.nodeValue = "..."; }
                    YAHOO.util.Dom.addClass(tr, "onProcess");
                }
                break;
            case "kind":        
                if(newValue != " "){
                    switch(newValue){
                        case "storage": 
                            var emName = emEditor.editorUI.panel.getActiveElemName();
                            var attName =this.saveNewAttribute(tr, emName);
                            var row = emEditor.editorUI.views.add.addExpandRowArrow(tr, emName, attName, true);
                            break;
                        default: console.log(newValue);
                    }
                }else{
                    if ( !elem.firstChild ) { elem.innerHTML = "..."; } else { elem.firstChild.nodeValue = "..."; }
                    YAHOO.util.Dom.addClass(tr, "onProcess");
                }
                break;  
            default: console.log("error manageBox4NewItems");           
        }
        
        if( !is ) {
            emEditor.onEditBox = {}; 
        }
        
    };
    /**
    * handle behavior for the text boxes
    * @param {html input element} elem
    * 
    */
    _o.manageTextBox = function(elem, prop, box) {

        var 
        cont, 
        tr,
        ty,
        checkNumbers    = true,
        tb              = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
        reservedList    = _conf.reservedForAttributs;
                
        if (tb.id != "currentModelProperties" && tb.id != "currentAttProperties" && tb.id != "currentEmProperties" && tb.className != "underKeyForm") {
            //revert to old value if the box is empty, except for properties 
            if (elem.firstChild.nodeValue == null && emEditor.onEditBox.oldValue) {
                elem.innerHTML =  emEditor.onEditBox.oldValue;
            }
        }
        
        if (!prop) { cont = elem.parentNode.parentNode.parentNode; }
        
        var 
        obj             = elem.parentNode.parentNode,
        t               = emEditor.uD.getElementType( elem ),   
        newValue        = null,
        emToUpdate      = [], 
        isReserved      = false,
        isInObject      = null,
        isInherited     = emEditor.selectedItems.isInherited,
        mainKeyName,
        k,
        is,
        ex,
        emName,
        attN,
        is,
        ex;
        
        if (elem.nodeName != "SELECT" ) {
            if (box) {
                newValue = elem.checked;
            } else { 

                if(elem.firstChild){
                    newValue = elem.textContent;
                    if (t != "restrictingQuery" && t != "format" && t != "description") {  
                        /* !!  method to add in order to check if the item is a number value !! */
                        if (t == "defaultTopSize" || t == "limiting_length" || t == "length" || t == "minLength" || t == "maxLength" || t == "minValue" || t == "maxValue" || t == "defaultValue" || t == "sliderMin" || t == "sliderMax" || t == "sliderInc"){
                           
                            checkNumbers = false;
                        }
                        if( t != "propertiesTable" && emEditor.uD.getWafData( elem.parentNode ) != "onGet" && !prop) { 
                            newValue = emEditor.editorUI.validate.makeJSCompliant( newValue, checkNumbers );
                        }
                        elem.textContent = newValue;
                    }
                }else{
                    newValue = null;
                }

            }
        }
        
        if (newValue === null) { 
            newValue = "";
        } 
        
        tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
        ty = YAHOO.util.Dom.getAncestorByTagName(elem, "table").className;

        if (newValue != tr.dataset.info || ty == "propertiesTable" || ty == "underKeyForm") { //emEditor.onEditBox.oldValue $(tr).attr("waf-data")
                             
                if( prop ) { 
                    emName = emEditor.selectedItems.emName;
                } else { 
                    emName = emEditor.onEditBox.emName; //emEditor.editorUI.panel.getActiveElemName(); 
                } 
    
                switch (ty){
                    case "underKeyForm":  
                        if($(elem).hasClass("typeEditBox")){ 
                            
                            if(emEditor.onEditBox.oldValue != null && !newValue){ 
                                _u.remove.typeProperty($(".bt-active").attr("bt-xtitle"), t, true);
                            }else{ 
                                if(newValue && newValue != "" && newValue != " "){
                                    _u.typeProperty($(".bt-active").attr("bt-xtitle"), t, newValue, true);    
                                }
                            }
                        }else{ 
                            if( prop ) {
                                attN = emEditor.uD.getAttributeNameValue( emEditor.selectedItems.item ); //emEditor.selectedItems.item.title;
                            }else{
                                attN = emEditor.uD.getAttributeNameValue( tr ); //tr.title;
                            }
                            
                            mainKeyName = "defaultFormat"; 
                            this.updateAttributeProperties(emName, t, attN, newValue, emEditor.onEditBox.oldValue, mainKeyName, elem); 
                        }
                    
                    break;
                    case "attributesTable": 
                    case "attributeTable":           
                            
                            switch (t) {
                                case "notes" : 
                                    newValue = elem.value;
                                    if ($(emEditor.onEditBox.item).hasClass("meth") ){
                                        _u.extraProperties.noteForMethods(emEditor.onEditBox.emName, emEditor.onEditBox.item.id.split("-")[3], newValue);
                                    } else {
                                        _u.extraProperties.noteForAttributes(emEditor.onEditBox.emName, emEditor.onEditBox.item.id.split("-")[3], newValue);
                                    }
                                break; 
                                case "manyToOne":   break;
                                case "oneToMany":   break;
                                case "manyToMany":  break;
                                case "attProperty":  
                                    var ts = YAHOO.util.Dom.getAncestorByTagName(elem, "td");
                                    var inputVal = YAHOO.util.Dom.getElementsByClassName("editable_input", "div", ts.previousSibling)[0].firstChild.nodeValue;
                                    _u.attributeProperty(emName, inputVal, emEditor.editorUI.dom.getPreviousSiblingByClass(ts.parentNode, "mainAttRow").title, newValue);
                                    break;  
                                case "newEmAttProperty":    
                                    //get value; if bool : save it, and go to next
                                    if (_check.isBool(newValue)) {
                                        var ptr = emEditor.editorUI.dom.getPreviousSiblingByClass(tr, "mainAttRow");
                                        var attName = emEditor.uD.getWafData( ptr );
                                        _u.attributeProperty(emName, newValue, attName, "true");
                                        var type = _g.emAttPropertyValue(emName, emEditor.uD.getWafData(ptr), "type");
                                        var nextProp = _g.propertyList4Autocomp(type);
                                        if(nextProp.length-1 != 0){emEditor.editorUI.views.add.attPropRow(tr, emName, attName);}                                  
                                    }else{
                                        emEditor.editorUI.views.add.enableValueBox(elem);     
                                    }                                   
                                    break;
                                case "name":  
  
                                    is = this.isInDataList(newValue, _g.emAttributesList(emName));
                                    ex =  _check.doesExtends(emEditor.selectedItems.emName);

                                    if (!is) {
                                        while (ex != null) {
                                            is = this.isInDataList(newValue, _g.emAttributesList(ex), false);
                                            ex =  _check.doesExtends(ex);
                                        }
                                    }

                                    $.each(reservedList, function(index, value) { 
                                        if(value === newValue || value === newValue.toLowerCase() ) { 
                                            isReserved = true;
                                            return false;
                                        }
                                    });
                                    
                                    if (is || isReserved) {
                                        
                                        window.setTimeout( function(){ 
                                            
                                            $(tr).btOn(); 
                                            elem.focus();
                                        
                                        }, 100);
                                        
                                        //YAHOO.util.Dom.addClass(elem, "errorText");
                                        if(emEditor.enterKey){
                                            //elem.focus();
                                            emEditor.enterKey = false;
                                        }   
                                                                    
                                    } else { 
                                        $(tr).btOff();
                                        var primK = _g.primKey(emName);
                                        if (emEditor.onEditBox.oldValue != null) { 
                                            switch(_g.emAttPropertyValue(emName, emEditor.onEditBox.oldValue, "kind")) {
                                            case _conf .xmlData.relatedEntity: 
                                            case _conf .xmlData.relatedEntities :   
                                                emToUpdate = _u.navigationAtt(emName, emEditor.onEditBox.oldValue, newValue, false);
                                                //emToUpdate = _u.flattenedAtt(emName, emEditor.onEditBox.oldValue, newValue).concat(emToUpdate);                                                    
                                            break;
                                            case _conf.xmlData.storage :
                                                emToUpdate = _u.flattenedAtt(emName, emEditor.onEditBox.oldValue, newValue);
                                            break;
                                            default: //computed && flattened
                                            }
                                        }        

                                        var extendPath = _g.extendTree(emName);
                                        var other = [];
                                        $.each(extendPath, function(index, value) { 
                                            $.each(value, function(i, v) { 
                                                if (!_uA.isValueIn( v, other )) {
                                                    other.push(v);
                                                }
                                            });
                                        });
                                        
                                        var d = emEditor.uD.getWafData( tr );
                                        console.log(emName, t, d, newValue)
                                        _u.attributeProperty(emName, t, d, newValue);
                                        $.each(other, function(i, v) { 
                                           _u.attributeProperty(v, t, d, newValue);
                                        });
                                        
                                        var saveSelect = emEditor.selectedItems;

                                        _wRefresh({emName :emName, itemName:newValue, type:"att", action:"update", lookForExtend:true, oldValue : tr.dataset.info, name : true});

                                        for (var u in emToUpdate) {
                                            _wRefresh({emName : emToUpdate[u].emName, itemName:emToUpdate[u].attProp.name, type:"att", action:"update", lookForExtend:true});
                                        }

                                        if (primK === emEditor.onEditBox.oldValue) {
                                            _u.property(emName,  _conf .xmlData.primKey, newValue);
                                            _b.properties.entity(emName, false, false);
                                        }
                                    }

                                    break;
                                case 'path' : 
                                    this.updateAttributeProperties(emName, emEditor.uD.getElementType(elem), emEditor.uD.getWafData( emEditor.selectedItems.item ), elem.value, emEditor.onEditBox.oldValue, false, elem);
                                    var cont = elem.parentNode;
                                    emEditor.editorUI.dom.removeNode(cont, elem);
                                    cont.innerHTML = "<div title='path' contentEditable='true' class='"+_conf .htmlData.contentEditable+"2 pathMany'>"+elem.value+"</div>";
                                    YAHOO.util.Event.addListener(cont.firstChild, "focus", function (e) {_o.switchToEditMode(this, e);});
                                     break;     
                                default:  
                                    if (prop) {
                                        if (emEditor.selectedItems.item) {
                                            attN = emEditor.uD.getWafData( emEditor.selectedItems.item );
                                        }
                                    } else {
                                        attN = emEditor.uD.getWafData( tr );
                                    }   
                                    
                                    this.updateAttributeProperties(emName, t, attN, newValue, emEditor.onEditBox.oldValue, false, elem);
                            }
                        
                        
                        break;
                    case "propertiesTable": 
                    case "propertiesBackTable": 
                        if(newValue != emEditor.onEditBox.oldValue) {
                            this.updateEmProperties(elem, t, newValue);
                        }
                        break;
                    case "methodsTable": 
                      
                        var cell = YAHOO.util.Dom.getAncestorByTagName(elem, "td"),
                            row,
                            oldFrom,
                            ex,
                            upname,
                            nameForId,
                            atts;
                        
                        if( emEditor.onEditBox.oldValue == undefined && cell.title == "name") { 
                            //handle specific behavior when loosing focus on Mac (cmd-tab)
                        } else {

                            (YAHOO.util.Dom.getAncestorByTagName(elem, "table").parentNode.className === "methodsContainer") ? nameForId = "method" : nameForId = "methodP";
                            row =  YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
                            oldFrom = _g.methodFrom(emName, emEditor.uD.getWafData( row ));
                            upname = false;

                            if( cell.className == "name" ) {  
                                upname = true;
                                newValue = emEditor.editorUI.validate.makeJSCompliant(newValue);
                                elem.textContent = newValue;
                                

                                //check if name already exist !                                                            
                                isInObject = _uA.isValueInObject ( newValue, _g.methodsList(emName), "name" )
                                if (isInObject != null) {
                                    is = true;
                                } else {
                                    is = false;
                                }
                                
                                ex =  _check.doesExtends(emName);

                                if (!is) {
                                    while (ex != null) {
                                        isInObject = _uA.isValueInObject ( newValue, _g.methodsList(ex), "name" )
                                        if (isInObject != null) {
                                            is = true;
                                        } else {
                                            is = false;
                                        }
                                        ex =  _check.doesExtends(ex);
                                    }
                                }

                                var reservedListForMeth;

                                if (_g.methodeProperty(emName, emEditor.uD.getWafData( row ), "applyTo") == "dataClass") {
                                    reservedListForMeth = emEditor.config.reservedForMethods;
                                } else {
                                    reservedListForMeth = emEditor.config.reservedForMethods;
                                }

                                $.each(reservedList, function(index, value) { 
                                   if(value === newValue || value === newValue.toLowerCase() ) { 
                                       is = true;
                                       return false;
                                   }
                                })

                                if (is) {
                                    
                                    setTimeout(function() { /* keep this timeout */
                                        $("#"+tr.id).btOn();
                                        elem.focus();
                                    },200);
                                    return false;
                                    
                                } else {
                                
                                    $("#"+tr.id).btOff();
                                     emEditor.uD.setWafData(row, newValue);
                                    _perms.updateNames( "method", emEditor.onEditBox.oldValue, newValue, emName);
                                    _u.methodProperty(emName, "name", newValue, emEditor.onEditBox.oldValue, emEditor.onEditBox.oldValue, $(tr).hasClass("notDone"));
                                
                                }
                               
                            } else {
                            
                                newValue = elem.value;
                                _u.methodProperty(emName, "applyTo", newValue, emEditor.onEditBox.oldValue, emEditor.uD.getWafData( row ));
                            }

                            if (nameForId == "methodP") { 
                                _b.entity.methods(emName, null, null, true);
                                _wRefresh({emName : emName, itemName:emEditor.uD.getWafData(row), type:"meth", action:"update", lookForExtend:true, oldValue:emEditor.onEditBox.oldValue, name:upname});
                            } else { 
                                _wRefresh({emName : emName, itemName:emEditor.uD.getWafData(row), type:"meth", action:"update", lookForExtend:true, oldValue:emEditor.onEditBox.oldValue, name:upname});
                            }
                        }                        
                        break; 
                        case "modelTable":
                            if (t === "notes") {
                                newValue = elem.value;
                                _u.extraProperties.noteForModel(newValue);
                            } else { 
                                _u.modelAttributeProperty(t, newValue);
                            }
                            
                        break; 
                    default:console.error("manageTextBox"); 
                }
            }
        
            if(emEditor.enterKey && !emEditor.returnKey){
                emEditor.enterKey=false;
            }
        emEditor.onEditBox = {};

    };
    
    _o.manageTypeInput = function( elem, sup, addSep, fromFocus ) { 
     
        var emName      = emEditor.editorUI.panel.getActiveElemName(),
            elemJq      = $("#"+elem.id),
            newValue    = elemJq.val(),
            mn, 
            ext,
            value, 
            items,
            item,
            l,
            tr,
            rels;
        
        if(addSep){
            //newValue = newValue + ".";
        }else{
            if(newValue.charAt(newValue.length-1) == "." && !sup){
                    $("#"+elem.id).val( newValue.slice(0, newValue.length-1) );
                    newValue = $("#"+elem.id).val();
            }   
        }
        
        item    = newValue.split(".");
        l       = item.length;
        tr      = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
       
        //resize
        this.resizePanel(elem, sup);
        
        switch (l){
        case 0: 
        case 1:  
            items = _g.typeList(false, true, false);
            rels = _g.relations(emName); 
            items = items.concat(rels); 
            elemJq.setOptions({startmsg: "Choose the type of the your attribute."});
            elemJq.setOptions({endmsg: "Choose a datastore class or collection to create a relation attribute or a type to create a storage or calculated attribute."});
            elemJq.setOptions({noresultsmsg: "The value entered is not an existing type or the datastore class doesn't have a primary key."});
            break;
            
        case 2:  
            destination = _check.isRelatedAtt(emName, item[0]);

            if (destination != null) { 
                if(_g.emAttPropertyValue(emName, item[0], "kind", false) === "relatedEntities"){ 
                    items = _g.emAttributesList(destination, false, false, false, true);
                }else{
                    items = _g.emAttributesList(destination, false, false, false);
                }
                
                ext = _check.doesExtends(destination);
                while ( ext ) {
                    if( ext ) {
                        items = items.concat(_g.emAttributesList(ext, false, false, false));
                    }
                    ext = _check.doesExtends(ext);
                }
                
                //sauf si le premier est un rel et le type en ies !
                elemJq.setOptions({startmsg: "You have first to create relation in <span style='color:red'>"+destination+"</span>"});
                elemJq.setOptions({endmsg: "Select an attribute from <span style='color:red'>"+destination+"</span> to create an alias attribute."});
                elemJq.setOptions({noresultsmsg: "You can add a relation setted in <span style='color:red'>"+destination+"</span> to make a relation path."});
            }else{
                    items = [];
            }
            
            break;
        case 3:     
            destination = _check.isRelatedAtt(emName, item[0]);

            destination = _check.isRelatedAtt(destination, item[1]);
            if( destination != null ) {
                items = _g.emAttributesList(destination, false, false, true); 
                elemJq.setOptions({startmsg: "You have first to create a relation or any attributes in <span style='color:red'>"+destination+"</span>"});
                elemJq.setOptions({endmsg: "You can add a relation setted in <span style='color:red'>"+destination+"</span> to make a relation path, or add an attribute to make a flattened."});
                elemJq.setOptions({noresultsmsg: "You can add a relation setted in <span style='color:red'>"+destination+"</span> to make a relation path."});
            }else{
                items = [];
                elemJq.setOptions({startmsg: "You can't add another attribute here."});
            }
           
            break;  
        default: 
            var destination = _check.isRelatedAtt(emName, item[0]);
            for( var i=1; i<l-1; i++ ) {
                destination = _check.isRelatedAtt(destination, item[i]);
            }
            if( destination != null ) {
                items = _g.emAttributesList(destination, false, false, true); 
                elemJq.setOptions({startmsg: "You have first to create a relation or any attributes in <span style='color:red'>"+destination+"</span>"});
                elemJq.setOptions({endmsg: 
                    "You can add a relation setted in <span style='color:red'>"+destination+"</span> to make a relation path, or add an attribute to make a flattened."});
                elemJq.setOptions({noresultsmsg: "You can add a relation setted in <span style='color:red'>"+destination+"</span> to make a relation path."});
            }else{
                items = [];
                elemJq.setOptions({startmsg: "You can't add another attribute here."});
            }

        }
        elemJq.flushCache();
        elemJq.setOptions({data: items});  
    };
   
    _o.managePathInput = function( elem, keyCode ) {
    
        var 
        val         = elem.value, 
        attName     = emEditor.uD.getWafData( YAHOO.util.Dom.getAncestorByTagName(elem, "tr") ), //emEditor.selectedItems.item.title;
        td          = YAHOO.util.Dom.getAncestorByTagName(elem, "td"),
        emName      = emEditor.editorUI.panel.getActiveElemName(),//emEditor.selectedItems.emName;
        elType      = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable+"2", "div", td)[0].innerHTML,
        destination = elType,
        path        = val.split("."),
        tempDes, 
        el;
        
        switch (keyCode) {   
            case 190:              
                for(var k in path){
                    if (path[k]) {
                        destination = _check.isRelatedAtt(destination, path[k]);
                    }
                }
                items = _g.relations(destination); //manyToOnRelation
                ext = _check.doesExtends(destination);
                if(ext){
                    items = items.concat(_g.relations(ext));
                }
                el = $("#"+elem.id);
                el.setOptions({noresultsmsg: "This relation attribute does not exist. Validate to create it in <span style='color:blue'>"+destination+"</span>"});    
                el.setOptions({notExistMessage: "This relation attribute does not exist. Validate to create it in <span style='color:blue'>"+destination+"</span>"});  
                el.flushCache();
                el.setOptions({data: items});
                 break; 
            case 8: 
                if(val[val.length-1] == "."){
                    val =  val.slice(0, val.length-1);
                    path = val.split(".");
                }
                if(path.length != 1){
                    for(var k in path){
                        tempDes = _check.isRelatedAtt(destination, path[k]);
                        if(tempDes != null){destination = tempDes;} 
                    }
                }
                
                items = _g.relations(destination);//manyToOnRelation
                ext = _check.doesExtends(destination);
                if (ext) {
                   items = items.concat(_g.relations(ext));
                }
                el = $("#"+elem.id);
                el.setOptions({noresultsmsg: "This relation attribute does not exist. Validate to create it in <span style='color:blue'>"+destination+"</span>"});  
                el.setOptions({notExistMessage: "This relation attribute does not exist. Validate to create it in <span style='color:blue'>"+destination+"</span>"});          
                el.flushCache();
                el.setOptions({data: items});
            break;  
            default:    
         }//end switch

    };
    
    _o.manageType = function( emName, elem, newValue, tr, news, pathVal, isExt ) {  

            YAHOO.util.Dom.removeClass( elem.parentNode, "typeDoesNotExist" );
            
            var item = newValue.split("."),
                l = item.length, 
                unknown = true,
                value, items, attName, type, td, el, container, table, trs, type, d,  attName, pathValue, mmane, atts, autoNameIndex,
                parsedTitle, parsedIndex, parsedTitleStart, isty, kindToAdd,
                primKey;
            
            d = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable, "div", YAHOO.util.Dom.getElementsByClassName("name", "td", tr)[0])[0];
            attName = d.innerHTML;        

            switch( l ) {
            case 1:                    
                    if( $(elem).hasClass( "emSing" ) ) { 
                  
                        unknown = false;
                        //newValue = _g.manyName(newValue);
                        pathValue = _g.collectionName(newValue);
                        var primK = _g.primKey(newValue);
                        if( news ) {
                            _vu.typeCell(tr, true, pathValue, unknown, "relatedEntity");
                            attName = this.saveNewRelation(tr, emName, newValue, true, elem, null, "relatedEntity", news);
                        } else {
                            //update relation !
                            attName = this.saveNewRelation(tr, emName, newValue, true, elem, null, "relatedEntity", news, newValue);
                            _vu.typeCell(tr, true, newValue, unknown, "relatedEntity");
                        }
                        mmane = _g.collectionName(emName);

                        var tpName = mmane[0].toLowerCase() + mmane.substring( 1, mmane.length );
                        atts = _g.emAttributesList(pathValue, false, false, false, false);
                        autoNameIndex = 0;

                        for ( var l in atts ) {
                            
                            parsedTitle = atts[l].split("_");
                            parsedIndex = parsedTitle.length - 2;
                            parsedTitleStart = "";

                            if( parsedTitle.length >= 2 ) { 
                        
                                if( !isNaN( parseInt( parsedTitle[ parsedIndex+1 ] ) ) ) {
                                    parsedTitleStart = atts[l].substr(0, atts[l].length-2);
                                }else{
                                    parsedTitleStart = atts[l];
                                }
                                
                            } else {
                                parsedTitleStart = parsedTitle[ parsedIndex+1 ];
                            }
                                                        
                            if( parsedTitleStart == tpName ) {
                                autoNameIndex++;
                            }
                        }
                                                
                        
                        if( autoNameIndex != 0 ) {
                            tpName = tpName + "_" + autoNameIndex;
                        }
                      
                        _u.newAttribute(pathValue, tpName, mmane, "relatedEntities", true, attName, true, mmane);

                        _wRefresh({emName : newValue, itemName:tpName, type:"att", action:"add", lookForExtend:true});

                        td = YAHOO.util.Dom.getAncestorByTagName(elem, "td");
                        el = YAHOO.util.Dom.getElementsByClassName("pathMany", "div", td)[0];
                        if(el){
                            container = YAHOO.util.Dom.getAncestorByClassName(el, "editable_base");
                            emEditor.editorUI.dom.removeNode(td, container);
                        }                        
                    }


                    if ($(elem).hasClass("em")) {      

                            unknown = false;
                            if( !_check.isRelatedAtt(newValue, pathVal) && pathVal.split(".").length == 1 ) {
                                _u.create1NRelation(emName, newValue, pathVal); 
                                _wRefresh({emName : newValue, itemName:pathVal, type:"att", action:"add", lookForExtend:true});
                                
                            }
                            attName = this.saveNewRelation(tr, emName, newValue, true, elem, null, "relatedEntities", news, pathVal);     
                            _vu.typeCell(tr, true, newValue, null, "relatedEntities");
                            
                            table = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                            trs = table.getElementsByTagName('tr');
                            
                            if (tr.rowIndex == trs.length-1) {
                                if (emName) {
                                    var pRef = emEditor.editorUI.panel.getPanelRef(emName);
                                    emEditor.editorUI.panel.addFocusOrOpen(null, emName, pRef.id, null, true, false, true);
                                    if(emEditor.enterKey){ 
                                        setTimeout(function() {emEditor.editorUI.views.add.entity.attribute(table, null, true);},0);   //keep tm
                                    }
                                }
                                
                            }                         
                    }                      
                                         
                    isty = $(elem).hasClass("scal");
                    unknown = $(elem).hasClass("unk"); 
                    kindToAdd = "storage";
                    
                    if(isty || unknown){ 
                       
                        if (unknown) {
                               emEditor.errorManager.addError({
                                  "class"        : emName,
                                  "message"      : "type",
                   	              "attribute"    : attName	    
                               },
                               false);
                        } else {
                            emEditor.errorManager.lookForErrorToRemove( emName, "type", attName );
                        }
                       
                        if( isExt ) {
                           kindToAdd = "calculated"; 
                        }
                        
                        if(unknown){ 
                            YAHOO.util.Dom.addClass(elem.parentNode, "typeDoesNotExist");
                        }
                        
                        if (news) { 
                        
                            attName = this.saveNewAttribute(tr, emName, kindToAdd); 
                            YAHOO.util.Dom.removeClass(tr, "notSaved");
                        
                        } else { 
                            
                            var linkedAtt = _nav.getPathTree(emName, attName, false, emName);
                            var attData;
                            
                            $.each(linkedAtt, function(index, value) { 
                              attData = _g.emAttribute(value.emName, value.attName);
                              if (attData.kind === "alias") {
                                  _u.attributeProperty( value.emName, "type", value.attName, newValue, "alias"); 
                                  _wRefresh({
                                      emName          : value.emName, 
                                      emStart         : value.emName, 
                                      itemName        : value.attName, 
                                      type            : "att", 
                                      action          : "update", 
                                      isExtend        : false, 
                                      lookForExtend   : true
                                      });
                              }
                            });
                            
                            type = emEditor.uD.getElementType(elem);
                            attName = emEditor.uD.getWafData(tr);
                            _u.remove.allProperties(emName, type, attName, newValue);
                            _u.attributeProperty(emName, type, attName, newValue, kindToAdd);
                            
                            primKey     = _g.primKey(emName);

                            if (primKey === attName) {
                                _u.attributeProperty(emName, "autosequence", attName, true, null, true);
                                _u.attributeProperty(emName, "unique", attName, true, null, true);
                            }
                            
                            _b.properties.attribute(emName, emEditor.uD.getWafData(tr), false);
                            td = YAHOO.util.Dom.getAncestorByTagName(elem, "td");
                            el = YAHOO.util.Dom.getElementsByClassName("pathMany", "div", td)[0];
                            
                            if (el) {
                                container = YAHOO.util.Dom.getAncestorByClassName(el, "editable_base");
                                emEditor.editorUI.dom.removeNode(td, container);
                            }
                                
                            _wRefresh({
                                emName          : _check.whosExtends(emName)[0], 
                                emStart         : emName, 
                                itemName        : emEditor.uD.getWafData(tr), 
                                type            : "att", 
                                action          : "update", 
                                isExtend        : true, 
                                lookForExtend   : true, 
                                extendFrom      : emName 
                                });
                                                          
                        }
                        //this is field or a compued => voir les extends !
                        _vu.typeCell(tr, false, false, unknown);
                        if (unknown) {
                            $(tr).btOff();
                        }
                        
                        
                    }
                    break;  
            default:                      
                    var destination = _check.isRelatedAtt(emName, item[0]);

                    var kind = _g.emAttPropertyValue(emName, item[0], "kind");
                    
                    var many = false;
                    if(kind == "relatedEntities"){
                        many = true;
                    }
                    if(!destination){
                        destination = item[0]; 
                    }
 
                    for( var i=1; i<l; i++ ) {
                        d = _check.isRelatedAtt(destination, item[i]);
                        
                        kind = _g.emAttPropertyValue(destination, item[i], "kind")
                        
                        if (kind == "relatedEntities") {
                            many = true;
                        }
                        if (!d) { 
                            type = _g.typeOfAttribute(destination, item[i]);
                        } else {
                            destination = d;
                        }
                    }
                    
                    if (type) {
                        kind = "alias";
                    } else {
                        type = destination; 
                        kind = "relatedEntity";
                        if (many) {
                            type = destination;
                            kind = "relatedEntities";
                        }
                    }
                    _vu.typeCell(tr, true, type, null, kind);
                    attName = this.saveNewRelation(tr, emName, newValue, false, elem, type, kind, news, true, many);
            }
            
            window.setTimeout(function(){
                if (emEditor.toRemoveAfterUpdate) {
                    _o.selectRow(emEditor.toRemoveAfterUpdate.tr, event);
                    _oR.attribute(emEditor.toRemoveAfterUpdate.table, emEditor.toRemoveAfterUpdate.tr.rowIndex, emEditor.toRemoveAfterUpdate.tr, true);
                    emEditor.toRemoveAfterUpdate = null;
                }
            }, 500);
            
            
            return attName;
    }
    /**
    * manage the type properties from the type's popup
    * @param {object} elem
    * @param {string} typeName
    * 
    */
    _o.manageTypeProperties = function(elem, typeName){ 
       var propertyName = emEditor.uD.getElementType(elem);
       var newValue = elem.textContent, emToUpdate;
       if(newValue && propertyName != "pattern"){ newValue = emEditor.editorUI.validate.makeJSCompliant(newValue); elem.textContent = newValue;}
       var trData = $(".bt-active").get()[0];

       if(newValue != emEditor.onEditBox.oldValue){
           switch (propertyName){
           case "name": 
               if(newValue && newValue != "" && newValue != " "){

                   if(_g.typePos(newValue)){
                       //$(elem.parentNode.parentNode.parentNode).btOn();
                       setTimeout(function() {  elem.focus(); },0);

                   }else{
                       _u.typeProperty(typeName, propertyName, newValue); 
                       //elem.title = newValue;
                       $(".bt-active").attr('bt-xtitle', newValue);
                       $("#typePropertiesTable").get()[0].title = newValue;
                       //update if needed
                       emToUpdate = _u.updateCustomTypeName(emEditor.onEditBox.oldValue, newValue);
                       if(emToUpdate.length != 0){
                           for(k in emToUpdate){
                               _windows.reLoad(emToUpdate[k], false, true, true);
                           }
                       }
                       trData.childNodes[0].firstChild.nextSibling.textContent = newValue;
                   }

               }else{
                   elem.textContent = emEditor.onEditBox.oldValue;
               }

           break;
           case "extends": 
               if(newValue && newValue != "" && newValue != " "){ 
                   emToUpdate = _u.typeProperty(typeName, propertyName, newValue);  
                   _b.properties.type(typeName, $(".bt-active"));
                   trData.childNodes[1].innerHTML = newValue;
                    if(emToUpdate.length != 0){
                        for(k in emToUpdate){
                            _windows.reLoad(emToUpdate[k], false, true, true);
                        }
                    }
               }else{
                   elem.textContent = emEditor.onEditBox.oldValue;
               }

           break;
           default:    

               if(emEditor.onEditBox.oldValue != null && !newValue){ 
                   _u.remove.typeProperty(typeName, propertyName);
               }else{ 
                   if(newValue && newValue != "" && newValue != " "){
                       _u.typeProperty(typeName, propertyName, newValue);  
                   }
               }
               //to do : reload only of needed
               if(emEditor.selectedItems){
                   _b.properties.attribute(emEditor.selectedItems.emName, emEditor.uD.getWafData( emEditor.selectedItems.item ), false);
               }
           }
       }
    };
       
})();
