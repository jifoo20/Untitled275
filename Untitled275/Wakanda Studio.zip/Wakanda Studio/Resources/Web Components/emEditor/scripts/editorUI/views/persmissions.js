/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() { 
emEditor.editorUI.views.permissions = {};
_perm = emEditor.editorUI.views.permissions;

_perm.build = function() {
    
    var target, // MODEL, CLASS, METHOD
        tab3,
        tab2,
        permJq          = $(".perm"),
        permHeaderJq    = $(".perm-header"),
        permContentJq   = $(".perm-content"),
        permHeader      = permHeaderJq.get()[0],
        permContent     = permContentJq.get()[0]; 
        list            = permContentJq.find("ul"),
        markup          = "",
        comboBoxGroup   = [],
        listForClasses  = _conf.permissions.classes,
        listForMethods  = _conf.permissions.methods;
    
    function addForClasses() { 
        markup = '<li class="perm-listTitle">For Classes</li>';

        $.each( listForClasses, function(index, value) { 
           markup = markup + 
           '<li class="perm-listContent">'+
				'<div class="perm-verbe '+value+'">'+value+'</div><div class="perm-group" id=""></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>'+
			'</li>';
        });
    }    

    function addForMethods( notAddHeader ) {
        
        if(!notAddHeader) {
            markup = markup + '<li class="perm-listTitle">For Methods</li>';
        }
        
        $.each( listForMethods, function(index, value) { 
           markup = markup + 
           '<li class="perm-listContent">'+
				'<div class="perm-verbe '+value+'">'+value+'</div><div class="perm-group" id=""></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>'+
			'</li>';
        });

        list.get()[0].innerHTML = "";
        list.append(markup);

        comboBoxGroup = list.find(".perm-group");
        $.each( comboBoxGroup, function(index, value) { 
            _b.comboBox("index", "test1", value, ["test1", "test3", "test2"]);
        });
    }
    
    permJq.show();
    
    if( emEditor.selectedItems.emName == "___MODEL" ) {
        target = "MODEL";
    } else {
        (emEditor.selectedItems.item) ? target = "METHOD" : target = "CLASS";
    }
    
    switch ( target ) {
    case "MODEL": 
        emEditor.leftTabview.set('activeIndex', 0);
        tab2 = emEditor.leftTabview.getTab(1);
        tab2.set('disabled', true);
        tab3 = emEditor.leftTabview.getTab(2);
        tab3.set('disabled', true);
        $("#currentEmProperties").hide(); 
        $("#currentAttProperties").hide(); 
        permHeader.textContent = "Model Permissions";
        
        addForClasses();
        addForMethods( false );
        
        break;
    case "CLASS": 
        permHeader.textContent = "Class Permissions";
        addForClasses();
        addForMethods( false );
        break;
    case "METHOD": 
        permHeader.textContent = "Method Permissions";
        addForMethods( true );
        break;
    default:
    }
  
    
};

_perm.hide = function() {
    $(".perm").hide();
};

})();

/*

<div class="perm">
	
	<div class="perm-header">Permissions</div>
	<div class="perm-content">
		<ul>
			<li class="perm-listTitle">For Classes</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Read</div><div class="perm-group" id="perm1"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Write</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Update</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Create</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Remove</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listTitle">For Methods</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Execute</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
			<li class="perm-listContent">
				<div class="perm-verbe">Promote</div><div class="perm-group"></div><div title="Temporary Force Permissions" class="perm-force"><input type="checkbox"/></div>
			</li>
		</ul>
	</div>
	
</div>
</div>

*/