/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    _o.saveNewAttribute = function(tr, emName, kind){ 
        
        //get all _conf .htmlData.contentEditable
        var k;
        var elems = YAHOO.util.Dom.getElementsByClassName("editable_input", "div", tr);
        var elemIn = YAHOO.util.Dom.getElementsByClassName("editable_input", "input", tr);
        var kindName = kind;
        var attName = elems[0].firstChild.nodeValue;
        var typeName = elemIn[0].value;
        
        if( kind === "calculated" ) {
            $(tr).addClass("calculated");     
        } else {
            $(tr).addClass("scal"); 
        }
        
        
        if(kind == "storage" || kind == "calculated"){    
            _u.newAttribute(emName, attName, typeName, kindName, false, null, true);
            _b.properties.entity(emName, false, false);
        }                
                                                                  
        //update UI
        tr.id=_conf .htmlData.classEm+"-"+emName+"-"+_conf .htmlData.classAttribute+"-"+attName;
        YAHOO.util.Dom.removeClass(tr, "notSaved");
        this.selectRow(tr, null, true);     

        _wRefresh({
            emName : emName, 
            itemName : attName, 
            type:"att", 
            action:"add", 
            isExtend:false, 
            lookForExtend:true, 
            doNotloadFirt:true 
            });
        //console.timeEnd("addNewAtt");

        return attName;     
    };
    
    /**
    * save a new relation. 
    * @param {string} tr line of the attribute in the table
    * @param {string} emName                                
    * @param {string} path
    * @param {string} single only one element in the path
    * @param {string} elem text box                 
    * @param {string} type
    * @param {string} kind
    */
    _o.saveNewRelation = function(tr, emName, path, single, elem, type, kind, news, pathVal, noRS){ 
                      
       emEditor.onEditBox.ref = null;

        if(kind == "alias"){
            $(tr).addClass("flat");
        }else{
            $(tr).addClass("rel");
        }
              
        var d = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", YAHOO.util.Dom.getElementsByClassName("name", "td", tr)[0])[0],
            attName = d.innerHTML,
            em, 
            wrong = false, 
            reversePath,
            emName = emEditor.editorUI.panel.getPanelRefFromID(YAHOO.util.Dom.getAncestorByClassName(tr, "yui-module").id).emName,
            pRef,
            table,
            rowindex,
            oldValue, 
            table,
            tr;
        
        if(single){

            if(kind == "relatedEntities"){   
                kind = "relatedEntities";
                type = path;
                path = pathVal;
            }else{                          
                kind = "relatedEntity";
                type = path;
                path = _g.collectionName(path);
            }

        }
        

        (noRS) ? reversePath = false : reversePath = true;

        if(!wrong){ 
            
            tr.id=_conf .htmlData.classEm+"-"+emName+"-"+_conf .htmlData. classAttribute+"-"+attName;
            YAHOO.util.Dom.removeClass(tr, "notSaved");

            oldValue = _u.newAttribute(emName, attName, type, kind, true, path, news, reversePath); 
            
            if( !news ) {
                //call remove
                var alosoToRm = _oR.getAttributesLinks(emName, attName);

                $.each(alosoToRm, function(index, value) { 
              
                  pRef = emEditor.editorUI.panel.getPanelRef(value.emName);
                  table = $("#"+pRef.id+' .attributesTable').get()[0];
                  rowindex = $("#entityModels-"+value.emName+"-attribute-"+value.attName).get()[0].rowIndex;
                  _u.remove.attributes(value.emName, value.attName);
                  _wRefresh({emName : value.emName, itemName:value.attName, type:"att", action:"remove", lookForExtend:true, "table": table, "rowIndex": rowindex});
              
                });
             
            
                 _b.properties.attribute(emName, attName, false);      
            }
 
            _wRefresh( {
                emName : _check.whosExtends(emName)[0], 
                emStart : emName, 
                itemName : attName, 
                type:"att", 
                action:"add", 
                isExtend:true, 
                lookForExtend:true, 
                extendFrom : emName 
            });
            
            
            if( oldValue ) {
                //ask to remove or not the old path (after an update) if not used
                /*if ( !_oR.getAttributesLinks ( oldValue.oldTarget, oldValue.oldPath ) ) {
                    
                    table = $("#"+emEditor.panels[ emEditor.panelsRef[oldValue.oldTarget] ].id).find("table.attributesTable").get()[0];
                    tr = $("#entityModels-"+oldValue.oldTarget+"-attribute-"+oldValue.oldPath).get()[0];
                    emEditor.toRemoveAfterUpdate = { table:table, tr:tr};
                  
                }*/
            }
                        
            return attName;
        }else{
            return null;
        }

    };
    
    _o.saveTypeBox = function( elem, news ) {  
        
        var attName, 
            cont, 
            emName  = emEditor.panels[ emEditor.panelsRef[ $(elem).closest(".yui-panel").get()[0].id ] ].emName,
            ext     = _check.doesExtends(emName),
            menu,
            tr,
            newValue,
            val;


        //switch to old value if available end if the input is empty
        if (emEditor.onEditBox.oldValue) {
            if (!elem.value || elem.value == "" || elem.value == " ") {
                elem.value = emEditor.onEditBox.oldValue;
            }
        }

        if (!elem.value || elem.value == " " || elem.value == "") { 

            elem.value = _conf.defaultAcValue;
        }
        
        if (emEditor.onEditBox.oldValue != elem.value) { 

            tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
            newValue = elem.value;//$("#"+elem.id).val();
            //validate name
            if (newValue.charAt(newValue.length-1) == ".") {
                $("#"+elem.id).val(newValue.slice(0, newValue.length-1)); 
                newValue = elem.value;//$("#"+elem.id).val();
            }  
            attName = this.manageType(emName, elem, newValue, tr, news, null, ext);
            
            if (YAHOO.util.Dom.getElementsByClassName("ac_results", "div", document.body)[0]) {
                menu = YAHOO.util.Dom.getElementsByClassName("ac_results", "div", document.body)[0].style.display;
            } else {
                menu = null;
            }

        } else {

            newValue = elem.value;
        
        }
        
        emEditor.onEditBox = {};
       
        if (!menu || menu == null || menu == "none") {
            val = newValue;
            cont = elem.parentNode;
            emEditor.editorUI.dom.removeNode(cont, elem);
            cont.innerHTML = "<div title='type' contentEditable='true' class='"+_conf.htmlData.contentEditable+"2'>"+val+"</div>";            
             
            if (!emEditor.unknownAskWhatToDo && $(cont).hasClass("typeDoesNotExist")) {
                emEditor.unknownAskWhatToDo = true;
                 sc = $(emEditor.selectedItems.item);
                 sc.btOff();
                 val = sc.find(".editable_input2").get()[0].textContent;
                 //_h.click.addNewEm(null, val);
                 emEditor.unknownAskWhatToDo = false;  
            }
             
            return {elem:cont.firstChild, attName:attName};

        } else {
            return {elem:null, attName:attName};
        }
    };
    
    _o.savePathBox = function(elem, news){ 
        var tr, 
            typeElemn, 
            cont, 
            status  = "", 
            i       = 1,
            go      = false,
            firstVal,
            emName,
            panelID;
        
        tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
        if (emEditor.onEditBox.oldValue) {
            if (!elem.value || elem.value == "" || elem.value == " ") {
                elem.value = emEditor.onEditBox.oldValue;
            }
        }
                
        if(elem.value == "" || elem.value == " " || !elem.value){ 
            //do not save and add an status
            status = "onProcess";
            _vu.typeCell(tr, null, null, true);
        }else{
            //save
            typeElem = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable+"2", "div", tr)[0];
            $(typeElem).addClass("em");
            
            var names = _g.emNoRelationAttributeNames( _g.dataClassName(typeElem.innerHTML, true) );

            for (var k in names) {
                firstVal = elem.value;
                if (names[k] === elem.value) {
                    while( !go ) {
                        if( names[k] === elem.value ) {
                            elem.value = firstVal + i;
                            i = i+1;
                        } else {
                            go = true;
                        }
                    }
                    break;
                }


            }            
            
            panelID = $(elem).closest(".yui-overlay").get()[0].id;
            emName = emEditor.editorUI.panel.getPanelRefFromID( panelID ).emName;
                        
            this.manageType(emName, typeElem, typeElem.innerHTML, tr, news, elem.value);
        }
        //switch back to a div
        cont = elem.parentNode;
        emEditor.editorUI.dom.removeNode(cont, elem);
        cont.innerHTML = "<div title='path' contentEditable='true' class='"+_conf .htmlData.contentEditable+"2 pathMany "+status+"'>"+elem.value+"</div>";
        YAHOO.util.Event.addListener(cont.firstChild, "focus", function (e) {_o.switchToEditMode(this, e);});
        


    };
    
    _o.saveNewType = function(name, extend){  

        _u.type(name, extend); //n.firstChild.nodeValue, currentValue

        //reload ui if needed
        if(emEditor.emToUpdateForUI.length > 0){
            for(var k in emEditor.emToUpdateForUI){
                _windows.reLoad(emEditor.emToUpdateForUI[k], true, true);
            }
            emEditor.emToUpdateForUI = [];
        }
        
        if(emEditor.tabKey){
            emEditor.tabKey = false;
            this.selectRow(line, null, true);               
        }
        
    }
    
})();