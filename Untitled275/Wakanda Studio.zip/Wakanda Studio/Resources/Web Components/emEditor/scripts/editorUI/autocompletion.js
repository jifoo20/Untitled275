/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    /**
    * autocompletion management
    */
    emEditor.editorUI.autocompletion = {};
    _aC = emEditor.editorUI.autocompletion;
    
    _aC.lookForClassToAdd = function(val){
        if(val){
            var addCustumClass = val.split("&?"), cl;
            switch(addCustumClass[1]){
            case "em": 
                val = addCustumClass[0]; 
                cl = "emAcListMany";
                break;
            case "emSing": 
                val = addCustumClass[0]; 
                cl = "emAcList";
                break;
            case "cusTypes": 
                val = addCustumClass[0];
                cl = "customTypesAcList";
                break;
            default: cl = "";
            }
            
            return {val:val, cl:cl};
        }else{
            return {};
        }           
    },
    /**
    * init the ac on an input/div
    * @param 
    */
    _aC.init = function(obj, target, multiple, addInfo){

                var enterMessage, endmsg, notExistMessage;
                    var au = true, items;
                    switch (obj){
                        case "path": 
                            enterMessage = 'Enter a path to reverse.';
                            endmsg = "Enter a path to reverse.";
                            notExistMessage = 'This relation attribute does not exist.'; 
                            break;
                        case "attProperty":
                            au = false;
                            break;
                        case "scriptKind":
                            enterMessage = 'Choose an sctipt kind.';
                            endmsg = "Choose a scriptKind in order to create a computed attribute.";
                            notExistMessage = 'Wrong !';
                            break;  
                        case "extends" :
                            if(addInfo == "type"){ 
                                enterMessage = 'Choose a scalar type to extend.';
                                endmsg = "Choose a scalar type to extend.";
                                notExistMessage = 'This type does not exist.';
                            }else{
                                enterMessage = 'Choose an entity Model name.';
                                endmsg = "The new Entity will inherit all the Attributes from the one you select here.";
                                notExistMessage = 'This entity Model does not exist.';
                            }
                            break;
                        case _conf.htmlData.newEmProperty: 
                            enterMessage = 'Choose a property name.';
                            endmsg = "Choose a property name.";
                            notExistMessage = 'This property does not exist and will not be saved.';
                            break;  
                        case "type": 
                            enterMessage = 'Choose a type.';
                            endmsg = "Choose a type to create an attribute or a Datastore Class or Collection to create a relation attribute.";
                            //notExistMessage = ' ';
                            break;  
                        case "newEmAttProperty": 
                            enterMessage = 'Choose the property to add.';
                            endmsg = "Choose the property to add.";
                            notExistMessage = 'This property does not exist !';
                            break;              
                        default: au = false;
                    }
                    if(au){

                        $("#"+target).autocompletes([""], {
                                matchContains: false,
                                scroll: true,
                                startmsg: enterMessage,
                                noresultsmsg: notExistMessage,
                                endmsg: endmsg,
                                multiple:multiple
                                });
                    }

                    return au;
    },
    /**
    * set the content of the list
    * @param 
    */
    _aC.buidItemsList = function(notSavedItems, obj, target, addMore){            
                     
                var au = true, 
                    items, tr, rel, ma, ty, ext,
                    tg,
                    trAn,
                    attrN,
                    type,
                    toRm,
                    emName = emEditor.editorUI.panel.getActiveElemName(), 
                    empty = false,
                    objRef = null;                           

                if( target ) {
                    tg = document.getElementById(target);
                    objRef = $("#"+target);
                }
         
                switch (obj) {
                    case "path":
                        
                        tr = YAHOO.util.Dom.getAncestorByTagName(tg, "tr");
                        ma = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable+"2", "div", tr)[0].innerHTML;
                        ty = ma;
                        items = _g.relations(ty, false, true);  //manyToOnRelation
                        ext = _check.doesExtends(ty);
                        items = items.concat( _g.relations(ext, false, true) );
                        if( items.length === 0 ) {
                            empty = "create";
                        }else{
                            empty = items;
                        }
                        
                    break;
                    case "attProperty":
                        au = false;
                        
                    break;          
                    case "scriptKind":
                        items = [_conf.xmlData.javascript, _conf.xmlData.db4d]; 
                        break;
                        
                    case "newEmAttProperty": 
                        tr = YAHOO.util.Dom.getAncestorByTagName(tg, "tr");
                        trAn = emEditor.editorUI.dom.getPreviousSiblingByClass(tr, "mainAttRow");
                        attrN = emEditor.uD.getWafData( trAn );
                        type = _g.emAttPropertyValue(emName, attrN, "type");
                        items = _g.propertyList4Autocomp(type);                
                        //remove already added properties
                        toRm = _g.attProperties(emName, attrN);
                        for( var k in toRm ) {
                            this.removeFromDataList(toRm[k], items);
                        }
                        break;
                        
                    case "extends" : 
                        if(addMore == "typePropertiesTable"){
                            items = _g.scalarTypes();
                        }else{
                            items = emEditor.editorData.getEmList();
                            this.removeFromDataList(emName, items);
                        }           
                        break;
                        
                    case _conf.htmlData.newEmProperty: 
                        items = _g.emPropertiesList();
                        var propertiesUsed = _g.emProperties(emName);
                        for(var key in propertiesUsed){
                            this.removeFromDataList(propertiesUsed[key], items);
                        }
                        if(notSavedItems){
                            for(var key2 in notSavedItems){
                                this.removeFromDataList( emEditor.uD.getWafData(notSavedItems[key2] ), items );
                            }
                        }
                        break;
                        
                    case "type" : 
                        tg = objRef.get()[0];   
                        tr = YAHOO.util.Dom.getAncestorByTagName(tg, "tr");
                        var attName = emEditor.uD.getWafData( tr );
                        var kind = _g.emAttributeName(emName,attName); 
                        rel = _g.relations(emName, true);
                        items = _g.typeList(false, true, false);
                        items = items.concat(rel); 
                        break;  
                        
                    default: 
                        au = false;
                }
        
                if( au && objRef ) {
                    objRef.flushCache();
                    objRef.setOptions({data: items});
                }
        
                return empty;
    },
    /**
    * return the ac list, function use for the new ac system usind the standart Jq autocomplete
    * @param {string} item the item to autocomplete
    */
    _aC.getItemsList = function ( item, attType ) {
                
        var list    = null,
            emName  = emEditor.selectedItems.emName;
            attName = emEditor.selectedItems.item.id.split("-")[3],
            type    = null;
        
        if (emEditor.selectedItems.isInherited) {
            attName = emEditor.selectedItems.item.id.split("-")[4];
        } else {
            attName = emEditor.selectedItems.item.id.split("-")[3];
        }    
                                
        switch ( item ) {
        case "format" : 

            if (attType) {
                type = attType;
            } else {
                type = _g.emAttPropertyValue(emName, attName, "type");
            }

            switch ( type ) {
            case "date" :
                list = _conf.format.date.text;
                break;
            case "string" :
                list = _conf.format.string.text;
                break;    
            default:
            }
            break;
        default:
        }
        
        return list;
    },
    /**
    * display the ac list by sending key down event
    * @param {jquery object} o
    */
    _aC.getSelected = function(){ 
                var autoRes = YAHOO.util.Dom.getElementsByClassName("ac_results", "div", emEditor.editorUI.panel.getActiveID())[0];
                var lis = autoRes.getElementsByTagName("li");
                var ul = autoRes.getElementsByTagName("ul")[0];
                var selElem = YAHOO.util.Dom.getElementsByClassName("ac_over", "li", autoRes)[0];
                return selElem.innerHTML;
    },
    /**
    * set emEditor.currentAutoCompSel to the current selected value
    * @param {html li object} li
    */
    _aC.setCurrent = function(li){ 
        if(!li){
            emEditor.currentAutoCompSel = null;
           // emEditor.currentAutoCompSelType = null;
        }else{
            emEditor.currentAutoCompSel = li.textContent;
            emEditor.currentAutoCompSelType = null;
            if($(li).hasClass("emAcList")){
                emEditor.currentAutoCompSelType = "emSing";
            }
            if($(li).hasClass("emAcListMany")){
                emEditor.currentAutoCompSelType = "em";
            }
        }
       
    },
    /**
    * just set emEditor.autocompOn at true if the ac is running
    * @param {bool} val
    */
    _aC.setState = function(val){
        emEditor.autocompOn = val;
    },
    /**
    * display the ac list by sending key down event
    * @param {jquery object} o
    */
    _aC.display = function(o){
        var e = jQuery.Event("keydown");
        e.which = 40; // Some key value
        //var o = $("#"+elem.id);
        o.trigger(e);
    },
    /**
    * remove a given element from an array
    * @param {string} prop  element to remove
    * @param {array} tab 
    * @return {array}   
    */  
    _aC.removeFromDataList = function(prop, tab){
        if(typeof prop != "function"){
                for(var key in tab){
                    if(tab[key] === prop){ tab.splice(key,1);}
                }
         }
        return tab;
    }


})();