/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
    /*
    todo:
    feed back for the user
    */

    emEditor.editorUI.validate = {};

    /**
    * remove all not js valid digits from the giver string
    * @param {String} data string to check
    * @return {String} the string updated
    */
    emEditor.editorUI.validate.makeJSCompliant = function( data , checkNumbers ) {
       
        if( data ) {
            data = data.replace(/\s/g, "_");
            var l = data.length;
            var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?~"; 
            for (var i = 0; i < l; i++) {
                if (iChars.indexOf(data.charAt(i)) != -1) {
                    data = data.replace(data.charAt(i),' ');  
                }
            }
            data = data.replace(/\s/g, "");
            //if(checkNumbers){
                data = this.cleanFromStartNumbers(data);
            //}
            //data = this.cleanFromAccent(data);
            return data;
        }else{
            return "";
        }
    };
  
    /**
    * remove all not js valid digits from the giver string
    * @param {String} data string to check
    * @return {String} the string updated
    */
    emEditor.editorUI.validate.cleanFromAccent = function( s ) { 
        var temp = s.replace(/[àâä]/gi,"a");
        temp = temp.replace(/[éèêë]/gi,"e");
        temp = temp.replace(/[îï]/gi,"i");
        temp = temp.replace(/[ôö]/gi,"o");
        temp = temp.replace(/[ùûü]/gi,"u");
        temp = temp.replace(/[ç]/gi,"c");
        return temp;
    }; 
  
    /**
    * remove all not js valid digits from the giver string
    * @param {String} data string to check
    * @return {String} the string updated
    */
    emEditor.editorUI.validate.cleanFromStartNumbers = function( s ) {
        var firtDigit = s[0], 
            reg = /\d/g;

        if(reg.test(firtDigit)){
            s = "_" + s;
        }
        
        return s;
    };

    /**
    * check if the value entered in the given field is correct, depending on is type, defined on the config.js file
    * @param {String} fieldName
    * @param {String} attributeType  
    * @param {String} value  
    * @return {object} { isWrong = false, requiredType = number } 
    */
    emEditor.editorUI.validate.checkType = function( fieldName, attributeType, value ) {
    
        var result = { },
            requiredType,
            valueType, 
            typeProp, 
            list = [],
            isInteger = parseInt(value),
            stopChecking = false; 
        
        result.isWrong = false;
        
        if( !isNaN( isInteger ) ) { 
           value = isInteger;
        }
        
        
        switch (attributeType) {
            case "string" : 
                list = _conf.typeProperties[attributeType];
                list = list.concat(_conf.attProperties.forString);
                break;
            case "number" : 
            case "long" :
                list = _conf.typeProperties["number"];    
                list = list.concat(_conf.attProperties.forNumber);
                break;  
            default:  stopChecking = true;
        }

        if( !stopChecking ) {
            
            $.each(list, function(i, elem){

                if( elem && elem[fieldName] ) {
                    requiredType = elem[fieldName];
                    return;
                }

             });

             if( requiredType && requiredType != "string") {

                 valueType = typeof(value);

                 if( valueType != requiredType ) {
                     result.isWrong = true;
                     result.requiredType = requiredType;
                 }
             }
        } else {
            result.isWrong = false;
        } 

        return result;
    };
    
    /**
    * For Classes properties, check if the value entered in the given field is correct, depending on is type, defined on the config.js file
    * @param {String} fieldName
    * @param {String} value  
    * @return {object} { isWrong = false, requiredType = number } 
    */
    emEditor.editorUI.validate.checkTypeForClass = function( fieldName, value ) {
    
        var result = { },
            requiredType,
            valueType, 
            typeProp, 
            list = [],
            isInteger = parseInt(value),
            stopChecking = false; 
       
        result.isWrong = false;
        
        if( !_uA.isValueIn( fieldName, _conf.notToValidate.emProperty ) ) {
            
            if( !isNaN( isInteger ) ) { 
               value = isInteger;
            }

            $.each(_conf.emProperty, function(i, elem){

                if( elem[fieldName] ) {
                    requiredType = elem[fieldName];
                    
                    return false;
                }

             });

            if( requiredType ) {
                valueType = typeof(value);
                
                if( valueType != requiredType ) {
                     result.isWrong = true;
                     result.requiredType = requiredType;
                 } else {
                     result.isWrong = false;
                     result.requiredType = requiredType;
                 }
            }
                
        }
      
        return result;
    }
})();
