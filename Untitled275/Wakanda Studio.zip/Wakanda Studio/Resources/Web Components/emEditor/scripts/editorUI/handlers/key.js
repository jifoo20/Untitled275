/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    /**
    * keypress events management
    */
    _h.key = {
        
            /**
            * specific keypress manager for the path input !!!!!!!!!!! deprecated
            * @param {event} ev 
            * @param {html object} elem html input
            */
            inputPathPress:function(e, elem){  
                switch (e.keyCode) 
                {   
                    case 13:    
                        e.preventDefault(); e.stopPropagation();
                        if(!emEditor.autocompOn){
                            elem.blur();
                        }else{
                            emEditor.autocompOn = false;
                        }
                    break;
                    default:   // _o.managePathInput(elem, e.keyCode);
                }//end switch
            },
            /**
            * keypress event for properties panel
            * @param {event} ev 
            * @param {dom} elem text box
            */  
            fieldPress:function(e, elem){ 
                
                switch (e.keyCode) // 9=>tab, 13=>enter 39->next 37->back 40->bottom
                {   
                    case 13:    if(emEditor.uD.getElementType(elem) != "description"){
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if(!emEditor.autocompOn){
                                        elem.blur();
                                    }else{
                                        emEditor.autocompOn = false;
                                    }
                                }
                                break;
                    default:    
                 }//end switch
            },
            /**
            * keypress event for dock text fields
            * @param {event} ev 
            * @param {dom} elem text box
            */
            forDock:function(ev, elem){
                switch (ev.keyCode) // 9=>tab, 13=>enter 39->next 37->back 40->bottom
                {           
                case 13:    ev.preventDefault();ev.stopPropagation();
                            emEditor.enterKey = true;
                            elem.blur();
                            break;
                case 9:     //ev.preventDefault();
                            break;
                default:    
                }//end switch
            },
            /**
            * keypress event for new items
            * @param {event} ev 
            * @param {dom} elem text box
            */
            forNew:function(ev, elem){
                switch (ev.keyCode) // 9=>tab, 13=>enter 39->next 37->back 40->bottom
                {               
                case 13: 
                    ev.preventDefault();ev.stopPropagation(); 
                    emEditor.enterKey = true;
                    elem.blur();
                    break;  
                case 9:     
                    ev.preventDefault();ev.stopPropagation(); 
                    emEditor.tabKey = true;
                    elem.blur();
                    break;
                default:    return;
                }//end switch
            },
            /**
            * keypress event at document level
            * @param {event} ev 
            */
            delegate:function(e){ 
               
                    var tr = YAHOO.util.Dom.getElementsByClassName("selected", "tr", "center-body")[0];
                    var bd = YAHOO.util.Dom.getAncestorByClassName(emEditor.onEditBox.ref, "bd"), trs;
                    var target = e.target;
                     
                    if(!bd || bd.parentNode.id != _conf .htmlData.propertiesContainerID){   
                        var table = YAHOO.util.Dom.getAncestorByTagName(tr, "table"), k;
                        if(table){ 
                            switch (e.keyCode) 
                            {   
                            case -1:   
                            break;
                            case 38: 
                                if(!$(target).hasClass('ui-autocomplete-input')){    
                                    if(!emEditor.onEditBox.ref){
                                        if($(tr.previousSibling).hasClass("mainAttRow")){
                                            _o.selectRow(tr.previousSibling, false, false); 
                                        }else{
                                            trs = table.getElementsByTagName("tr");
                                            _o.selectRow(trs[trs.length-1], false, false);
                                        }
                                    }
                                }
                                break;
                            case 40: 
                                if(!$(target).hasClass('ui-autocomplete-input')){    
                                    if(!emEditor.onEditBox.ref){
                                        if($(tr.nextSibling).hasClass("mainAttRow")){
                                            _o.selectRow(tr.nextSibling, false, false); 
                                        }else{
                                            trs = table.getElementsByTagName("tr");
                                            _o.selectRow(trs[0], false, false); 
                                        }  
                                    }
                                }
                                break;
                            case 13: 
                                if(!$(target).hasClass('ui-autocomplete-input')){
                                    e.stopPropagation();
                                    e.preventDefault();
                                    if(table.className == "attributesTable"){ 
                                        trs = table.getElementsByTagName('tr');
                                        if(!emEditor.onEditBox.ref){
                                            tr.firstChild.getElementsByClassName("editable_input")[0].focus();
                                        }
                                    }
                                }
                                 break;
                            case 9 :   break;
                            case 8:   
                            case 46:  
                                    if( !$(target).hasClass('ui-autocomplete-input') ) {
                                        switch(table.className){
                                        case "attributesTable": 
                                            if( emEditor.onEditBox.ref == null && !emEditor.alertMessageDisplayed ) {
                                                e.preventDefault(); 
                                                e.stopPropagation(); 
                                                _oR.attribute(table, tr.rowIndex, tr);
                                            }
                                            break;
                                        case "methodsTable": 
                                            if( emEditor.onEditBox.ref == null ) { 
                                                e.preventDefault(); 
                                                e.stopPropagation(); 
                                                _oR.method(table, tr.rowIndex, tr);
                                            }
                                            break;
                                        case _conf .htmlData.typesTable: 
                                            if( emEditor.onEditBox.ref == null ) { 
                                                e.preventDefault(); 
                                                e.stopPropagation(); 
                                                _oR.type(table, tr.rowIndex, tr);
                                            }
                                            break;  
                                        default: console.error("keypressMain, 8");
                                    }
                                }
                             break;
                            case 32: //space
                            break;
                            default:
                                var container = YAHOO.util.Dom.getAncestorByClassName(emEditor.onEditBox.ref, "yui-module");
                                if(container){ //r && emEditor.onEditBox.ref.offsetWidth > 60
                                    emEditor.editorUI.panel.manageResizeWidth(container, false); 
                                }
                            }
                        }else{  
                            
                            if(emEditor.typeUnkMessage){
                                
                                switch (e.keyCode) {
                                case 38: 
                                case 40: 
                                    var tunk = $(".typeUnkMessage");
                                    var selTunk = tunk.find(".itemSelected");

                                    if(selTunk.hasClass("createEm")){
                                        tunk.find(".createEm").removeClass("itemSelected");
                                        tunk.find(".createType").addClass("itemSelected");
                                    }else{
                                        tunk.find(".createEm").addClass("itemSelected");
                                        tunk.find(".createType").removeClass("itemSelected");
                                    }
                                    
                                    break;
                                default:
                                }
                                
                            }else{ 
                                if(e.keyCode === 13){  
                                    e.stopPropagation();
                                    e.preventDefault();
                                    emEditor.enterKey = true;
                                    e.target.blur();
                                }
                            }
                            
                        }
                    } 
            },
            /**
            * keypress event on text boxes
            * @param {event} ev 
            * @param {dom} elem text box
            */
            press:function(ev, elem){   

                var emName      = emEditor.editorUI.panel.getActiveElemName(), 
                    container   = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"),
                    tabl        = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
                    elemType    = emEditor.uD.getElementType(elem),
                    tabl, 
                    notSavedItems, 
                    b, 
                    tr, 
                    trs,
                    message,
                    attName,
                    attData,
                    path,
                    f;

                switch (ev.keyCode) {                
                case 13:  
                case 9: 

                        if (tabl.className != "attributeTable" && tabl.className != "underKeyForm" && tabl.className != "propertiesTable") { 
                            ev.preventDefault(); 
                            ev.stopPropagation();
                        }
                    
                        notSavedItems = YAHOO.util.Dom.getElementsByClassName("notSaved", "div", tabl);
                        b = YAHOO.util.Dom.getAncestorByTagName(elem, "table");

                        if (!emEditor.autocompOn) { 
                            switch (tabl.className) {
                            
                            case "methodsTable": 
                                elem.blur();
                            break;
                            case "attributesTable": 
                            case "attributeTable":    
                               
                                if (ev.ctrlKey) {
                                    emEditor.editorUI.views.add.entity.attribute(tabl);
                                } else { 
                                    tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                                    trs = tabl.getElementsByTagName('tr');
                                    notSavedItems = YAHOO.util.Dom.getElementsByClassName("notSaved", "div", tabl);
                                    b = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                                    emEditor.enterKey = false; 
                                    emEditor.returnKey = true;

                                    switch(emEditor.uD.getElementType(elem)){ //elem.title
                                    case "name":  
                                        emEditor.enterKey = true; 
                                        emEditor.returnKey = true;
                                        elem.blur();
                                        path = YAHOO.util.Dom.getElementsByClassName("path", "td", YAHOO.util.Dom.getAncestorByTagName(elem, "tr"))[0];
                                        
                                        if( YAHOO.util.Dom.hasClass(path, "tableHidden") ) {
                                            _h.hidePathCollumn(false, elem, true);
                                        }
                                        
                                        f = YAHOO.util.Dom.getElementsByClassName("editable_input2", "div", path);
                                        
                                        if( f[0] ) {
                                            
                                            //attName = $(tr).attr("waf-data");
                                            attName = tr.dataset.info;
                                            attData = _g.emAttribute(emName, attName);
                                            if (attData.kind === "relatedEntity") {
                                                linkedAtributes = _nav.getPathTree(emName, attName, true, emName);
                                            } else if ( attData.kind === "storage") {
                                                linkedAtributes = _nav.flattenedPathTree(emName, attName);
                                            }   
                              
                                            if ( linkedAtributes ) {
                                        
                                                if (linkedAtributes.length != 0) {
                                                    ev.stopPropagation();
                                                    ev.preventDefault();
                                                                                
                                                    message = _conf.langage.en.alertTip.typeUpdate;
                                                    $.each(linkedAtributes, function(index, value) { 
                                                        message = message + "-<i> "+value.attName+"</i> in the <i>"+value.emName+"</i> class.<br>";
                                                    });
                                                
                                                    _b.errorMessage.addNotEditableTypeAlert(tr, message);

                                                    $(tr).btOn();     
                                                
                                                } else {
                                                    f[0].focus();
                                                }
                                            } 
                                          
                                        }
                                        break;
                                    case "type": 
                                        if (ev.keyCode === 13) {
                                            emEditor.enterKey = true;
                                        } else {
                                            emEditor.tabKey = true;
                                        }
                                        elem.blur(); 
                                        break;
                                    case "path": 
                                        emEditor.enterKey = true;
                                        elem.blur();
                                        break;
                                    default :
                                    }
                                }
                            break;  
                            case _conf.htmlData.typesTable: 
                                //
                                break;
                            default:  
                                
                                    if (ev.keyCode === 13 && emEditor.uD.getElementType(elem) != "description") {
                                        ev.preventDefault(); 
                                        elem.blur();
                                    }
                            }

                        }else{  

                            $("#"+elem.id).getSelected();
                            if (emEditor.currentAutoCompSel == null) {  
                                
                                if (emEditor.typeUnkMessage) { 
                                     emEditor.autocompOn = false;
                                     emEditor.enterKey = false;
                                     emEditor.unknownAskWhatToDo = true;
                                     var el = elem.parentNode, sc;
                                     elem.blur();
                                    
                                    var tunk = $(".typeUnkMessage");
                                    var selTunk = tunk.find(".itemSelected");

                                    if(selTunk.hasClass("createEm")){
                                        sc = $(el).closest("tr");
                                        sc.btOff();
                                        val = sc.find(".editable_input2").get()[0].textContent;
                                        _h.click.addNewEm(null, val);
                                        emEditor.unknownAskWhatToDo = false;
                                    }else{
                                        sc = $(el).closest("tr");
                                        sc.btOff();
                                        val = sc.find(".editable_input2").get()[0].textContent;
                                        _o.saveNewType(val, "string");
                                        var target = _conf .htmlData.typesTable;
                                        var tb = document.getElementById(target);
                                        _b.types(tb);
                                        emEditor.unknownAskWhatToDo = false;
                                    }
                                }else{
                               
                                    _o.setInputWidth(elem);
                                    emEditor.editorUI.panel.manageResizeWidth(container, false);
                                    emEditor.enterKey = true;
                                    elem.blur();
                                }


                            }else{ 
                                if(tabl.className != _conf .htmlData.typesTable){
                                    var v = $("#"+elem.id).val();
                                    if(v.charAt(v.length-1) == "."){
                                        $("#"+elem.id).val(v.slice(0, v.length-1));
                                    }
                                    if(_o.setInputWidth(elem)){ 
                                        emEditor.editorUI.panel.manageResizeWidth(container, false); 
                                    }
                                }
                            }

                            emEditor.autocompOn = false;

                    }   
                    break;
                    
                      /*  if( elem.nodeName  === "INPUT") {
                            _o.setInputWidth(elem);
                            //if(elem.offsetWidth > 60){
                                emEditor.editorUI.panel.manageResizeWidth(container, false); 
                            //}
                        }*/
                    break;
                    case 8:   
                        if(elemType == "type" || elemType == "path"){
                            if(elemType == "path"){
                                _o.managePathInput(emEditor.onEditBox.ref, ev.keyCode);
                            }else{
                                _o.manageTypeInput(elem, true);
                            }
                        }else{ 
                            if (elem.firstChild.nodeValue == null && elemType == "name") { 
                                var table = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                                var tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                                ev.stopPropagation(); 
                                ev.preventDefault();
                            } else {   

                                if(container && elemType != "name"){ 
                                    var tabs = container.getElementsByTagName("TABLE");
                                    if (_o.setInputWidth(elem)) { 
                                        emEditor.editorUI.panel.manageResizeWidth(container, true); 
                                    }
                                } else if (elemType =="name") { 
                                    if(container){
                                        container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module");              
                                        var tbs = container.getElementsByTagName("table"),
                                            tb = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
                                            oWi = tb.offsetWidth,
                                            resizePan = false,               
                                            newOwi = oWi-7;
                                            
                                        if (newOwi > 170) {
                                            for (var t in tbs) {
                                                if (tbs[t].nodeName == "TABLE") {
                                                    resizePan = true;
                                                    tbs[t].style.width=newOwi+"px";
                                                }
                                            }
                                            YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module").style.width = newOwi-_conf .htmlData.ajustWidth+"px";
                                        }
                                    }
                                    
                                }
                            }
                        }
                    break;          
                    default:  
                        setTimeout(function() { /* keep this timeout */ 
                            if( ev.keyCode != 39 && ev.keyCode != 37 && ev.keyCode != 91 && ev.keyCode != 18 && ev.keyCode != 16 ) {   
                                    if( elemType == "type" || elemType == "path" ) { 
                                        if( ev.keyCode == 190 ) {
                                            if( elemType == "path" ) { 
                                                _o.managePathInput(emEditor.onEditBox.ref, ev.keyCode);
                                            } else { 
                                                _o.manageTypeInput(elem, false, true);   
                                            }
                                        }else{  
                                            _o.setInputWidth(elem);
                                            emEditor.editorUI.panel.manageResizeWidth(container, false); 
                                                                                    }
                                    }

                                    if(elemType == "name" && tabl.className != _conf.htmlData.typesTable){

                                       // if(elem.offsetWidth > 60){
                                            emEditor.editorUI.panel.manageResizeWidth(container, false); 
                                        //}
                                    }

                            }  
                            
  
                        },0);
                }//end switch
            }
        
    };
    
})();