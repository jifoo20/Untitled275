/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
   emEditor.editorUI.views.update = {};
   _vu = emEditor.editorUI.views.update;    
   
   _vu.layout = {
            toogleBoth:function() { 

                if (emEditor.leftLayoutState == 'visible' || emEditor.rightLayoutState == 'visible') {

                    emEditor.layout.getUnitByPosition('left').collapse();
                    emEditor.leftLayoutState = 'collapsed';
                    emEditor.layout.getUnitByPosition('left').set('width', 1);
                    emEditor.layout.getUnitByPosition('right').collapse();
                    emEditor.rightLayoutState = 'collapsed';
                    emEditor.layout.getUnitByPosition('right').set('width', 1);

                } else {

                    emEditor.layout.getUnitByPosition('left').expand();
                    emEditor.layout.getUnitByPosition('right').expand();
                    emEditor.rightLayoutState = 'visible';
                    emEditor.leftLayoutState = 'visible';

                    if (emEditor.selectedItems.emName === "___MODEL") {

                        _b.properties.model();

                    } else {

                        if (emEditor.selectedItems.item) {

                            if (emEditor.selectedItems.itemType === "attribute") {
 
                                _b.properties.attribute(emEditor.selectedItems.emName, emEditor.selectedItems.itemName);

                            } else {

                                _b.properties.method(emEditor.selectedItems.emName, emEditor.selectedItems.itemName);

                            }

                        } else {
console.log("lklklk")
                            _b.properties.entity(emEditor.selectedItems.emName);

                        }
                    }    
                }
                emEditor.previewObj.setScopeSize();   
             },
             toogleX:function(layout) {
                if (emEditor.leftLayoutState == 'visible' || emEditor.rightLayoutState == 'visible') {
                    emEditor.layout.getUnitByPosition(layout).collapse();
                    emEditor.layout.getUnitByPosition(layout).set('width', 1);
                    if (layout == "left") {
                       emEditor.leftLayoutState = 'collapsed';
                    } else {
                       emEditor.rightLayoutState = 'collapsed';  
                    }
                  } else {
                    emEditor.layout.getUnitByPosition(layout).expand();
                    if (layout == "left") {
                        emEditor.leftLayoutState = 'visible';
                    } else {
                        emEditor.rightLayoutState = 'visible';  
                    }
                  }
             },
             toogle:function(layout, layoutState) {
                if (layoutState == 'visible') {
                    emEditor.layout.getUnitByPosition(layout).collapse();
                    layoutState = 'collapsed';
                    emEditor.layout.getUnitByPosition(layout).set('width', 1);
                } else {
                    emEditor.layout.getUnitByPosition(layout).expand();
                    layoutState = 'visible';
                }  
             }  
           };
           
   _vu.events = {
                addEvent:function(table, val){
                    var row = table.insertRow(-1);
                    //remove icns
                    var cell = row.insertCell(-1);
                    cell.innerHTML = val;
                    //kind
                    cell = row.insertCell(-1);
                    cell.innerHTML = "<div class=''></div>";
                    //edit icns
                    cell = row.insertCell(-1);
                    cell.title = val;
                    cell.innerHTML = "<div class='editScript'></div>";
                    YAHOO.util.Event.addListener(cell, "click", function (e) { _h.click.events(e, this);});
               },
               menuButton:{

                   removeItem:function(id, val){
                       var lis = $("#"+id+" li");
                    $.each(lis, function(key, value) { 
                         if (value.firstChild.innerHTML == val) {
                             $("#"+value.id).remove();
                         }
                       });
                   }
               }
           };
           
   _vu.toggleAttr = function(k, e){      
       
        var pid = emEditor.editorUI.panel.getActiveID(),
            res = "true",
            t;

        if ($(e.currentTarget).hasClass("hide")) { 
            $("#"+pid+" ."+k).addClass("removedHidden");
            res = "false";
            $(e.currentTarget).removeClass("hide");
            $(e.currentTarget).addClass("see");
        } else {
            $("#"+pid+" ."+k).removeClass("removedHidden");
            $(e.currentTarget).addClass("hide");
            $(e.currentTarget).removeClass("see");
        }

        switch (k) {
        case "scal": 
            t = "scalarVisible"; 
        break;
        case "rel": 
            t = "relVisible"; 
            $.queued.add(function(){ 
                if (emEditor.curve && emEditor.relationCurve) { 
                 _c.loadRelationCurve(  false, emEditor.panels[emEditor.panelsRef[emEditor.editorUI.panel.getActiveID()].panel] ); 
                }
            });
            $.queued.add(function(){ 
                $.queued.clear(); 
            });
        break;
        case 'flat': 
            t = "flatVisible"; 
        break;
        case 'meth': 
            t = "methVisible"; 
        break;    
        case 'methodInherited' : 
            t ="methodInhVisible"; 
        break; 
        case 'inherited' : 
            t = "inheritedVisible"; 
        break; 
        case 'calculated' : 
            t = "calcuVisible"; 
        break; 
        default:
        }

        if (res === "false") {
            $(e.currentTarget).find("span").get()[0].innerHTML = "Show";
        } else {
            $(e.currentTarget).find("span").get()[0].innerHTML = "Hide";
        }

        _u.extraProperties.set(emEditor.editorUI.panel.getPanelRefFromID(pid).emName, t, res);

    };
           
   _vu.innerForm = function(sel) {
            
        var oldVal, 
            table,
            v, 
            elem,
            items,
            addListenner,
            edit, 
            select,
            trs,
            type = false,
            next = null;

        if ($(sel).hasClass("typeEditBox")) { 
           type     = true;
           oldVal   = _g.typePropertyValue($(".bt-active").attr("bt-xtitle") , sel.title, "defaultFormat");
        } else { 
           oldVal   = _g.emAttPropertyValue(emEditor.selectedItems.emName, emEditor.uD.getWafData(emEditor.selectedItems.item), "defaultFormat", sel.title);
        }

        table = YAHOO.util.Dom.getAncestorByTagName(sel, "table");

        if (oldVal && emEditor.uD.getWafData(sel) === "presentation") { 
           trs = YAHOO.util.Dom.getElementsByClassName("presentation", "tr", table);
           for (var k in trs) {
               //remove in data
               elem = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", trs[k])[0];
               if(type){
                   _u.remove.typeProperty($(".bt-active").attr("bt-xtitle"), elem.title, true); //sel.title
               }else{ 
                   _u.remove.attributeUnderProperty(emEditor.selectedItems.emName, emEditor.uD.getElementType(elem), emEditor.uD.getWafData(emEditor.selectedItems.item), "defaultFormat", emEditor.selectedItems.isInherited);
               }
               //remove in UI
               table.deleteRow(trs[k].rowIndex);
           }
        }

        //update form
        items = _conf.typeProperties.presentation[sel.value]; 
        addListenner = _b.addFormRows(table, items, "", sel.value, type);

        for (var k in addListenner) {
   
           edit = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", addListenner[k])[0];

           if (edit) {
               YAHOO.util.Event.addListener(edit, "focus", function (e) {_o.switchToEditMode(this);});
               YAHOO.util.Event.addListener(edit, "keypress", function (e) {
                   if($(this).hasClass("typeEditBox")){ $(".bt-active").refreshCanvas(); }
                   _h.key.fieldPress(e, this);
               });
               YAHOO.util.Event.addListener(edit, "blur", function (e) { _h.blur.main(e, this);});
           } else {
               sel = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.editableSelect, "select", addListenner[k])[0];
               YAHOO.util.Event.addListener(sel, "change", function (e) { 
                 //_h.select.defaultFormat(e, this);
               });
           }
   
        }

        $(".bt-active").refreshCanvas();
       
   };
           
   _vu.extendCellForType = function(line) {
       
           var cell = YAHOO.util.Dom.getElementsByClassName("extendCell", "td", line)[0],
               inp;
               
           cell.appendChild(_b.editableBox("extends", ""));
           inp = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", cell)[0];
           YAHOO.util.Event.addListener(inp, "focus", function (e) {_o.switchToEditMode(this, e);});
           inp.id=emEditor.ids++;
           autoc = _aC.init(inp.title, inp.id, false, "type");
           YAHOO.util.Event.addListener(inp, "keydown", function (e) {_h.key.forNew(e, this);});
           YAHOO.util.Event.addListener(inp, "blur", function (e) { _h.blur.forNew(e, this);});
           inp.focus();
   };
           
   _vu.methods = function(elem, methName) {
       
       var tdName = YAHOO.util.Dom.getAncestorByTagName(elem, "td"),
           tdEdit = tdName.nextSibling,
           tdApply = tdEdit.nextSibling,
           foc,
           edit;
           
       tdName.title = "name";
       emEditor.uD.setWafData(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"), methName);
       foc = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", tdName)[0];
       emEditor.uD.setElementType(foc,"name");
       YAHOO.util.Event.removeListener(foc, "blur");
       YAHOO.util.Event.addListener(foc, "blur", function (e) { _h.blur.main(e, this);});
       YAHOO.util.Event.addListener(foc, "focus", function (e) {_o.switchToEditMode(this, e);});
       tdEdit.innerHTML='<div class="editScript"></div>';
       YAHOO.util.Event.addListener(tdEdit, "click", function (e) {_h.editMethod(this);});
       tdApply.innerHTML = _b.selectBox(_conf .methodPath.target, "scriptKind", null, "entity");
       edit = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.editableSelect, "select", tdApply)[0];
       YAHOO.util.Event.addListener(edit, "change", function (e) {_o.manageTextBox(this);});    
       YAHOO.util.Event.addListener(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"), "click", function (e) { _o.selectRow(this, e);});
   };
           
   _vu.typeCell = function(tr, rel, type, error, kind){ 

       var trJq     = $(tr),
           tds      = trJq.find("td.type"),
           typeTD   = tds.find("div.typeIcns").get()[0],
           unk      = false,
           emName,
           k;

      if( trJq.find("td.path .editable_base").hasClass("typeDoesNotExist") ) {
          error = true;
      }
      
       if (error) {
           unk = true;
           YAHOO.util.Dom.addClass(typeTD, "typeIsunknown");
       } else {
           
           if (!type || type == "") {
               type = trJq.find("td.path input.editable_input").get()[0].value;
           }
           
           //get root type (if custom)
           var scalarType = _check.scalarType(type);

           typeTD.className = "";
           YAHOO.util.Dom.addClass(typeTD, "typeIcns"); 
           if(rel){
               if(type){ 
                   if(emEditor.emRef[type] != undefined ) {
                            
                           if(kind == "relatedEntities"){
                               YAHOO.util.Dom.addClass(typeTD, "typeIsRelatedEntities");
                           }else{
                               YAHOO.util.Dom.addClass(typeTD, "typeIsRelatedEntity");
                           }
                           
                   }else{  
                       if(!_check.isType(scalarType)){
                            YAHOO.util.Dom.addClass(typeTD, "typeIsRelatedEntity");
                       }else{
                            YAHOO.util.Dom.addClass(typeTD, "typeIs"+scalarType);
                       }
                   }
               }else{ 
                       YAHOO.util.Dom.addClass(typeTD, "typeIsRelatedEntities");
               }
           }else{
               YAHOO.util.Dom.addClass(typeTD, "typeIs"+scalarType);
           }
       }
       
       k = $(tr).find(".keyIcns");
       
       emName = emEditor.selectedItems.emName;
       
       if (!_uA.isValueIn(scalarType, _conf.primKeyType)) {
            if(k.length > 0){
                trJq.find(".keyIcns").remove();
                trJq.find(".primKey").removeClass("primKey");
                
                if (!_g.primKey(emName)) { 
                    emEditor.errorManager.addError({
                       "class"        : emName,
                       "message"      : "key"    
                    },
                    false);
                }
            }
       } else {
            if (k.length == 0) {
                trJq.find("td.type").prepend('<div class="keyIcns"></div>');
            }
       }
       
       return unk;
       
   };
           
   _vu.primKey = function(emName, val, oldKey) {
       
       var row      = $("#"+_b.attrituteRowID(emName, val)),
           nameBox,
           typeBox,
           oldRow,
           oldNameBox,
           oldTypeBox;
       
       if (row.length != 0) {
           nameBox  = row.find("."+_conf.htmlData.contentEditable);
           typeBox  = row.find(".type"); 
           emEditor.editorUI.dom.toggleClass(_conf.htmlData.primKeyClass, nameBox.get()[0]);
           emEditor.editorUI.dom.toggleClass(_conf.htmlData.primKeyClass, typeBox.get()[0]);
       }
       
       if (oldKey) {
           _u.remove.attributeProperty(emName, _conf.xmlData.primKey, oldKey)
           oldRow       = document.getElementById(_b.attrituteRowID(emName, oldKey));
           oldNameBox   = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable, "div", oldRow)[0];
           oldTypeBox   = YAHOO.util.Dom.getElementsByClassName("type", "td", oldRow)[0];
           emEditor.editorUI.dom.toggleClass(_conf.htmlData.primKeyClass, oldNameBox);
           emEditor.editorUI.dom.toggleClass(_conf.htmlData.primKeyClass, oldTypeBox);
       }
       
       if (emEditor.selectedItems.item) {
           _b.properties.attribute (emName, emEditor.selectedItems.item.id.split('-')[3], false );
       }
       
       
   };
   
})();