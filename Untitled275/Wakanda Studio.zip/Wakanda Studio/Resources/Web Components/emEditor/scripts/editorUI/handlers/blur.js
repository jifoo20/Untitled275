/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function () {  
        /**
        * blur events management
        */
        _h.blur = {};
        
        /**
        * manage the blur only for the title of the panel (em name)
        * @param {span html element} span 
        */
        _h.blur.panelTitle = function(span){  
            
            //emEditor.enterKey = false;
            YAHOO.util.Dom.removeClass(span, "active");
            YAHOO.util.Event.removeListener(span, "mousedown");
            event.cancelBubble=false;
            var oldName = span.title;
            var newName = span.textContent;
            
            if(newName === "" || newName === " " || !newName){
                span.innerHTML = oldName;
            }
            
            if(oldName != newName){ 
                //check if newName is valid
                if( emEditor.emRef[newName] != undefined ){ //   _check.isEm(newName)
                    YAHOO.util.Dom.addClass(span, "onError");
                }else{//save the new name if valid
                    newName = emEditor.editorUI.validate.makeJSCompliant(newName);
                    span.textContent = newName;
                    span.title = newName;
                    _o.updateEmName(newName, oldName);
                }
            }
        },
        /**
        * blur event used only for new items
        * @param {event} ev 
        * @param {dom} elem text box
        */
        _h.blur.forNew = function(ev, elem){ 
            _o.manageBox4NewItems(elem);
        },
        /**
        * blur event used only dock (menu) field
        * @param {event} ev 
        * @param {dom} elem text box
        */
        _h.blur.forDock = function(ev, elem){ 
            _o.manageDockTextBoxes('blur', elem);
        },
        
        /**
        * blur for textarea
        * @param {event} ev 
        * @param {dom} elem textarea 
        */
        _h.blur.textarea = function blur_textarea (ev, elem){ 
            
            //var val = elem.value;
            _o.manageTextBox(elem, true);
            
        },
        /**
        * main blur event
        * @param {event} ev 
        * @param {dom} elem text box
        */
        _h.blur.main = function(ev, elem){  
            
            emEditor.studio.editMenu.controleMetaKey(false);
            
            var tr, 
                news = false, 
                foc = false, 
                currentValue, 
                re, 
                ide, 
                el,
                container = YAHOO.util.Dom.getAncestorByClassName(elem, "bd"), 
                table = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
                elemType, 
                split;

            if (table.id == _conf.htmlData.currentEmProperties || table.id == _conf .htmlData.currentAttProperties || table.id == "typePropertiesTable") {  
              
              if (table.id === "typePropertiesTable") { 
                 if( emEditor.autocompOn ) { 
                     emEditor.autocompOn = false;
                     ev.stopPropagation();
                     ev.preventDefault();
                     return;
                 }
                
                 _o.manageTypeProperties(elem, table.title);  
                
              } else { 
                 _o.manageTextBox(elem, true);  
              }
            
            } else {  
                  
            if (YAHOO.util.Dom.hasClass(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"), "notSaved")) {   // TEST !!!! 
                    news = true;
                    
                    switch (emEditor.uD.getElementType(elem)) {
                    case "type":  

                            var enterKey = emEditor.enterKey;
                           
                            if (emEditor.autocompOn) {    
                                currentValue = elem.value;
                                $("#"+elem.id).getSelected();
                                
                                setTimeout(function() { /* keep */ 
                                    $(elem).addClass(emEditor.currentAutoCompSelType);
                                    if (!currentValue) {  
                                        _o.setInputWidth(elem, emEditor.currentAutoCompSel);  
                                        if (elem.offsetWidth > 60) {
                                            emEditor.editorUI.panel.manageResizeWidth( YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"), false); 
                                        }
                                    } else { 
                                        split = currentValue.split(".");
                                        if (split.length > 1) { 
                                            if (!enterKey && emEditor.currentAutoCompSel && split[split.length-1] != emEditor.currentAutoCompSel) {  
                                               elem.value = elem.value + emEditor.currentAutoCompSel;
                                            }
                                            _o.setInputWidth(elem, elem.value); 
                                        } else { 
                                            if (emEditor.currentAutoCompSel != null) { 
                                                elem.value = emEditor.currentAutoCompSel;
                                                _o.setInputWidth(elem, emEditor.currentAutoCompSel);  
                                            }
                                        } 
                                        if (elem.offsetWidth > 60) {
                                            emEditor.editorUI.panel.manageResizeWidth( YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"), false); 
                                        }
                                    }                           
                                                
                                },0);
                                
                               if (elem.offsetWidth > 60) {
                                   emEditor.editorUI.panel.manageResizeWidth( YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"), false); 
                               }

                               foc = true;
                               elem.focus();
                               emEditor.autocompOn = false;
                               val = elem.value;
                            } else { 
                               val = elem.value;
                            }
                            
                            ide = false;
                            el = $(elem);
                            if(_check.isEm(val)){
                                el.addClass("em");
                                el.removeClass("emSing");
                                el.removeClass("scal");
                                el.removeClass("unk");
                                ide = true;
                            }else if(_check.isSingleEm(val)){
                                el.addClass("emSing");
                                el.removeClass("em");
                                el.removeClass("scal");
                                el.removeClass("unk");
                                ide = true;
                            }else if(_check.isType(val)){
                                el.addClass("scal");
                                el.removeClass("em");
                                el.removeClass("emSing");
                                el.removeClass("unk");
                                ide = true;
                            }

                            if(!ide){
                                el.removeClass("scal");
                                el.removeClass("em");
                                el.removeClass("emSing");
                                el.addClass("unk");
                            }
                                         
                             if(val == "" || val == " "){
                                el.addClass("scal");
                                el.removeClass("em");
                                el.removeClass("emSing");
                                el.removeClass("unk");
                            }                                                

                            if(!foc){ 
                                if(el.hasClass("em")){ 
                                    _o.switchToEditPath(elem, true); 
                                }else{ 
                                    var elems = _o.saveTypeBox(elem, true);
                                    if(!emEditor.autocompOn || emEditor.enterKey){ 
                                        if(emEditor.enterKey && !el.hasClass("unk")) { 
                                            emEditor.editorUI.views.add.entity.attribute(table, null, true);                         
                                        }
                                    }else{                      
                                        emEditor.autocompOn = false;
                                    }
                                }
                            }
                            emEditor.enterKey = false;
                        break;
                        case 'path': 

                            if( !emEditor.autocompOn ) { 
                                    var elems = _o.savePathBox(elem, true);
                            }else{ 
                                currentValue = elem.value;
                                
                                $("#"+elem.id).getSelected();
                                
                                setTimeout(function() { /* keep */ 
                                    re = elem.value+emEditor.currentAutoCompSel;
                                    _o.setInputWidth(elem, re);
                                    var container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module");
                                    emEditor.editorUI.panel.manageResizeWidth(container, false);
                                    elem.focus();
                                },0);
                                
                                emEditor.autocompOn = false;
                            }
                        break;
                        default:   
                            _o.manageBox4NewItems(elem); enter = false;
                    }
            }else{   //TEST !!!! 
                    var wrong = false;
                    var t = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                    var td = YAHOO.util.Dom.getAncestorByTagName(elem, "td");
                    var addFocusToPath = false, val = "";
                    
                    switch( emEditor.uD.getElementType(elem) ){
                        case "type": 
                        
                                var enterKey = emEditor.enterKey;
                                    if(emEditor.autocompOn){ 
                                        currentValue = elem.value;
                                        $("#"+elem.id).getSelected();
                                        setTimeout(function() { 
                                            
                                            $(elem).addClass(emEditor.currentAutoCompSelType);
                                            if (!currentValue) { 
                                                _o.setInputWidth(elem, emEditor.currentAutoCompSel);  
                                                if (elem.offsetWidth > 60) {
                                                    emEditor.editorUI.panel.manageResizeWidth( YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"), false); 
                                                }
                                            }else{ 
                                                split = currentValue.split(".");
                                                if (split.length > 1) { 
                                                    if (!enterKey && emEditor.currentAutoCompSel && split[split.length-1] != emEditor.currentAutoCompSel) { 
                                                       elem.value = elem.value  +emEditor.currentAutoCompSel;
                                                    }
                                                    _o.setInputWidth(elem, elem.value); 
                                                }else{ 
                                                    if (emEditor.currentAutoCompSel != null) {
                                                        elem.value = emEditor.currentAutoCompSel;
                                                        _o.setInputWidth(elem, emEditor.currentAutoCompSel);  
                                                    }
                                                } 
                                            }                           
                                            
                                            if (elem.offsetWidth > 60) {
                                                emEditor.editorUI.panel.manageResizeWidth( YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"), false); 
                                            }

                                        },0);


                                       foc = true;
                                       elem.focus();
                                       emEditor.autocompOn = false;
                                       val = elem.value;
                                    }else{
                                        val = elem.value;
                                    }

                                    ide = false;
                                    el = $(elem);
                                    if(_check.isEm(val)){
                                        el.addClass("em");
                                        el.removeClass("emSing");
                                        el.removeClass("scal");
                                        el.removeClass("unk");
                                        ide = true;
                                    }else if(_check.isSingleEm(val)){
                                        el.addClass("emSing");
                                        el.removeClass("em");
                                        el.removeClass("scal");
                                        el.removeClass("unk");
                                        ide = true;
                                    }else if(_check.isType(val)){
                                        el.addClass("scal");
                                        el.removeClass("em");
                                        el.removeClass("emSing");
                                        el.removeClass("unk");
                                        ide = true;
                                    }

                                    if(!ide){
                                        el.removeClass("scal");
                                        el.removeClass("em");
                                        el.removeClass("emSing");
                                        el.addClass("unk");
                                    }
                                    
                                    if(val == "" || val == " "){
                                        el.addClass("scal");
                                        el.removeClass("em");
                                        el.removeClass("emSing");
                                        el.removeClass("unk");
                                    }

                                    if (!foc) { 
                                        if (el.hasClass("em")){  
                                            _o.switchToEditPath(elem, emEditor.enterKey);
                                        } else {
                                            var elems = _o.saveTypeBox(elem, false);
                                            if (!emEditor.autocompOn || emEditor.enterKey) { 
                                                if (emEditor.enterKey && !el.hasClass("unk")) { 
                                                    emEditor.editorUI.views.add.entity.attribute(table, null, true);                         
                                                } else if (emEditor.tabKey) {
                                                    emEditor.tabKey = false;
                                                    var rowIdx = t.rowIndex;
                                                    var nextRow = rowIdx + 1;
                                                    if (rowIdx != table.rows.length -1) {
                                                        if (table.rows[nextRow]) {
                                                            _o.selectRow(table.rows[nextRow], false, false); 
                                                            $(table.rows[nextRow]).find(".name .editable_input").get()[0].focus();
                                                        } 
                                                    } else {
                                                        emEditor.editorUI.views.add.entity.attribute(table, null, true);
                                                    }
                                                } 
                                            }else{                      
                                                emEditor.autocompOn = false;
                                            }
                                        }
                                    }
                                    emEditor.enterKey = false;
                     
                        break;
                        case "path": 
                                emEditor.enterKey = false;  
                                if(!emEditor.autocompOn || emEditor.enterKey){ 
                                    var elems = _o.savePathBox(elem, false);
                                }else{ 
                                    currentValue = elem.value;

                                    $("#"+elem.id).getSelected();

                                    setTimeout(function() { 
                                        if(currentValue.split(".").length > 1){
                                            //elem.value = currentValue+emEditor.currentAutoCompSel;
                                        }else{ 
                                            if(emEditor.currentAutoCompSel){
                                                //elem.value = emEditor.currentAutoCompSel;
                                            }
                                        }
                                        
                                        if(emEditor.enterKey){
                                            re = elem.value;
                                        }else{
                                            re = emEditor.currentAutoCompSel; //+currentValue
                                        }
                                        
                                        _o.setInputWidth(elem, re);
                                        var container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"); 
                                        emEditor.editorUI.panel.manageResizeWidth(container, false);

                                        elem.focus();
                                    },0);

                                    emEditor.autocompOn = false;
                                }
                        break;
                        default: 
                            var prop = false;
                            if(table.className == "underKeyForm"){
                                prop = true;
                            }
                            
                            _o.manageTextBox(elem, prop); 
                        }
                    }//TEST
            }
        }
    
})();

