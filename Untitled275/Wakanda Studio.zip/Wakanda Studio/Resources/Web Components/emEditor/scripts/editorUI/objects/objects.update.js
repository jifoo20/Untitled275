/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    _o.updateAttributeProperties = function( emName, t, attN, newValue, oldValue, underKey, ref ) { 

            var isValid,
                refJq,
                tr;
            
            if (ref) { 
                refJq = $(ref);
            }
           
            if ( newValue === "" || newValue === " " ) {
                newValue = null;
                if ( ref ) {
                    refJq[0].btOn = null; 
                    refJq[0].btOff = null;
                    refJq[0].btRefresh = null; 
                    refJq.removeClass("onError");
                }
                isValid = { isWrong : false };
            } else {   
              isValid = emEditor.editorUI.validate.checkType( t, _g.emAttPropertyValue(emName, attN, "type", false), newValue );
            } 

            if ( isValid.isWrong ) { 
                if( ref ) {
                    tr = refJq.closest("tr");
                    refJq.bt( "The required value for "+ tr.find("td")[0].textContent +" is a "+isValid.requiredType+".", {
                        offsetParent:$('body'),
                        killTitle: false,
                        closeWhenOthersOpen: true,
                        fill: '#E2E2E2'
                     });

                    window.setTimeout(function(){ 
                        refJq.addClass("onError");
                    }, 0);
                }
                return false;
            }else{
                if( ref ) {
                   refJq[0].btOn = null; 
                   refJq[0].btOff = null;
                   refJq[0].btRefresh = null; 
                   refJq.removeClass("onError"); 
                }
            }
            
            if ( oldValue && newValue == null ) {
                if ( underKey ) { 
                    _u.remove.attributeUnderProperty(emName, t, attN, underKey, emEditor.selectedItems.isInherited);
                } else { 
                    _u.remove.attributeProperty(emName, t, attN, underKey);
                }
            } else { 
                if ( underKey ) {
                    _u.attributeUnderProperty(emName, t, attN, newValue, underKey, emEditor.selectedItems.isInherited);
                } else {

                    if ( newValue != null ) { 
                        if (emEditor.selectedItems.isInherited) {
                            _u.inheritedAttributeProperty(emName, t, attN, newValue);
                        } else {
                            _u.attributeProperty(emName, t, attN, newValue, null, true);
                        }
                        
                    }
                }
            }
            
            if (emEditor.selectedItems.isInherited) {
                
                var tr      = refJq.closest("tr"),
                    td2     = refJq.closest("td"),
                    td      = tr.find("td")[0],
                    addClass,
                    maintTr,
                    matinTD;
                
                var rm = document.createElement("div");
                rm.title = "Remove this overridden value";
                
                if (!tr.closest("table").hasClass("underKeyForm")) {
                    
                    $(td).addClass("overrided");
                    tr.addClass("isOverrided");

                    if (td2.find("input").length === 0) {
                        addClass = "forTextField"; 
                    } else {
                        addClass = "";
                    }
                    
                    rm.className = "removeOverrideValue " + addClass;
                    td2.append(rm);
                    
                } else {
                    
                    maintTr = tr.closest("table").parent().parent();
                    maintTr.addClass("isOverrided");
                    matinTD = $(maintTr.find("td")[0]);
                    matinTD.addClass("overrided");
                    addClass = "forDefaultFormat";
                    rm.className = "removeOverrideValue " + addClass;
                    matinTD.append(rm);
                }
                    
                
                
            }

    };
    
    _o.updateEmName = function(newName, oldName){

        var pan = null, 
            sn,
            panToReload;
        
        pan = emEditor.panels[emEditor.panelsRef[oldName]];
        
        //**update data
        _u.property(oldName, "collectionName", newName);

        //**update ref
        emEditor.panelsRef[newName] = emEditor.panelsRef[oldName];
        emEditor.emRef[newName] = emEditor.emRef[oldName];
        delete emEditor.panelsRef[oldName];
        delete emEditor.emRef[oldName];
        
        //**look for other panel to update (UI)
        panToReload = _u.emName(oldName, newName);
              
        for(var k in panToReload){
            
            if (panToReload[k].attProp != "extend") {
                _wRefresh ( {emName : panToReload[k].emName, newValue:newName, itemName : panToReload[k].attProp.name, type:"em", action:"update",  isExtend:false, lookForExtend:true, oldValue:oldName, emNameChange : true} );
            } else {
                _wRefresh ( {emName : panToReload[k].emName, newValue:newName, itemName : panToReload[k].attProp, type:"extendsViews", action:"update",  isExtend:false, lookForExtend:true, newValue:newName, oldValue:oldName, emNameChange : true} );
            }
            
        }

    };
    /**
    * manage update for em properties
    * @param {html input element} elem
    * @param {string} t  properties name
    * @param {string} newValue  properties value
    */
    _o.updateEmProperties = function( elem, t, newValue ) { 

        var emName              = emEditor.onEditBox.emName, //emEditor.editorUI.panel.getActiveElemName(),
            tr                  = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
            ov                  = emEditor.onEditBox.oldValue,
            pan                 = emEditor.panels[emEditor.panelsRef[ov]],
            reservedList        = _conf.reserved,
            workOnCOllection    = false,
            doesExist           = false,
            isReserved          = false,
            pRef,
            emToReload,
            header,  
            isValid,
            extendTree;  

        if (!emName) {
            emName = emEditor.editorUI.panel.getActiveElemName();
        }

        if ((newValue === ov || ov === undefined) && elem.nodeName != "INPUT") {
            if (ov != undefined) {
                elem.innerHTML = ov;
            }
            return;
        }                

        if( emEditor.uD.getElementType(elem) == "className" || emEditor.uD.getElementType(elem) == "collectionName" ) {//this is a "many" name of the em
            
            newValue = emEditor.editorUI.validate.makeJSCompliant(newValue);
            
            if( ov != newValue ) { 
                newValue = newValue.substr(0,1).toUpperCase() +	newValue.substr(1,newValue.length);
            }
            
            if( newValue != emEditor.onEditBox.oldValue ) { //do nothing here if nothing has been changed
                
                $.each(emEditor.emRef, function(index, value) { 
                    
                    if(index === newValue ) { //.toLowerCase()
                        doesExist = true;
                        return false;
                    }
                });

                $.each(reservedList, function(index, value) { 
                    if(value === newValue || value === newValue.toLowerCase() ) { 
                        isReserved = true;
                        return false;
                    }
                });
                
                if (isReserved || doesExist  || newValue == "" || !newValue) {
                    /** do not allow already existing names, so keep focus & open an alert & stop this script
                        add a timeout because of the alert, is removed by the click event (causing the blur) without it. **/
                    setTimeout(function() { 
                        elem.focus(); 
                        emEditor.onEditBox.oldValue = ov;
                        $(tr).btOn();  
                    },200); 
                    return;
                } else {  /* update className  */ 
                   
                    if (emEditor.uD.getElementType(elem) === "className") { 

                        extendTree = _g.extendTree(emName);

                        _perms.updateNames( "class", ov, newValue, ov);

                        _u.extraProperties.renameClassName(ov, newValue);

                        //pRef = emEditor.editorUI.panel.getPanelRef(emName);
                        header = $("#"+pan.id+"_c .headerSpan").get()[0]
                        header.textContent = newValue;
                        header.title = newValue;
                        
                        //update panels ref
                        pan.emName = newValue;
                        emEditor.panelsRef[newValue] = emEditor.panelsRef[ov];
                        if( newValue != ov ) {
                            delete emEditor.panelsRef[ov];
                        }
                        emEditor.emRef[newValue] = emEditor.emRef[ov];
                        emEditor.selectedItems.emName = newValue;
                        
                        //update all id
                        $.each($("#"+pan.id + " tr"), function(index, value) { 
                          value.id = value.id.replace("-"+ov+"-", "-"+newValue+"-");
                        });

                        //update all id in the extended tree
                        $.each(extendTree, function(j, val) { 
                            $.each(val, function(k, em) {
                                pan2 = emEditor.panels[emEditor.panelsRef[em]],
                                $.each($("#"+pan2.id + " tr."+ov), function(x, v) { 
                                    v.id = v.id.replace("-"+ov+"-", "-"+newValue+"-");
                                    $(v).removeClass(ov).addClass(newValue);
                                });
                            });
                        });
                        
                        elem.textContent = newValue;
                        var panToReload = _u.emName(ov, newValue);
                        var tempEm;

                        for(var k in panToReload){

                            if (panToReload[k].emName === ov) {
                                tempEm = newValue;
                            } else {
                                tempEm =panToReload[k].emName;
                            }

                            if (panToReload[k].attProp == "extend") {
                                _wRefresh ( {emName : tempEm, newValue:newValue, itemName : panToReload[k].attProp, type:"extendsViews", action:"update",  isExtend:false, lookForExtend:true, newValue:newValue, oldValue:ov, emNameChange : true} );
                            } else {  
                                _wRefresh ( {emName : tempEm, newValue:newValue, itemName : panToReload[k].attProp.name, type:"em", action:"update",  isExtend:false, lookForExtend:true, newValue:newValue, oldValue:ov, emNameChange : true} );
                            }
                        
                        }
                       
                        //**refresh menu
                        var trs = $("#"+_conf .htmlData.menuTableEm+" tr"),
                            outlineElem;

                        $.each(trs, function(index, value) { 

                            outlineElem = $(value);

                            if(outlineElem.attr("data-title") === ov){
                                outlineElem.get()[0].id = "outline_"+newValue;
                                outlineElem.attr("data-title", newValue);
                                outlineElem.find("div.emName").get()[0].textContent = newValue;
                                return false;
                            }
                        });


                        $("#currentEmProperties .entityModelsPropertiesName").get()[0].textContent = newValue; 
                        
                        //if needed, rename the many name, do it only if "newName" keyword is used
                        var mmane = _g.collectionName(ov);
                        sp = mmane.split("Co"); 
                        if(sp[1] == "llection"){ 
                            workOnCOllection = true;
                        }
                        
                        //emToReload = _check.useAsaTypeInRelation(emName); 
                    }else{ 
                        /* update collectionName  */ 
                        _o.updateEmName(newValue, emEditor.onEditBox.oldValue);
                        return;
                    }
                }
            }
        }        
        
        //the item is empty
      
        if((newValue==null || newValue=="" || newValue==" ") && ov ) {   
            _u.remove.entityProperty(emName, t);
            if(t=="extends" && emEditor.onEditBox.oldValue){
                _windows.reLoad(emName, true);
            }
        } else { 
        
            isValid = emEditor.editorUI.validate.checkTypeForClass ( t, newValue );
            var refJq = $(elem); 
                        
            if ( isValid.isWrong ) { 
                if( refJq ) {
                    
                    refJq.bt( "The required value for "+ $(tr).find("td")[0].textContent +" is a "+isValid.requiredType+".", {
                        offsetParent:$('body'),
                        killTitle: false,
                        closeWhenOthersOpen: true,
                        fill: '#E2E2E2'
                     });

                    window.setTimeout(function(){ 
                        refJq.addClass("onError");
                    }, 0);
                }
                return false;
            }else{
                if( refJq ) {
                   refJq[0].btOn = null; 
                   refJq[0].btOff = null;
                   refJq[0].btRefresh = null; 
                   refJq.removeClass("onError"); 
                }
            }
                
            if (t != "collectionName") { 
 
                if ($(elem).hasClass("notes")) {
                    emName = emEditor.onEditBox.emName;
                    _u.extraProperties.noteForClass(emName, elem.value);
                } else {
                    _u.property(emName, t, newValue);
                }
                
            }

            if (t === "className") { 
                 emToReload = _u.singleEMName(emName, t, newValue, ov);
            }
        }
        
        //**update UI
        if( workOnCOllection ) {
            //$("#currentEmProperties div[waf-data='collectionName'] div").get()[0].textContent = newValue + "Collection"; 
            $("#currentEmProperties div[data-info='collectionName'] div").get()[0].textContent = newValue + "Collection"; 
            _o.updateEmName(newValue + "Collection", mmane);
        }
        for( var k in emToReload ) {
            _wRefresh ( {emName : emToReload[k].emName, itemName : emToReload[k].attProp.name, type:"att", action:"update",  isExtend:false, lookForExtend:true, oldValue:null} );
        }
    };
    
    _o.updateEmFromPanel = function( panelID, elem ) { 
        
            var header          = $("#"+panelID+"_c .headerSpan").get()[0],
                newValue        = elem.textContent,
                ov              = header.textContent, 
                pan             = emEditor.editorUI.panel.getPanelRef(ov),
                elemJq          = $(elem),
                doesExist       = false,
                isReserved      = false,
                reservedList    = _conf.reserved;
            
            if( newValue == null || !newValue ) {
                elem.textContent = ov;
                newValue = ov;
            }
            
            if( ov != newValue ) {
                
                newValue = emEditor.editorUI.validate.makeJSCompliant( newValue, false );
                newValue = newValue.substr(0,1).toUpperCase() + newValue.substr(1,newValue.length);
                
                //check if the name is already used or not
                $.each(emEditor.emRef, function(index, value) { 
                    
                    if(index === newValue ) { 
                        doesExist = true;
                        return false;
                    }
                });
                
                //check if the name is js reserved or not
                $.each(reservedList, function(index, value) { 
                    if(value === newValue || value === newValue.toLowerCase() ) { 
                        isReserved = true;
                        return false;
                    }
                });
                
                if( doesExist || isReserved ) { 
                    _b.errorMessage.addContextualAlertForPanel( elemJq, _conf.langage.en.alertTip.className );
                    setTimeout( function() { //delay in order to avoid the click event to close the popup
						elemJq.btOn();
						elem.focus();
					}, 100);
                    return;
                }
                
                _perms.updateNames( "class", ov, newValue, ov);
                _u.extraProperties.renameClassName(ov, newValue);

                elemJq.btOff();
                header.textContent = newValue;
                header.title = newValue;
                $("#currentEmProperties div[data-info='className'] div").get()[0].textContent = newValue; 
                $("#currentEmProperties .entityModelsPropertiesName").get()[0].textContent = newValue; 

                //update panels ref
                pan.emName = newValue;
                emEditor.panelsRef[newValue] = emEditor.panelsRef[ov];
                delete emEditor.panelsRef[ov];
                emEditor.emRef[newValue] = emEditor.emRef[ov];
                emEditor.selectedItems.emName = newValue;

                //update all id's
                $.each($("#"+panelID + " tr"), function(index, value) { 
                  value.id = value.id.replace("-"+ov+"-", "-"+newValue+"-");
                });

                var panToReload = _u.emName(ov, newValue);
                _u.property(ov, "className", newValue);
                var emToReload = _u.singleEMName(ov, "className", newValue, ov);

                //**refresh menu
                var trs = $("#"+_conf.htmlData.menuTableEm+" tr");
                var val;
                
                $.each(trs, function(index, value) { 
                  val = $(value);
                  if(val.attr("data-title") === ov){
                    val.get()[0].id = "outline_"+newValue;
                    val.attr("data-title", newValue);
                    val.find("div.emName").get()[0].textContent = newValue;
                    return false;
                  }
                });
                
                for( var k in emToReload ) {
                    _wRefresh ( {emName : emToReload[k].emName, itemName : emToReload[k].attProp.name, type:"att", action:"update",  isExtend:false, lookForExtend:true, oldValue:null} );
                }

                
                for(var k in panToReload){
                    if(panToReload[k].attProp == "extend"){
                        _wRefresh ( {emName : panToReload[k].emName, newValue:newValue, itemName : panToReload[k].attProp, type:"extendsViews", action:"update",  isExtend:false, lookForExtend:true, newValue:newValue, oldValue:ov, emNameChange : true} );
                    }else{ 
                        _wRefresh ( {emName : panToReload[k].emName, newValue:newValue, itemName : panToReload[k].attProp.name, type:"att", action:"update",  isExtend:false, lookForExtend:true, newValue:newValue, oldValue:ov, emNameChange : true} );
                    }
                }

                //if needed, rename the many name, do it only if "newName" keyword is used
                var mmane = _g.collectionName(newValue);
                sp = mmane.split("C"); 
                if(sp[1] == "ollection"){ 
                    workOnCOllection = true;
                }
                $("#currentEmProperties div[data-info='collectionName'] div").get()[0].textContent = newValue + "Collection"; 
                _o.updateEmName(newValue + "Collection", mmane);
                
                    
            }
            emEditor.studio.editMenu.controleMetaKey( false ); 
            elemJq.remove();
    }
    
})();