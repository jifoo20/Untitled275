/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function($){
    /*
    * Prerequisite :    - the container MUST BE "foursquare" x = y
    *                   - the scale calculation depend on specific EME markup !
    *
    * Usage :           - init object calling $("#containerID").miniPreview({workspace:"worskSpaceID", buildAtInit: false}); 
    *                   - Update the preview calling $("#containerID").updatePreview();
    */
    
    /**
    * init the sroll object
    * @param {object} options { workspace:id , buildAtInit: false };
    */
	$.fn.miniPreview = function(options) { 
	    
	    /**
	    * workspace : the id of the workspace to sccale
	    * buildAtInit : will build the preview at the init. If false, you need to call updatePreview() after the init to build it.
	    **/

        //init var
        var targetJq    = this,
            targetDom   = this.get()[0],
            scope       = document.createElement("div"),
            min1        = document.createElement("div"),
            //full      = document.createElement("div"),
            workspace   = $("#"+options["workspace"]),
            scale       = 0.055, //default val
            contSize    = 275,    
            onInit      = true,
            mT          = 0,
            mL          = 0,
            rtime,
            timeout,
            delta;

            
        //init view
        //full.className = 'viewFullScreen';
        //$(full).appendTo(targetJq.parent());
        //$(full).click(function(){ $("#minPreviewContainer").fullScreenMode(); });
        $('.viewFullScreen').click(function(){ $("#minPreviewContainer").fullScreenMode(); });
        targetJq.addClass("minPreviewContainer");
        scope.id = "minScope";
        scope.className = "minPreviewScope";
        min1.id = "min1";
        min1.className = "minPreviewInner";
        targetDom.appendChild(scope);
        targetDom.appendChild(min1);
        scope = $("#minScope");
        min1 = $("#min1");       
        min1.css("-webkit-transform", "scale("+scale+")");

        //set drag event
        scope.draggable({ containment: "parent" , drag: function(event, ui) { 
            var st = ui.position.top / scale ;
            var sl = ui.position.left / scale ;
            workspace.get()[0].parentNode.scrollLeft = sl;
            workspace.get()[0].parentNode.scrollTop = st;
        }});
        
        //set scroll events
        $(workspace.parent()).scroll(function(){
            setScopePos(this);
        });
        
        //set window's resize event
        rtime = new Date(1, 1, 2000, 12,00,00);
     	timeout = false;
     	delta = 200;

   		$(window).resize(function() {
				rtime = new Date();
				if (timeout === false) {
					timeout = true;
					setTimeout(resizeend, delta);
				}
			});

 		function resizeend() {
 			if (new Date() - rtime < delta) {
 				setTimeout(resizeend, delta);
 			} else {
 				timeout = false;
 				updateScopeSize();
 				if($("div.fullmask").length > 0){
 				    leaveFullScreen();
     				fullScreenMode();
 				}
 			}				
 		}
         
        //update scope size
        var updateScopeSize = function() { 
            var h = workspace.get()[0].parentNode.offsetHeight;
            var w = workspace.get()[0].parentNode.offsetWidth; 
            scope.css("height", h*scale +"px");
            scope.css("width", w*scale +"px");
        };
        
        //update preview
        var setPreview = function() { 

            if (emEditor.miniatureCollapsed) {
                return;
            }

            //copie html content
            min1.get()[0].innerHTML = workspace.get()[0].innerHTML; 
            
            //clean html
            //min1.find("svg").remove();
            //min1.find("svg").attr("id", "");
            min1.find('div').attr("id", "");
            min1.find('tr').attr("id", "");
            min1.find(".editClassNameInPanel").remove();
            min1.find(".ac_results").remove();
            min1.find("div[contentEditable=true]").attr("contentEditable", false);
            
            //add mask
            var p = min1.find(".yui-panel-container");
            var ip = document.createElement("div");
            ip.className = "mask";
            p.append(ip);
            
            //set drag event
            p.draggable({ 
                handle:".mask", 
                helper: function(){ 
                    var t = document.createElement("div"); 
                    t.style.width=this.offsetWidth*scale+"px"; 
                    t.style.height=this.offsetHeight*scale+"px"; 
                    t.className = "panelDragMask"; 
                    targetDom.appendChild(t); 
                    return t;
                }, 
                stop : function(event, ui){
                  var t = ui.position.top;
                  var l = ui.position.left;
                  
                  var emName = $(this).find(".mask").get()[0].title;
                  var pRef = emEditor.editorUI.panel.getPanelRef(emName);
                  var pane = $("#"+pRef.id+"_c").get()[0];
                  var ptop = t/scale;
                  var pleft = (l/scale);
                  pane.style.top = ptop+"px";
                  pane.style.left = pleft+"px";
                  var centerBodyLeft = emEditor.centerBody.getAttributeConfig('left').value;
                  emEditor.editorUI.panel.keepPos(pane.offsetLeft+centerBodyLeft, pane.offsetTop, emName, pRef.id);
                  if(emEditor.curve && emEditor.relationCurve){ 
                        $.queued.add(function(){ 
                            _c.loadRelationCurve();
                        });
                    }
                    
                    $.queued.add(function(){ 
                        emEditor.previewObj.updatePreview();
                    });
                  
                    $.queued.add(function(){ 
                        $.queued.clear(); 
                    });
                  
                } 
            });       
            
            p.dblclick(function(){ 
                var emName = $(this).find(".mask").get()[0].title;
                emEditor.editorUI.panel.addFocusOrOpen(null, emName, null, false, true, false);
            });    
            
            //set titles
            $.each(p, function(index, value) { 
               value.childNodes[2].title = value.firstChild.firstChild.firstChild.title;
            });
            
            //scale all
            if( onInit ) {
                onInit = false;
                upScale(false);
            }else{
                upScale(true);
            }
             
        };  
        
        //update scope position
        var setScopePos = function(){
            var st = workspace.get()[0].parentNode.scrollTop;
            var sl = workspace.get()[0].parentNode.scrollLeft;
            
            scope.css("top", st*scale+"px");
            scope.css("left", sl*scale+"px");

        };
        
        var findMaxSize = function(){
            var elems = $("div.yui-panel-container ", workspace);
            var maxH = 0, maxL = 0, f;
            mT = 0;
            mL = 0;
            
            $.each(elems, function(index, value) { 
                maxH = value.offsetHeight + value.offsetTop;
                maxL = value.offsetWidth + value.offsetLeft;
                
                if(mT < maxH){
                    mT = maxH;
                }
                
                if(mL < maxL){
                    mL = maxL;
                }                
                      
            });
            
            if(mT > mL){
               f = mT; 
            }else{
               f = mL;
            }
            
            var sv = contSize / (f);  
            return sv;
            
        };
        
        var upScale = function( rel ) {  
            s = findMaxSize();
            
            var max = contSize * 0.0008, // 0.0008
                min = contSize * 0.0002;
          
            if(s > max){
                s = max;
            }
            /*if(s < min){
                s = min;
            }*/
            scale = s;
            min1.css("-webkit-transform", "scale("+scale+")")
            updateScopeSize();
            setScopePos();
            /*if( emEditor.curve && emEditor.relationCurve && rel ) { 
                _c.loadRelationCurve(true);
              }*/
        };
        
        var fullScreenMode = function(){
            
            var fullmask = document.createElement("div");
            fullmask.className = "fullmask";
            
            var closeButton = document.createElement("div");
            closeButton.className = "closeButton";
            $(closeButton).click(function(){ $("#minPreviewContainer").leaveFullScreen(); });
            
            var w = $(document.body).get()[0].offsetWidth;
            var h = $(document.body).get()[0].offsetHeight;
            
            //fullmask.style.height=h+"px"
            $(fullmask).appendTo(document.body);
            $(closeButton).appendTo(document.body);
            
            targetJq.appendTo(document.body);
            targetDom.style.top = h - 280 + "px";
            targetDom.style.left = w - 280 + "px";
            
            scope.hide();    
            
            targetJq.animate({
                top: "0px",
                left: "50%",
                height:h+"px",
                width:h+"px",
                marginLeft:"-"+h/2+"px",
                backgroundColor:"#fff",
                borderLeft: "1px solid #999",
                borderRight: "1px solid #999"
              }, 100, function() {
                  closeButton.style.marginLeft = targetDom.offsetLeft +targetDom.offsetWidth -40 + "px";
              });
              
              contSize = h;
              scale = 1;
              emEditor.previewObj.updatePreview();
        };
        
        var leaveFullScreen = function(){
            $(".fullmask").remove();
            $(".closeButton").remove();
            
            targetJq.appendTo($("#layout-doc > .yui-layout-unit-right .yui-layout-unit-bottom > .yui-layout-wrap > .yui-layout-bd"));            
            targetDom.style.height = "280px"; 
            targetDom.style.left = "0px";
            targetDom.style.marginLeft = "0px"; 
            targetDom.style.borderLeft = "0px solid #999";
            targetDom.style.borderRight = "0px solid #999";
              
            contSize = 275;
            scope.show();  
            emEditor.previewObj.updatePreview();
        };
        
        var getLastScaleValue = function(){
            emEditor.lastScale = scale;
        };
        
        if( options.buildAtInit ){ setPreview(); }

		return this.each(function() { 
			this.setScopeSize = function(){
			    updateScopeSize();
			};
			this.updatePreview = function(){
                setPreview();
			};
			this.upScale = function(s){
                upScale(s);
			}
			this.fullScreenMode = function(){
                fullScreenMode();
			}
			this.leaveFullScreen = function(){
                leaveFullScreen();
			}
			this.getLastScaleValue = function(){
                getLastScaleValue();
			}
		});
		
		
	};
	
	/**
     * 
     * A convenience function update the preview
     */
	jQuery.fn.updatePreview = function() {
        return this.each(function(index){
            if (jQuery.isFunction(this.updatePreview)) {
                this.updatePreview();
            }
        });
     };
     
     /**
      * 
      * A convenience function to update the size of the scope
      */
     jQuery.fn.setScopeSize = function() {
        return this.each(function(index){
            if (jQuery.isFunction(this.setScopeSize)) {
                this.setScopeSize();
            }
        }); 
    };
    
      /**
       * 
       * A convenience function to update the size of the scope
       */
      jQuery.fn.upScale = function(s) { 
         return this.each(function(index){
             if (jQuery.isFunction(this.upScale)) {
                 this.upScale(s);
             }
         }); 
     };
     
       /**
        * 
        * A convenience function to update the size of the scope
        */
       jQuery.fn.fullScreenMode = function() { 
          return this.each(function(index){
              if (jQuery.isFunction(this.fullScreenMode)) {
                  this.fullScreenMode();
              }
          }); 
      };
        /**
         * 
         * 
         */
        jQuery.fn.leaveFullScreen = function() { 
           return this.each(function(index){
               if (jQuery.isFunction(this.leaveFullScreen)) {
                   this.leaveFullScreen();
               }
           }); 
       };
         /**
          * 
          * 
          */
         jQuery.fn.getLastScaleValue = function() { 
            return this.each(function(index){
                if (jQuery.isFunction(this.getLastScaleValue)) {
                    this.getLastScaleValue();
                }
            }); 
        };
 
})(jQuery);


