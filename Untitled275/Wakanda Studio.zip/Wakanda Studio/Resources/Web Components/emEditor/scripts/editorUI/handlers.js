/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
  
    /**
    * all methods called by user action
    */
    emEditor.editorUI.handlers = {};
    _h = emEditor.editorUI.handlers;
    
    emEditor.editorUI.handlers = {
    toggleAttributes:function(type, viewInPanel){
        
        var pRef,
            opened,
            sel,
            lookFor,
            extraP,
            genExtraP;

        switch (type){
        case "methods" :     
            lookFor = " .meth";
            extraP = "methVisible";
            genExtraP = "methodShowMode";
            break;
        case "alias" :     
            lookFor = " .flat";
            extraP = "flatVisible";
            genExtraP = "flattShowMode";
            break;    
        case "relation" :     
            lookFor = " .rel";
            extraP = "relVisible";
            genExtraP = "relShowMode";
            break; 
        case "inherited" :     
            lookFor = " .inherited";
            extraP = "inheritedVisible";
            genExtraP = "inhShowMode";
            break;  
        case "scalar" :     
            lookFor = " .scal";
            extraP = "scalarVisible";
            genExtraP = "scalShowMode";
            break;  
        /*case "removed" :     
            lookFor = " .meth";
            extraP = "removedVisible";
            break;  */
        default: error.log( "type unknown in _h.toggleAttributes" );      
        }
        
        // update catalog
        _u.extraProperties.changeAttViewState(extraP, viewInPanel);
        _u.extraProperties.defineAttDisplay(genExtraP, viewInPanel);

        // update oppenned panels
        opened = _g.panelsToOpen();
        $.each(opened, function(index, value) { 
          
            pRef = emEditor.editorUI.panel.getPanelRef(value.emName);
            sel = $("#"+pRef.id+lookFor);
            
            if( viewInPanel ) {
                if( $(sel[0]).hasClass("removedHidden") ) {
                    sel.removeClass("removedHidden");
                }                    
            } else {
                if( !$(sel[0]).hasClass("removedHidden") ) {
                    sel.addClass("removedHidden");
                }
            }
          
        });

        emEditor.editorUI.panel.manageResizeWidth( $("#"+pRef.id).get()[0], false, true, true );
        emEditor.previewObj.updatePreview();
   
    },
    displayRemoveButton:function(tr) {
        var rmButton = YAHOO.util.Dom.getElementsByClassName("removeIcnForAttributes", "div", tr)[0];
        rmButton.style.display = "display";
    },
    hideRemoveButton:function(tr) {
        var rmButton = YAHOO.util.Dom.getElementsByClassName("removeIcnForAttributes", "div", tr)[0];
        rmButton.style.display = "none";
    },
    editMode:function(box) { 
        
        YAHOO.util.Event.addListener(box, "click", function(event){event.stopPropagation(); event.preventDefault();});
        box.focus();
    },
    /**
    * allow to toggle composition / relatedEntities for an att
    * @param {event} ev 
    * @param {html object} elem checkbox
    */
    manageComposition:function(e, box) {
        var emName = emEditor.selectedItems.emName;
        //var attName = emEditor.selectedItems.item.title;
        var attName = emEditor.uD.getWafData( emEditor.selectedItems.item );
        
        if(box.checked){ //switch to composition
            _u.attributeProperty(emName, "kind", attName, _conf .xmlData.composition);
            }else{ //switch to relatedEntities
            _u.attributeProperty(emName, "kind", attName, _conf .xmlData.relatedEntities);
        }
    },
    openNonEmPanels:function(elem) {
        var panelOpen = emEditor.editorUI. windows.isPanelOpenned(_conf .htmlData.idTypePanel); 
        if(panelOpen != null){
            emEditor.editorUI. windows.putFocus(panels[panelOpen].panel, _conf .htmlData.classType);
        }else{
                if(YAHOO.util.Dom.hasClass(elem, "type")){ //type
                    var body = _b.contentView("Types", _conf .htmlData.classType);
                    var header = _b.header("Custom Types", _conf .htmlData.classType);
                    emEditor.onCreationPanel = {name:_conf .htmlData.idTypePanel, type:_conf .htmlData.classType, body:body, header:header, footer:null};
                    emEditor.editorUI. windows.add(_conf .htmlData.idTypePanel, false, false);
                }else{ 
                    console.log("to do openNonEmPanels !!");
                }
        }
    },
    createMeth:function(ev, elem){
        ev.stopPropagation(); ev.preventDefault(); 
        _o.createNewMethod(elem);
    },
    editMethod:function(elem) {  
       
        var emName;
        var tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"); 
        var methName;
        var methData;
        var jqTr = $(tr);
        if(jqTr.hasClass("notDone")){
            jqTr.removeClass("notDone")
        }
       
        if($(tr).hasClass("methodInherited")){
            methName = emEditor.uD.getWafData( tr );
            emName = tr.id.split("-")[1];
        }else{
            methName = emEditor.uD.getWafData( tr );
            emName = emEditor.editorUI.panel.getActiveElemName();
        }

        methData = _g.methodData(emName, methName);
        
        if( methData.userDefined ) {
            emEditor.studio.doScript("gotoDefinition", methData.from);
        } else {
            _o.editScript(methData.from);
        } 
        
        
    },
    editComputed:function(elem) { 
        
        if(YAHOO.util.Dom.hasClass(elem, "createScript")){
            YAHOO.util.Dom.removeClass(elem, "createScript");
            YAHOO.util.Dom.addClass(elem, "editScript");
            var b = elem.parentNode.childNodes[1];
            YAHOO.util.Dom.addClass(b, "removeScript");
        }
        
        YAHOO.util.Dom.getAncestorByTagName(elem, "table");
        //var attName = emEditor.selectedItems.item.title;
        var attName = emEditor.uD.getWafData( emEditor.selectedItems.item );
        var emName = emEditor.selectedItems.emName;
        var type = elem.parentNode.className;
        var from = emName+"."+attName+"."+type;
        //check if does already exist
        if(!_check.computedAttributes(emName, attName, type)){
            _u.attributeProperty(emName, type, attName, from, "calculated");
        }
        
        if( _g.idComputedUserDefined(emName, attName, type) ) {
            emEditor.studio.doScript("gotoDefinition", _g.computedValue(emName, attName, type));
        }else{
            _o.editScript(_g.computedValue(emName, attName, type));
        }
        
    },
    removeComputed:function(elem){
        if(YAHOO.util.Dom.hasClass(elem, "removeScript")){
            //rm script
            YAHOO.util.Dom.getAncestorByTagName(elem, "table");
            //var attName = emEditor.selectedItems.item.title;
            var attName = emEditor.uD.getWafData( emEditor.selectedItems.item );
            var emName = emEditor.selectedItems.emName;
            var type = elem.parentNode.className;
            
            YAHOO.util.Dom.removeClass(elem, "removeScript");
            var b = elem.parentNode.firstChild;
            YAHOO.util.Dom.removeClass(b, "editScript");
            YAHOO.util.Dom.addClass(b, "createScript");
            
            _u.remove.computedScript(emName, attName, type);
        }
    },
    boxChecked:function(e, box) { 

            if (emEditor.selectedItems.emName != "___MODEL" && emEditor.selectedItems.item) {
                var td = emEditor.selectedItems.item.firstChild;     
                if( box.title == "identifying" ) {
                    if(box.checked){
                        YAHOO.util.Dom.addClass(td, "identifying");
                    } else {
                        YAHOO.util.Dom.removeClass(td, "identifying");
                    }
                }
            }
        
            _o.manageTextBox( box, true, true );

    },
    selectPanel:function( pan, fromRow, sClick, e ) {  

            if( emEditor.selectedInput && !$(emEditor.selectedInput).hasClass("ac_input") ) { 
                emEditor.selectedInput.blur();
                emEditor.selectedInput = null;
                window.setTimeout( function(){ _h.selectPanel(pan, fromRow, sClick, e) }, 500);
                return;
            }
    
            //blur current focused item before changing selection
            if (emEditor.onEditBox.ref) { 
                emEditor.elemToSave = emEditor.selectedItems.emName;
            } else {
                emEditor.elemToSave = null;
            }
            
            /* multi. sel */
            var panelID = pan.id, 
                emName = emEditor.editorUI.panel.getPanelRefFromID( panelID ).emName,
                reloadCurve = true,
                tr;
                                       
             if (e) {
                 if( $( "#"+panelID ).find(".editClassNameInPanel").length === 0 || e.target.className != "editClassNameInPanel") {
                     $(".editClassNameInPanel").blur();   
                 }
                 tr = YAHOO.util.Dom.getAncestorByTagName(e.target, "tr");
             }
             
             if(emEditor.selectedItems.emName == emName) { 
                 reloadCurve = false;
             } 

             if (e && e.ctrlKey || e && e.metaKey) { 

                 if( !$("#"+panelID+"_c").hasClass( "multiSelected" ) ) {
                     emEditor.emPropertiesTable.style.display = "none";
                     emEditor.attPropertiesTable.style.display = "none";
                     emEditor.emEventTable.style.display = "none";
                     emEditor.attEventTable.style.display = "none";
                     if( !emEditor.multiSelect ) { 
                         emEditor.multiSelect = [];
                     }                 
                     if( emEditor.selectedItems.emName ) {
                         var pRef = emEditor.editorUI.panel.getPanelRef(emEditor.selectedItems.emName);
                         if( !$("#"+pRef.id+"_c").hasClass("multiSelected") ) {
                             $("#"+pRef.id+"_c").addClass("multiSelected");
                         }
                         if( !_uA.isValueIn(pRef.id, emEditor.multiSelect) ) {
                             emEditor.multiSelect.push(pRef.id);
                         }
                     }
                     if( !_uA.isValueIn(panelID, emEditor.multiSelect) ) {
                         emEditor.multiSelect.push(panelID);
                     }

                     $("#"+panelID+"_c").addClass("multiSelected");
                     $("#outline_"+emName +" td").addClass("selected");
                     return;
                     
                 } else { 
                    _uA.removeFromArray(panelID, emEditor.multiSelect);
                    $("#"+panelID+"_c").removeClass("multiSelected");
                    return;
                 } 

             } else {
                 emEditor.multiSelect = [];
                 $(".multiSelected").removeClass("multiSelected");
             }
             /* end multi. sel */
             
            /*if( emEditor.rightLayoutState != 'visible' ) {
                emEditor.layout.getUnitByPosition('right').expand();
                emEditor.rightLayoutState = 'visible';
                emEditor.previewObj.setScopeSize(); 
            }*/
            
            if (e && tr) {
                
                if (emEditor.handlePerms) {
                    if( !$(tr).hasClass("meth") ) {
                       //  _perm.hide();
                    } else { 
                       _perm.build();
                    }
                }
                
            }
            
            if (sClick && emEditor.rightLayoutState != "visible") {
                emEditor.selectedItems.emName = emName;
                return;
            }
            
            var panelID = pan.id,
                c       = true,
                pRef    = emEditor.editorUI.panel.getPanelRefFromID(panelID),   
                emName  = pRef.emName;

            if( emEditor.selectedItems.emName != emName ) {
                
                var notSaved = $("tr.notSaved");
                   if( notSaved.get()[0] ) { 
                        $(notSaved).btOff();
                   }
                
                var table = document.getElementById(_conf.htmlData.attEventsPanels);
                table.style.display = "none";
             
                emEditor.selectedItems.emName = emName;
                if (fromRow) { 
                    c = false; 
                }
                _b.properties.entity( emName, c, fromRow );
                _b.events.entity( emName, c, fromRow );
                _b.entity.methods( emName, null, null, true );  
                var pRef = emEditor.editorUI.panel.getPanelRef( emEditor.selectedItems.emName );
                emEditor.editorUI.panel.addFocus( pRef.id );
                
                $("#menuTableEm td").removeClass("selected");
                $("#outline_"+emName +" td").addClass("selected");

                
            } else {   

                if (event && !$(event.target).hasClass("headerSpan") && emEditor.selectedItems.item && emEditor.selectedItems.emName === emName) {
                    return false;
                }
                
                _b.properties.entity(emName, c, fromRow);
                _b.events.entity(emName, c, fromRow);
                _b.entity.methods(emName, null, null, true);
                emEditor.emPropertiesTable.style.display = "table";
                emEditor.attPropertiesTable.style.display = "none";
                emEditor.emEventTable.style.display = "table";
                emEditor.attEventTable.style.display = "none";
                $(emEditor.selectedItems.item).removeClass("entityModels");
                emEditor.selectedItems.item = null;            
            }
            
            if( emEditor.relationCurve === "true" ) {
                emEditor.relationCurve = true;
            }
            if( emEditor.relationCurve === "false" ) {
                emEditor.relationCurve = false;
            }
            if( emEditor.handlePerms ) { 
                _perm.build();
            }           
                        
            //reset tab views
            var tab3 = emEditor.leftTabview.getTab(2);
            tab3.set('disabled', false);
            tab3 = emEditor.leftTabview.getTab(1);
            tab3.set('disabled', false);
            tab3 = emEditor.leftTabview.getTab(0);
            tab3.set('disabled', false);

            emEditor.studio.updateMenus();

            //load the relation curve for this em
            if( emEditor.curve && emEditor.relationCurve && reloadCurve ) {
                _c.loadRelationCurve();                    
            }
                
    },
    dragStopHandler:function( elem ) {
                if(dropTarget.id == "center-body"){         
                    _u.remove.entityProperty(emEditor.editorUI.panel.getActiveElemName(), elem.firstChild.nodeValue);
                    var tb = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                    var tr = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
                    if(tr.rowIndex == 0){
                        var td = tr.firstChild;
                        var trs = tb.getElementsByTagName("tr");
                        if(trs.length == 1){
                            console.log("remove if no items remaining to do !!");
                        }else{
                            var target = trs[1].firstChild;
                            trs[1].insertBefore(td, target);
                            tb.deleteRow(tr.rowIndex);
                        }

                    }else{
                        tb.deleteRow(tr.rowIndex);
                    }

                }
    },
    hidePathCollumn:function( elem, fromTb, keepOpen, fromSave, noRelCurve ) {

            var table, 
                container, 
                but,
                allPath,
                bd,
                tab,
                pathW,
                disp, 
                close = false, 
                keepState;  
            
            if ( !fromTb ) {
                container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module");
            } else {
                container = YAHOO.util.Dom.getAncestorByClassName(fromTb, "yui-module");
            }
            if ( !elem ) {
                but = YAHOO.util.Dom.getElementsByClassName("hidePath", "div", container)[0];
            } else {
                but = elem;
            }
            
            allPath = YAHOO.util.Dom.getElementsByClassName("path", "td", container);
            bd      = YAHOO.util.Dom.getElementsByClassName("bd", "div", container)[0]; //force table to update his width before resizing the panel
            tab     = bd.getElementsByTagName('table');
            pathW   = 0;
            
            for( var k in allPath ) {
                if ( allPath[k].offsetWidth > pathW) { pathW = allPath[k].offsetWidth; } 
            }
            
            for( var key in allPath ) {
                disp = allPath[key];
                if ( YAHOO.util.Dom.hasClass(disp, "tableHidden") ) {
                        YAHOO.util.Dom.removeClass(disp, "tableHidden");
                        YAHOO.util.Dom.removeClass(but, "right"); 
                        keepState = true;
                } else {
                    if ( !keepOpen ) {
                        YAHOO.util.Dom.addClass(disp, "tableHidden");
                        YAHOO.util.Dom.addClass(but, "right");
                        keepState = false;
                    }
                }
            }
            
            if ( !fromSave ) { 
                _u.extraProperties.setPathState(keepState, emEditor.editorUI.panel.getActiveElemName());
            }
           
            emEditor.editorUI.panel.manageResizeWidth(container, false, true, noRelCurve);
    },
    /**
    * select all openned panels in the workspace
    */
    selectAllEms : function(){
        //if(e.keyCode === 65 && e.ctrlKey == true && emEditor.onEditBox){
        var ps = $(".yui-panel-container");
        ps.addClass("multiSelected");
        emEditor.emPropertiesTable.style.display = "none";
        emEditor.attPropertiesTable.style.display="none";
        emEditor.emEventTable.style.display = "none";
        emEditor.attEventTable.style.display = "none";
        emEditor.multiSelect = [];
        var ids;
        $.each(ps, function(index, value) { 
            ids = value.id.split("_")[0];
            if(ids){
                emEditor.multiSelect.push(ids);
            }
        });
     //}
    },
    /**
    * select the model and unsemect the current selected class
    */
    selectModel : function ( ev ) {

        var pIndex,
            ok = true;
       
       if( ev ) {
            
           if( ev.srcElement && ev.srcElement.nodeName != "svg" ) {
               if( ev.srcElement.id != "center-body" || emEditor.selectedItems.emName == "___MODEL" || emEditor.onEditBox.ref ) {
                  ok = false;
               } 
           }    
       }
       
       if (emEditor.onEditBox.ref) {
           ok = false;
       }
              
       if (ok) {
           
           $(".entityModels td").removeClass("selected");
           _b.properties.model();

           //unselect current s election
           if( emEditor.selectedItems && emEditor.selectedItems.emName ) {
               pIndex = emEditor.panelsRef[emEditor.selectedItems.emName];
               if( emEditor.panels[pIndex] ) {
                   emEditor.panels[pIndex].panel.blur();
               }
               emEditor.emPropertiesTable.style.display = "none";
               emEditor.attPropertiesTable.style.display = "none";
               emEditor.emEventTable.style.display = "none";
               emEditor.attEventTable.style.display = "none";
               //_c.loadRelationCurve();
               $(emEditor.selectedItems.item).removeClass("selected");
               emEditor.selectedItems.item = null;
           }

            window.setTimeout(function(){

                emEditor.selectedItems.emName = "___MODEL";
                if( emEditor.handlePerms ) {
                     _perm.build();
                }

            }, 100);
            
            window.setTimeout(function(){emEditor.studio.updateMenus();},100); 
        }

    }   
};

_h = emEditor.editorUI.handlers;

})();




