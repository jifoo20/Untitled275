/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {
    emEditor.editorUI.views.delegate = {};
    
    emEditor.editorUI.views.delegate.click = function() {
		

        $("body").delegate("div.updateMask, div.removeOverrideValue, div.perm-remove, input.perm-force, #center-body, li.addMeth, div.addElem, div.removeIcnForAttributesI, #center-body, div.keyIcns, div.privateAttKey, li.createType, li.createEm, li.editType, li.doNothing", "click", function(event){

            emEditor.methodApplyToMenu.get()[0].style.display = "none";
            
            var tg = this.className.split(" "), 
            sc, 
            met, 
            val,
            attPos,
            classPos,
            propName,
            isMeth = $(emEditor.selectedItems.item).hasClass("methodInherited");

            if( this.id === "center-body" ) { 
                _h.selectModel(event);
            }

            switch(tg[0]){
                case "removeOverrideValue": 
                    
                    classPos    = emEditor.editorData.findEntityModel(emEditor.selectedItems.emName);
                    attName     = emEditor.selectedItems.item.id.split("-")[4];
                    emName      = emEditor.selectedItems.emName;
                    
                    if (isMeth) {
                        attPos = _g.method(classPos, attName);
                        sel = $(this.parentNode).find("select")[0];
                        if (sel.id === "methRetTypeCombo") {
                            propName = "returnType";
                        } else {
                            propName = "scope";
                        }
                        
                        _u.remove.methodProperty (emName, propName, attName);
                        _b.properties.methods(emName, attName, false, false, true); 
                        
                    } else {
                        attPos = emEditor.editorData.findEmAtrribute(classPos, emEditor.selectedItems.item.id.split("-")[4]);
                        if ($(this.parentNode).find("select").length != 0) {
                            propName    = $(this.parentNode).find("select")[0].title;
                        } else {
                            propName    = emEditor.uD.getElementType(this);
                            if (!propName) {
                                propName = emEditor.uD.getElementType($(this.parentNode).find(".editable_base div").get()[0]);
                            }
                        }

                        _u.remove.attributeProperty(emName, propName, attName);

                        if (_g.attProperties(emName, attName).length === 0) {
                            _classes[classPos]["attributes"].splice(attPos, 1);
                        }

                        _b.properties.attribute(emName, attName, false, true);
                    }   

                    break;
                case 'perm-remove':
                    _perms.remove(this);
                    break;
                case "perm-force":
                    _perms.set.forced(this);
                    break;
                case "addMeth":
                    _h.click.addOnClick(_conf.htmlData.classMeth, null, tg[1]);
                    break;    
                case "createType":
                    emEditor.unknownAskWhatToDo = true;
                    if (emEditor.onEditBox.ref) {
                        emEditor.onEditBox.ref.blur();
                    }
                    sc = $(emEditor.selectedItems.item);
                    sc.btOff();
                    val = sc.find(".editable_input2").get()[0].textContent;
                    _o.saveNewType(val, "string");
                    var target = _conf .htmlData.typesTable;
                    var tb = document.getElementById(target);
                    _b.types(tb);
                    emEditor.unknownAskWhatToDo = false;
                    break;
                case "createEm":
                
                    emEditor.unknownAskWhatToDo = true;
                    if(emEditor.onEditBox.ref){
                        var v = emEditor.onEditBox.ref.value;
                        emEditor.onEditBox.ref.value = v.substr(0,1).toUpperCase() + v.substr(1,v.length);  
                        emEditor.onEditBox.ref.blur();
                    }
                    sc = $(emEditor.selectedItems.item);
                    sc.btOff();
                    val = sc.find(".editable_input2").get()[0].textContent;
                    _h.click.addNewEm(null, val);
                    emEditor.unknownAskWhatToDo = false;
                    break;
                case "editType":
                    sc = $(emEditor.selectedItems.item);
                    sc.btOff();
                    sc.find(".editable_input2").get()[0].focus();
                    break;
                case "doNothing":
                    emEditor.unknownAskWhatToDo = true;
                    if(emEditor.onEditBox.ref){
                        emEditor.onEditBox.ref.blur();
                    }
                    $(emEditor.selectedItems.item).btOff();
                    emEditor.unknownAskWhatToDo = false;
                    break;
                case "privateAttKey":
                    if (!$(this).closest("tr").hasClass("noEdit")) {
                        (tg[1] == "bt-active") ? sc = tg[2] : sc = tg[1];
                        _o.manageScope($(this), sc);   
                    }
                    break;
                case "keyIcns":
                    //!! to do : move here from click.js.
                    /*var r = $(this).parent().parent(".mainAttRow");

                if(r.hasClass("selected")){
                    var val = r.get()[0].title;

                     //emName
                    var emName = emEditor.editorUI.panel.getPanelRefFromID(emEditor.editorUI.panel.getActiveID())["emName"];
                    var oldKey = _g.primKey(emName);

                    //update data
                    if(val != null && val != ""){
                        _u.attributeProperty(emName, _conf .xmlData.primKey, val, "true");
                    }
                    //update UI
                    _vu.primKey(emName, val, oldKey);
                }*/
                
                    break;
                case "addElem":
                
                    var pa = $(this.parentNode);
                    if($(this.parentNode).hasClass("meth") || $(this.parentNode.parentNode).hasClass("methodsTable")) {                    
             
                        emEditor.methodApplyToMenu.get()[0].style.display = "block";

                        var clientX = event.clientX;
                        var docX = document.documentElement.clientWidth;
                        var menuWidth = emEditor.methodApplyToMenu.get()[0].offsetWidth;

                        if(clientX + menuWidth > docX) { //just avoid displaying the menu out of the view
                            clientX = docX - menuWidth;
                        }

                        emEditor.methodApplyToMenu.get()[0].style.top = event.clientY + "px";
                        emEditor.methodApplyToMenu.get()[0].style.left = clientX + "px";
                        event.stopPropagation();
                    }else{
                    
                        _h.click.addOnClick(_conf.htmlData.classEm, event);
                    }
                
                    break;
                case "removeIcnForAttributesI":
                
                    event.stopPropagation();
                    event.preventDefault();

                    var tr = YAHOO.util.Dom.getAncestorByTagName(this, "tr");
                    var table = YAHOO.util.Dom.getAncestorByTagName(this, "table");

                    if(YAHOO.util.Dom.hasClass(table, "attributesTable")){
                        _oR.attribute(table, tr.rowIndex, tr);
                    }else{
                        _oR.method(table, tr.rowIndex, tr);
                    }

                    break;
                default:
                    /* multi. sel */

                    if(event.srcElement.id === "center-body" || event.srcElement.nodeName === "svg"){ 
                     
                        //blur edit name if needed
                        $(".editClassNameInPanel").blur();
                        
                        $(".multiSelected").removeClass("multiSelected");
                        var toSel = $("div.focused .yui-module").length;
                        if(toSel.length > 0){
                            _h.selectPanel(toSel.get()[1], false, null, event);
                        }
                        emEditor.multiSelect = [];
                    }
            /* end multi. sel */
            }
	      
        });
	
    };
	
    emEditor.editorUI.views.delegate.blur = function() {    
		
        $("body").delegate("div.editable_input", "blur", function(){
                
            var tg = this.className.split(" ");
	            
            switch(tg[0]){

                case "editable_input":
                    _h.blur.main(event, this);
                break;
                case "editClassNameInPanel":
                    /*if(this.textContent != emEditor.selectedItems.emName) {
                    
                    }*/
                break;
                default:
                    console.log("emEditor.editorUI.views.delegate.blur");
            }
	      
        });
	
    };
    
    emEditor.editorUI.views.delegate.change = function() {    
		
        $("body").delegate("textarea.notes", "change", function(){
                
            var tg = this.className.split(" ");
	            
            switch(tg[0]){
                case "notes":
                    _h.blur.textarea(event, this);
                break;
                default:
                    console.log("emEditor.editorUI.views.delegate.change");
            }
	      
        });
        
        $("body").delegate("input[type=checkbox]", "change", function(){
                
            var tg = this.className.split(" ");
            	            
            switch(tg[0]){
                case "isRemoved": 
                    emEditor.editorUI.objects.manageInheritedFromSelection();
                break;
                default:
                    //console.log("emEditor.editorUI.views.delegate.change");
            }
	      
        });
	
    };
	
    emEditor.editorUI.views.delegate.focus = function() {
        
        $("body").delegate(".attributeTable .ui-autocomplete-input, .perm-group .ui-autocomplete-input, textarea.notes, div.editable_input, div.editable_input2", "focus", function(){

            var tg = this.className.split(" ");
            	            
            switch(tg[0]){
                case "notes": 
                case "editable_input": 
                    _o.switchToEditMode(this, event);
                break;
                case "editable_input2":
                    _o.switchToEditMode(this);
                break;
                case "ui-autocomplete-input": 
                    if ($(this.parentNode).hasClass("method")) {
                         emEditor.onEditBox = {
                                oldValue    : null, 
                                ref         : this,
                                emName      : emEditor.selectedItems.emName,
                                item        : emEditor.selectedItems.item
                         };
                    } else {
                        _perm.selectedItems = emEditor.editorUI.utilities.cloneObj(emEditor.selectedItems);
                    }
                break;
                default:
                    console.log("emEditor.editorUI.views.delegate.blur");
            }
	      
        });
        
        $("body").delegate("input", "focus", function(){
                        
            emEditor.selectedInput = this;
	      
        });
        
	
    };
	
    emEditor.editorUI.views.delegate.keydown = function() {
		
        $("body").delegate("div.editable_input", "keydown", function(){
                      
            var tg = this.className.split(" ");
            	            
            switch(tg[0]){
                case "editable_input":
                    if(tg[1] != "backprop"){  
                        _h.key.press(event, this);
                    }
                    break;
            
                default:
                    console.log("emEditor.editorUI.views.delegate.blur");
            }
	      
        });
	
    };
	
    emEditor.editorUI.views.delegate.keypress = function() {
		
        $("body").delegate("div.editable_input.backprop", "keypress", function() {

            var tg = this.className.split(" ");

            switch(tg[0]){
                case "editable_input":
                    if(tg[1] == "backprop"){   
                        _h.key.fieldPress(event, this);
                    }
                    break;
            
                default:
                    console.log("emEditor.editorUI.views.delegate.blur"); 
            }
	      
        });
	
    };
	
    emEditor.editorUI.views.delegate.dblclick = function() {
		
        $("body").delegate("div.editable_input", "dblclick", function(){
                        
            var tg = this.className.split(" ");
            	            
            switch(tg[0]){
                case "editable_input":
                    _h.editMode(this, event);
                    break;
            
                default:
                    console.log("emEditor.editorUI.views.delegate.blur");
            }
	      
        });
	
    };
	
    emEditor.editorUI.views.delegate.mouseDown = function() {
    /*$("body").delegate("#center-body", "mousedown", function(){
                var tg = this.className.split(" ");

                switch(tg[0]){
                case "editable_input":    
                    //emEditor.editorUI.multiSelBox.mousedown(e);
                break;

                default: console.log("emEditor.editorUI.views.delegate.blur");
                }

    	 }); */
    };
	
    emEditor.editorUI.views.delegate.mouseEnter = function() {
        $("body").delegate("tr.mainAttRow, tr.meth", "mouseenter", function(){
            var elem = $(this);
            var bd = elem.closest(".bd");
            if(bd.length > 0){
                
                var trHeight = this.offsetHeight;
                var sTop = bd.get()[0].scrollTop;
                var rmElem = elem.find(".removeIcnForAttributes");
                rmElem.css("height", trHeight-1);
                if(trHeight > 27){ 
                    rmElem.css("margin-top", -sTop-12);
                }else{
                    rmElem.css("margin-top", -sTop-2);
                }
                
            }

        }); 
    }
	
})(); 


    
    
