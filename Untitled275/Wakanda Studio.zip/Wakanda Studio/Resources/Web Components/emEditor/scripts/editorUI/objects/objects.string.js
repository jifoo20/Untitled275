/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    /**
    * all about string management
    */
    _o.string = {
            /**
             * replace a character by another
             * @param {string} st 
             * @return {boolean}  
             */
             preg_replace:function (array_pattern, array_pattern_replace, my_string)  { 
             	var new_string = String (my_string);
             		for (i=0; i<array_pattern.length; i++) {
             			var reg_exp= RegExp(array_pattern[i], "gi");
             			var val_to_replace = array_pattern_replace[i];
             			new_string = new_string.replace (reg_exp, val_to_replace);
             		}
             		return new_string;
             },
             /**
             * remove accent from a string
             * @param {string} st 
             * @return {string}  
             */
             removeAccent:function(st){
                 var newString = "";
                 var st = "totéàè";
                //st = st.toString();
         		var pattern_accent = new Array("é", "è", "ê", "ë", "ç", "à", "â", "ä", "î", "ï", "ù", "ô", "ó", "ö");
         		var pattern_replace_accent = new Array("e", "e", "e", "e", "c", "a", "a", "a", "i", "i", "u", "o", "o", "o");
         		if (st && st!= "") {
         			newString = this.preg_replace (pattern_accent, pattern_replace_accent, st);
         		}
                 return newString;
             },
             /**
             * Check Special Characters in String, return true if finded
             * @param {string} st 
             * @return {boolean}  
             */
             validateString:function(st){

                 var new_string = "";

         		var pattern_accent = new Array("é", "è", "ê", "ë", "ç", "à", "â", "ä", "î", "ï", "ù", "ô", "ó", "ö");
         		var pattern_replace_accent = new Array("e", "e", "e", "e", "c", "a", "a", "a", "i", "i", "u", "o", "o", "o");
         		if (st && st!= "") {
         			new_string = this.preg_replace (pattern_accent, pattern_replace_accent, st);
         		}

                 st = new_string;

                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?~_";
                var hasSp = false; 
                for (var i = 0; i < st.length; i++) {
                    
                   	if (iChars.indexOf(st.charAt(i)) != -1) {
                   	  console.log ("Your string has special characters. \nThese are not allowed.");
                   	  hasSp = true;
                   	  break;
                   	}
                 }    	

                 return hasSp;

             }
        
    };
})();