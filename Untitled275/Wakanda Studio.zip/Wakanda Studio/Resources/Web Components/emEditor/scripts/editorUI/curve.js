/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() { 

    /*
    paper.path("M 25 200 l 60 0 l 0 90 l 80 0 l 0").attr({'stroke-width': 4});​
    */

    /**
    * curve, to manage relationships links
    */
    emEditor.editorUI.curve = { };
    _c =  emEditor.editorUI.curve;
    /**
    * build the link using raphael library
    * @param {object} trs html object, line in the table where the relation starts
    * @param {number} x start x value
    * @param {number} y Start y value
    * @param {number} ax ctrl Start X value
    * @param {number} ay ctrl Start y value
    * @param {number} bx ctrl End x value
    * @param {number} by ctrl End y value
    * @param {number} zx End x value
    * @param {number} zy End y value
    * @param {string} color color of the link
    * @param {string} emStart name of the entity where the link start from
    * @param {object} emEnd information about the link, name of the entoty where the relation goes
    */
	_c.init = function(trs, x, y, ax, ay, bx, by, zx, zy, color, emStart, emEnd, trsEnd){
    
        
        //get workspace ref
		var r = emEditor.editorUI.svgDrowSpace,
		    st,
		    curve,
		    diffLabel,
            sn = _g.collectionName(emStart),
            nb = 0;
           
        if(!emEditor.bezierCurve && emStart != emEnd.type && sn != emEnd.type ){ 
            
            $.each(_c.relationCurve, function(index, value) { 
                                                
                if( value.emStart == emStart && value.emEnd.type == emEnd.type ) {
                  nb++;  
                } else if ( value.emStart == _classes[emEditor.emRef[emEnd.type]]["className"] && emStart == _classes[emEditor.emRef[value.emEnd.type]]["className"] ) {
                  nb++;  
                }
                
            });
            
            var dis = zx - x,
                mid = dis / 2, 
                mdiff = nb*4,
                path = [["M", x, y], ["l", mid+mdiff, 0], ["l", 0, zy-y], ["l", mid-mdiff, 0 ]],
                hasMany,
                belongTo;
                
                if( emEnd.kind == "relatedEntity" ) {
                    if( x < zx ) {
                        belongTo = r.text(x+50, y+15, "Belongs to >>").attr({fill: "#A5A5A5", "font-size":11});
                    }else{
                        belongTo = r.text(x-50, y+15, "<< Belongs to").attr({fill: "#A5A5A5", "font-size":11});
                    }   
                    hasMany = null;
                }else{
                    diffLabel = 50;
                    if( x < zx ) {
                        diffLabel = -50;
                        hasMany = r.text(x-diffLabel, y-10, "Has many >>").attr({fill: "#A5A5A5", "font-size":11});
                        belongTo = r.text(zx+diffLabel, zy-10, "<< Belongs to").attr({fill: "#A5A5A5", "font-size":11});
                    }else{
                        diffLabel = 50;
                        hasMany = r.text(x-diffLabel, y-10, "<< Has many").attr({fill: "#A5A5A5", "font-size":11});
                        belongTo = r.text(zx+diffLabel, zy-10, "Belongs to >>").attr({fill: "#A5A5A5", "font-size":11});
                    }

                    hasMany.hide();
                }
                
                belongTo.hide();
                
            controls =  r.set(
                        r.circle(x, y, 5).attr({fill: color, stroke: color, "stroke-width": 3}),  
                        r.circle(zx, zy, 5).attr({fill: color, stroke: color, "stroke-width": 3})
                        );
                      
        }else{

        	var path = [["M", x, y], ["C", ax, ay, bx, by, zx, zy]],
                path2 = [["M", x, y], ["L", ax, ay], ["M", bx, by], ["L", zx, zy]],
            controls = r.set(
                r.circle(x, y, 5).attr({fill: "#ccc", stroke: color, "stroke-width": 3}),  
                r.circle(ax, ay, 5).attr({fill: "none", stroke: "none", "stroke-width": 0}), //ctrl is hidden !
                r.circle(bx, by, 5).attr({fill: "none", stroke: "none", "stroke-width": 0}), //ctrl is hidden !
                r.circle(zx, zy, 5).attr({fill: "#ccc", stroke: color, "stroke-width": 3})
                );
        }
     
		 if(trsEnd){ 
	         //build svg object
	         (emEnd.type == "alias") ? st = "-" : st = "---";
             curve = r.path(path).attr({stroke: color || Raphael.getColor(), "stroke-width": 2, "stroke-dasharray": st}); //, "stroke-dasharray": "-"
	     }else{
	         curve = r.path(path).attr({stroke: color || Raphael.getColor(), "stroke-width": 2});
	     }
         
         //keep data about the relation in the curve object
         curve.controls = controls;
         curve.emstart = emStart;
         curve.hasMany = hasMany;
         curve.belongTo = belongTo;
         curve.emEnd = emEnd;
         curve.color = color;
         if( trsEnd ) { 
             curve.trEnd = trsEnd;
         }
        
         curve.mouseover(function (event) { 
                          
             this.attr({stroke: "orange", "stroke-width": 4});
             this.controls.attr({stroke: "#E26626"});
             if( this.belongTo ) {
                 this.belongTo.show();
                 this.belongTo.toFront(); 
             }
             
             if( this.hasMany != null ) {
                 this.hasMany.show();
                 this.hasMany.toFront();
                 if(this.hasMany.attrs.y < this.belongTo.attrs.y) { 
                     this.belongTo.translate(0, 20);
                 }else{
                    this.hasMany.translate(0, 20);
                 }
                 
                 
                 if (this.controls[0].attrs.cx > this.controls[1].attrs.cx) {
                     if(Math.abs( this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140 ) {  
                          //if inversion
                          this.hasMany.attr('text','<<');
                          this.belongTo.attr('text','>>');
                          this.belongTo.translate(-35, 0);
                          this.hasMany.translate(35, 0);
                      }
                 }else{
                    if(Math.abs( this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140 ) {  
                          //if inversion
                          this.hasMany.attr('text','>>');
                          this.belongTo.attr('text','<<');
                          this.belongTo.translate(35, 0);
                          this.hasMany.translate(-35, 0);
                      }    
                 }
                 
                 
             }else{
             
                if(this.controls[0].attrs.cy < this.controls[1].attrs.cy) { 
                     this.belongTo.translate(0, -30);
                 }
                 
                 if (this.controls[0].attrs.cx > this.controls[1].attrs.cx)  {

                     if(Math.abs(this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140) {
                          this.belongTo.attr('text','<<');
                          this.belongTo.translate(35, 0);
                      }
                 }else{
                    if(Math.abs(this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140) {
                         if( this.belongTo ) {
                             this.belongTo.attr('text','>>');
                             this.belongTo.translate(-35, 0);
                         }
                     }
                 }
                 
             }
             
             var message = {};
             var displayKind;
             
             message.name = this.emEnd.name;
             message.type = this.emEnd.type;
             message.kind = this.emEnd.kind;
             message.path = this.emEnd.path;
             
             if (message.kind === "relatedEntities" || message.kind === "relatedEntity") { 
                displayKind = "Relation Attribute";
             } else {
                displayKind = message.kind;
             }

             emEditor.timer = setTimeout(function() { 
                  emEditor.relTooltip = new YAHOO.widget.Overlay("toolTipOverlay", { xy:[event.pageX+10,event.pageY+10],
                    												visible:true,
                    												width:"200px",
                    												zindex:9999 
                    									});

                   emEditor.relTooltip.setHeader("Relationship");
                   emEditor.relTooltip.setBody(
                    "<span class='toolTipLabel'>Name</span>: <span class='toolTipText'>"+message.name+"</span><br>"+
                    "<span class='toolTipLabel'>Type</span>: <span class='toolTipText'>"+message.type+"</span><br>"+
                    "<span class='toolTipLabel'>Path</span>: <span class='toolTipText'>"+message.path+"</span><br>"+
                    "<span class='toolTipLabel'>kind</span>: <span class='toolTipText'>"+displayKind
                   );

                  emEditor.relTooltip.render("center-body");
                
             },0); //800
             
         });
         
         curve.mouseout(function (event) {
             clearTimeout(emEditor.timer);
             this.attr({stroke: this.color, "stroke-width": 2});
             this.controls.attr({stroke: this.color});
             
             if( this.hasMany != null ) {
                 if(this.hasMany.attrs.y < this.belongTo.attrs.y) { 
                     this.belongTo.translate(0, -20);
                 }else{
                    this.hasMany.translate(0, -20);
                 }

                  if (this.controls[0].attrs.cx > this.controls[1].attrs.cx) {
                      if(Math.abs( this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140 ) {  
                           //if inversion
                           this.hasMany.attr('text','<< Has many');
                           this.belongTo.attr('text','Belongs to >>');
                           this.belongTo.translate(35, 0);
                           this.hasMany.translate(-35, 0);
                       }
                  }else{
                     if(Math.abs( this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140 ) {  
                           //if inversion
                           this.hasMany.attr('text','Has many >>');
                           this.belongTo.attr('text','<< Belongs to');
                           this.belongTo.translate(-35, 0);
                           this.hasMany.translate(35, 0);
                       }    
                  }

                 this.hasMany.hide();
             }else{
                if(this.controls[0].attrs.cy < this.controls[1].attrs.cy) { 
                     this.belongTo.translate(0, 30);
                 }
                 if (this.controls[0].attrs.cx > this.controls[1].attrs.cx)  {
                      if(Math.abs(this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140) {
                           this.belongTo.attr('text','<< Belongs to');
                           this.belongTo.translate(-35, 0);
                       }
                  }else{
                     if(Math.abs(this.controls[0].attrs.cx - this.controls[1].attrs.cx) < 80 && Math.abs(this.controls[0].attrs.cy - this.controls[1].attrs.cy) < 140) {
                          if(this.belongTo) {
                              this.belongTo.attr('text','Belongs to >>');
                              this.belongTo.translate(35, 0);
                          }
                      }
                  }
             }
             if( this.belongTo ) {
                 this.belongTo.hide();
             }
             
             
             if(emEditor.relTooltip){
                 //emEditor.relTooltip.hide();
                 $("#toolTipOverlay").remove();
             }
         });
         curve.click(function (event) {
              if(emEditor.relTooltip){
                  //emEditor.relTooltip.hide();
                  $("#toolTipOverlay").remove();
              }
         });
             
            //set the controls used to update the curve on drag
        /*     controls[0].update = function (x, y) {  
                 var X = this.attr("cx") + x,
                     Y = this.attr("cy") + y;
                 this.attr({cx: X, cy: Y});
                 path[0][1] = X;
                 path[0][2] = Y;
                 path2[0][1] = X;
                 path2[0][2] = Y;
                 controls[1].update(x, y);
             };
             controls[1].update = function (x, y) {
                 var X = this.attr("cx") + x,
                     Y = this.attr("cy") + y;
                 this.attr({cx: X, cy: Y});
                 path[1][1] = X;
                 path[1][2] = Y;
                 path2[1][1] = X;
                 path2[1][2] = Y;
                 curve.attr({path: path});
             };
             controls[2].update = function (x, y) {
                 var X = this.attr("cx") + x,
                     Y = this.attr("cy") + y;
                 this.attr({cx: X, cy: Y});
                 path[1][3] = X;
                 path[1][4] = Y;
                 path2[2][1] = X;
                 path2[2][2] = Y;
                 curve.attr({path: path});
             };
             controls[3].update = function (x, y) { 
                 var X = this.attr("cx") + x,
                     Y = this.attr("cy") + y;
                 this.attr({cx: X, cy: Y});
                 path[1][5] = X;
                 path[1][6] = Y;
                 path2[3][1] = X;
                 path2[3][2] = Y;
                 controls[2].update(x, y);
             };

             //allow to drag ctrl points, for test purpose
             //controls.drag(emEditor.editorUI.curve.move, emEditor.editorUI.curve.up);
             */
	        //keep curve ref in emEditor.editorUI.curve.relationCurve
	        if(emEditor.bezierCurve){
	            _c.relationCurve.push({curveRef: curve, ctrlRef: controls, trs:trs, emStart:emStart, emEnd:emEnd, start:controls[0], end:controls[3], ctrlStart:controls[1], ctrlEnd:controls[2]});
	        }else{
	            _c.relationCurve.push({curveRef: curve, ctrlRef:controls, trs:trs, emStart:emStart, emEnd:emEnd});
	        }			
	},
	_c.initForMP = function(trs, x, y, ax, ay, bx, by, zx, zy, color, emStart, emEnd, trsEnd){
	        //get workspace ref
    		var r = emEditor.editorUI.svgDrowSpaceMP,
    		    st,
    		    curve;
	   
	        emEditor.previewObj.getLastScaleValue();
            var sc = emEditor.lastScale;
		    
		    var x = x*sc,
		        y = y*sc,
		        ax= ax*sc,
		        ay= ay*sc,
		        bx= bx*sc, 
		        by= by*sc, 
		        zx= zx*sc, 
		        zy= zy*sc,
                sn = _g.collectionName(emStart); //_g.singleName(
                
            if(!emEditor.bezierCurve && emStart != emEnd.type && sn != emEnd.type){ 
                //var nb = 0;
               /* $.each(_c.relationCurve, function(index, value) { 
                    if(value.emStart == emStart && value.emEnd.type == emEnd.type){
                      nb++  
                    }
                });*/

                var dis = zx - x, 
                    mid = dis / 2, 
                    mdiff = 1,//nb*8,
                    path = [["M", x, y], ["l", mid+mdiff, 0], ["l", 0, zy-y], ["l", mid-mdiff, 0 ]];

                /*controls =  r.set(
                            r.circle(x, y, 2).attr({fill: color, stroke: color, "stroke-width": 1}),  
                            r.circle(zx, zy, 2).attr({fill: color, stroke: color, "stroke-width": 1})
                            );*/
            }else{

            	var path = [["M", x, y], ["C", ax, ay, bx, by, zx, zy]],
                    path2 = [["M", x, y], ["L", ax, ay], ["M", bx, by], ["L", zx, zy]];
               /* controls = r.set(
                    r.circle(x, y, 2).attr({fill: "#ccc", stroke: color, "stroke-width": 1}),  
                    r.circle(ax, ay, 2).attr({fill: "none", stroke: "none", "stroke-width": 0}), //ctrl is hidden !
                    r.circle(bx, by, 2).attr({fill: "none", stroke: "none", "stroke-width": 0}), //ctrl is hidden !
                    r.circle(zx, zy, 2).attr({fill: "#ccc", stroke: color, "stroke-width": 1})
                    );*/

            }

    		 if(trsEnd){ 
    	         //build svg object
    	         (emEnd.type == "alias") ? st = "-" : st = "---";
                 curve = r.path(path).attr({stroke: color || Raphael.getColor(), "stroke-width": 1, "stroke-dasharray": st}); 
    	     }else{
    	         curve = r.path(path).attr({stroke: color || Raphael.getColor(), "stroke-width": 1});
    	     }
    	     
    	     if(emEditor.bezierCurve){
 	            _c.relationCurveMp.push({curveRef: curve, trs:trs, emStart:emStart, emEnd:emEnd, start:controls[0], end:controls[3], ctrlStart:controls[1], ctrlEnd:controls[2]});
 	        }else{
 	            _c.relationCurveMp.push({curveRef: curve, trs:trs, emStart:emStart, emEnd:emEnd});
 	        }

	}; 
	/**
    * look all the entity and init the curves depending on the configuration
    */
	_c.loadRelationCurve = function(mp, pan){ 

		//declare var
		var links, stop, sleft, sh, sw, etop, eleft, eh, ew, p, trs, table, ind, adj, tn, drow, 
		    endTop,
		    startLeft,
		    ctrlEndLeft,
		    panels,
	        curPan,
		    emName, color, np = [], npmp = [], tb, tbmp,
		    flat , flatPath, flatEnd, flatName, flatP, t, trsEnd, adjEnd=0, emNamef = null, p, panelOpen, panelResized, sid, kindName; //var for flattened curves
            
        if(pan){  
            panels = [];
            //panels = emEditor.panels;
            sn = _g.collectionName(pan.emName);
            if( _c.relationCurve ) {
                tb = _c.relationCurve; 
                tbmp = _c.relationCurveMp;
                $.each( tb, function( index, value ) { 
                  if (value.emStart === pan.emName || value.emStart === sn || value.emEnd.type == pan.emName || value.emEnd.type == sn ) {

                      if( !_uA.isValueInObject( value.emStart, panels, "emName" ) ) {
                         panels.push( emEditor.panels[emEditor.emRef[value.emStart]] ); 
                      }

                      kindName = _g.dataClassName(value.emEnd.type);
                      if( !_uA.isValueInObject( kindName, panels, "emName" ) ) {
                         panels.push( emEditor.panels[emEditor.emRef[kindName]] ); 
                      }
                      
                      value.ctrlRef.remove();              
                      value.curveRef.remove();
                      tbmp[index].curveRef.remove();  

                      //remove all ref in emEditor.editorUI.curve.relationCurve
                      np = tb.slice(0, index-1).concat(tb.slice(index+1, tb.length+1));
                      npmp = tbmp.slice(0, index-1).concat(tbmp.slice(index+1, tbmp.length+1))
                  }
                });     

		       /* for(var k in emEditor.panels){
		            links = _g.relationShips(emEditor.panels[k].emName);
		            for(var l in links){
		                if( emEditor.panels[k].emName == pan.emName ||  pan.emName == links[l].type ||  pan.emName == _g.dataClassName(links[l].type) ) {
				            
				            if( !_uA.isValueInObject( emEditor.panels[k].emName, panels, "emName" ) ) {
                                 panels.push(emEditor.panels[emEditor.panelsRef[emEditor.panels[k].emName]]);
                              }
				        }
		            }
			        
                }       */
                _c.relationCurve = np;
                _c.relationCurveMp = npmp;
            }else{
                panels = [pan];
            	_c.relationCurve = [];
        		_c.relationCurveMp = [];
            }

        }else{ 
            panels = emEditor.panels;
            //clear the workspace
    	    if(!mp){
    	        emEditor.editorUI.svgDrowSpace.clear();
    	        emEditor.editorUI.svgDrowSpaceMP.clear();
    	    }else{
    	        emEditor.editorUI.svgDrowSpaceMP.clear();
    	    }
        	//clear the relation curve object
    		_c.relationCurve = [];
    		_c.relationCurveMp = [];
        }

        //if relationCurveMode === 2, we only look for relations stating from the selected panel !!!! to do : handle multi selection !!!!
        if(emEditor.relationCurveMode === 2){
			sid = emEditor.editorUI.panel.getActiveID();
			if(sid){
			    emNamef = emEditor.editorUI.panel.getPanelRefFromID(sid).emName;
			}
		}

		//set positions of the curve for each curves (startx, starty, ctrlx, ctrly, endx, endy, ctrlx, ctrly)
		for(var k in panels){
		                
				if( panels[k] ) {
				    emName = panels[k]["emName"]; 
				} else {
				    return;
				}
				//get relations
				var ffid = emEditor.editorUI.panel.getPanelRef(emName).id;

				/*if($("#"+ffid+" .bd").css("display") == "none" || _extra.panelExtraPro(emName).relVisible == false || $("#"+emEditor.editorUI.panel.getActiveID()+" .bd").css("display") == "none"){
				    return;
				}*/

				links = _g.relationShips(emName);
                
				if(links.length != 0){

					stop = panels[k]["panel"].element.offsetTop;
					sleft = panels[k]["panel"].element.offsetLeft;
					sw = panels[k]["panel"].element.offsetWidth;
					sh = panels[k]["panel"].element.offsetHeight;
				
					for(var li in links){
					    
                        flat = false;
						if(links[li].kind == "relatedEntity" || links[li].kind == "relatedEntities"){ 
                            
                            switch (links[li].kind){
                                case "alias": 
                                    flat = true;
                                    flatPath = links[li].path.split(".");
                                    flatEnd = flatPath[0];
                                    flatName = flatPath[1];
                                    flatP = _uA.isValueInObject(flatEnd, links, "name"); 
                                    tn = links[flatP].type;
                                    break;
                                case "relatedEntity": 
                                    var sn = _g.dataClassName(links[li].type);
                                    if( sn == null ) { 
                                        tn = _g.collectionName(links[li].type);
                                    }else{
                                        tn = links[li].type;
                                    }
                                    
                                    break;
                                default: tn = _g.dataClassName(links[li].type);
                            }
                          
                            adjEnd = 0;
                            var manyTrEnd = null;
                            
                            //***test to handler 1->n reverse links
                            var manyTrEnd = null;
                            if(links[li].kind == "relatedEntities"){
                                if(links[li].path){
                                    ff = emEditor.editorUI.panel.getPanelRef(tn); 
                                    if(ff){
                                        table = YAHOO.util.Dom.getElementsByClassName("attributesTable", "table", ff.id)[0];
            							if(table){
            							    trs = table.getElementsByTagName("tr");
                							for(var t in trs){ 
                							    if( typeof(trs[t]) != "function" && typeof(trs[t]) != "number" ){
                    								if( emEditor.uD.getWafData( trs[t] ) == links[li].path && links[li].path.split(".").length < 2){
                    									manyTrEnd = trs[t];
                    									adjEnd = manyTrEnd.offsetTop+50;
                    									break;
                    								}
                								}
                							}
            							}
                                    }
                                    
                                }
                            }
                            //***END test to handler 1->n reverse links

                            drow = false;
                            
                            if(emEditor.relationCurveMode === 1){
						    	drow = true;
							}else{
							    if(emNamef){
    								if(emEditor.relationCurveMode === 2 && emName == emNamef){ //emEditor.editorUI.panel.getPanelRef(tn);
        						        drow = true;
                                    }
                                    if(emEditor.relationCurveMode === 2 && tn == emNamef){
        						    	drow = true;    
                                    }
                                }
							}
							
							//***test to handler 1->n reverse links
							if(drow){
							    if(links[li].kind == "relatedEntity" ){ //|| links[li].kind == "relatedEntities							        
							       if(_check.isRelatedEntityInUseAsPath(emName, links[li].name, tn)){
							           drow = false;
							       }
							    }
							}
                            //***END test to handler 1->n reverse links

							p = emEditor.editorUI.panel.getPanelRef(tn);

							table = YAHOO.util.Dom.getElementsByClassName("attributesTable", "table", panels[k]["panel"].id)[0];
							trs = table.getElementsByTagName("tr");
							for(var t in trs){
							    
								if( emEditor.uD.getWafData( trs[t] ) == links[li].name){
									ind = trs[t];
									break;
								}
							}
					
							adj = ind.offsetTop+50;
						
							if(p != null && drow){ 
							    if(flat){
							        var o = $("#center-body #" + p.id + " tr");
							        $.each(o, function(index, value) { 
                                      if( emEditor.uD.getWafData( value )  == flatName) {
                                          trsEnd = value;
                                      }
                                    });
                                    adjEnd = trsEnd.offsetTop+50;
							    }else{
							        trsEnd = null;
							    }
							    
								etop = p.panel.element.offsetTop;
								eleft = p.panel.element.offsetLeft;
								ew = p.panel.element.offsetWidth;
								eh = p.panel.element.offsetHeight;
								
								
                		       /* if(sh == 23 || eh == 23){ //abort if the panel is minimized
                		            return false;
                		        }*/
								
                		        //look if closed, look if reduced
                		        var pe                  = _g.panelState(p["emName"], p.id),
                                    ps                  = _g.panelState(panels[k]["emName"], panels[k]["id"]),
                                    panelResizedEnd,
                                    panelResizedStart,
                                    scrollTopStart      = YAHOO.util.Dom.getElementsByClassName("bd", "div", panels[k]["id"])[0].scrollTop,
                                    scrollTopEnd        = YAHOO.util.Dom.getElementsByClassName("bd", "div", p.id)[0].scrollTop,
                                    m                   = adj;

                                if (pe.panel && ps.panel) {
                                    panelResizedEnd     = pe.panel.resizedHeight;
                                    panelResizedStart   = ps.panel.resizedHeight;        
                                }
   

						       if(panelResizedStart){ 
						           if(panelResizedStart < adj){
    						           adj = panelResizedStart;
    						           if((panelResizedStart-scrollTopStart+30) < adj){
    						               adj = m - (scrollTopStart); 
    						           }
    						       }else{
    						            adj = adj - scrollTopStart;
    						       }
    						       if(adj < 0){
         						       adj = 0;
         						    }
						       }
						       
 						       if(panelResizedEnd){  
 						           if(p.id != panels[k]["id"]){ 
 						               if(panelResizedEnd < adjEnd){
            						           adjEnd = panelResizedEnd;
            						           if((panelResizedEnd-scrollTopEnd+30) < adjEnd){
            						               //adjEnd = panelResizedEnd-scrollTopEnd+15;
            						               adj = m - (scrollTopEnd); 
            						           }
            						       }else{
            						            adjEnd = adjEnd - scrollTopEnd;
            						       }

            						       if(adjEnd < 0){
            						           adjEnd = 0;
            						       }
 						           }
 						       }
						       
						        //target the link to the panel itself if :
						        if(p.id == panels[k]["id"] && links[li].kind == "relatedEntity"){
								    
								    startLeft = sleft+ew;
								    endTop = etop; 
								    eleft = eleft;
								    
								}else{ //else target the link to a tr in the target em manel (could be the same)
								
							    	if(sleft > eleft){
										startLeft = sleft; 
									}else{
										startLeft = sleft+sw;
									}
									
									endTop = etop+adjEnd;

									if(eleft+ew < sleft){
										eleft = eleft + ew;
									}
									
								}
						
														
								if(links[li].kind == "relatedEntity") {
								    color = "#ccc";
								}
								if(links[li].kind == "relatedEntities") {
								    color = "#8CC63E"; //3866DB
								    if(manyTrEnd){ trsEnd = ind; links[li].trEnd = manyTrEnd; }
								} 
								if(links[li].kind == "alias") {
								    color = "#ccc";
								    links[li].emEndName = tn;
								    links[li].trEnd = trsEnd;
								}		

                                //if (_classes[emEditor.emRef[p.emName]].extraProperties.isMinimized != "true" && _classes[emEditor.emRef[panels[k].emName]].extraProperties.isMinimized != "true") {
                                if (_extra.isMinimized(p.emName) != "true" && _extra.isMinimized(panels[k].emName) != "true") {
    								if(mp){
    								    if(p.id != panels[k]["id"]){ 
        								    _c.initForMP( ind, startLeft, stop+adj, eleft, stop+adj, startLeft, endTop, eleft, endTop, color, emName, links[li], trsEnd);
        								}else{
        								    _c.initForMP( ind, startLeft, stop+adj, eleft+ew+50, stop+adj, startLeft, endTop, eleft+ew, endTop, color, emName, links[li]);
        								}
    								}else{
    								    if(p.id != panels[k]["id"]){ 
        									_c.init( ind, startLeft, stop+adj, eleft, stop+adj, startLeft, endTop, eleft, endTop, color, emName, links[li], trsEnd);
        								    _c.initForMP( ind, startLeft, stop+adj, eleft, stop+adj, startLeft, endTop, eleft, endTop, color, emName, links[li], trsEnd);
        								}else{
        								    _c.init( ind, startLeft, stop+adj, eleft+ew+50, stop+adj, startLeft, endTop, eleft+ew, endTop, color, emName, links[li]);
        								    _c.initForMP( ind, startLeft, stop+adj, eleft+ew+50, stop+adj, startLeft, endTop, eleft+ew, endTop, color, emName, links[li]);
        								}
    								}
								}
							}
						}
					}
				}
		    }	
		    
	},
	/**
   * update the curves on panel drag
   * @param {object} pan ref of the html panel dragged
   */
	_c.onDrag = function(pan) {
	    
	        
	    
	     /*
			var emName = pan.id.split("-")[0], stop, sleft, sh, sw, x, y, adj, panelEndRef, ew, eh, sl, et, panelStartRef, m, mE, ml;
			var panelStartLeft, startLeftCx, startLeftCy, panelStartTop, panelEndLeft, panelEndTop, panelEndWidth, panelEndHeight, trsEnd, adjFlat=0;
			panelRef = emEditor.editorUI.panel.getPanelRef(emName);
			stop = panelRef.element.offsetTop;
			sleft = panelRef.element.offsetLeft;
			sw = panelRef.element.offsetWidth;
			sh = panelRef.element.offsetHeight;
			relationCurve = emEditor.editorUI.curve.relationCurve;
            var ps, pe, panelResizedStart, panelResizedEnd, scrollTopStart, scrollTopEnd, m, emE;
            
			for(var k in relationCurve){ 
		    
			    if(relationCurve[k].emStart != relationCurve[k].emEnd.type){
			        
			        if(relationCurve[k].emStart == emName){ //move start
	            
    					x = relationCurve[k]["start"].attrs.cx;
    					y = relationCurve[k]["start"].attrs.cy;
    					ey = relationCurve[k]["end"].attrs.cy;
    					ex = relationCurve[k]["end"].attrs.cx;
    					trs = relationCurve[k].trs;
    					adj = trs.offsetTop+50;
    					
    					//look if closed, look if reduced
        		        ps = _g.panelState(emName, emName+"-entityModels");
        		        panelResizedStart = ps.panel.resizedHeight;
        		        scrollTopStart = YAHOO.util.Dom.getElementsByClassName("bd", "div", emName+"-entityModels")[0].scrollTop;
                        m = adj;
                        
				       if(panelResizedStart){
				           if(panelResizedStart < adj){
					           adj = panelResizedStart;
					           if((panelResizedStart-scrollTopStart+15) < adj){
					               adj = m - (scrollTopStart);
					           }
					       }else{
					            adj = adj - scrollTopStart;
					       }
					       if(adj < 0){
						       adj = 0;
						    }
				       }
    				
    					if(relationCurve[k].emEnd.emEndName){ 
                            panelEndRef = emEditor.editorUI.panel.getPanelRef(relationCurve[k]["emEnd"]["emEndName"]);
                        }else{
                            panelEndRef = emEditor.editorUI.panel.getPanelRef(relationCurve[k]["emEnd"]["type"]);
                        }
                        
    					panelEndLeft = panelEndRef.element.offsetLeft;
    					panelEndTop = panelEndRef.element.offsetTop;
    					panelEndWidth = panelEndRef.element.offsetWidth;
    					panelEndHeight = panelEndRef.element.offsetHeight;
    					startLeftCx = relationCurve[k]["start"].attrs.cx;
    					startLeftCy = relationCurve[k]["start"].attrs.cy;
    					
    					panelStartRef = emEditor.editorUI.panel.getPanelRef(relationCurve[k]["emStart"]);
    					sleft = panelStartRef.element.offsetLeft;
    					sw = panelStartRef.element.offsetWidth;
    					
    					var mE, mS;

    					//set start left
    					if(sleft+sw < panelEndRef.element.offsetLeft){
    						sl = sleft-x+sw;
    					}else{
    						sl = sleft-x;
    					} 

    					if(x < panelEndLeft + panelEndWidth){
    						relationCurve[k]["end"].update((panelEndLeft)-ex, 0);
    						mE = (panelEndLeft)-ex;
    					}else{
    						relationCurve[k]["end"].update((panelEndLeft + panelEndWidth)-ex, 0);		
    						mE = (panelEndLeft + panelEndWidth)-ex;				
    					}

    					relationCurve[k]["start"].update(sl, stop-y+adj);
    					relationCurve[k]["ctrlStart"].update(-(sl)+mE, 0);
    					relationCurve[k]["ctrlEnd"].update(sl-mE, 0); 

    				}
    				
    			    for(var b in relationCurve){ //move end
    			
    				    if(relationCurve[b].emStart != relationCurve[b].emEnd.type && relationCurve[b].emEnd.type == emName || relationCurve[b].emEnd.emEndName == emName){ //MOVE END 

        					if(relationCurve[b].emEnd.trEnd){
        					    trsEnd = relationCurve[b].emEnd.trEnd;
    					        adjFlat = trsEnd.offsetTop+50;
    					    }else{
    					        adjFlat = 0;
    					    }
    					
                            if(relationCurve[b].emEnd.emEndName){ 
                                emE = relationCurve[b]["emEnd"]["emEndName"];
                            }else{ 
                                emE = relationCurve[b]["emEnd"]["type"];
                            }
    					    
					       pe = _g.panelState(emE, emE+"-entityModels");
            		       panelResizedEnd = pe.panel.resizedHeight;
            		       scrollTopEnd = YAHOO.util.Dom.getElementsByClassName("bd", "div", emE+"-entityModels")[0].scrollTop;
					       m = adjFlat;
					       
					       if(panelResizedEnd){
					           if(panelResizedEnd < adjFlat){
						           adjFlat = panelResizedEnd;
						           if((panelResizedEnd-scrollTopEnd+15) < adjFlat){
						               adjFlat = m - (scrollTopEnd);
						           }
						       }else{
						            adjFlat = adjFlat - scrollTopEnd;
						       }
						       
						       if(adjFlat < 0){
						           adjFlat = 0;
						       }
					       }
    					
        					x = relationCurve[b]["end"].attrs.cx;
        					y = relationCurve[b]["end"].attrs.cy;

                            if(relationCurve[b].emEnd.emEndName){ 
                                panelEndRef = emEditor.editorUI.panel.getPanelRef(relationCurve[b]["emEnd"]["emEndName"]);
                            }else{ 
                                panelEndRef = emEditor.editorUI.panel.getPanelRef(relationCurve[b]["emEnd"]["type"]);
                            }
        					
        					panelStartRef = emEditor.editorUI.panel.getPanelRef(relationCurve[b]["emStart"]);
                        
        					panelStartLeft = panelStartRef.element.offsetLeft;
        					panelStartTop = panelStartRef.element.offsetTop;
        					panelEndLeft = panelEndRef.element.offsetLeft;
        					panelEndTop = panelEndRef.element.offsetTop;
        					panelEndWidth = panelEndRef.element.offsetWidth;
        					panelEndHeight = panelEndRef.element.offsetHeight;
        					startLeftCx = relationCurve[b]["start"].attrs.cx;
        					startLeftCy = relationCurve[b]["start"].attrs.cy;

        					ew = panelEndRef.element.offsetWidth;
        					sw = panelStartRef.element.offsetWidth;
        					eh = panelEndRef.element.offsetHeight;
                        
                        
                        
        					//set start left
        					if(panelStartLeft+sw < panelEndRef.element.offsetLeft){
        						sl =panelStartLeft-startLeftCx+sw;
        						relationCurve[b]["start"].update(panelStartLeft-startLeftCx+sw, 0);
        					}else{
        						sl = panelStartLeft-relationCurve[b]["start"].attrs.cx;
        						relationCurve[b]["start"].update(panelStartLeft-startLeftCx, 0);
        					}

        					if(panelStartLeft < panelEndLeft + panelEndWidth){
        						ml=0;
        					}else{
        						ml = (panelEndLeft + panelEndWidth)-panelEndLeft;
        					}

        					relationCurve[b]["end"].update(sleft-x+ml, stop-y+adjFlat);//stop-y+m
        					relationCurve[b]["ctrlEnd"].update(-(sleft-x+ml)+sl, 0);
        					relationCurve[b]["ctrlStart"].update((sleft-x+ml)-sl, 0);
        				}   
			    }
			    
			    }else{ 
			            if(relationCurve[k].emStart == emName){ 
			                
        					x = relationCurve[k]["start"].attrs.cx;
        					y = relationCurve[k]["start"].attrs.cy;
        					ey = relationCurve[k]["end"].attrs.cy;
        					ex  = relationCurve[k]["end"].attrs.cx;
        					trs = relationCurve[k].trs;
        					adj = trs.offsetTop+50;
        					panelEndRef = emEditor.editorUI.panel.getPanelRef(relationCurve[k]["emEnd"]["type"]);
        					panelEndLeft = panelEndRef.element.offsetLeft;
        					panelEndTop = panelEndRef.element.offsetTop;
        					panelEndWidth = panelEndRef.element.offsetWidth;
        					panelEndHeight = panelEndRef.element.offsetHeight;
        					startLeftCx = relationCurve[k]["start"].attrs.cx;
        					startLeftCy = relationCurve[k]["start"].attrs.cy;
        					var mE, mS;
    					
    					    //look if closed, look if reduced
             		        ps = _g.panelState(emName, emName+"-entityModels");
             		        panelResizedStart = ps.panel.resizedHeight;
             		        scrollTopStart = YAHOO.util.Dom.getElementsByClassName("bd", "div", emName+"-entityModels")[0].scrollTop;
                            m = adjFlat;
     				       
     				        if(panelResizedStart){
     				           if(panelResizedStart < adj){
     					           adj = panelResizedStart;
     					           if((panelResizedStart-scrollTopStart+25) < adj){
     					               adjFlat = m - (scrollTopEnd);
     					           }
     					       }else{
     					            adj = adj - scrollTopStart +10;
     					       }
     					       if(adj < 0){
     						       adj = 0;
     						   }
     				        }
    					
        					//set start left
        					sl = sleft-x+sw;
                            mE = (panelEndLeft)-ex;
                                                            
        					relationCurve[k]["end"].update(panelEndLeft-ex+panelEndWidth, stop-y+adj);					
        					relationCurve[k]["start"].update(sl, stop-y+adj);
 
    					}
    			}
			}*/
	},
	/**
    * allow to drag ctrl points, for test purpose
    */
	_c.move = function(dx, dy){
			this.update(dx - (this.dx || 0), dy - (this.dy || 0));
	        this.dx = dx;
	        this.dy = dy;
	},
	/**
    * allow to drag ctrl points, for test purpose
    */
	_c.up = function() {
		this.dx = this.dy = 0;
	};	

})();