/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    emEditor.editorUI.views.listenner = {};
            /**
            * all about remove actions (em, att…)
            * @param {html element} box clicked element
            */
            emEditor.editorUI.views.listenner.setRemove = function(box){
                YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("removeIcnForAttributes", "div", box)[0], "click", function (e) { 
                    e.stopPropagation(); e.preventDefault();

                    var tr = YAHOO.util.Dom.getAncestorByTagName(this, "tr");
                    var table = YAHOO.util.Dom.getAncestorByTagName(this, "table");

                    if(YAHOO.util.Dom.hasClass(table, "attributesTable")){
                        _oR.attribute(table, tr.rowIndex, tr);
                    }else{
                        _oR.method(table, tr.rowIndex, tr);
                    }

                });
            };
            /**
            * special listenner sets for properties panel
            * @param {html element} edit div or input elements
            */
            emEditor.editorUI.views.listenner.listennerProp = function(edit){
                edit.id=emEditor.ids++;  
                autoc = _aC.init(emEditor.uD.getElementType(edit), edit.id);
                YAHOO.util.Event.addListener(edit, "keypress", function (e) {_h.key.fieldPress(e, this);});
                YAHOO.util.Event.addListener(edit, "focus", function (e) {_o.switchToEditMode(this);});                      
                YAHOO.util.Event.addListener(edit, "blur", function (e) { _h.blur.main(e, this);});
            };
            /**
            * listenner use for attributes panels
            * @param {html element} elem div or input elements
            * @param {bool} multiple if the autocompletion is multiple
            * @param {bool} noFocus if no focus listenner is required
            */
            emEditor.editorUI.views.listenner.listenners = function(elem, multiple, noFocus){
                if(!noFocus){
                    YAHOO.util.Event.addListener(elem, "focus", function (e) {_o.switchToEditMode(this, e);});
                }
                elem.id=emEditor.ids++;
                autoc = _aC.init(emEditor.uD.getElementType(elem), elem.id, multiple);
                YAHOO.util.Event.addListener(elem, "keydown", function (e) {_h.key.press(e, this);});
                YAHOO.util.Event.addListener(elem, "blur", function (e) { _h.blur.main(e, this);});
            };
    
})();