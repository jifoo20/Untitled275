/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
    _windows.rotate = {};
    
    /**
    * init the flip object. Add the back div to the panel's container
    * @param {YUI panel object} panel 
    */
    _windows.rotate.init = function(panel){

        var container = panel.element,
            emName = emEditor.editorUI.panel.getPanelRefFromID(panel.id).emName,
            hd;

        //add header event
        /*$("#"+panel.id +" .headerSpan").dblclick(function(){                                  
            _windows.rotate.flip(emEditor.editorUI.panel.getPanelRefFromID(this.parentNode.parentNode.id).emName); 
        });*/
        
        hd = $("#"+panel.id +" .hd");
        
        hd.append('<div class="infoBulle face">i</div>');
        
        hd.find(".infoBulle.face").click( function() {
            _windows.rotate.flip(emEditor.editorUI.panel.getPanelRefFromID(this.parentNode.parentNode.id).emName);
        });
        
        //add flip content
        var back = document.createElement("div");
        back.className = "panel-back-container";
        back.innerHTML = "<div class='panel-back-header'> </div>";
        back.appendChild(_b.properties.backPanel(panel, emName));
        
        //add info button
        var ib = document.createElement("div");
        ib.id = emEditor.ids++;
        $(ib).addClass("infoBulle");
        back.appendChild(ib);
        
        //add done button
        var b = document.createElement("button");
        b.innerHTML = "Done";
        back.appendChild(b);
        //add event to button
        $(b).click(function(){
            _windows.rotate.flip(emEditor.editorUI.panel.getPanelRefFromID(this.parentNode.previousSibling.previousSibling.id).emName, true);
        });
        
        //append all in the target
        container.appendChild(back);

        //add info tooltip
        $('#'+ib.id).bt("<div class='backInfoBullIcs'></div><p>"+_conf .langage.en.helpTips.aboutEmNames+"</p>",{
          trigger: 'click',
          closeWhenOthersOpen: true,
          offsetParent:$('body'),
          cssStyles: {
            fontFamily: '"lucida grande",tahoma,verdana,arial,sans-serif', 
            fontSize: '13px'
          },
          shadow: true,
          shadowColor: 'rgba(0,0,0,.9)',
          shadowOverlap: false,
          noShadowOpts: {strokeStyle: '#999', strokeWidth: 2},
          showTip: function(box){
              $(box).fadeIn(500);
            }
        });

        //hide the back panel
        $(back).hide();
         
    };
    /**
    * make the panel flip
    * @param {string} emName allow to find the proper panel
    * @param {bool} unflip if true trigger an unflip
    */
    _windows.rotate.flip = function(emName, unflip){

        //get panel ref
        var p = emEditor.editorUI.panel.getPanelRef(emName);
        var container = p.panel.element;
        if(emEditor.onFlip && emEditor.onFlip.changeSize === true && emEditor.onFlip.em == emName){ 
            unflip = true;
        }
        
        //toggle the panel
        if(unflip){
            
            $("#"+p.panel.id +" .hd .infoBulle.back").toggleClass("face");
            $("#"+p.panel.id +" .hd .infoBulle.back").toggleClass("back");
            $("#"+p.panel.id +" .hd span.headerSpan").toggleClass("back");
            
            if(container.offsetWidth != emEditor.onFlip.w){
                container.firstChild.style.width = emEditor.onFlip.w+"px";
            }
            if(container.offsetHeight != emEditor.onFlip.h){
                container.firstChild.style.height = "auto";
            }
            $(".headerSpan", p.panel.element).get()[0].textContent = emName;
            $(".headerButton", p.panel.element).css("display", "block");
            $(".container-close", p.panel.element).css("display", "block");
            
            emEditor.onFlip = null;
            $(container).rotate3Di('unflip', 500, {sideChange: _windows.rotate.changeSide});
            
        }else{
            
            if(emEditor.onFlip && emEditor.onFlip.em == emName){
                return;
            }
            
            $("#"+p.panel.id +" .hd .infoBulle.face").toggleClass("back");
            $("#"+p.panel.id +" .hd .infoBulle.face").toggleClass("face");
            $("#"+p.panel.id +" .hd span.headerSpan").toggleClass("back");
            
            if(emEditor.onFlip != null){
                _windows.rotate.flip(emEditor.onFlip.em, true);
            }
            
            $(".headerSpan", p.panel.element).get()[0].textContent = "Enter Entity Model names :";
            $(".headerButton", p.panel.element).css("display", "none");
            $(".container-close", p.panel.element).css("display", "none");
            
            emEditor.onFlip = {em : emName, changeSize: true, h : container.offsetHeight, w : container.offsetWidth};
            
            if(container.offsetWidth < "220"){
                container.firstChild.style.width = "220px";
            }
            if(container.offsetHeight < "160"){
                container.firstChild.style.height = "160px";
            }
            
            $(container).rotate3Di('flip', 500, {direction: 'clockwise', sideChange: _windows.rotate.changeSide});
            
            setTimeout(function(){ //have to wait the end of the flip effect to set the focus
                $(".panel-back-container div.editable_input", container).get()[0].focus();
            }, 550);
                
        }       
        
    };
    
    _windows.rotate.changeSide = function(){
                
        var c = $(".panel-back-container", this);        
        if(c.get()[0].style.display === "none"){
            c.show();
        }else{
            c.hide();
        }
        _c.loadRelationCurve(  false, emEditor.panels[this.id.split("_")[0]] ); 
        
        setTimeout(function(){ //have to wait the end of the flip effect
            emEditor.previewObj.updatePreview();
        }, 550);
    };
  
    
})();