/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    _h.select = {
        /**
        * change the value of the comboBox
        * @param {string} newValue
        */
        comboBox:function(newValue, type, extra){

            var emName,
                methName,
                typeJq = $(type);
                            
            switch( true ) {
            case typeJq.hasClass("method"): 
                
                if(newValue == _conf.langage.en.noReturnType){
                    newValue = null;
                }

                if (emEditor.selectedItems.isInherited) {
                    methName = emEditor.onEditBox.item.id.split("-")[4];
                    _u.methodProperty(emEditor.selectedItems.emName, "returnType", newValue, null, methName, false, true);
                    _b.properties.methods(emEditor.selectedItems.emName, methName, false, false, true); 
                } else {
                    _u.methodProperty(emEditor.selectedItems.emName, "returnType", newValue, null, emEditor.onEditBox.item.id.split("-")[3], false);
                }
            
            break;
            case typeJq.hasClass("perm-group"): 
                _perms.set.right( newValue, type, extra);
                
            break;
            default:
            }
                
        },
        /**
        * change the value of the script for a given att
        * @param {event} ev 
        * @param {html object} elem select
        */
        scriptChange:function (sel) { 
            
            var emName  = emEditor.selectedItems.emName,
                attName = emEditor.uD.getWafData( emEditor.selectedItems.item ),
                tr      = $(emEditor.selectedItems.item),
                val     = sel.value; 
            
            switch (val) {
                case _conf.xmlData.db4d: 
                    _u.attributeProperty(emName, "kind", attName, "calculated");
                    _u.attributeProperty(emName, "scriptKind", attName, "db4d");
                    tr.addClass("calculated").removeClass("scal");
                    tr.find(".keyIcns").remove();
                    break;
                case _conf .xmlData.javascript: 
                    _u.attributeProperty(emName, "kind", attName, "calculated");
                    _u.attributeProperty(emName, "scriptKind", attName, val);
                    tr.addClass("calculated").removeClass("scal");
                    tr.find(".keyIcns").remove();
                    break;
                default: 
                    _u.attributeProperty(emName, "kind", attName, "storage");
                    _u.remove.scriptProperties(emName, attName);
                    tr.removeClass("calculated").addClass("scal");
                    if (_uA.isValueIn( _g.emAttPropertyValue(emName, attName, "type", false) , _conf.primKeyType)) {
                        tr.find(".type").prepend('<div class="keyIcns"></div>');
                    }
                    
            }

            _b.properties.attribute(emName, attName);
        },
        /**
        * change the value of the index for a given att
        * @param {event} ev 
        * @param {html object} elem select
        */
        changeIndexKind:function(e, sel){

            var td = emEditor.selectedItems.item.firstChild;
            var emName = emEditor.editorUI.panel.getPanelRefFromID(emEditor.editorUI.panel.getActiveID())["emName"];
                        
            if (sel.value == " " || sel.value == "" || sel.value == null || sel.value === "None") {
                if (YAHOO.util.Dom.hasClass(td, "indexed")) {
                    YAHOO.util.Dom.removeClass(td, "indexed");
                }
                
                if (emEditor.selectedItems.isInherited) { 
                    _u.inheritedAttributeProperty(emName, "indexKind", emEditor.selectedItems.item.id.split("-")[4]);
                } else {
                    _u.attributeProperty(emName, "indexKind", emEditor.selectedItems.item.id.split("-")[3]);
                }
                
            } else {
                if (!YAHOO.util.Dom.hasClass(td, "indexed")) {
                    YAHOO.util.Dom.addClass(td, "indexed");
                }
                
                if (emEditor.selectedItems.isInherited) { 
                    _u.inheritedAttributeProperty(emName, "indexKind", emEditor.selectedItems.item.id.split("-")[4], sel.value);
                } else {
                    _u.attributeProperty(emName, "indexKind", emEditor.selectedItems.item.id.split("-")[3], sel.value);
                }
            }
            
            if (emEditor.selectedItems.isInherited) {
                _b.properties.attribute(emName, emEditor.selectedItems.item.id.split("-")[4], false, true); 
            }
            
        },
        /**
        * change the value of the primary key for a given entity model
        * @param {event} ev 
        * @param {html object} elem select
        */
        changePrimKey:function(e, sel) { 

            var emName = emEditor.editorUI.panel.getPanelRefFromID(emEditor.editorUI.panel.getActiveID())["emName"],
                oldKey = _g.primKey(emName),
                val = sel.value;
            
            if(val != null && val != ""  && val != " " ) {
                _u.attributeProperty(emName, _conf.xmlData.primKey, val, "true");
                _u.attributeProperty(emName, _conf.xmlData.unique, val, "true");
                emEditor.errorManager.lookForErrorToRemove( emName, "key" );
            } else {
                emEditor.errorManager.addError({
                   "class"        : emName,
                   "message"      : "key"    
                },
                false);
            }   
            
            //update UI
            _vu.primKey(emName, val, oldKey);
            
        },
        /**
        * change the value of the defaultFormat for a given attribute
        * @param {event} ev 
        * @param {html object} elem select
        */
        defaultFormat:function(e, sel) { 
            //complete inner form
            _vu.innerForm(sel);

            if ($(sel).hasClass("typeEditBox")) {
                //save value
                if(sel.value == ""){  
                    _u.remove.typeProperty($(".bt-active").attr("bt-xtitle"), sel.title, true);
                }else{ 
                    _u.typeProperty($(".bt-active").attr("bt-xtitle"), sel.title, sel.value, true)    
                }
            } else {
                //save value
                
                if (sel.value == "") {  
                    _u.remove.attributeUnderProperty(emEditor.selectedItems.emName, emEditor.uD.getWafData( sel ), emEditor.uD.getWafData(emEditor.selectedItems.item), "defaultFormat", emEditor.selectedItems.isInherited)
                } else {
                    _u.attributeUnderProperty(emEditor.selectedItems.emName, emEditor.uD.getWafData( sel ), emEditor.uD.getWafData(emEditor.selectedItems.item), sel.value, "defaultFormat", emEditor.selectedItems.isInherited)
                }
                
                if (emEditor.selectedItems.isInherited) {
                    _b.properties.attribute(emEditor.selectedItems.emName, emEditor.selectedItems.item.id.split("-")[4], false, true); 
                }
            }
        }
         
    };
})();