/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

/**
* add a new yui panel to the workspace
*/
_windows.add = function(panelID, dock, prop, emName, addAttribute, withFocus, openSaved, isNew){

    var setP,
        extraP = _extra.panelExtraPro(emName),
        x, y, ty, autoc, sp, openPath, bd, ft, bdCont,
        savePos = true,
        ty = emEditor.onCreationPanel.type,
        close,
        id,              
        p = extraP,
        drag = true, 
        close = true, 
        panelJq,
        width = "200px",
        noEdit = false;

    var classInfo = _classes[ emEditor.emRef[emName] ];

    if (classInfo.noEdit || classInfo.noSave) {
        noEdit = true;
    }

    id = emEditor.panels.push( {panel:null, id:panelID, emName: emName, type:ty, visible:true} );     

    if( extraP === null || !extraP.position ) {
        setP = this.getPanelInitPos();
        /*setP.x -= emEditor.centerBody.body.scrollLeft;
        setP.y -= emEditor.centerBody.body.scrollTop;
        setP.x = setP.x + emEditor.centerBody.getAttributeConfig('left').value+5;*/
        savePos = true;
    }    

    if( p && p.panel ) {
        if( p.panel.position ) {
            savePos = false;
            x = parseInt(p.panel.position.X);
            y = parseInt(p.panel.position.Y);
            x -= emEditor.centerBody.body.scrollLeft;
            y -= emEditor.centerBody.body.scrollTop;
        } else {
            x = setP.x;
            y = setP.y;
        }
        //add the width of the left layout to x
        x = x + emEditor.centerBody.getAttributeConfig('left').value+5;
        if( p.panel.pathVisible ) {
            openPath = p.panel.pathVisible;
        }
        if( !p.isOpen ) {
            close = true;
        }
    } else {
        x = setP.x;
        y = setP.y;
    }  

    //build YUI panel
    emEditor.panels[id-1].panel = new YAHOO.widget.Panel(panelID, { 
        xy  :                   [ x,y ], 
        visible :               true, 
        draggable :             drag,
        close :                 close,
        constraintoviewport :   false,
        width :                 width
    });   
     
    //keep panel ref 
    emEditor.panelsRef[panelID] = (id-1);
    emEditor.panelsRef[emName] = (id-1);
    emEditor.panelsRef[ _classes[ emEditor.emRef[emName] ]["collectionName"] ]  = (id-1);

    //set content                                           
    emEditor.panels[id-1].panel.setHeader( emEditor.onCreationPanel.header );
    emEditor.panels[id-1].panel.setBody( emEditor.onCreationPanel.body );
    emEditor.panels[id-1].panel.setFooter( "" );
    
    //render
    emEditor.panels[id-1].panel.render( "center-body" ); //emEditor.loadFragment  center-body
    panelJq = $( "#"+panelID );
    
    //rotate events
    //_windows.rotate.init( emEditor.panels[id-1].panel ); 

    var b = emEditor.onCreationPanel.body;

    //add header event
    if (!noEdit) {

        panelJq.find(".headerSpan").dblclick( function() {
        /*if( !$(this).hasClass("back") ) {
            emEditor.editorUI.panel.minimize();
        }*/
        emEditor.studio.editMenu.controleMetaKey( false ); 
        $(this.parentNode.parentNode).append('<div contenteditable="true" class="editClassNameInPanel">'+this.textContent+'</div>');                  
        $(".editClassNameInPanel")
        .blur(function(){
            _o.updateEmFromPanel( panelID, this );
        });
        
        emEditor.editorUI.utilities.focusContentEditableBox($(".editClassNameInPanel").get()[0]);  
                           
        });

    } else {
        panelJq.find(".headerSpan").addClass("noEdit");
    }


    //event on panel
    YAHOO.util.Event.on(panelID, "click", function(e){ _h.selectPanel(this, false, true, e); });
   
    //add a type class          
    //YAHOO.util.Dom.addClass(panelID, emEditor.onCreationPanel.type);
    panelJq.addClass(emEditor.onCreationPanel.type);
    // Create Resize instance, binding it to the 'resizablepanel' DIV 
    this.resize(emEditor.panels[id-1].panel, p, emName);

    
    var closeButton = panelJq.find("a.container-close");
    closeButton.click(function(e) {
        _windows.remove(YAHOO.util.Dom.getAncestorByTagName(event.target, "div").id);    
    });    
    
    panelJq.find("div.hidePath").click(function(event) { 
        _h.hidePathCollumn(this);
    });
 
   
    //register to the overlay
    if( emEditor.overlayManager == null ) {
        emEditor.overlayManager = new YAHOO.widget.OverlayManager();
    }
    emEditor.overlayManager.register([emEditor.panels[id-1].panel]);


    //rewrite focus method to prevent from scrolling the desktop on focus
    emEditor.panels[id-1].panel.focus = function( arguments, callee, caller, length, name ) { 
      if( emEditor.overlayManager._manageFocus(this) ) {
          this.focusEvent.fire();
      }
    }

    if( isNew ) {
        this.manageContainerScroll(emEditor.panels[id-1].panel);
    }

    //set drag events methods
    _wDrag.on(emEditor.panels[id-1].panel);  
    _wDrag.end(emEditor.panels[id-1].panel);
    _wDrag.b4start(emEditor.panels[id-1].panel);                  

    var table = panelJq.find(".attributesTable").get()[0],
        oRows = table.getElementsByTagName('tr'),
        pan = panelJq.find(".bd").get()[0];

    //manage the path collumn visibility
    if( openPath == "true" ){ openPath = true; }
    if( openPath == true ) {

        _h.hidePathCollumn(YAHOO.util.Dom.getElementsByClassName("hidePath", "div", panelID)[0], null, null, true, true);

    } else {

        //manage panel width **** add a method to manage that **** 
        var cont = panelJq.find(".contentContainer").get()[0];
        var tab = cont.getElementsByTagName('table');
        var w=0;
        for(var a in tab){
            if(tab[a].nodeName == "TABLE") {
                if(w<tab[a].offsetWidth){
                    w = tab[a].offsetWidth;
                }
            }
        }
        if( w<_conf .htmlData.minAttTableWith ) {
            w = _conf.htmlData.minAttTableWith;
        }
        for(var b in tab){
            if(tab[b].nodeName == "TABLE"){
                tab[b].style.width=w+_conf.htmlData.ajustWidth+"px";
            }
        }

        panelJq.css('width', w); 
        
    }   

    if(withFocus != false && withFocus != "false"){ 
        setTimeout(function() { 
            _h.selectPanel(emEditor.panels[id-1].panel, false, false);
        },0);
    }
    
    if(isNew) {
        setTimeout(function() { 
            _h.selectPanel(emEditor.panels[id-1].panel, false, false);
        },0);
    }

    //just remove focus on the close button
    closeButton.blur();

    //save the position of the panel
    if (savePos) { 
        emEditor.editorUI.panel.keepPos(x, y, emName, panelID); 
    };

    //add a new attribute if the ENTER key has been pressed
    if(addAttribute){
        if(emEditor.enterKey){
            views.add.entity.attribute(table); //add a new line if no att
        }
    }

   /* if(!openSaved && emEditor.curve && emEditor.relationCurve){ 
       _c.loadRelationCurve( ); //false, emEditor.panels[id]
    }*/

    if(savePos || openSaved){

        var cont = $("#center-body").get()[0].parentNode;
            cont.scrollLeft = 0;
            cont.scrollTop = 0;
        }
        
        if ( extraP != null && extraP.panelColor ) {
            panelJq.find('.hd' ).css( "background-color", extraP.panelColor ); 
        } else {
            var color = emEditor.editorUI.utilities.getRandomColor();
            _u.extraProperties.definePanelColor(emName, "#"+color);
            panelJq.find('.hd' ).css( "background-color", "#"+color ); 
        }    

    if (extraP != null && extraP.isMinimized == "true") { 
        ft = pan.nextSibling;
        bdCont = pan.parentNode;
        pan.style.display="none";
        ft.style.display="none";
        bdCont.style.height="auto";
    }    

    if (!openSaved) { 
        window.setTimeout( function(){ emEditor.previewObj.updatePreview(); }, 0)
    }else{
        panelJq.parent().css("display", "none");
    }
    
    if( isNew ) {
        
        emEditor.studio.editMenu.controleMetaKey( true );        
        $(".editClassNameInPanel")
        .blur(function(){
            _o.updateEmFromPanel( panelID, this );
        }); 
        
        emEditor.editorUI.utilities.focusContentEditableBox($(".editClassNameInPanel").get()[0]);
        
    }
    
    //make table rows sortable
    if (!noEdit) {
        _windows.makeTableRowDraggable( $("#"+panelID+" tbody") );    
    } else {
       // panelJq.find(".headerButton.hidePath").css("margin-right", "30px");
        panelJq.find(".editable_input").css("-webkit-user-modify", "read-only");
       // panelJq.find(".headerButton.minimizeBut").remove();
        panelJq.find(".addElem.studio-icon-add").remove();
        
    }
};


})();