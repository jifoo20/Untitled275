/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
        emEditor.editorUI.views.add = {};

        emEditor.editorUI.views.add.pathFieldForMany = function(cell){
            var manyPath = _b.editableBox(_conf .xmlData.relationPath, "", true, "pathMany");
            cell.appendChild(manyPath);
            var el = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable+"2", "div", cell)[1];
            emEditor.editorUI.views.listenner.listenners(el);
            return el;
        };
        
        emEditor.editorUI.views.add.type = function(table){               
            var trs = table.getElementsByTagName("tr"), newName;
            
            //get for new Name
            newName = emEditor.editorUI.views.add.entity.getNewName("type");
            newRow = table.insertRow(-1);
            newRow.title = newName;
            newRow.id = emEditor.ids++;
            newCell1 = newRow.insertCell(-1);
            newCell1.className="nameCell";
            //newCell1.innerHTML = "<div class='rmEMButton'></div>";
            //newCell1.appendChild(views.build.editableBox("name", _conf .langage.en.newTypeText));
            newCell1.title = newName;
            newCell1.innerHTML = "<div class='rmEMButton'></div><div class='typeMenuList'>"+newName+"</div>";
            newCell = newRow.insertCell(-1);
            newCell.innerHTML = "string";
            newCell.className="extendCell";
            
            YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("rmEMButton", "div", newCell1)[0], "click", function (e) { 
                e.stopPropagation(); e.preventDefault();
                var tr = YAHOO.util.Dom.getAncestorByTagName(this, "tr");
                _oR.type(YAHOO.util.Dom.getAncestorByTagName(this, "table"), tr.rowIndex, tr);
            });
            
            //add event for popup
            _b.setPopupForType(newRow);
            
            //save type 
            _o.saveNewType(newName, "string");
            
            //add focus to popup
            var is = newRow.id;  
            setTimeout(function() { /* keep this timeout */
                $("#"+is).btOn(); 
                $("#typePropertyPopupContainer .typeEditBox")[0].focus();
            },0);
            
        };
        
        emEditor.editorUI.views.add.scriptProperties = function(emName){ // use it !!!!! ?????
            
                var propPan = document.getElementById(_conf .htmlData.propertiesContainerID);
                var tb = YAHOO.util.Dom.getElementsByClassName("attributesTable", "table", propPan)[0];
                for(var i = tb.rows.length; i > 1;i--)
                {
                    tb.deleteRow(i -1);
                }
                var newRow, newCell, propVal, prop, propType, el, edit;
                var list = ["onGet", "onSet", "onQuery"];
                
                for(var key in list){

                    newRow = tb.insertRow(-1);
                    newCell = newRow.insertCell(-1);
                    newCell.innerHTML = list[key];
                    newCell = newRow.insertCell(-1);
                    newCell.innerHTML="edit";
                    YAHOO.util.Event.on(newCell, "click", function(e){ console.log("edit script");});
                                
                }
        };
        
        emEditor.editorUI.views.add.enableValueBox = function(elem){
            var key = elem.firstChild.nodeValue;
            var nextTD = YAHOO.util.Dom.getAncestorByTagName(elem, "td").nextSibling;
            nextTD.innerHTML = 
            '<div class="editable_base editable_input_area">'+
            '<div class="editable_shawdow" wef-data="'+key+'">'+
            "<div contentEditable='true' class='"+_conf .htmlData.contentEditable+"'>...</div>"+
            '</div>'+
            '</div>';
            var el = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", nextTD)[0];
            emEditor.editorUI.views.listenner.listenners(el);
            var tb = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
            var cont = YAHOO.util.Dom.getAncestorByTagName(tb, "div");
            var container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"); 
            emEditor.editorUI.panel.manageResizeWidth(container, false);
            el.focus();
        };
        
        emEditor.editorUI.views.add.attPropRow = function(tr, emName, attName){ //use it ?
            //add new row
            var table = YAHOO.util.Dom.getAncestorByTagName(tr, "table");
            var newRow = table.insertRow(tr.rowIndex+1);
            YAHOO.util.Dom.addClass(newRow, _conf .htmlData.classEm+"-"+emName+"-"+_conf .htmlData. classAttribute+"-"+attName);
            YAHOO.util.Dom.addClass(newRow, "innerRow");
            YAHOO.util.Dom.addClass(newRow, "displayed");
            var newCell = newRow.insertCell(-1);
            newCell = newRow.insertCell(-1);
            newCell = newRow.insertCell(-1);
            newCell1 = newRow.insertCell(-1);
            newCell1.className = "keys";
            newCell1.innerHTML=
            '<div class="editable_base editable_input_area">'+
            '<div class="editable_shawdow" data-info="newEmAttProperty">'+
            "<div contentEditable='true' class='"+_conf .htmlData.contentEditable+"'>...</div>"+
            '</div>'+
            '</div>';
            newCell = newRow.insertCell(-1);
            newCell.className = "values";
            '<div class="editable_base editable_input_area">'+
            '<div class="editable_shawdow">'+
            "<div title=''></div>"+
            '</div>'+
            '</div>';
            //add listenners
            var elem = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", newCell1)[0];         
            emEditor.editorUI.views.listenner.listenners(elem);
            elem.focus();
            
            var rowNum = table.getElementsByTagName('TR').length;
            var vertCell = YAHOO.util.Dom.getElementsByClassName("contentVerticalTitle", "TD", table)[0];
            vertCell.rowSpan = rowNum;
            
            return newRow;              
        };
        
        emEditor.editorUI.views.add.addExpandRowArrow = function(tr, emName, attName, open, valueToAdd){  // valueToAdd !!!!
            var td = tr.getElementsByTagName("td")[3];
            td.innerHTML="<div class='hideShowInnerCol'></div><div class='numberOfInnerRow'></div>";
            //add new row
            var table = YAHOO.util.Dom.getAncestorByTagName(tr, "table");
            var newRow = table.insertRow(tr.rowIndex+1);
            YAHOO.util.Dom.addClass(newRow, _conf .htmlData.classEm+"-"+emName+"-"+_conf .htmlData. classAttribute+"-"+attName);
            YAHOO.util.Dom.addClass(newRow, "innerRow");
            var newCell = newRow.insertCell(-1);
            newCell = newRow.insertCell(-1);
            newCell = newRow.insertCell(-1);
            newCell1 = newRow.insertCell(-1);
            newCell1.className = "keys";
            newCell1.innerHTML=
            '<div class="editable_base editable_input_area">'+
            '<div class="editable_shawdow">'+
            "<div title='newEmAttProperty' contentEditable='true' class='"+_conf .htmlData.contentEditable+"'>...</div>"+
            '</div>'+
            '</div>';
            newCell = newRow.insertCell(-1);
            newCell.className = "values";
            '<div class="editable_base editable_input_area">'+
            '<div class="editable_shawdow">'+
            "<div title=''></div>"+ //_conf .htmlData.contentEditable='true' class='"+_conf .htmlData.contentEditable+"'
            '</div>'+
            '</div>';
            YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("hideShowInnerCol", "div", hideShowCol), "click", function(){
                emEditor.editorUI.panel.hideShowInnerRow(this);
            });
            //add listenners
            var elem = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", newCell1)[0];
            emEditor.editorUI.views.listenner.listenners(elem);           
            //auto expand if needed
            if(open){
                setTimeout(function() { emEditor.editorUI.panel.hideShowInnerRow(YAHOO.util.Dom.getElementsByClassName("hideShowInnerCol", "div", td)[0]); },0);
                setTimeout(function() { elem.focus(); },0); 
            }
            return newRow;
        };
  
        emEditor.editorUI.views.add.typeUnkMessage = function(line, editType){
           if(!emEditor.typeUnkMessage){
               var cont =   "<div class='typeUnkMessage'>"+
                               //"<p>The type you just entered is unknown. By default, a new Entity Model will be created. What do you want to do ? </p>"+
                               "<p>The type you just entered is unknown. A new Entity Model will be created. </p>"+
                               "<ul>"+
                               // "<li class='createEm itemSelected'>Create a new Entity Model</li>"+
                                 "<li class='createEm itemSelected'>Create the new Entity Model now</li>";
                                //"<li class='createType selectedLi'>Create a new custom type</li>";

                   if(editType){
                       cont = cont + "<li class='editType'>Edit the type</li>";
                   }

                   cont = cont + //"<li class='doNothing'>Do nothing</li>"+
                   "</ul>"+    
                   "</div>";    

                  $(line).bt( cont, {
                         offsetParent:$('body'),
                         trigger: "[on, off]", 
                         killTitle: false,
                         closeWhenOthersOpen: true,
                         fill: 'rgba(0,0,0,0.4)',
                         strokeWidth: 0, 
                         spikeLength: 10,
                         spikeGirth: 10,
                         padding: 1,
                         cornerRadius: 2,
                         cssStyles: {
                           fontFamily: '"lucida grande",tahoma,verdana,arial,sans-serif', 
                           fontSize: '12px',
                           color:'#fff',
                           padding:"10px"
                         },
                         positions: ['right', 'bottom'],
                         shadow: true,
                         shadowOffsetX: 2,
                         shadowOffsetY: 2,
                         shadowBlur: 5,
                         shadowColor: 'rgba(0,0,0,.9)',
                         shadowOverlap: false,
                         width:250,
                         overlap: 30, 
                           showTip: function(box){
                               emEditor.typeUnkMessage = true;
                               $(box).fadeIn(500);
                             },
                             hideTip: function(box){
                               emEditor.typeUnkMessage = false;
                               $(box).animate({opacity: 0}, 500, function(){$(box).remove();});
                             }
                      });

                      setTimeout(function() { /* keep this timeout */
                          $(line).btOn();
                      },100);
           }
                      
        };
})();