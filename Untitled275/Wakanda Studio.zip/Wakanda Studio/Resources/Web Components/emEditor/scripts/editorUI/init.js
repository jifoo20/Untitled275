/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    emEditor.editorUI.initUI = function() {

        //emEditor.loadFragment = document.createDocumentFragment();        
        
        var rl,
            md,
            emAdded;
            
        emEditor.errorManager       = new emEditor.ErrorManager();
        emEditor.centerBodyRef      = $( "#center-body" );
        emEditor.methodApplyToMenu  = $( "#methodApplyToChoice" );
        
        emEditor.centerBodyRef.handMove();
        
        if( emEditor.catalog.dbInfo ) {
            emEditor.modelName = emEditor.catalog.dbInfo[0].name;
        }
        
        rl                  = _extra.relationCurve();
        md                  = _extra.methodsDisplay();
        emEditor.scriptMode = _extra.scriptMode();

        emEditor.editorUI.initDomObjects();
    
        if (emEditor.catalog.dbInfo) {
            $(".modelName").get()[0].innerHTML = emEditor.catalog.dbInfo[0].name;
        }
    
        if( md != null ) {
            ( md == "false" ) ? emEditor.displayMethodInPanel = false : emEditor.displayMethodInPanel = true;
        }
    
        if( rl ) {
            emEditor.relationCurve = rl.run;
            emEditor.relationCurveMode = parseInt(rl.mode);
        }else{
            emEditor.relationCurve = true;
            emEditor.relationCurveMode = 2;
        }
    
        //init right layout tabs
        //emEditor.rightMenuTabs = new YAHOO.widget.TabView("rightMenuTabs");

        //update markups        
        emAdded = emEditor.editorUI.dock.buildDockBlock(_conf .htmlData.classEm);

        //build layouts
        _b.layout();

        emEditor.autoSizeBox = document.getElementById("autoSizeBox");

        // Store references to center layout
        emEditor.centerBody = YAHOO.widget.LayoutUnit.getLayoutUnitById( 'center-body' );
        
        //avoid natif yui autoscroll
        YAHOO.util.DD.prototype.alignElWithMouse = function( el, iPageX, iPageY ) {
            return true;
        }

        //keep references for properties panels
        emEditor.modelPropertiesTable   =   $(".modelTable").get()[0];
        emEditor.emPropertiesTable      =   $(".propertiesTable").get()[0]; //YAHOO.util.Dom.getElementsByClassName( "propertiesTable", "table", _conf.htmlData.propertiesContainerID )[0];
        emEditor.attPropertiesTable     =   $(".attributeTable").get()[0]; //YAHOO.util.Dom.getElementsByClassName( "attributesTable", "table", _conf.htmlData.propertiesContainerID )[0];
        emEditor.emEventTable           =   document.getElementById( _conf.htmlData.emEventsPanels );
        emEditor.attEventTable          =   document.getElementById( _conf.htmlData.attEventsPanels );

        //add document delegates
        $(window).resize(function() {
            var can = $(".bt-active");
            if(can){
                can.refreshCanvas();
            }
        });
        
        //load the relation curve for this em
        if(emEditor.relationCurve === "true") {
            emEditor.relationCurve = true;
        }
        if(emEditor.relationCurve === "false") {
            emEditor.relationCurve = false;
        }
    
        //init delegates
        YAHOO.util.Event.on( document, "keydown", function(e) { _h.key.delegate(e); } );
        YAHOO.util.Event.on( document, "mousedown", function(e) { _h.click.delegate(e); } );
        YAHOO.util.Event.on( document, "mouseup", function(e) { _h.click.delegate(e); } );
        emEditor.editorUI.views.delegate.click();
        emEditor.editorUI.views.delegate.dblclick();
        emEditor.editorUI.views.delegate.focus();
        emEditor.editorUI.views.delegate.keydown();
        emEditor.editorUI.views.delegate.mouseEnter();
        emEditor.editorUI.views.delegate.change(); 
        //emEditor.editorUI.views.delegate.mouseDown();
        emEditor.editorUI.views.delegate.blur();  

        //miniPreview
        emEditor.previewObj = $("#minPreviewContainer").miniPreview( { workspace:"center-body "} );

        //get properties Type Popup
        emEditor.propertiesTypePopupTable = $( "#typePropertiesTable" ).get()[0];

        //get the methods container
        emEditor.methodContainer = $( "#methodsPanels" ).get()[0];

        //set the space to drow svg curve
        if( emEditor.curve ) { 
            emEditor.editorUI.svgDrowSpace  =  Raphael( _conf .htmlData.mainOverlayContainer );  // new ScaleRaphael(_conf .htmlData.mainOverlayContainer, 5000, 5000);            
            emEditor.svgBalise = $( "#"+_conf .htmlData.mainOverlayContainer+" svg" ).get()[0];
            emEditor.svgBalise.setAttribute( "width", "100%" );
            emEditor.svgBalise.setAttribute( "height", "100%" );

            emEditor.editorUI.svgDrowSpaceMP  = Raphael( minPreviewContainer );
            $( "#minPreviewContainer svg" ).get()[0].style.height = "100%";
            $( "#minPreviewContainer svg" ).get()[0].style.width = "100%";
        }
        
        //init events for properties panel
        _o.initPropertiesEvents();
        //_o.layout.collapseRight();
        emEditor.emPropertiesTable.style.display    = "none";
        emEditor.attPropertiesTable.style.display   = "none";

        if( emEditor.catalog.dataClasses.length === 0 ) {
            $("img.loader").hide(); 
            $(".yui-panel-container").css("display", "block");
            $('body').removeClass('waf-loading');
            emEditor.editorUI.handlers.click.addNewEm();
        } else {
            setTimeout(function(){ emEditor.editorUI.initUI.buildPanels(); }, 0);
        }
        
        emEditor.studio.editMenu.controleMetaKey( false );
        
    };
    
    emEditor.editorUI.initUI.buildPanels = function(){
                
        //add panels already openned
        var op = _g.panelsToOpen(),
            foc = false, 
            pRef, 
            self, 
            doBuild;

        //add a queue manager to handle live loading
        $.each(op, function(index, value) {
            
            self = this;
            emEditor.editorUI.panel.addFocusOrOpen(null, this.emName, null, false, false, true);
            //$.queued.add(doBuild, this);
        });
        if(emEditor.curve && emEditor.relationCurve && emEditor.relationCurveMode == 2){ 
           //_c.loadRelationCurve( ); //false, emEditor.panels[id]
        }
        $("img.loader").hide(); 
        $(".yui-panel-container").css("display", "block");
        $('body').removeClass('waf-loading');
        //emEditor.previewObj.updatePreview();
                
        $.queued.add(function(){ emEditor.previewObj.updatePreview(); });
        $.queued.add(function(){ 
            if(emEditor.curve && emEditor.relationCurve && emEditor.relationCurveMode == 1){ 
               emEditor.editorUI.curve.loadRelationCurve( ); //false, emEditor.panels[id]
            }
        });
        
        $.queued.add(function(){ 
            _h.selectModel(); 
            emEditor.errorManager.displayErrorState(); // !!
            $.queued.clear(); 
        });
        
        
        /*$.queued.add(function(){ 
            $("img.loader").remove(); 
            $.queued.clear(); 
            $(".yui-panel-container").css("display", "block");
            $('body').removeClass('waf-loading');
            emEditor.previewObj.updatePreview();
            console.timeEnd('timerName');
            }
        );*/
        
       // emEditor.editorUI.test();
     //$("#center-body").append(emEditor.loadFragment);
    }
    
    /*emEditor.editorUI.test = function(){
        console.time("testPerf");
        	var g = 0;
        	while (g != 1000000000) {
        		g++;
        	}
        	console.timeEnd("testPerf");        	
    }*/
    
    
})();

