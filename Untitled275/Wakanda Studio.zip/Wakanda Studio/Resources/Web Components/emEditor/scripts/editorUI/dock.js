/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
        /**
        * all about dock management and creation (DOCK now = the em menu in the left panel)
        */
        emEditor.editorUI.dock = {
           /**
            * add a dock block
            * @param {string} add type of elem to add (em, rel…)
            */
            buildDockBlock : function(add, refresh){
            
                    var cat = emEditor.catalog;
                    var l, key, newRow, newCell, newSpan, tb, target, extraP, col, oldCat = false, inner = "", bgColor;
                    
                    switch (add){
                        case _conf.htmlData.classEm : 
                            l = _classes; 
                            target = _conf.htmlData.dockEmID; 
                            break;
                        case _conf.htmlData.classRelation : 
                            l = cat.relationship; 
                            target = _conf.htmlData.dockRelationsID; 
                            break;
                        case _conf.htmlData.classType : 
                            l = cat.type; 
                            target = _conf.htmlData.typesTable; 
                            break;
                        default: console.log("error emEditor.editorUI / buildDockBlock()"); break;
                    }
                
                    tb = document.getElementById(target);
                
                    if( refresh ){ tb.innerHTML = ""; }
                
                    if( target == _conf .htmlData.typesTable ) { 
                        _b.types(tb);
                    }
                    
                    if(target == _conf.htmlData.dockEmID){
                        
                        inner = inner + "<tbody>";
                        
                        for( key in l ) {
                            
                            if( emEditor.emindex ) {
                                //build em panel index table (done here because of perf purpose, since here we "loop" through the em object on each load)
                                emEditor.emRef[l[key]["className"]] = key;
                                emEditor.emRef[l[key]["collectionName"]] = key;
                            }
                            
                            i = emEditor.ids++;
                            extraP = _extra.panelExtraPro(l[key]["className"]);

                            if (!extraP) {
                                bgColor = "#eee";
                            } else {
                                bgColor =  extraP.panelColor;
                            }
                            
                            inner = inner + 
                                    "<tr id='outline_"+ l[key]["className"] +"' class='"+ add +"' data-title='"+ l[key]["className"] +"'>"+
                                    "<td>"+
                                    "<div class='rmEMButton studio-icon-remove'></div>"+
                                    "<div class='emMenuList'>"+
                                    "<div class='colPrev' style='background-color:"+bgColor+";'></div>"+
                                    "<div class='emName'>"+l[key]["className"]+"</div>"+
                                    "</div></td></tr>";
                          
                        }
                        
                        inner = inner + "</tbody>";
                        
                        tb.innerHTML = inner;
                        
                        $(tb).find(".rmEMButton").click( function (e) { _oR.entityModel(e, this);} );
                        
                        $(tb).find("tr")
                        .click( function(event){ emEditor.editorUI.panel.addFocusOrOpen(this);} )
                        .contextMenu({
                             menu: 'panelContMenu'
                         },
                             function(action, el, pos) { 
                                 _h.contextual.dock(action, el);
                         });
                
                    }
                    if(l){
                        if(l.length == 0){
                            return false;
                        }else{
                            return true;
                        }
                    }
                
            },
            /**
            * look if the element is related to a entity, a relation, or other objects... look at the classname
            * @param {object} elem 
            */
            lookForElementType : function(elem){
                    var type;
                    if(YAHOO.util.Dom.hasClass(elem, _conf .htmlData.classRelation)){type = _conf .htmlData.classRelation;};
                    if(YAHOO.util.Dom.hasClass(elem, _conf .htmlData.classEm)){type = _conf .htmlData.classEm;};
                    if(YAHOO.util.Dom.hasClass(elem, _conf .htmlData.classType)){type = _conf .htmlData.classType;};
                    return type;
            },
            /**
            * build the ID of the panel from tr object of the dock
            * @param {object} elem tr
            * @return {string}
            */
            buildPanelId: function(elem){
                var objectType = this.lookForElementType(elem); 
                var objectName = elem.title;
                return objectName + "-" + objectType;
            }
        }

})();