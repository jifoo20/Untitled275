/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
if(!emEditor){
	var emEditor = {};
	if(!emEditor.editorUI){
		emEditor.editorUI = {};
	}
}

/**
* manage the UI objects
*/
emEditor.editorUI.objects = {
   
    /**
    * just add events to proper markup elements in the properties panels
    */
    initPropertiesEvents:function(){
        var tp = YAHOO.util.Dom.getElementsByClassName("propertiesTable", "table", _conf.htmlData.propertiesContainerID)[0];
        var ta = YAHOO.util.Dom.getElementsByClassName("attributeTable", "table", _conf.htmlData.propertiesContainerID)[0];
        YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("dockCloseIcns", "div", tp)[0], "click", 
        function(event){emEditor.editorUI.panel.collapseExpandBlock(this);});
        YAHOO.util.Event.addListener(YAHOO.util.Dom.getElementsByClassName("dockCloseIcns", "div", ta)[0], "click", 
        function(event){emEditor.editorUI.panel.collapseExpandBlock(this);});
    },
    cleanTableRows:function(tb){
        if (tb) {
            for(var i = tb.rows.length; i > 0;i--) {
                tb.deleteRow(i -1);
            }
        }
    },
    createNewMethod:function(emName, methName, applyTo){

        var nameSpace;

        _u.methodProperty(emName, "name", methName, null, methName);
        _u.methodProperty(emName, "from", emName +"."+ methName, null, methName);
        _u.methodProperty(emName, "applyTo", applyTo, null, methName);
        _u.methodProperty(emName, "scope", "publicOnServer", null, methName);
        
        switch(applyTo) {
        case "entityCollection":    nameSpace = "collectionMethods"; break;
        case "entity":              nameSpace = "entityMethods"; break;
        case "dataClass":           nameSpace = "methods"; break;
        default:
        }
        
        _o.editScript("guidedModel."+ emName +"."+nameSpace+"."+methName, true);
    },
    /**
    * toggle removed on an extended attribute
    * @param {html object} elem clicked element (tr)
    * @param {event} e click event 
    */
    removedAttribute:function( elem, e) { 
        var emName = emEditor.editorUI.panel.getActiveElemName(),
            attName = emEditor.uD.getWafData( elem ),
            elemJq = $(elem);
                
        if (elemJq.hasClass("removed")) {
            
            elemJq.removeClass("removed");
            elemJq.find(".removed").removeClass("removed");
            _u.manageRemoved(attName, emName, false);   
        
        } else {
        
            elemJq.addClass("removed").addClass("removedHidden");
            _u.manageRemoved(attName, emName, true);

            if (!_g.isRemovedVisible(emName)) {
                elemJq.addClass("removedHidden");
            }
            
        }
    },
    /**
    * toggle removed on an extended attribute
    * @param {html object} elem clicked element (tr)
    * @param {event} e click event 
    */
    manageInheritedFromSelection:function() {  
        
        var elem = emEditor.selectedItems.item,
            emName  = emEditor.selectedItems.emName,
            attName = emEditor.uD.getWafData( elem ),
            elemJq  = $(elem);

        if (elemJq.hasClass("removed")) {

            elemJq.removeClass("removed");
            elemJq.find(".removed").removeClass("removed");
            _u.manageRemoved(attName, emName, false);   

        } else {

            elemJq.addClass("removed");
            _u.manageRemoved(attName, emName, true);

            if (!_g.isRemovedVisible(emName)) {
                elemJq.addClass("removedHidden");
            }

        }
    },
    /**
    * hide or show the removed attributes
    * @param {string} panelID
    * @param {bool} updateData if we update the data and the UI or only the UI
    */
    showRemoded:function(panelID, noUpdateData, openSaved, e){
        
        var emName, 
            res,
            emName,
            pRef,
            panelID,
            table,
            trs,
            ti; 
            
        if( !panelID ) { 
            emName = emEditor.editorUI.panel.getActiveElemName();
            pRef = emEditor.editorUI.panel.getPanelRef(emName);
            panelID = pRef.id;
        }else{
            emName = emEditor.editorUI.panel.getPanelRefFromID(panelID).emName;
        }
                
        table = YAHOO.util.Dom.getElementsByClassName("attributesTable", "table", panelID)[0];
        trs = YAHOO.util.Dom.getElementsByClassName("inherited", "tr", table);
        
        for( var key in trs ) {
            ti = trs[key].id.split("-")[1];
                if(YAHOO.util.Dom.hasClass(trs[key], "removed")){
                    if(YAHOO.util.Dom.hasClass(trs[key], "removedHidden")){
                        YAHOO.util.Dom.removeClass(trs[key], "removedHidden");
                        if(!noUpdateData){ 
                            _u.extraProperties.keepRemovedState(emName, true);
                        }
                    }else{
                        YAHOO.util.Dom.addClass(trs[key], "removedHidden");
                        if(!noUpdateData){
                            if(!openSaved){ 
                                _u.extraProperties.keepRemovedState(emName, false);
                            }
                        }
                    }
                }   
        }       
        
        if( e ) {
             if( $(e.target).hasClass("hide") ) { 
                    //$("#"+panelID+" ."+k).addClass("removedHidden");
                    res = "false";
                    $(e.target).removeClass("hide");
                    $(e.target).addClass("see");
               }else{
                    //$("#"+panelID+" ."+k).removeClass("removedHidden");
                    $(e.target).addClass("hide");
                    $(e.target).removeClass("see");
               }
               
               if( !res || res == "false" ) {
                    $(e.target).find("span").get()[0].innerHTML = "Show";
               }else{
                    $(e.target).find("span").get()[0].innerHTML = "Hide";
               }
        }
    },
    expendColapsInh:function(e, elem){
        var table = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
        var em = emEditor.uD.getWafData(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"));
        var trs = YAHOO.util.Dom.getElementsByClassName("inherited", "tr", table);
        var ti, tab3;
        for(var key in trs){
            ti = trs[key].id.split("-")[1];
            if(ti == em){
                if(YAHOO.util.Dom.hasClass(trs[key], "tableHidden")){
                    YAHOO.util.Dom.removeClass(trs[key], "tableHidden");
                    YAHOO.util.Dom.replaceClass(elem, "blockClose", "blockOpen");                   
                }else{
                    YAHOO.util.Dom.addClass(trs[key], "tableHidden");
                    YAHOO.util.Dom.replaceClass(elem, "blockOpen", "blockClose");
                }   
            }   
        }       
    },
    addInputPropertiesFocus:function(){
        var table = YAHOO.util.Dom.getElementsByClassName("attributeTable", "table", _conf .htmlData.propertiesContainerID)[0];
        var el = table.childNodes[3].firstChild.lastChild.firstChild;
        switch (el.nodeName){
        case "SELECT": 
        case "INPUT": el.focus(); break;
        default: YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", el)[0].focus();
        }
    },
    selectRow:function(elem, e, fromTabEvent){ 

        if (!emEditor.allowInheritedSelection && $(elem).hasClass("methodInherited")) {
            return;
        }
        
        /* exp sel */
        if(event && event.metaKey){
            return;
        }
        
        if (emEditor.onEditBox && emEditor.onEditBox.ref) {
            emEditor.onEditBox.ref.blur();
        }

        var elemSel         = $(elem),
            notSaved        = $("tr.notSaved"),
            firt            = notSaved.get()[0],
            isSel           = elemSel.hasClass("selected"),
            tab1            = emEditor.leftTabview.getTab(0),
            tab2            = emEditor.leftTabview.getTab(1),
            tab3            = emEditor.leftTabview.getTab(2),
            elemToFocus, 
            cont,
            tb, 
            cl,
            isInh = false,
            classIsInherited;

        if (elemSel.hasClass("inherited") || elemSel.hasClass("methodInherited")) {
            isInh = true;
        }    
        
        tab1.set('disabled', false);
        
        if (emEditor.allowInheritedSelection) {
            if (isInh) {
                classIsInherited = true;
            }
            isInh = false;
        }
        
        if (firt) { 
            
            if (elem.id != firt.id) {
                $(notSaved).btOff();
                if( emEditor.onEditBox.ref ) {
                    emEditor.onEditBox.ref.blur();
                }
            } else {
                elemToFocus = $("#"+elem.id+" .editable_input2");
                if (event) {
                    event.stopPropagation();
                }
                if (elemToFocus) {
                    elemToFocus.get()[1].focus(); 
                    return;
                }
            }
        } 

        if (isInh) {
            emEditor.editorUI.objects.removedAttribute(elem, e);
        }
          
        if (!isSel && !isInh) { 

            tb = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
            cl = tb.className;
  
            if( e ) { e.stopPropagation(); e.preventDefault(); }

            if( !isSel ) {
                if( emEditor.selectedItems.item != null ) {
                    YAHOO.util.Dom.removeClass(emEditor.selectedItems.item, "selected");
                }
                emEditor.selectedItems.item = elem;
                elemSel.addClass("selected");
                cont = elem.id.split("-");
                
                if (classIsInherited) {
                    emEditor.selectedItems.isInherited = true;
                } else {
                    emEditor.selectedItems.isInherited = false;
                }
                   
                var emName = emEditor.editorUI.panel.getActiveElemName();
                    
                switch(cl){
                case "attributesTable" : 
                    
                     if( emEditor.leftTabview.get('activeIndex') == 2 ) {
                           emEditor.leftTabview.set('activeIndex', 0);  
                     }

                    emEditor.selectedItems.itemType = "attribute";
                    emEditor.selectedItems.itemName = cont[3];
                    
                     //desable methos tab
                     tab3.set('disabled', true);
                     //desable methos tab
                     tab2.set('disabled', false);
                     
                    if(!elemSel.hasClass("notSaved")){ 

                        

                        if( emEditor.selectedItems.emName == null || emEditor.selectedItems.emName != emName ) {
                           _h.selectPanel(YAHOO.util.Dom.getAncestorByTagName(emEditor.selectedItems.item, "div").parentNode.parentNode.parentNode, true, null, e);
                           
                        }
                  
                        if (classIsInherited && $(elem).hasClass("inherited")) {
                            _b.properties.attribute(cont[2], cont[4], fromTabEvent, true); 
                            //_b.events.attribute(cont[2], cont[4], fromTabEvent, , isInherited);
                            emEditor.leftTabview.set('activeIndex', 0);
                            tab2.set('disabled', true);
                        } else {
                            _b.properties.attribute(cont[1], cont[3], fromTabEvent); 
                            _b.events.attribute(cont[1], cont[3], fromTabEvent);
                        }
                        
                    }else{ 
                    
                        if( emEditor.selectedItems.item != null ) {
                            YAHOO.util.Dom.removeClass(emEditor.selectedItems.item, "selected");
                            emEditor.selectedItems.item = null;
                        }
                        
                    }
                    
                    if (emEditor.handlePerms) {
                        _perm.hide();
                         
                    }               
                       
                    break;
                case "methodsTable" :
                                          
                        if (emEditor.leftTabview.get('activeIndex') === 1 || emEditor.leftTabview.get('activeIndex') === 2) {
                              emEditor.leftTabview.set('activeIndex', 0);  
                        }

                        emEditor.selectedItems.itemType = "method";
                                                        
                        if (elemSel.hasClass("methodInherited")) {
                            emEditor.selectedItems.itemName = cont[4];
                        } else {
                            emEditor.selectedItems.itemName = cont[3];
                        }

                        if( emEditor.selectedItems.emName == null || emEditor.selectedItems.emName != emName ) {
                            console.log(YAHOO.util.Dom.getAncestorByTagName(emEditor.selectedItems.item, "div").parentNode.parentNode.parentNode)
                           _h.selectPanel(YAHOO.util.Dom.getAncestorByTagName(emEditor.selectedItems.item, "div").parentNode.parentNode.parentNode, true, null, e);
                        }

                        //clean content
                        emEditor.emPropertiesTable.style.display    = "none";
                        emEditor.attPropertiesTable.style.display   = "none";
                        emEditor.attEventTable.style.display        = "none";
                        emEditor.emEventTable.style.display         = "none";
                        $("#currentModelProperties").hide();
                        
                        //manage tab views
                        tab2.set('disabled', true);  
                        tab3.set('disabled', true);  

                        if (_g.methodeProperty(cont[1], cont[3], "userDefined")) {
                            //clean content
                            emEditor.emPropertiesTable.style.display = "none";
                            emEditor.attEventTable.style.display = "none";
                            emEditor.emEventTable.style.display = "none";
                            if (elemSel.hasClass("methodInherited")) {
                                _b.properties.methods(cont[2], cont[4], fromTabEvent, true, true); 
                            } else {
                                _b.properties.methods(cont[1], cont[3], fromTabEvent, true);
                            }
                        } else {
                            if (elemSel.hasClass("methodInherited")) {
                                _b.properties.methods(cont[2], cont[4], fromTabEvent, false, true); 
                            } else {
                                _b.properties.methods(cont[1], cont[3], fromTabEvent); 
                            }
                        }

                        var table = document.getElementById(_conf.htmlData.attEventsPanels);
                        table.style.display = "none";
                        emEditor.selectedItems.emName = emEditor.editorUI.panel.getActiveElemName();
                        
                        if (emEditor.handlePerms) {
                            _perm.build(); 
                        }
                    
                    break; 
                default: console.error("objects.selectRow");
                }
            }
        }
        
    },
    setNoBlur:function(){
        emEditor.noBlur = true;
    },
    /**
    * set the width of an input (through a gost div)
    * @param {html input element} elem
    * @return {bool} true if the size has been updated
    */
    setInputWidth:function(elem, val){
        var elemW = elem.offsetWidth;
        var change;
        var value;
        
        (val) ? value = val : value = elem.value;
        
        emEditor.autoSizeBox.innerHTML = value;
                
        if( emEditor.autoSizeBox.offsetWidth == 0 ) { 
            
            elem.style.width = _conf.htmlData.minInputSizeForType+"px";
            
        } else {
        
            elem.style.width = emEditor.autoSizeBox.offsetWidth + "px";
            
        }
        
        if( elemW != emEditor.autoSizeBox.offsetWidth && elemW > 40 ) {
            change = true;
        } else {
            change = false;
        }

        return change;
    },
    resizePanel:function(elem, sup){ 
        if(emEditor.editorUI.objects.setInputWidth(elem)){
            if(sup){
                var container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"); 
                var tbs = container.getElementsByTagName("table");
                var tb = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                var oWi = tb.offsetWidth;                   
                var newOwi = oWi-7;
                for(var t in tbs){
                    if(tbs[t].nodeName == "TABLE"){
                    tbs[t].style.width=newOwi+"px";}
                }
                YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module").style.width = newOwi-_conf .htmlData.ajustWidth+"px";
            }
        }
    },
    isInDataList:function( val, tab, lowerCase ) {
        var is = false;
        for( var key in tab ) {
            if( lowerCase ) {
                if( tab[key].toLowerCase() === val.toLowerCase() ){ is = true; break;}
            } else {
                if( tab[key] === val ){ is = true; break;}
            }
            
        }
        return is;
    },
    /**
    * send a request to the studio in order to edit a script. 
    * @param {string} from the path od the script to edit
    */
    editScript:function(from, onCreate){ 

        var meth = from.split("."),
            path = "",
            i = 0, 
            params = "";
        
        while (meth[i]) {

            if (i != 0 && i != 1) {
                path = path + ".";
            }

            if (i != 0) {

                path = path + meth[i];

            } else {

                if (meth[0] != _conf.methodPath.nameSpace) {
                    path = path + meth[i] + ".";
                }

            }

            i++;
        }
        
        switch (meth[3]) {
        case "onSet":   
            params = "value";
        break;
        case "onQuery": 
            params = "compOperator, valueToCompare"; 
        break;
        case "onSort":  
            params = "ascending"; 
        break;
        case "events":  
            params = "attributeName"; 
        break;
        default: //
        }

        if (onCreate) {
            emEditor.studio.doScript(_conf.studioMessage.createScript, path+_conf.methodPath.param+params+")");
        } else {
            emEditor.studio.doScript(_conf.studioMessage.editScript, path+_conf.methodPath.param+params+")");
        }
        
    },
    /**
    * check if the given value has the many indicator. 
    * @param {string} val 
    * @return {bool}
    */
    hasManyIndicator:function(val){
        var carOne = _conf .htmlData.manyIndicator[0];
        var hasMany;
        (val.split(carOne).length > 1) ? hasMany = true : hasMany = false; 
        return hasMany;
    },
    removeHtmlTags:function(txt) {
     a = txt.indexOf('<');
        b = txt.indexOf('>');
        len = txt.length;
        c = txt.substring(0, a);
        if(b == -1) {
           b = a;
        }
        d = txt.substring((b + 1), len);
        txt = c + d;
        cont = txt.indexOf('<');
        if (a != b) {
          txt = this.removeHtmlTags(txt);
        }
     return(txt);
    }
    
};

_o = emEditor.editorUI.objects;