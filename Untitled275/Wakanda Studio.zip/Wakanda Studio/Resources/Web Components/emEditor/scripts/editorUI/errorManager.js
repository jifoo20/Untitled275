/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() { 
 
    /**
    * @constructor errorManager
    * @namespace emEditor.ErrorManager
    */
    emEditor.ErrorManager = function() {
        
        this.manager            = this;
        this.errorList          = {};   //{id:"", classe:"", attribute:"", message:""}
        this.messageAtt         = _conf.langage.en.alertTip.errorManager_messageAtt;
        this.messagePrimKey     = _conf.langage.en.alertTip.errorManager_messagePrimKey;
        //this.init();
        
    };
    
    /**
    * @method init
    * @namespace emEditor.ErrorManager.prototype.init
    */
    emEditor.ErrorManager.prototype.init = function errorManager_init() {
         
	    
       
    };     
	
	/**
    * @method addError
    * @param {object} error the definition of the error {classe:"className", attribute:"attName", message:"type || key"}
    * @namespace emEditor.ErrorManager.prototype.addError
    */
    emEditor.ErrorManager.prototype.addError = function errorManager_addError( error, isStartup ) {
	    
	    if (!_check.doesExtends(error["class"])) {
	        
	        if (!this.errorList[error["class"]]) {
    	        this.errorList[error["class"]] = {};
    	    }

    	    if (!this.errorList[error["class"]].att) {
    	        this.errorList[error["class"]].att = {};
    	    }

    	    if (error.message === "type") {
    	        this.errorList[error["class"]].att[error.attribute] = error.message;

    	    }

    	    if (error.message === "key" ) {
    	        this.errorList[error["class"]].key = true;
    	    }

    	    if (!isStartup) {
    	        this.buildErrorByClass( error["class"] );
    	    }
	    }    
	    
    };
    
    /**
   * @method lookForErrorToRemove
   * @param {string} className 
   * @param {string} kind type || key 
   * @param {string} className 
   * @namespace emEditor.ErrorManager.prototype.lookForErrorToRemove
   */
   emEditor.ErrorManager.prototype.lookForErrorToRemove = function errorManager_lookForErrorToRemove( className, kind, attributeName ) {
       
        if (this.errorList[className]) {
            if (kind === "key") {
                if (this.errorList[className].key) {
                    this.removeError(className, "key");
                }
            }

            if (kind === "type") {
                if (this.errorList[className].att && this.errorList[className].att[attributeName]) {
                    this.removeError(className, "type", attributeName);
                }
            }
        }

   };

    /**
    * @method removeError
    * @param {number} errorID the reference(id) of the error
    * @namespace emEditor.ErrorManager.prototype.addError
    */
    emEditor.ErrorManager.prototype.removeError = function errorManager_removeError( className, errorKind, attributeName ) {
         
        var line    = $("#outline_"+className),
            message,
            ref     = this.errorList[className],
            that    = this;
  
        if (errorKind === "type") {
            this.errorList[className].att[attributeName] = null;            
        }
        
        if (errorKind === "key") {
            this.errorList[className].key = false;
        }    

        this.buildErrorByClass( className );
    };
    
    /**
    * @method displayErrorState
    * @param {bool} isStartup if call at editor startup
    * @namespace emEditor.ErrorManager.prototype.displayErrorState
    */
    emEditor.ErrorManager.prototype.displayErrorState = function errorManager_displayErrorState() {
        
        var className,
            attName,
            message,
            line,
            that = this;
        
        $.each(this.errorList, function(index, value) { 
            that.buildErrorByClass( index );
        });
    };
    
    /**
    * @method buildErrorForByClass
    * @param {string} className 
    * @namespace emEditor.ErrorManager.prototype.buildErrorForByClass
    */
    emEditor.ErrorManager.prototype.buildErrorByClass = function errorManager_buildErrorByClass( className ) {
       
        var attName,
            message,
            line,
            errors,
            noError = true;
        
        line = $("#outline_"+className);
        errors = this.errorList[className];

        if (errors.att) {
            message = this.messageAtt;
            $.each(errors.att, function(i, v) { 
                if( v != null) {
                    noError = false;
                    attName = i;
                    message = message + " <i>"+attName+"</i>";
                }
            });
        }
        
        if (errors.key) { 
            if (!noError) {
                message = message + "<br>";
            } else {
                message = "";
            }
            noError = false;
            message = message + this.messagePrimKey;
        }
        
        if (noError) {
            line.removeClass("confError");
            line.bt({killTitle: false});
        } else { 
            line.addClass("confError");
            line.bt( "<div id='outline_error_"+className+"'>"+message+"</div>", {
                offsetParent:$('body'),
                fill: 'rgb(255,255,255)',
                trigger: "hover",
                killTitle: false
             });
        }
    };

    /**
    * @method buildErrorByID
    * @param 
    * @namespace emEditor.ErrorManager.prototype.buildErrorForByClass
    */
    emEditor.ErrorManager.prototype.buildErrorByID = function errorManager_buildErrorByID( id, message ) {

         $("#"+id).parent().bt( "<div>"+message+"</div>", {
                offsetParent:$('body'),
                fill: 'rgb(255,255,255)',
                trigger: "[on, off]",
                windowMargin: 10, 
                killTitle: false
             }).btOn();

        window.setTimeout(function(){
           $("#"+id).parent().btOff();
        },3000);

    }
})();
