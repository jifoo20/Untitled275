/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* emEditor objects
*/
var emEditor = {};

/**
* define if the current catalog is running with "auto" or "manual" script mode.
*/
emEditor.scriptMode; 

/**
* panel object to store panel object references
*/
emEditor.panels = [];
emEditor.panelsRef = {};

/**
* layout objects + var
*/
emEditor.layout;
emEditor.leftLayoutState = "visible";
emEditor.rightLayoutState = "visible";
emEditor.centerBody;
emEditor.leftTabview;
emEditor.metTab;

/**
* use to store UI object to refresh
*/
emEditor.emToUpdateForUI=[];

/**
* autocompletion var
*/
emEditor.list = {};
emEditor.autocompOn = false;
emEditor.onAutocompValue = null;
emEditor.currentAutoCompSel;

/**
* key state
*/
emEditor.enterKey = false;
emEditor.tabKey = false;
emEditor.returnKey;

/**
* object to store the selected items
*/
emEditor.selectedItems = {};

/**
* for relations curve tooltip 
*/
emEditor.relTooltip;

/**
* propertiesPanel ref
*/
emEditor.propertiesPanel = null;

/**
* alert message
*/
emEditor.alertMessage;
emEditor.alertMessageDisplayed = false;

/**
* keep the ref of the edited box
*/
emEditor.onEditBox={oldValue:null, ref:null};

/**
* DEPRECATED
*/
emEditor.waitingForUUID = false;

/**
* keep the data to remove during actions
*/
emEditor.toDeleteData={};

/**
* ref of the div to manage autosize of input box
*/
emEditor.autoSizeBox;

/**
* juste to store last id use for unique auto id generation
*/
emEditor.ids = 0;
emEditor.idPanel = 1;

/**
* keep in memory the information about panel during panel creation. 
*/
emEditor.onCreationPanel;

/**
* main overlay for managing multiple panels in the workspace. 
*/
emEditor.overlayManager = null;

/**
* indicate that no blur is needed. 
*/
emEditor.noBlur = false;

/**
* events buttons 
*/
emEditor.eventEnMenuButton; 
emEditor.eventAttMenuButton;

/**
* relation Curve
*/
emEditor.relationCurve;
emEditor.relationCurveMode;

/**
* properties Type Popup
*/
emEditor.propertiesTypePopupTable;

/**
* properties & event tables ref
*/
emEditor.emPropertiesTable;
emEditor.attPropertiesTable;
emEditor.emEventTable;
emEditor.attEventTable;
emEditor.methodContainer;

emEditor.centerBodyRef;

/**
* to send only 1 setDirty by time
*/
emEditor.setDirtyDone = false;

/**
* timer object
*/
emEditor.timer;

/**
* svg
*/
emEditor.svgBalise;

/**
* fliped panel
*/
emEditor.onFlip;

/**
* pre builded dom objects for perf purpose
*/
emEditor.domObject = {};
_dom = emEditor.domObject;

/**
* main UI object management
*/
emEditor.editorUI = {

    /**
    * reload a catalog without rebuiding the ui 
    */
    reloadCatInUI: function( noNew ) { 
        
        //re init var
        emEditor.ids                                = 0;
        emEditor.idPanel                            = 1;
        emEditor.enterKey                           = false;
        emEditor.tabKey                             = false;
        emEditor.propertiesPanel                    = null;
        emEditor.alertMessageDisplayed              = false;
        emEditor.onEditBox                          = {oldValue: null, ref: null};
        emEditor.selectedItems.item                 = null;
        emEditor.overlayManager                     = null;
        emEditor.panels                             = []; 
        emEditor.panelsRef                          = {};
        panels                                      = emEditor.panels;
        emEditor.list                               = {};
        emEditor.autocompOn                         = false;
        emEditor.onAutocompValue                    = null;
        emEditor.emPropertiesTable.style.display    = "none";
        emEditor.attPropertiesTable.style.display   = "none";
        emEditor.emEventTable.style.display         = "none";
        emEditor.attEventTable.style.display        = "none";
        
        if (!emEditor.displayMethodInPanel) {
            $(".methodsContainer table.methodsTable").remove();
        }
        //update menu's markups        
        emEditor.editorUI.dock.buildDockBlock(_conf.htmlData.classEm, true);
        //emEditor.editorUI.dock.buildDockBlock(_conf .htmlData.classType, true); //temp remove TYPE !!
        
        //clean render container
        $("#center-body div").remove();

        if (emEditor.scriptMode == "manual") {
            _dom.methHeader.innerHTML = "<div class='typeIcnsHeader methods'></div><span>Methods</span>";
        }
        
        _c.loadRelationCurve();

        emEditor.editorUI.initUI.buildPanels();

    },
    
    initDomObjects: function() {
        /* panel */
        _dom.contentContainer = document.createElement("div");
        _dom.contentContainer.className = "contentContainer";
        
        _dom.attributesTable = document.createElement("table");
        _dom.attributesTable.className = "attributesTable";
        
        _dom.header = document.createElement("div");
        _dom.header.className = "objHeader";
        _dom.header.innerHTML = "<div class='typeIcnsHeader attributes'></div><span>Attributes</span>"+
                                "<div class='addElem studio-icon-add'></div>";
        
        _dom.content = document.createElement("div");
        _dom.content.className = "objContent";
 
        _dom.methodsTable = document.createElement("table");
        _dom.methodsTable.className = "methodsTable";
        
        _dom.methHeader = document.createElement("div");
        _dom.methHeader.className = "objHeader meth";
        
        if( emEditor.scriptMode == "auto" ) { 
            _dom.methHeader.innerHTML = "<div class='typeIcnsHeader methods'></div><span>Methods</span>"+
                                        "<div class='addElem studio-icon-add'></div>";
        } else {
            _dom.methHeader.innerHTML = "<div class='typeIcnsHeader methods'></div><span>Methods</span>";
        }
    },
    /**
    * actions on dom
    */
    dom:{
        /**
        * toggle a class form the given element
        * @param {String} className 
        * @param {html object} obj html element where to toggle the class
        */
        toggleClass:function(className, obj){
            if(YAHOO.util.Dom.hasClass(obj, className)){
                YAHOO.util.Dom.removeClass(obj, className);
            }else{
                YAHOO.util.Dom.addClass(obj, className);
            }
        },
        /**
        * remove a node from another one
        * @param {html object} from container of the object to remove
        * @param {html object} elem object to remove
        */
        removeNode:function(from, elem){
            from.removeChild(elem);
        },
        getPreviousSiblingByClass:function(from, classN){
            var tr=from;
            while(!YAHOO.util.Dom.hasClass(tr, classN)){
                tr = tr.previousSibling;    
            }
            return tr;
        }
    },
    /**
    * methods to manage waf message
    */
    wafMessage: {
        /**
        * buid and send a WAF message using location.href
        */
        send:function(message){ 
                if(emEditor.webarea){window.location.href = 'waf:' + message;  }
                console.log("WAf message "+message+" sent to the Studio.");      
        }
    },
    /**
    * methods to manage uuid
    */
    uuid:{
        use:function(){             
            return emEditor.studio.getUUID();
        }
    }

}
