/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
    _windows.drag = {};
    _wDrag = _windows.drag;
    
    /**
    * set on drag method to yui panel drag event
    * @param {YUI panel object} p 
    */
    _wDrag.on = function(p){  
        
         //drag events management
         p.dd.onDrag = function(event) {

            if(emEditor.relationCurve && emEditor.curve){
                _c.onDrag(this);
            }                     

            var el = this.getEl();
                scrollBarLeftOffset = (emEditor.centerBody.body.scrollTop) ?
                parseInt(emEditor.centerBody.body.style.width) - emEditor.centerBody.body.clientWidth :
                0;
            var scrollBarTopOffset = (emEditor.centerBody.body.scrollLeft) ?
                parseInt(emEditor.centerBody.body.style.height) - emEditor.centerBody.body.clientHeight :
                0;

            var left = el.offsetLeft,
                right = left + el.offsetWidth,
                top = el.offsetTop,
                bottom = top + el.offsetHeight,
                deltaX = event.pageX - this.deltaX,
                deltaY = event.pageY - this.deltaY,
                l, t,
                centerBodyLeft = emEditor.centerBody.getAttributeConfig('left').value,
                centerBodyWidth = emEditor.centerBody.getAttributeConfig('width').value,
                centerBodyTop = 0,
                centerBodyHeight = emEditor.centerBody.getAttributeConfig('height').value;



              if(right > $("#center-body").get()[0].offsetWidth && deltaX  + el.offsetWidth > centerBodyLeft + centerBodyWidth){
                 // 
              }else{
                // El is near left border
                if(left < emEditor.centerBody.body.scrollLeft) {
                  emEditor.centerBody.body.scrollLeft = left;
                }

                // El is over right border
                if(deltaX  + 100 > centerBodyLeft + centerBodyWidth) { //deltaX + el.offsetWidth > centerBodyLeft + centerBodyWidth
                  //l = left + 7;
                  l = left + el.offsetWidth-100  + 7;
                  emEditor.centerBody.body.scrollLeft = right - emEditor.centerBody.getSizes().body.w + scrollBarLeftOffset;
                // El is between left & right borders
                } else {
                  l = deltaX - centerBodyLeft + emEditor.centerBody.body.scrollLeft - 5;
                }

                if(l < 0) l = 0;
                YAHOO.util.Dom.setStyle(el, 'left', l + 'px');
              }
  
              if(bottom > $("#center-body").get()[0].offsetHeight && deltaY + el.offsetHeight > centerBodyTop +emEditor.centerBody.getSizes().body.h){
                 
              }else{
                // El is near top border
                if(top < emEditor.centerBody.body.scrollTop) {
                    emEditor.centerBody.body.scrollTop = top;
                }

                // El is over bottom border
                if(deltaY + 50> centerBodyTop + centerBodyHeight) { //deltaY + el.offsetHeight > centerBodyTop + centerBodyHeight
                    t = top + el.offsetHeight-50  + 7; // t = top + 7
                    emEditor.centerBody.body.scrollTop = bottom - emEditor.centerBody.getSizes().body.h + scrollBarTopOffset;
                // El is between top & bottom borders
                } else { 
                    t = deltaY - centerBodyTop + emEditor.centerBody.body.scrollTop - 5;
                }

                    if(t < 0) t = 0;
                }

              YAHOO.util.Dom.setStyle(el, 'top', t + 'px');
              
              //resize container
              /*           
              var scrollBarLeftOffset = (emEditor.centerBody.body.scrollTop) ?
                   parseInt(emEditor.centerBody.body.style.width) - emEditor.centerBody.body.clientWidth :
                   0;
               var scrollBarTopOffset = (emEditor.centerBody.body.scrollLeft) ?
                   parseInt(emEditor.centerBody.body.style.height) - emEditor.centerBody.body.clientHeight :
                   0;

               var w = emEditor.centerBody.body.scrollLeft + emEditor.centerBody.getSizes().body.w - scrollBarLeftOffset;
               var h = emEditor.centerBody.body.scrollTop + emEditor.centerBody.getSizes().body.h - scrollBarTopOffset;

               w = Math.max(max.width, w);
               h = Math.max(max.height, h);

               YAHOO.util.Dom.setStyle(emEditor.centerBody.body.children[0], 'width', w + 'px');
               YAHOO.util.Dom.setStyle(emEditor.centerBody.body.children[0], 'height', h + 'px');
               */     
               
               
               /* multi. sel */
               if($("#"+this.id).hasClass("multiSelected")){
                   var diffT,
                          diffL;

                      if(emEditor.oldPL == null){
                          emEditor.oldPL = left;
                          emEditor.oldPT = top;
                      }

                      diffT = top - emEditor.oldPT;
                      diffL = left - emEditor.oldPL;
                      emEditor.oldPL = left;
                      emEditor.oldPT = top;    

                      sels = $("#center-body .multiSelected");
                      var  onDragP = this,
                           onDragId = onDragP.id.split("_")[0];
                      $.each(sels, function(index, value) {
                        if(value.id.split("_")[0] != onDragId){  
                            value.style.top = value.offsetTop + diffT + "px";
                            value.style.left = value.offsetLeft + diffL + "px";
                        } 
                      });
               }
               /* end multi. sel */
          };
    };
    
    /**
    * set on end method to panel yui drag event
    * @param {YUI panel object} p 
    */
    _wDrag.end = function(p){
     
         p.dd.b4EndDrag  = function(event){
             
            var centerBodyLeft = emEditor.centerBody.getAttributeConfig('left').value,
                centerBodyWidth = emEditor.centerBody.getAttributeConfig('width').value,
                centerBodyTop = 0,
                centerBodyHeight = emEditor.centerBody.getAttributeConfig('height').value,
                pid = this.id.split("_")[0], 
                elem, elemT, elemL, emN,
                pref = emEditor.panels[ emEditor.panelsRef[pid]];
                
            emEditor.previewObj.updatePreview();

            $(emEditor.svgBalise).animate({
                opacity: 1
            }, 20, function() {
                // Animation complete.
            });
                    
            // We have to find the far borders
            max = {width: 0, height: 0};
            for(var i=0;i < emEditor.panels.length; i++) {
              var right = emEditor.panels[i].panel.element.offsetLeft + emEditor.panels[i].panel.element.offsetWidth;
              max.width = Math.max(max.width, right);

              var bottom = emEditor.panels[i].panel.element.offsetTop + emEditor.panels[i].panel.element.offsetHeight;
              max.height = Math.max(max.height, bottom);
            }

            /*  var scrollBarLeftOffset = (emEditor.centerBody.body.scrollTop) ?
                  parseInt(emEditor.centerBody.body.style.width) - emEditor.centerBody.body.clientWidth :
                  0;
              var scrollBarTopOffset = (emEditor.centerBody.body.scrollLeft) ?
                  parseInt(emEditor.centerBody.body.style.height) - emEditor.centerBody.body.clientHeight :
                  0;

              var w = emEditor.centerBody.body.scrollLeft + emEditor.centerBody.getSizes().body.w - scrollBarLeftOffset;
              var h = emEditor.centerBody.body.scrollTop + emEditor.centerBody.getSizes().body.h - scrollBarTopOffset;

              w = Math.max(max.width, w);
              h = Math.max(max.height, h);

              YAHOO.util.Dom.setStyle(emEditor.centerBody.body.children[0], 'width', w + 'px');
              YAHOO.util.Dom.setStyle(emEditor.centerBody.body.children[0], 'height', h + 'px');
                */              
 

            // Saving the panel position !!!! +5 for the border width of the container !!! 
            emEditor.editorUI.panel.keepPos(
              this.getEl().offsetLeft + centerBodyLeft + 5, 
              this.getEl().offsetTop + centerBodyTop + 5,
              pref.emName,
              pid
            );
            
            //emEditor.multiSelect
            if(emEditor.multiSelect &&  emEditor.multiSelect.length > 0){
                $.each(emEditor.multiSelect, function(index, value) { 
                  if(value != pid ){
                    elem = $("#"+value).get()[0].parentNode;
                    elemT = elem.offsetTop + centerBodyTop + 5;
                    elemL = elem.offsetLeft + centerBodyLeft + 5;
                    emN = emEditor.editorUI.panel.getPanelRefFromID(value).emName;
                    _u.panelPos(elemL-emEditor.centerBody.getAttributeConfig('left').value+5, elemT, emN, value);
                  }
                });
                /*if( emEditor.curve && emEditor.relationCurve ){ 
                    _c.loadRelationCurve( ); 
                }*/
            }else{
                /*if( emEditor.curve && emEditor.relationCurve && emEditor.selectedItems.emName == pref.emName){ 
                    _c.loadRelationCurve(  ); //false, pref
                    //_c.loadRelationCurve(  ); 
                }*/
            }
            
            if( emEditor.curve && emEditor.relationCurve ){ 
                _c.loadRelationCurve( ); 
            }
            
        };
            
    };
    
    /**
    * set "before start" method to yui panel drag event
    * @param {YUI panel object} p 
    */
    _wDrag.b4start = function(p){
       
        p.dd.b4StartDrag = function(x, y){
            
            $(".bt-active").btOff();
            $(".color_swatch").parent().remove();
            
              emEditor.oldPL = null;
            //emEditor.svgBalise.style.display = "none";
            $(emEditor.svgBalise).animate({
              opacity: 0
            }, 300, function() {
              // Animation complete.
            });
              
            /*var el = this.getEl();

            var left = el.offsetLeft;
            var top = el.offsetTop;

            var deltaX = x - this.deltaX;
            var deltaY = y - this.deltaY;

            var centerBodyLeft = emEditor.centerBody.getAttributeConfig('left').value;
            var centerBodyWidth = emEditor.centerBody.getAttributeConfig('width').value;
            //var centerBodyTop = emEditor.centerBody.getSizes().header.h;
            var centerBodyTop = 0;
            var centerBodyHeight = emEditor.centerBody.getAttributeConfig('height').value;

            // El is already over left border
            if(left < emEditor.centerBody.body.scrollLeft) {
              this.deltaX += left - emEditor.centerBody.body.scrollLeft;
            }
            // El is already over right border
            if(deltaX + el.offsetWidth > centerBodyLeft + centerBodyWidth) {
              this.deltaX += deltaX + el.offsetWidth - centerBodyLeft - centerBodyWidth;
            }

            // El is already over top border
            if(top < emEditor.centerBody.body.scrollTop) {
              this.deltaY += top - emEditor.centerBody.body.scrollTop;
            }
            // El is already over bottom border
            if(deltaY + el.offsetHeight > centerBodyTop + centerBodyHeight) {
              this.deltaY += deltaY + el.offsetHeight - centerBodyTop - centerBodyHeight;
            }*/
          };
    };
    
})();    