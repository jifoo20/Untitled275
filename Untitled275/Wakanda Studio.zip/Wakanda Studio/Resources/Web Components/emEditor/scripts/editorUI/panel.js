/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
if(!emEditor){
	var emEditor = {};
	if(!emEditor.editorUI){
		emEditor.editorUI = {};
	}
}

/**
* methods to manage panel stuff
*/
emEditor.editorUI.panel={

    managePathCollumn:function(panelID, keepOpen, openSaved){
    
        var table, container, but;  
        container = document.getElementById(panelID);
        var emName = emEditor.editorUI.panel.getPanelRefFromID(panelID).emName;
        var allPath = YAHOO.util.Dom.getElementsByClassName("path", "td", container);
                    
        //force table to update his width before resizing the panel
        var bd = YAHOO.util.Dom.getElementsByClassName("bd", "div", container)[0];
        var tab = bd.getElementsByTagName('table');
        var pathW = 0;
        
        for(var k in allPath){
            if(allPath[k].offsetWidth > pathW){pathW = allPath[k].offsetWidth;}
        }
        var disp, close = false;
        but = YAHOO.util.Dom.getElementsByClassName("hidePath", "div", container); 
        if(YAHOO.util.Dom.hasClass(but, "right")){
            YAHOO.util.Dom.removeClass(but, "right");
        }
        
        for(var key in allPath){
            disp = allPath[key];
            if(YAHOO.util.Dom.hasClass(disp, "tableHidden")){
                    YAHOO.util.Dom.removeClass(disp, "tableHidden"); 
                    if(!openSaved){
                        _u.extraProperties.setPathState(true, emName);
                        
                    }
            }else{
                if(!keepOpen){
                    YAHOO.util.Dom.addClass(disp, "tableHidden");
                    _u.extraProperties.setPathState(false, emName);
                }
            }
        }
        //manage panel width
        var w=0, wCont;
        for(var a in tab){
            if(tab[a].nodeName == "TABLE"){
                if(w<tab[a].offsetWidth){
                    w = tab[a].offsetWidth;
                }
            }
        }
        
        if(w-pathW < _conf .htmlData.minAttTableWith){
            w = _conf .htmlData.minAttTableWith+_conf .htmlData.ajustWidth;
            wCont = w;
        }else{
            w = w-pathW;
            wCont = w+_conf .htmlData.ajustWidth;
        }
        if(!keepOpen){
            close = true;
        }else if(w == w-pathW){
            close = true;
        }
        if(close){
            document.getElementById(panelID).style.width=w+"px";
            for(var i in tab){
                if(tab[i].nodeName == "TABLE"){
                    tab[i].style.width=wCont+"px";
                }
            }
        }
    },
    /**
    * keep the position of the panel in the data file 
    * @param {number} x 
    * @param {number} y 
    */
    keepPos:function(x, y, emName, panelID){  
        if(!emName){
            emName = this.getActiveElemName();
            panelID = this.getActiveID();
        } 
        
        _u.panelPos(x-emEditor.centerBody.getAttributeConfig('left').value+5, y, emName, panelID);
    },
    addFocus:function(panelID){ 
        for(var key in emEditor.panels){
            if(emEditor.panels[key].id == panelID){ 
                emEditor.panels[key].panel.focus();
                break;
            }
        }
    },
    manageResizeWidth:function(panel, onlyBD, updatePreview, noReloadCurve){

        if(  panel ) { //emEditor.displayMethodInPanel &&
            var bd;
            if( YAHOO.util.Dom.hasClass(panel, "bd") ) {
                bd = panel;
            } else { 
                bd = YAHOO.util.Dom.getElementsByClassName("bd", "div", panel)[0];
            }

            var tab = bd.getElementsByTagName('table');
            var w=0, wCont, i;
            for(i in tab) {
                if(tab[i].nodeName == "TABLE"){
                    tab[i].style.width = "auto";
                    if( w<tab[i].offsetWidth ) {
                        w = tab[i].offsetWidth;
                    }
                }
            }
                    
            if(w-_conf.htmlData.ajustWidth < _conf.htmlData.minAttTableWith){ 
                w = _conf.htmlData.minAttTableWith;
                wCont = _conf.htmlData.minAttTableWith + _conf.htmlData.ajustWidth;
            }else{
                wCont = w;
            }

            for(i in tab){
                if(tab[i].nodeName == "TABLE"){
                   tab[i].style.width=wCont+"px";
                }
            }
        
            var cont = YAHOO.util.Dom.getElementsByClassName("contentContainer", "div", panel)[0];
            var offW = cont.offsetWidth;
            if (offW != w) {
                if (!onlyBD) {
                    panel.style.width = w-_conf.htmlData.ajustWidth+"px";
                }
            }
                        
            if( !noReloadCurve && emEditor.relationCurve) { 
                _c.loadRelationCurve( );
            }
            
            if( updatePreview ) {
                emEditor.previewObj.updatePreview();
            }
            
        }
    },
    getActiveID:function(){
        var is = null;
        if(emEditor.overlayManager){
            if(emEditor.overlayManager.getActive()){
                is = emEditor.overlayManager.getActive().id;
            }
        }
        return is;
    },
    getPanelRef:function(emName){ 
       /* var p = null;
        for (var k in emEditor.panels){
            if(emEditor.panels[k]["emName"] === emName){
                p = emEditor.panels[k];
                break;
            }
        } */
        //return p;
        return emEditor.panels[emEditor.panelsRef[emName]];
    },
    getPanelRefFromID:function(id){
        /*pan = null;
        for (var k in emEditor.panels){
            if(emEditor.panels[k]["id"] == id){
                pan = emEditor.panels[k];
                break;
            }
        }
        return pan;*/
        
        return emEditor.panels[emEditor.panelsRef[id]];
    },
    /**
    * return the name of the active element
    */
    getActiveElemName:function(){ //todo
        var name = null;
        if(emEditor.overlayManager){
            var oa = emEditor.overlayManager.getActive();
            if(oa){
                var is = oa.id;
                name = this.getPanelRefFromID(is).emName;
            }
        }
        return name;
    },
    manageToolTip:function(left, top, text){ 
        
        var tb = YAHOO.util.Dom.getAncestorByTagName(emEditor.onEditBox.ref, "table");
        var target;
        
        switch (tb.id){
        case _conf .htmlData.typesTable : target = _conf .htmlData.typesTable; break;
        case "menuTableEm": target = "menuTableEm"; break;
        default: target = emEditor.overlayManager.getActive().id;
        }
    
        
        if(!document.getElementById("tooltip")){
            var tool = document.createElement("div");
            tool.className="errorToolTip";
            tool.id="tooltip";
            tool.style.left=left;
            tool.style.top=top;
            tool.innerHTML=text;
            var panel = document.getElementById(target);
            panel.appendChild(tool);

            setTimeout(function() {
                var panel = document.getElementById(target);
                var tool = document.getElementById("tooltip");
                panel.removeChild(tool);
                },2000);
        }
    },
    /**
    * open/close all the row of a table for attributes 
    * @param {object} elem html table
    */
    hideShowInnerRow:function(elem){
        var sty;
        var TR = YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
        var tab = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
        var rows = YAHOO.util.Dom.getElementsByClassName(TR.id, "tr", tab);
        
        if(YAHOO.util.Dom.hasClass(rows[0], "displayed")){
            sty= true;
        }
        for(var key in rows){
            if(sty){
                YAHOO.util.Dom.removeClass(rows[key], "displayed");
                //taille
            }else{
                YAHOO.util.Dom.addClass(rows[key], "displayed");
            }       
        }
        var cont = YAHOO.util.Dom.getAncestorByTagName(tab.parentNode, "div");
        var tabs = cont.getElementsByTagName('table');
        var w=0;
        
        //reset last td width for all table
        var firtsTr = tab.getElementsByTagName("tr")[0];
        var panID = YAHOO.util.Dom.getAncestorByTagName(cont, "div").parentNode;
        var t = cont.getElementsByTagName('table');
        var i=0;
        for(i in t){
            if(t[i].nodeName == "TABLE"){
                firtsTr = t[i].getElementsByTagName("TR")[0];
                tds = firtsTr.getElementsByTagName("td");
                tds[tds.length-1].style.width="";
            }
            i++;
        }
        
        //get the larger table
        for(i in tabs){
            if(w<tabs[i].offsetWidth){
                w=tabs[i].offsetWidth;
            }
        }
        if(sty){
            YAHOO.util.Dom.removeClass(elem, "open");
            
            if(YAHOO.util.Dom.getElementsByClassName("displayed", "tr", cont).length != 0){
                    panID.style.width=w+"px"; //-ajustWidth
                }else{
                    panID.style.width=w+"px";
                    cont.style.minWidth=w-_conf .htmlData.ajustWidth+"px";

                }
        }else{
            YAHOO.util.Dom.addClass(elem, "open");
            cont.style.minWidth=w-_conf .htmlData.ajustWidth+"px";
            
            panID.style.width=w+_conf .htmlData.ajustWidth+"px";
        }
        //pou again td with at 100% for all table
        i=0;
        for(i in t){
            if(t[i].nodeName == "TABLE"){
                firtsTr = t[i].getElementsByTagName("TR")[0];
                tds = firtsTr.getElementsByTagName("td");
                tds[tds.length-1].style.width="100%";
            }
            i++;
        }

    //  var container = YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"); 
    //  this.manageResizeWidth(container, false, sty);

    },
    /**
    * open/close all the row of a table
    * @param {object} elem html table
    */
    collapseExpandBlock:function (elem, close, open){ 
        var ancestor = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
        var icsn = ancestor.childNodes[1].childNodes[4];
        if(!icsn){
            icsn= ancestor.childNodes[1].childNodes[1];
        }
        if(YAHOO.util.Dom.hasClass(ancestor, "collapsed")){
            if(!close){
                YAHOO.util.Dom.removeClass(ancestor, "collapsed");
                YAHOO.util.Dom.removeClass(icsn, "blockClose");
                YAHOO.util.Dom.addClass(icsn, "blockOpen");
            }
        }else{
            if(!open){
                    YAHOO.util.Dom.addClass(ancestor, "collapsed");
                    YAHOO.util.Dom.addClass(icsn, "blockClose");
                    YAHOO.util.Dom.removeClass(icsn, "blockOpen");
                }
        }
    },
    /**
    * hide show groups by types
    * @param {object} elem 
    */
    hideShowGroups:function(elem){
        var ty = YAHOO.util.Dom.getAncestorByTagName(elem, "table").className;
        _windows.hideShow(ty);
    },
    /**
    * fit the container to the content if needed, set css properties to default
    * @param {object} elem html table
    */
    fitToContent : function(elem){          
        var ancestor = YAHOO.util.Dom.getAncestorByTagName(elem, "div");
        var parent = ancestor.parentNode;
        var bd;
        if(ancestor.nextSibling.nextSibling.className == "bd"){
            bd=ancestor.nextSibling.nextSibling;
        }else{
            bd=ancestor.nextSibling;
        }   
        _windows.fit(parent, bd);
    },
    /**
    * minimize or expand the panel
    * @param {object} elem
    */
    minimize:function(elem){ 
        
        var bd, state = false;
        if(!elem){
           bd = $("#"+this.getActiveID() +" .bd").get()[0];
        }else{
           var ancestor = YAHOO.util.Dom.getAncestorByTagName(elem, "div");
           bd = ancestor.nextSibling;
        }

        var ft = bd.nextSibling;
        var c = bd.parentNode;
        var arrow = YAHOO.util.Dom.getElementsByClassName("hidePath", "div", ancestor)[0];

        if(bd.style.display=="block" ||  bd.style.display==""){
            //close
            bd.style.display="none";
            ft.style.display="none";
            c.style.height="auto";
            arrow.style.visibility = 'hidden';
            state = true;
        }else{
            //open
            
            bd.style.display="block";
            ft.style.display="block";
            arrow.style.visibility = 'visible';
        }   


        //keep state
        _u.extraProperties.defineMinimizeState(emEditor.panels[emEditor.panelsRef[this.getActiveID()]].emName, state);
        
        if(emEditor.curve && emEditor.relationCurve){
           _c.loadRelationCurve( ); //false, emEditor.panels[emEditor.panelsRef[this.getActiveID()]]
        }
        
        emEditor.previewObj.updatePreview();

    },
    /**
    * expand to full Screen
    * @param {object} elem
    */
    expand:function(elem){ //not use !
        var ancestor = YAHOO.util.Dom.getAncestorByTagName(elem, "div");
        var parent = ancestor.parentNode;
        parent.style.width=screen.width+"px";
        parent.style.height=screen.height+"px";
        parent.parentNode.style.top="0px";
        parent.parentNode.style.left="0px";
    },
    /**
    * hide/show elem table in the content
    * @param {object} elem
    */
    manageFilter:function(elem){
        var ty,table;
        if(YAHOO.util.Dom.hasClass(elem, "seeAtt")){ty="seeAtt";};
        if(YAHOO.util.Dom.hasClass(elem, "seeProp")){ty="seeProp";};
        
        var cont = YAHOO.util.Dom.getAncestorByTagName(YAHOO.util.Dom.getAncestorByTagName(elem, "div"), "div").nextSibling;

        switch (ty){
            case "seeAtt": 
                table = YAHOO.util.Dom.getElementsByClassName("attributeTable", "table", cont)[0];
                break;
            case "seeProp": 
                table = YAHOO.util.Dom.getElementsByClassName("propertiesTable", "table", cont)[0];
                break;
            default:    
        }
        
        if(YAHOO.util.Dom.hasClass(elem, "icnsOp")){
            YAHOO.util.Dom.removeClass(elem, "icnsOp");
            YAHOO.util.Dom.removeClass(table, "tableHidden");
        }else{
            YAHOO.util.Dom.addClass(elem, "icnsOp");
            YAHOO.util.Dom.addClass(table, "tableHidden");
        }
        
    },
    /**
    * add focus to a opened panel
    * @param {string} emName name of the panel's em
    */
    putFocus:function(emName){ 
        _windows.putFocus(this.getPanelRef(emName));
    },
    /**
    * remove a panel
    * @param {string} emName name of the panel's em
    */
    remove:function(emName){
        var pRef = emEditor.editorUI.panel.getPanelRef(emName);
        _windows.remove(pRef.id);
    },
    /**
    * look if a panel is already opened or not, build a new one if needed
    * @param {object} elem html tr
    */
    addFocusOrOpen:function( elem, emName, pID, addAttribute, withFocus, openSaved, noFocus, isNew ) {

        var panelID, 
            ti, 
            cl, 
            pposT,
            pposL,
            cbH,
            cbW, 
            cb, 
            pRefJq, 
            pRef,
            body,
            header,
            pDom,
            i = emEditor.idPanel++;
        
        if (emName) {
            ti = emName;
            //cl = _conf.htmlData.classEm;
        } else {
            ti = $(elem).attr("data-title");
            //cl = elem.className;
        }

        cl = _conf.htmlData.classEm;
        pRef = emEditor.editorUI.panel.getPanelRef(ti);
                
        if (pRef && pRef.emName == ti) {

            //just focus on the right place
            if (!noFocus) {
                
                cb = $("#center-body").get()[0];
                pRefJq = $("#"+pRef.id+"_c").get()[0];
             
                if( pRefJq.offsetTop > cb.parentNode.offsetHeight + cb.parentNode.scrollTop 
                    || pRefJq.offsetLeft > cb.parentNode.offsetWidth + cb.parentNode.scrollLeft 
                    || pRefJq.offsetTop < cb.parentNode.scrollTop 
                    || pRefJq.offsetLeft < cb.parentNode.scrollLeft ){
                   
                        pDom = $("#"+pRef.id).get()[0];
                        cb.parentNode.scrollTop = pDom.parentNode.offsetTop - 100;
                        cb.parentNode.scrollLeft = pDom.parentNode.offsetLeft - 100;
                }

            }
            _h.selectPanel(pRef.panel, false, false, null);
        } else {
        
            //build object content
            panelID = "emPanel"+i;
            body = _b.contentView(ti, cl);
            header = _b.header(ti, cl); 
            if (isNew) {
                $(body).append('<div contenteditable="true" class="editClassNameInPanel">'+emName+'</div>');
            }
            emEditor.onCreationPanel = {name:ti, type:cl, body:body, header:header, footer:null};
            if (!withFocus) { 
                _u.extraProperties.setPanelOpen(true, ti); 
            }
            _windows.add(panelID, false, false, ti, addAttribute, withFocus, openSaved, isNew);
        }
        
        //return;
        
    }
};