/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
/**
 * refresh an item in the given panel and in the extended ones if needed or required 
 * @param {object} conf configuration of the refresh action //{emName : emName, itemName : itemName, type:"att || meth", action:"add || update || remove",  isExtend:true, lookForExtend:true || false, oldValue:oldValue, name: false||true}
 */
 _windows.refresh = function( conf ) {

    var itemRef, att,
        pRef = emEditor.editorUI.panel.getPanelRef(conf.emName),
        nameBox,
        typeBox,
        pathBox,
        boxes,
        pID = null,
        panelRef=  null,
        queued = false,
        add,
        other = [],
        extendPath,
        className,
        oldValForItemName;

    if (pRef) {
        pID = pRef.id;
        panelRef = pRef.panel;
    }
                
     switch ( conf.action ) {
     case "add" : 
         if (conf.type === "att") {
             //get item ref
              if (conf.isExtend) {
                  itemRef = _g.emAttribute(conf.emStart, conf.itemName);   
                  if (panelRef != null && !conf.doNotloadFirt) {
                      emEditor.editorUI.views.add.entity.attributeByConf( pID, conf.emName, itemRef, conf.isExtend, conf.emStart );
                  }
              } else {
                  itemRef = _g.emAttribute(conf.emName, conf.itemName);
                  if (panelRef != null && !conf.doNotloadFirt) {
                      emEditor.editorUI.views.add.entity.attributeByConf( pID, conf.emName, itemRef, conf.isExtend, conf.emStart );
                  }
              }

              if (conf.lookForExtend) { 
                  className = _g.dataClassName(conf.emName);
                  extendPath = _g.extendTree(className);
                  $.each(extendPath, function(index, value) { 
                      $.each(value, function(i, v) { 
                          if ( !_uA.isValueIn( v, other ) ) {
                              other.push(v);
                          }
                      });
                  });

                  if (!conf.emStart) {
                      conf.emStart = conf.emName;
                  }
                
                  for (var key in other) {
                       _wRefresh({emName : other[key], emStart: _g.dataClassName(conf.emStart), itemName : conf.itemName, type:"att", action:"add", isExtend:true, lookForExtend:false, extendFrom : className });
                  }
              }
    
         } else {
            var pRef = emEditor.editorUI.panel.getPanelRef(conf.emName);
            if (!conf.emStart) {
                   conf.emStart = conf.extendFrom;
            }
            
            if (pRef) { 
                var methInfo = _g.methodData(conf.emStart, conf.itemName);
                emEditor.editorUI.views.add.entity.methods($("#"+pRef.id+" .methodsTable").get()[0], true, conf.itemName, true, false, { extendFrom: conf.emName, from: conf.emStart, apply : methInfo.applyTo });
            }

            if (conf.lookForExtend) {
                other = _check.whosExtends(conf.emName);
   
                for(var key in other){
                    _wRefresh({emName : other[key], emStart: conf.emStart, itemName : conf.itemName, type:"meth", action:"add", isExtend:true, lookForExtend:true, extendFrom : conf.emName });
                }
            }
         }     
  
         break;
     case "update" :   

         if(panelRef != null){
             
            if(conf.type == "att" || conf.type == "em"){

                 if (conf.isExtend) {
                     itemRef = _g.emAttribute(conf.emStart, conf.itemName);    
                     
                     if (conf.oldValue) {   
                         //use the value to get the item's id       
                          if (conf.type === "em") {
                            oldValForItemName = conf.itemName;
                          } else {
                            oldValForItemName = conf.oldValue;
                          }
                                            
                          att = $("#entityModels-"+conf.emStart+"-"+conf.emName+"-attribute-"+oldValForItemName).get()[0];
                          //update the id with the new value
                          att.id = "entityModels-"+conf.emStart+"-"+conf.emName+"-attribute-"+conf.itemName;
                          //update the title with the new value
                          emEditor.uD.setWafData(att, conf.itemName);
                      } else {
                          att = $("#entityModels-"+conf.emStart+"-"+conf.emName+"-attribute-"+conf.itemName).get()[0];
                      }

                      boxes = $("#entityModels-" +conf.emStart +"-" + conf.emName + "-attribute-" + conf.itemName).find(".editable_base");
                      nameBox = boxes.get()[0].firstChild;
                      typeBox = boxes.get()[1].firstChild;
                      if(boxes.get()[2]){
                          pathBox = boxes.get()[2].firstChild;
                      }
                      
                 } else {    

                     itemRef = _g.emAttribute(conf.emName, conf.itemName);

                     if (conf.name) {    
                          att = $("#entityModels-" + conf.emName + "-attribute-" + conf.oldValue).get()[0];
                          att.id = "entityModels-"+conf.emName+"-attribute-"+conf.itemName;
                          emEditor.uD.setWafData(att, conf.itemName);
                      } else {
                          att = $("#entityModels-" + conf.emName + "-attribute-" + conf.itemName).get()[0];
                      }
                      
                      boxes = $("#entityModels-" + conf.emName + "-attribute-" + conf.itemName + " .editable_input2");
                      nameBox = $("#entityModels-" + conf.emName + "-attribute-" + conf.itemName + " .editable_input").get()[0];
                      typeBox = boxes.get()[0];
                      pathBox = boxes.get()[1];
                 }
      
                 //update name
                 nameBox.innerHTML =  itemRef.name;
                 
                 //update type
                 if (itemRef.kind == "relatedEntity") {
                    typeBox.innerHTML =  itemRef.type;
                 }
                 if (itemRef.kind == "alias") {
                    typeBox.innerHTML =  itemRef.path; 
                 }                 
                 
                 if (itemRef.kind == "storage") {
                    typeBox.innerHTML =  itemRef.type;
                 }

                 if (itemRef.kind == "relatedEntities" && !itemRef.reversePath) {
                     typeBox.innerHTML =  itemRef.path;
                 }
                 
                 if (itemRef.kind == "relatedEntities" && itemRef.reversePath === "false") {
                     typeBox.innerHTML =  itemRef.path;
                 }
                 
                 if (itemRef.kind == "relatedEntities"  && itemRef.reversePath) {
                    typeBox.innerHTML =  itemRef.type;
                 }
                 
                 if (itemRef.kind == "relatedEntity" && itemRef.path.split(".").length > 1) {
                     typeBox.innerHTML =  itemRef.path;
                 }

                 _vu.typeCell(att, true, itemRef.type, false, itemRef.kind);
                 
                 //update path 
                 if (pathBox) {
                     pathBox.innerHTML =  itemRef.path; 
                 }
                 
                 if (conf.lookForExtend) { 
                     extendPath = _g.extendTree(conf.emName);
                     $.each(extendPath, function(index, value) { 
                         $.each(value, function(i, v) { 
                             if ( !_uA.isValueIn( v, other ) ) {
                                 other.push(v);
                             }
                         });
                     });
                      if(!conf.emStart) {
                          conf.emStart = conf.emName;
                      }
                      for( var key in other ) { 
                            _wRefresh({emName : other[key], emStart : conf.emStart, itemName : conf.itemName, type:conf.type, action:"update", isExtend:true, lookForExtend:false, extendFrom : conf.emName, oldValue : conf.oldValue });
                      }
                  }
             }
             
            if (conf.type == "meth") {
                
                if (conf.name) {
                    
                    if (conf.isExtend) {                        
                        itemRef = _g.methodeProperty(conf.extendFrom, conf.itemName, "applyTo");
                        att = $("#entityModels-"+conf.extendFrom+"-"+conf.emName+"-methodP-"+conf.oldValue).get()[0];                        
                        att.id = "entityModels-"+conf.extendFrom+"-"+conf.emName+"-methodP-"+conf.itemName;
                        //att.title = conf.itemName;
                        emEditor.uD.setWafData(att, conf.itemName);
                        var appBox = $(".name", att).get()[0];
                        appBox.textContent = conf.itemName;
                        
                    }else{
                        itemRef = _g.methodeProperty(conf.emName, conf.itemName, "applyTo");
                        att = $("#entityModels-"+conf.emName+"-methodP-"+conf.oldValue).get()[0];
                        att.id = "entityModels-"+conf.emName+"-methodP-"+conf.itemName;
                        emEditor.uD.setWafData(att, conf.itemName);
                        var appBox = $(".editable_input", att).get()[0];
                        appBox.textContent = conf.itemName;
                    }
                      
                   if(!conf.emStart) {
                       conf.emStart = conf.emName;
                   }
                   if(conf.lookForExtend){
                        extendPath = _g.extendTree(conf.emName);
                        $.each(extendPath, function(index, value) { 
                             $.each(value, function(i, v) { 
                                 if ( !_uA.isValueIn( v, other ) ) {
                                     other.push(v);
                                 }
                             });
                        });
                      _wRefresh({emName : other, emStart:conf.emStart, itemName : conf.itemName, type:"meth", action:"update", isExtend:true, lookForExtend:true, extendFrom : conf.emStart, name : true, oldValue:conf.oldValue });
                  }
                    
                }else{ //apply
                    if(conf.isExtend){
                        itemRef = _g.methodeProperty(conf.extendFrom, conf.itemName, "applyTo");
                        att = $("#entityModels-"+conf.extendFrom+"-"+conf.emName+"-methodP-"+conf.itemName);
                        
                        if( _conf.langage.en["applyTo_list"] && _conf.langage.en["applyTo_list"][itemRef] ) {
                            add = _conf.langage.en["applyTo_list"][itemRef];
                        } else {
                            add = apply;
                        }
                        
                        $("td.path", att).get()[0].textContent = add;
                    }else{
                        itemRef = _g.methodeProperty(conf.emName, conf.itemName, "applyTo");
                        att = $("#entityModels-"+conf.emName+"-methodP-"+conf.itemName);
                        var appBox = $("select", att).get()[0];
                        appBox.selectedIndex = $("option[value="+itemRef+"]", appBox).get()[0].index;
                    }
                    if(!conf.emStart) {
                        conf.emStart = conf.emName;
                    }
                    if(conf.lookForExtend){
                            extendPath = _g.extendTree(conf.emName);
                            $.each(extendPath, function(index, value) { 
                                $.each(value, function(i, v) { 
                                    if ( !_uA.isValueIn( v, other ) ) {
                                        other.push(v);
                                    }
                                });
                            });
                          for(var key in other){
                               _wRefresh({emName : other, emStart: conf.emStart, itemName : conf.itemName, type:"meth", action:"update", isExtend:true, lookForExtend:true, extendFrom : conf.emStart });
                          }
                      }
                }

            }
             
            if(conf.type == "extendsViews"){
                 var toUp = $("#"+panelRef.id +" .inheritedHeader .title");
                 for(var u in toUp){
                    if(toUp[u].title == conf.oldValue){
                        toUp[u].title = conf.newValue;
                        toUp[u].innerHTML = "Inherited from&nbsp;<span class='identifying'>"+conf.newValue+"</span>";
                    } 
                 }
                 toUp = $("#"+panelRef.id +" .methodInherited .identifying");
                 for(var up in toUp){
                     if(toUp[up].textContent == conf.oldValue){
                         toUp[up].innerHTML = conf.newValue;
                     } 
                  }
                 
             }
             

         }
         break;
     case "remove" :  
         if(conf.type == "att"){ 

            $( $(conf.table).find("tr")[conf.rowIndex]).animate({
                opacity: 0.1,
                fontSize: "0px", 
            }, 450, function() {
                    $(this).remove();
            });
            emEditor.selectedItems.item = null;
            document.getElementById( _conf.htmlData.currentAttProperties ).style.display = "none";

            if(!conf.emStart) {
                conf.emStart = conf.emName;
            }
            
            extendPath = _g.extendTree(conf.emName);
            $.each(extendPath, function(index, value) { 
                $.each(value, function(i, v) { 
                    if (!_uA.isValueIn( v, other )) {
                        other.push(v);
                    }
                });
            });
            
             $.each(other, function(d, em) { 

                     if (emEditor.editorUI.panel.getPanelRef(em)) {
                         /*$("#"+_conf .htmlData.classEm+"-"+conf.emStart+"-"+em +"-"+_conf .htmlData.classAttribute+"-"+conf.itemName).animate({
                             opacity: 0.1,
                             fontSize: "0px", 
                         }, 450, function() {
                             $(this).remove();
                         });*/

                         //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/
                         $("#"+_conf .htmlData.classEm+"-"+conf.emStart+"-"+em+"-"+_conf .htmlData.classAttribute+"-"+conf.itemName).remove();
                         var element = $(document.body);
                         var n = document.createTextNode(' ');
                         element.get()[0].appendChild(n);
                         var func = function(){
                             n.parentNode.removeChild(n)
                         };
                         func.defer;
                         //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/
                     }
                     

                });

         } else {

           $($("#"+_conf .htmlData.classEm+"-"+conf.emName+"-method-"+conf.itemName)).animate({
                opacity: 0.1,
                fontSize: "0px", 
              }, 450, function() {
                $(this).remove();
              }); 
             /*$($("#"+_conf .htmlData.classEm+"-"+conf.emName+"-methodP-"+conf.itemName)).animate({
                  opacity: 0.1,
                  fontSize: "0px", 
                }, 450, function() {
                  $(this).remove();
                });*/

                //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/
                $($("#"+_conf .htmlData.classEm+"-"+conf.emName+"-methodP-"+conf.itemName)).remove();
                var element = $(document.body);
                var n = document.createTextNode(' ');
                element.get()[0].appendChild(n);
                var func = function(){
                    n.parentNode.removeChild(n)
                };
                func.defer;
                //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/
             
             if(!conf.emStart) {
                 conf.emStart = conf.emName;
             }
             
             extendPath = _g.extendTree(conf.emName);
             $.each(extendPath, function(index, value) { 
                 $.each(value, function(i, v) { 
                    if ( !_uA.isValueIn( v, other ) ) {
                        other.push(v);
                    }
                });
             });

            $.each(other, function(d, em) { 
                
                 if(emEditor.editorUI.panel.getPanelRef(em)) {

                      /*$($("#"+_conf .htmlData.classEm+"-"+conf.emName+"-"+em+"-methodP-"+conf.itemName)).animate({
                              opacity: 0.1,
                              fontSize: "0px", 
                            }, 450, function() {
                              $(this).remove();
                            }); */

                    //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/
                    $($("#"+_conf.htmlData.classEm+"-"+conf.emName+"-"+em+"-methodP-"+conf.itemName)).remove();
                    var element = $(document.body);
                    var n = document.createTextNode(' ');
                    element.get()[0].appendChild(n);
                    var func = function(){
                        n.parentNode.removeChild(n)
                    };
                    func.defer;
                    //***************************** work arround to fix webarea redraw issue !!!!!!!!!! *****************************/       

                  }
                  
            });

             /*while(other) {
                 
             }*/
         }
       
        _h.selectPanel(emEditor.panels[emEditor.panelsRef[conf.emName]].panel, false, false, event);
        
         
         break;
     default:error.log("_windows.refresh ; No action found.");
     }
     
     // update panel (to add in an external function)
     if(document.getElementById(pID)){
        var table, 
            but,  
            container   = $("#"+pID).get()[0],
            allPath     = YAHOO.util.Dom.getElementsByClassName("path", "td", container),
            bd          = YAHOO.util.Dom.getElementsByClassName("bd", "div", container)[0],  //force table to update his width before resizing the panel
            tab         = bd.getElementsByTagName('table'),
            pathW       = 0,
            close       = false, 
            w           = 0, 
            wCont,
            disp, 
            keepState;            
            
        for (var k in allPath) {
          if (allPath[k].offsetWidth > pathW) {
              pathW = allPath[k].offsetWidth;
          }
        }

        //manage panel width
        
        for (var a in tab) {
          if (tab[a].nodeName == "TABLE") {
              tab[a].style.width="auto";
              if (w<tab[a].offsetWidth) {
                  w = tab[a].offsetWidth;
              }
          }
        }

        if (w-pathW < _conf .htmlData.minAttTableWith) {
            w = _conf .htmlData.minAttTableWith
        } else { 
            wCont = w;
        }

        document.getElementById(pID).style.width=w-40+"px"; //w-40

        emEditor.editorUI.panel.manageResizeWidth(container, false, false, true);

        //load the relation curve for this em
        if (emEditor.curve && emEditor.relationCurve) { 
            queued = true;
            $.queued.add(function(){ 
                //_c.loadRelationCurve(false, emEditor.panels[emEditor.emRef[conf.emName]]);
                _c.loadRelationCurve();
            });
        }

        //update preview
        if (conf.isExtend == false || conf.isExtend == undefined) {
            queued = true; 
            $.queued.add(function(){
                emEditor.previewObj.updatePreview();
            });
        }

        if (queued) {
            $.queued.add(function(){ 
                $.queued.clear(); 
            }); 
        }
     }
};

_wRefresh = _windows.refresh;

 })();