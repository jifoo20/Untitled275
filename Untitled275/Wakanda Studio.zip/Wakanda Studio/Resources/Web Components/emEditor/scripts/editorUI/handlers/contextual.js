/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

    _h.contextual = {
        
         maintContainer:function(action, el){  //deprecated !!

             switch (action){
             case "toggleMethView": 
                if(emEditor.displayMethodInPanel){ 
                       emEditor.displayMethodInPanel = false;
                       _u.extraProperties.defineMethodsDisplay("false");
                       emEditor.metTab = new YAHOO.widget.Tab({
                           label: 'Methods',
                           content: '<div id="methodsPanels"></div>',
                           active: false
                       })
                       emEditor.leftTabview.addTab( emEditor.metTab );
                       emEditor.methodContainer = $("#methodsPanels").get()[0];
                }else{
                    emEditor.leftTabview.set('activeIndex', 0); // make tab at index 0 active
                    $(emEditor.metTab["_configs"]["element"]["value"]).remove();
                    emEditor.displayMethodInPanel = true;
                    _u.extraProperties.defineMethodsDisplay("true");
                    $(emEditor.methodContainer).remove();
                }
             break;
             default: console.log("contextual.dock error");
             }
             emEditor.selectedItems.emName = null;
             emEditor.editorUI.reloadCatInUI(true);
         },
         
         dock:function(action, el){ 
             var emName = $(el).attr("data-title");
             switch (action){
             case "extends": 
                 //create a new em extends and then open it
                 _h.click.addNewEm(emName);                
             break;
             case "close": 
                 var pRef = emEditor.editorUI.panel.getPanelRef(emName);
                 _windows.remove(pRef.id);
             break;
             case "open": 
                 emEditor.editorUI.panel.addFocusOrOpen(null, emName, null, false, false, false, false, false); 
             break;
             default: console.log("contextual.dock error");
             }
         }
         
        
    };
})();