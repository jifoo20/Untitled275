/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
        
    /**
    * remove objects from file and from UI as well
    */
    _o.remove = {};
    _oR = _o.remove;
    
    _oR.alert = function() {
        emEditor.toDeleteData = {};
        emEditor.alertMessageDisplayed = false;
        emEditor.alertMessage.hide();
        $(".mask").hide();
    };
    _oR.entityModel = function(e, elem){ 
               
        e.stopPropagation();
        //look for relation attribute user this em
        var tr              = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
            tb              = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
            rowId           = tr.rowIndex,
            emName          = $(tr).attr("data-title"), 
            attsToRemove    = _nav.getAllByEntity(emName), 
            extendsTree     = _g.extendTree(emName),
            o,
            attLength,
            emLength,
            panelID,
            pRef,
            that = this;
            
            emEditor.toDeleteData.emToRemove = [];
            extendsTree = [];
            if (extendsTree.length === 0) {
                extendsTree.push([emName]);
            }

            $.each(extendsTree, function(index, value) { 

                for ( var i in value ) {
                    //attsToRemove = attsToRemove.concat(_nav.getAllByEntity(value[i])); !!!!!!!!
                }
console.log(attsToRemove)
                attLength   = attsToRemove.length;
                emLength    = value.length;

                if( attLength != 0 || emLength != 0 ) {
                    emEditor.toDeleteData.att =  attsToRemove;
                    for ( var j in value ) {
                        if ( !_uA.isValueIn ( value[j], emEditor.toDeleteData.emToRemove )  ) {
                            emEditor.toDeleteData.emToRemove.push(value[j]);
                        }
                    }
                    emEditor.toDeleteData.emName = emName; 
                    emEditor.toDeleteData.elem = elem;
                    if (emLength != 0 && attLength != 0) {
                        emEditor.toDeleteData.type = "entityModelAndAtt";
                    } else if ( emLength != 0 ) {
                        emEditor.toDeleteData.type = "entityModelToRm";
                    } else {
                        emEditor.toDeleteData.type = "entityModel";
                    }

                    for( var j in attsToRemove ) {
                        o = that.getAttributesLinks( attsToRemove[j].emName, attsToRemove[j].attName );
                        if(o){
                            for( var a in o ) {
                                if( o[a].emName != emName ) { //do not take attribute in the current entity, since it will be remove
                                    emEditor.toDeleteData.att.push( o[a] );
                                }
                            }
                        }
                    }      
                    _b.alert( _conf.langage.en.alertTip.deleteDsclassMessage, _o.remove.entityHandler ); 
                } else {
                    
                    pRef = emEditor.editorUI.panel.getPanelRef( emName );
                    ( pRef ) ? panelID = pRef.id : panelID = null;
                    emEditor.toDeleteData = {};
                    emEditor.toDeleteData.type = "oneEntity";
                    emEditor.toDeleteData.emName = emName;
                    emEditor.toDeleteData.tb = tb;
                    emEditor.toDeleteData.rowId = rowId;
                    emEditor.toDeleteData.panelID = panelID;
                    _b.alert( _conf.langage.en.alertTip.deleteDsclassMessage, _o.remove.oneEntity );
                } 
                
            });
            
            if (extendsTree.length === 0) { 
                pRef = emEditor.editorUI.panel.getPanelRef( emName );
                ( pRef ) ? panelID = pRef.id : panelID = null;
                emEditor.toDeleteData = {};
                emEditor.toDeleteData.type = "oneEntity";
                emEditor.toDeleteData.emName = emName;
                emEditor.toDeleteData.tb = tb;
                emEditor.toDeleteData.rowId = rowId;
                emEditor.toDeleteData.panelID = panelID;
                _b.alert( _conf.langage.en.alertTip.deleteDsclassMessage, _o.remove.oneEntity ); 
            }
    };
    _oR.oneEntity = function() { 
        _oR.onlyEntity(emEditor.toDeleteData.tb, emEditor.toDeleteData.rowId, emEditor.toDeleteData.panelID, emEditor.toDeleteData.emName);
        _oR.alert();
    };
    /**
    * remove an entity Model, UI and file as well, handle the extends
    * @param {html object} tb html table  
    * @param {number} rowId row id
    * @param {string} panelID id of the em's panel
    * @param {string} emName
    */
    _oR.onlyEntity = function( tb, rowId, panelID, emName ) {   
        //rm alert
        _oR.alert();
        //rm line
        if( tb ) {
            tb.deleteRow(rowId);
        }
        
        //rm panel if opened
        //var panelID = emEditor.editorUI.panel.getPanelRef(emName).id; 

        var pRef = emEditor.editorUI.panel.getPanelRef(emName);
        if(pRef != null){ 
            _windows.remove(pRef.id, false, true);
        }
        
        //rm data
        _u.remove.entity(emName);
        
        //remove extended if needed
        /*var others = _check.whosExtends(emName);
        for(var key in others){
            _u.remove.entityProperty(others[key], "extends");
        }*/

        //update display
        //_windows.reLoad(emName, true, others); 
        _h.selectModel(event);
    };
            
    _oR.onlyAttribute = function(table, rowindex, emName, attName){

        var attName     = emEditor.toDeleteData.attName,
            emName      = emEditor.toDeleteData.emName,
            table       = emEditor.toDeleteData.table,
            rowindex    = emEditor.toDeleteData.rowindex,
            isPk        = false;
        
        if (_g.primKey("DataClass1") === attName) {
            isPk = true;
        }
            
        $(".ac_results").remove();
        _u.remove.attributes(emName, attName);
        emEditor.toDeleteData = {};
        _oR.alert();
        
        var extendPath = _g.extendTree(emName);
        var other = [];
        $.each(extendPath, function(index, value) { 
            $.each(value, function(i, v) { 
                if (!_uA.isValueIn( v, other )) {
                    other.push(v);
                }
            });
        });
        
        $.each(other, function(idx, o) { 
            _u.remove.attributes(o, attName);
        });
        
        //manage errors
        if (isPk) {
            emEditor.errorManager.addError({
               "class"        : emName,
               "message"      : "key"    
            },
            false);
        }
        emEditor.errorManager.lookForErrorToRemove( emName, "type", attName );
        
        setTimeout(function() { 
            _wRefresh({emName : emName, itemName:attName, type:"att", action:"remove", lookForExtend:true, "table": table, "rowIndex": rowindex});
            //load the relation curve for this em
            /*if(emEditor.curve && emEditor.relationCurve){ 
                _c.loadRelationCurve();
            }*/
        },0);


    };
    /**
    * handler call by the alert window before deleting an entity model involved in relation attributes
    */
    _oR.entityHandler = function() { 

        var elem    = emEditor.toDeleteData.elem,
            tr      = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
            tb      = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
            rowId   = tr.rowIndex,
            emName  = emEditor.toDeleteData.emName,
            panelID = emName+"-"+_conf .htmlData.classEm,
            atts    = emEditor.toDeleteData.att, 
            trAtt,
            emToRemove = emEditor.toDeleteData.emToRemove;
            
        for(var k in atts){
            trAtt = $("#entityModels-"+atts[k].emName+"-attribute-"+atts[k].attName).get()[0];
            if (trAtt) {
                _wRefresh({emName : atts[k].emName, itemName:atts[k].attName, type:"att", action:"remove", lookForExtend:true, "table": trAtt.parentNode.parentNode, "rowIndex": trAtt.rowIndex});
            }
            _u.remove.attributes(atts[k].emName, atts[k].attName);
        }

        //remove the alert
 
        setTimeout(function() {  
            _oR.onlyEntity(tb, rowId, panelID, emName);  
            if( emToRemove ) {
                $.each(emToRemove, function(index, value) { 
                    var ref = emEditor.editorUI.panel.getPanelRef( value );
                    $("#outline_"+value).remove();
                    if (ref) {
                        _oR.onlyEntity(null, null, ref.id, value);
                    }
                    
                });
            }
            _oR.alert();
        },0);
        
    };
            
    _oR.attributeHandler = function(){ 

            var table,
                rowindex,
                emName  = emEditor.toDeleteData.emName,
                atts    = emEditor.toDeleteData.att,
                pRef;
            
            $(".ac_results").remove();//rm ac if needed
                       
            _oR.alert();
                            
            $.each(atts, function(index, value) {
                pRef = emEditor.editorUI.panel.getPanelRef(value.emName);
                if (pRef) {
                    table =  $("#"+pRef.id+' .attributesTable').get()[0];
                    rowindex = $("#entityModels-"+value.emName+"-attribute-"+value.attName).get()[0].rowIndex;
                }
                _u.remove.attributes(value.emName, value.attName);
                
                //lookForErrorToRemove( value.emName, kind, value.attName )
                _wRefresh({emName : value.emName, itemName:value.attName, type:"att", action:"remove", lookForExtend:true, "table": table, "rowIndex": rowindex});   
            });
        
            //remove the alert
            _oR.alert();

    };
            
    _oR.type = function(table, rowindex, tr) { 
        $("#"+tr.id).btOff();
        table.deleteRow(rowindex);
        emEditor.selectedItems.type = null;
        emEditor.selectedItems.emName = null;
        if(emEditor.propertiesPanel){emEditor.propertiesPanel.hide(); emEditor.propertiesPanel = null;}
        _u.remove.type($(tr).attr('bt-xtitle'));
    };
            
    _oR.attribute = function(table, rowindex, tr, proposal ) { 
                  
        var jqTr = $(tr);
        if(jqTr.hasClass("notSaved")){
            $("#"+tr.id).btOff();
            jqTr.remove();
            if($(".ac_results")){
                $(".ac_results").remove();
                emEditor.onEditBox = {oldValue:null, ref:null};
            }
        }else{
            var attName = emEditor.uD.getWafData(tr); 
             
            var emName = emEditor.selectedItems.emName;
           
            //look for other att using it as navigation att
            var otherAttToRm = this.getAttributesLinks(emName, attName);

            if(!otherAttToRm){
                emEditor.toDeleteData = {};
                emEditor.toDeleteData.attName = attName;
                emEditor.toDeleteData.emName = emName; 
                emEditor.toDeleteData.table = table;
                emEditor.toDeleteData.rowindex = rowindex;
                emEditor.toDeleteData.type = "oneAttribute";
                if( proposal ) {
                    _b.alert("<span></span>"+emEditor.toDeleteData.attName +_conf.langage.en.alertTip.deleteAttributeMessageAsking, _oR.onlyAttribute);
                } else {
                    _b.alert("<span></span>"+_conf.langage.en.alertTip.deleteAttributeMessage, _oR.onlyAttribute);
                }
                
            }else{
                emEditor.toDeleteData.att = otherAttToRm;
                emEditor.toDeleteData.att.unshift({emName:emName, attName:attName});
                emEditor.toDeleteData.emName = emName; 
                emEditor.toDeleteData.elem = tr;
                emEditor.toDeleteData.type = "attribute";
                _b.alert("<span></span>"+_conf.langage.en.alertTip.deleteAttributeMessage, _oR.attributeHandler);
            }
        }
    };

            
    _oR.getAttributesLinks = function( emName, attName ) { 

                var otherAttToRemove = [],
                    attParams;
                    
                switch( _g.emAttPropertyValue(emName, attName, "kind") ){
                case _conf.xmlData.relatedEntity: 
                case _conf.xmlData.relatedEntities : 
                    otherAttToRemove = _nav.getPathTree(emName, attName, false, emName);
                    break;
                case _conf.xmlData.storage : 
                    otherAttToRemove = _nav.flattenedPathTree(emName, attName);
                    break;     
                default: //computed && flattened

                }   

                /*if (_conf.xmlData.relatedEntities === "relatedEntities") {
 
                    attParams = _g.emAttribute(emName, attName);
                    if (attParams.path.split(".").length === 1) {
                        if (attParams.reversePath || attParams.reversePath === "true") {
                            if (_nav.getPathTree(attParams.type, attParams.path).length === 0) {
                                otherAttToRemove.push({
                                    attName: attParams.path,
                                    emName: _g.dataClassName(attParams.type),
                                    path: attParams.path
                                });
                            }
                        }
                    }
                }*/

                if( otherAttToRemove.length < 1 ) {
                    otherAttToRemove = false;
                }

                return otherAttToRemove;
    };
            
    _oR.method = function( table, rowindex, tr ) {

        emEditor.toDeleteData.methName = emEditor.uD.getWafData(tr);
        emEditor.toDeleteData.elem = tr;
        emEditor.toDeleteData.table = table;
        emEditor.toDeleteData.rowindex = rowindex;
        emEditor.toDeleteData.type = "method";
        _b.alert("<span></span>Deleting a method...", _oR.methodHandler); 
          
    };
    
    _oR.methodHandler = function() {
        var tr = emEditor.toDeleteData.elem;
        var methName = emEditor.toDeleteData.methName;
        var rowindex = emEditor.toDeleteData.rowindex;
        var emName = emEditor.selectedItems.emName;
        var table = emEditor.toDeleteData.table;
        //table.deleteRow(rowindex);
        emEditor.selectedItems.item = {};
        emEditor.toDeleteData = {};
        
        //emEditor.editorUI.handler.selectPanel(pRef);
        _u.remove.method(emName, methName);
        //remove the alert
        _oR.alert();
        _wRefresh({emName : emName, itemName:methName, type:"meth", action:"remove", table:table, rowIndex:rowindex, lookForExtend:true});

        var pRef = emEditor.editorUI.panel.getPanelRef(emName);
        _h.selectPanel(pRef.panel);
    }
    
    
    
})();