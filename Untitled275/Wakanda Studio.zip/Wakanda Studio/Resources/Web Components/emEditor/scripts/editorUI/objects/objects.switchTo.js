/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
    _o.switchToEditMode = function( elem, e ) { 

            if ($(".editable_input.relPath").get()[0]) {
                return false;
            }
            
            if ($(elem).hasClass("notes")) {
                emEditor.onEditBox = {
                    oldValue    : null, 
                    ref         : elem,
                    emName      : emEditor.selectedItems.emName,
                    item        : emEditor.selectedItems.item
                };
                return false;
            }
            
            emEditor.studio.editMenu.controleMetaKey(true);
           
            var tr          =   YAHOO.util.Dom.getAncestorByTagName(elem, "tr");
            
            if (!tr) {
                 tr = emEditor.selectedItems.item;
            }
           
            var title       =   emEditor.uD.getElementType(elem), 
                displayAc   =   true,
                container   =   YAHOO.util.Dom.getAncestorByClassName(elem, "yui-module"),
                module      =   YAHOO.util.Dom.getAncestorByClassName(tr, "yui-module"),
                ancestorTable,
                emName      = emEditor.editorUI.panel.getActiveElemName(),
                emNameCheck = tr.id.split("-")[1],
                autoc;

            if( emEditor.selectedItems.emName !=  emNameCheck && module && emNameCheck) { //check we are in the right panel
                emEditor.editorUI.panel.addFocusOrOpen(null, emNameCheck, null, false, false, false, false, false); 
                _o.selectRow(tr, false, false);
                emName = emNameCheck;
            }
            
            if( module ) { 
                _conf.autocompletionRenderID = document.getElementById(module.id); 
                emEditor.acPos = "em";
            } else {   
                ancestorTable = YAHOO.util.Dom.getAncestorByTagName(elem, "table");
                
                if( ancestorTable ) {
                    if( ancestorTable.id === "typePropertiesTable" ){
                        _conf.autocompletionRenderID = document.body; 
                        emEditor.acPos = "type";
                    } else { 
                        _conf.autocompletionRenderID = document.getElementById(_conf.htmlData.propertiesContainerID);
                        emEditor.acPos = "prop";
                    }
                }
                
            }

            if ((title === "type" || title === "path") && elem.nodeName == "DIV") { //type case
                
                if( YAHOO.util.Dom.hasClass(tr, "onProcess") ) { 
                    YAHOO.util.Dom.removeClass(tr, "onProcess");
                }

                var val  = elem.innerHTML, 
                    cont = elem.parentNode,
                    toCreate;
                    
                emEditor.editorUI.dom.removeNode(cont, elem);
                cont.innerHTML = '<input title="'+title+'" type="text" class="editable_input" value="'+val+'"/>';
                var inp = cont.firstChild; 
                inp.id=emEditor.ids++;
                autoc = _aC.init(inp.title, inp.id, true);
                YAHOO.util.Event.addListener(inp, "keydown", function (e) {_h.key.press(e, this);});
                YAHOO.util.Event.addListener(inp, "blur", function (e) { _h.blur.main(e, this);});

                if (title === "path") {
                    YAHOO.util.Dom.addClass(inp, "relPath");
                    var t = _aC.buidItemsList(null,inp.title, inp.id);
                    toCreate = YAHOO.util.Dom.getElementsByClassName("editable_input2", "div", tr)[0].innerHTML;

                    if (t === "create") {
                        var sn = emEditor.editorUI.panel.getActiveElemName(); //_g.manyName(
                        inp.value = sn[0].toLowerCase()+sn.substring(1,sn.length);
                        $("#"+inp.id).setOptions({noresultsmsg: 
                            "There is no relation attribute available in <span style='color:blue'>"+toCreate+"</span>. "+
                            "Press Enter to create the <span style='color:red'>"+inp.value+"</span> relation attribute in <span style='color:blue'>"+toCreate+"</span>."
                        }); 
                        displayAc = false;
                    }else{
                        //juste add if needed  
                        var target      = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable+"2", "div", tr)[0].textContent,
                            addNEwAtt   = true,
                            addVal      = emEditor.editorUI.panel.getActiveElemName(),
                            lowerAddVal = addVal[0].toLowerCase()+addVal.substring(1,addVal.length),
                            tpName      = lowerAddVal,
                            c           = 1, 
                            go          = false;
                        
                        while(!go){
                            if(_uA.isValueIn(tpName, t)){
                                tpName = lowerAddVal + "_" + c;
                                c++;
                            }else{
                                go = true;
                                lowerAddVal = tpName;
                            }
                        }
                        
                        if(addNEwAtt){
                            t = t.concat(lowerAddVal);
                            $("#"+inp.id).setOptions({
                                data: t, 
                                endmsg : 
                                        "Choose a relation attribute available in <span style='color:blue'>"+toCreate+"</span>. "+
                                        "Choose <span style='color:red'>"+lowerAddVal+"</span> in order to create a new n->1 relation in <span style='color:blue'>"+toCreate+"</span>."
                            });
                        }
                        
                    }
                }else{
                    _aC.buidItemsList(null,inp.title, inp.id);
                }
                elem = inp;
                emEditor.onEditBox = {
                    oldValue    :val, 
                    ref         :inp,
                    emName      : emEditor.selectedItems.emName,
                    item        : emEditor.selectedItems.item
                };
                this.setInputWidth(inp);
                inp.select();
            }else{      

                if (emEditor.onEditBox && emEditor.onEditBox.ref != elem) { 
                    emEditor.onEditBox = {
                        oldValue    :elem.textContent, 
                        ref         :elem,
                        emName      : emEditor.selectedItems.emName,
                        item        : emEditor.selectedItems.item
                    };
                    _aC.buidItemsList(null, "extends", elem.id, null);
                }else{  
                    YAHOO.util.Dom.removeClass(elem, "errorText"); 
                    YAHOO.util.Dom.removeClass(YAHOO.util.Dom.getAncestorByTagName(elem, "tr"), "onProcess");
                    if(title == "type"){
                        if (elem.value == "...") {
                            elem.value="";
                        }
                        this.manageTypeInput(elem, false, false, true); 
                    }
                }
            }
            
            //resize panel if needed
            if(container){
                emEditor.editorUI.panel.manageResizeWidth(container, false);
            }

            //display ac if needed
            if(YAHOO.util.Dom.hasClass(elem, "relPath")){                    
                setTimeout(function() { /* keep this timeout */
                     _aC.display($("#"+elem.id))
                 },0);
            }
    };

    _o.switchToEditType = function( tr, noFocus ) {
       
        emEditor.studio.editMenu.controleMetaKey(true);
        
        var td = YAHOO.util.Dom.getElementsByClassName("path", "td", tr)[0],
            elem = YAHOO.util.Dom.getElementsByClassName("editable_base", "div", td)[0].firstChild,
            ac;
        
        elem.value = "";
        elem.select();
    
        if(!elem.id){
            YAHOO.util.Dom.addClass(elem, _conf .htmlData.contentEditable);
            //add events
            elem.id=emEditor.ids++;
            var autoc = _aC.init(emEditor.uD.getElementType(elem), elem.id, true);
            YAHOO.util.Event.addListener(elem, "keydown", function (e) {_h.key.press(e, this);});
            YAHOO.util.Event.addListener(elem, "blur", function (e) { _h.blur.main(e, this);}); 
            _aC.buidItemsList(null, emEditor.uD.getElementType(elem), elem.id);  

        }
    
        ac = $("#"+elem.id);
        //display autocomp
        _aC.display(ac);
        
        if(!_check.doesExtends(emEditor.editorUI.panel.getActiveElemName())){
            //select string by default *********/ 
            //ac.getSelected();
           // while(emEditor.currentAutoCompSel != _conf.defaultAcValue){
                ac.setSelected();
                //ac.getSelected();
            //}
        }
        
        setTimeout(function() { /* keep this timeout */
            elem.select();
            emEditor.onEditBox.ref = elem;
            emEditor.onEditBox.oldValue = "";
        },0);                               
    };
    
    _o.switchToEditKind = function( tr, noFocus ) {
        //look kind nature : is Em, is scalar or custom.
        var td = YAHOO.util.Dom.getElementsByClassName("kind", "td", tr)[0];
        var elem = YAHOO.util.Dom.getElementsByClassName("editable_shawdow", "div", td)[0].firstChild;
        if( !elem.id ) {
            elem.contentEditable = true;
            YAHOO.util.Dom.addClass(elem, _conf .htmlData.contentEditable);
            //add events
            emEditor.editorUI.views.listenner.listenners(elem);               
        }

        if( !noFocus ){ elem.focus(); }else{ elem.innerHTML="..."; }
    };
    
    _o.switchToEditPath = function( elem, edit ) { 

        var val = elem.value,
            cont = elem.parentNode,
            el,
            pathDiv;
        
        emEditor.editorUI.dom.removeNode(cont, elem);
        cont.innerHTML = "<div title='type' contentEditable='true' class='"+_conf.htmlData.contentEditable+"2'>"+val+"</div>";
        //YAHOO.util.Event.addListener(cont.firstChild, "focus", function (e) { _o.switchToEditMode(this, e); });

        //add proper field for path
        
        pathDiv = $(cont.parentNode).find("div.pathMany");

        if (edit || pathDiv.length === 0) {
            
            if( pathDiv.length > 0 ) {
                el =  pathDiv.get()[0];
            } else {
                el = emEditor.editorUI.views.add.pathFieldForMany(YAHOO.util.Dom.getAncestorByTagName(cont, "td"));
            }

            setTimeout(function() { _o.switchToEditMode( el ); },0);
        }
                          
        
    };
    
})();