/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function($){
    /*
    * Usage :
    * triggerElem is the ID of the container to move. "handMove" will change the sroll values of it's parent if needed. 
    * triggerKey is the value of the keycode witch allow to scroll (default to 32)
    */
    
    /**
    * init the sroll object
    * @param {object} options { triggerElem:id,  triggerKey: keyCode}
    */
	$.fn.handMove = function(options) {

		//set var
		var triggerID = this[0].id,
		    triggerElem = $("#"+triggerID),
		    triggerElemDom = triggerElem.get()[0],
		    triggerElemParent,
		    body = $(document.body),
		    key = 32,
		    keyPressed = false,
		    mouseD = false,
		    prevX = 0,
		    prevY= 0,
		    prevScrollX = 0,
		    prevScrollY = 0,
		    moving = false;  
		
		if(options && options.triggerKey){
		    key = options.triggerKey;
		}      
		
		//set mouse move event
        triggerElem.mousemove(function(e){ 
            
            
			if(keyPressed && mouseD){
                
			   if( e.srcElement.nodeName === "svg" ) { //e.currentTarget.id === e.srcElement.id || prevX!=0 || prevY !=0

			       //triggerElem.css("cursor", "-webkit-grabbing");
			      
    			   var diffX =  e.clientX - prevX;
    			   var diffY =  e.clientY - prevY;
    			   
    			   triggerElemParent = triggerElemDom.parentNode;
    			   
    			   prevScrollX = triggerElemParent.scrollLeft;
    			   prevScrollY = triggerElemParent.scrollTop;
    			   prevX = e.clientX;
    			   prevY = e.clientY;

    			  if(diffX != e.clientX || diffY != e.clientY){ 

                        if(triggerElemParent.scrollLeft == 0 && triggerElemDom.offsetLeft >= 0){
                             triggerElemDom.style.left = triggerElemDom.offsetLeft + diffX + "px";
                        }else{
                            triggerElemDom.style.left = 0+"px";
                            triggerElemParent.scrollLeft = prevScrollX - diffX;
                        }   
                        
                        if(triggerElemParent.scrollTop == 0  && triggerElemDom.offsetTop >= 0){
                                triggerElemDom.style.top = triggerElemDom.offsetTop + diffY + "px";
                        }else{
                            triggerElemDom.style.top = 0+"px";
                            triggerElemParent.scrollTop = prevScrollY - diffY;
                        }
                     
    			  }
			  }
			}
			
	 	});
	 	
	 	//set mouse down event
	 	triggerElem.mousedown(function(e){ 
			mouseD = true;
	 	});
	 	
	 	//set mouse up event
	 	body.mouseup(function(e){ 
			mouseD = false;
			prevX = 0;
			prevY = 0;
			setPositionToZero();
	 	});
	 	
	 	//set keydown on body
	 /*	body.keydown(function(e){ 

	 	    if(e && e.srcElement && e.srcElement.nodeName != "BODY"){
	 	        //e.preventDefault(); //temp to remove
	 	        //e.stopPropagation(); 
	 	    }
            
			if(e && e.srcElement && e.keyCode === key && e.srcElement.nodeName == "BODY"){ // && e.srcElement.nodeName == "BODY"
			    e.preventDefault();
			    e.stopPropagation();
			    
			    if(keyPressed != true){
			        triggerElem.css("cursor", "move"); //-webkit-grab
    			    //triggerElem.css("cursor", "-webkit-grab"); //-webkit-grab
			    }
			    
			    keyPressed = true;
			    
			}else{

			    keyPressed = false;
			}
			
	 	});*/
	 	
	 	//set keydown on body
	 	body.mousedown(function(e){ 

			//if(e && e.srcElement && keyPressed){ // && e.srcElement.nodeName == "BODY" 
			//    e.preventDefault();
			//    e.stopPropagation();
			    
			//    if(keyPressed != true){
    		//	    body.css("-webkit-user-select", "none");
			//    }
			    
			//}

			if(e && e.srcElement && e.srcElement.nodeName === "svg"){ 
			    //e.preventDefault();
			    //e.stopPropagation();
			    if(keyPressed != true){
			        triggerElem.css("cursor", "move"); //-webkit-grab
    			    //triggerElem.css("cursor", "-webkit-grab"); //-webkit-grab
			    }
			    
			    keyPressed = true;
			    
			}else{

			    keyPressed = false;
			}
			
	 	});
	 	
	 	//set keydown on body
	 	body.mouseup(function(e){ 

			if(e && e.srcElement){ // && e.srcElement.nodeName == "BODY"
			    
			    if(keyPressed == true){
			        triggerElem.css("cursor", "auto"); //-webkit-grab
    			    //triggerElem.css("cursor", "-webkit-grab"); //-webkit-grab
    			    //triggerElem.css("-webkit-user-select", "none");
    			    body.css("-webkit-user-select", "auto");
			    }
			    
			}
			
	 	});
	 
	 	//set keyup on body
	 	body.keyup(function(e){ 
	 	    e.preventDefault();
            keyPressed = false;
            triggerElem.css("cursor", "auto");
            //triggerElem.css("-webkit-user-select", "auto");
            body.css("-webkit-user-select", "auto");
            setPositionToZero();
	 	});
		
		//revert if needed left and top value
		var setPositionToZero = function(){
		    if(triggerElem.get()[0].offsetTop > 0 || triggerElem.get()[0].offsetLeft > 0 && !moving){
			    moving = false;
			    triggerElem.animate({
                    top: "0px",
                    left: "0px"
                  }, 300, function() {
                    moving = false;
                  });
			}
		}

		//public methods
		/*return this.each(function() {
			this.exemple = function(){};
		});*/
	};
 
})(jQuery);
