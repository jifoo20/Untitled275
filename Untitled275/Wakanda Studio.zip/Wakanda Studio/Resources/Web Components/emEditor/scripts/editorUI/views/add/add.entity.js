/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  
    
    emEditor.editorUI.views.add.entity = {};    

    emEditor.editorUI.views.add.entity.methods = function(tab, inPanel, newName, forRefresh, isHidden, extData, selection){

        var emName,
            apply,
            newRow,
            table,
            from,
            nameForID,
            rmElem,
            idx,
            pRef,
            panelSel,
            add,
            container = null,
            tableJq,
            isInherited = false;
        
        if (!forRefresh) {
            newName = this.getNewName("method");
        }
        
        $("tr.selected").removeClass("selected");
        
        if (extData) {
            emName = extData.extendFrom;
            apply = extData.apply;
            isInherited = true;
        } else {
            emName = emEditor.editorUI.panel.getActiveElemName();
            apply = selection;
        }

        from = _conf .methodPath.nameSpace +"."+ emName +"."+ newName;  
        
        if (!forRefresh) {
            _o.createNewMethod(emName, newName, selection);
        }

        if (tab) { 
            table = tab;  
            tableJq = $(table);
        }
    
        if (table == "toBuild") {
            //build main container
            var content = document.createElement("div");
            YAHOO.util.Dom.addClass(content, "methodsContainer");

            //build table
            table = document.createElement("table");

            //build caption
            var cap = document.createElement("caption");
            if( emEditor.scriptMode ) {
                cap.innerHTML =  "<div class='addElem studio-icon-add'></div>";
            }
            table.className = "methodsTable";
            YAHOO.util.Dom.addClass(cap, "objHeader");
            table.appendChild(cap);
            emEditor.methodsContainer.appendChild(table);
            tableJq = $(table); 
        }
        
        (!inPanel) ? nameForID = "method" : nameForID = "methodP";
                
        if (extData) {
            
            pRef = emEditor.editorUI.panel.getPanelRef(emName)
            panelSel = $("#"+pRef.id).find(".methodsTable tr");
            
            //see the inherited header 
            tableJq.find( ".inheritedHeader."+ extData.from ).show();
            
            $.each( panelSel, function(index, value) { 
              if($(value).hasClass(extData.from)){
                  idx = value.rowIndex;
                  if($(value).hasClass("inheritedHeader") && value.style.display == "none"){
                      value.style.display = "table-row";
                  }
              }
            });
            newRow = table.insertRow(idx+1);
            $(newRow).addClass(extData.from).addClass("methodInherited");
            newRow.id="entityModels-" +extData.from + "-" + emName + "-"+nameForID+"-" + newName;
        }else{
            var l = YAHOO.util.Dom.getElementsByClassName("meth", "tr", table).length;
            newRow = table.insertRow(l);
            newRow.id="entityModels-" + emName + "-"+nameForID+"-" + newName;
        }
        
        if(emEditor.displayMethodInPanel && !extData){
            emEditor.selectedItems.emName = emName;
            emEditor.selectedItems.item = newRow;
        }
        
        emEditor.uD.setWafData(newRow, newName);
        
        $(newRow).addClass("meth");
    
        if(isHidden && inPanel){
            $(newRow).addClass("removedHidden");
        }
    
        newCell = newRow.insertCell(-1);
        //newCell.title="name";
        newCell.className="name";
                
        if(!extData){
            rmElem =    "<div class='removeIcnForAttributes'><div class='removeIcnForAttributesI studio-icon-remove '></div></div>"+
                        "<div class='privateAttKey publicOnServer'></div>";
                      
        }else{
            rmElem = "";
        }
        
        newCell.innerHTML=  rmElem ;

        newCell.appendChild(_b.editableBox("name", newName, false));                    

        if(!extData){
            _b.entity.scopeTootip($(".privateAttKey",newCell));
            editBox = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", newCell)[0];
        }

        newCell = newRow.insertCell(-1);
        newCell.innerHTML='<div class="editScript"></div>';
        newCell.className="type";
        YAHOO.util.Event.addListener(newCell, "click", function (e) {_h.editMethod(this);});
    
        newCell = newRow.insertCell(-1);
        newCell.className="path";
        newCell.title="from";
        
        if( _conf.langage.en["applyTo_list"] && _conf.langage.en["applyTo_list"][apply] ) {
            add = _conf.langage.en["applyTo_list"][apply];
        } else {
            add = apply;
        }

        newCell.innerHTML = add;
        
        if(!extData){
            var edit = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.editableSelect, "select", newCell)[0];
            YAHOO.util.Event.addListener(edit, "change", function (e) { _o.manageTextBox(this);});
            _b.errorMessage.addContextualAlert( newRow, _conf.langage.en.alertTip.nameAlreadyUsed );
        }
        
        //cell needed for view purpose
        if( inPanel ) {
            if(!_extra.panelExtraPro(emName).panel.pathVisible){
                $(newCell).addClass("tableHidden");
            }
            newCell = newRow.insertCell(-1);

            if (!isInherited) {
                newCell.className = 'dragHandle studio-sortable-handle';
            }
            
            
            container = YAHOO.util.Dom.getAncestorByClassName(newRow, "yui-module");
            emEditor.editorUI.panel.manageResizeWidth(container, false);
        }
        
        if(!extData){
            //refresh ui
            if(!forRefresh){
                
                if(inPanel){
                    //replace reload, get ext !   
                    _b.entity.methods(emName, null, null, true);   
                }else{ 
                    var pRef = emEditor.editorUI.panel.getPanelRef(emName);
                    this.methods($("#"+pRef.id+" .methodsTable").get()[0], true, newName, true, isHidden);
                }
                //get extended & refresh them
                var other = _check.whosExtends(emName);
                for(var key in other){
                    _wRefresh( {emName : other[key], itemName : newName, type:"meth", action:"add",  isExtend:true, extendFrom : emName, lookForExtend:true} );
                }
                
                setTimeout(function(){ emEditor.editorUI.utilities.focusContentEditableBox(editBox); }, 0);
                
            }
        }
        
        if (inPanel) {
            if(!isInherited) {
                _o.selectRow($(newRow).get()[0]);
            }
            
            if( emEditor.handlePerms ) {
                _perm.build();
            }
        }
        
        if( tableJq.find("tr").length > 1 ) {
            _windows.makeTableRowDraggable ( tableJq.find("tbody") );
        }
       
        
    };
                             
    emEditor.editorUI.views.add.entity.getNewName = function(obj){ 
    
        var names, 
            name,
            check, 
            n, 
            number = 1,
            i,
            splitValue,
            splitLenght,
            splitCheck;
    
        switch(obj){
        case "em": 
            names = _g.emList();
            name = _conf.langage.en.newName;
            splitValue = "s";
            splitLenght = 2;
            splitCheck = "DataCla";
            break;
        case "att": 
            names = _g.emAttributesList(emEditor.editorUI.panel.getActiveElemName());
            name = _conf .langage.en.newAttName;
            splitValue = "e";
            splitLenght = 1;
            splitCheck = "attribut";
            break;
        case "type": 
            names = _g.typesName();
            name = _conf .langage.en.newType;
            break;  
        case "method": 
            var meth = _g.methodsList(emEditor.editorUI.panel.getActiveElemName());
            names = [];
            if(meth){
                 $.each(meth, function(index, value) { 
                      names.push(value.name); 
                    });
            }else{
                names = [];
            }
            name = _conf.langage.en.newMethod;
            splitValue = "d";
            splitLenght = 1;
            splitCheck = "metho";
            break;      
        default:
        }
    
        for(var k in names){
            
            if( obj == "em") { 
                names[k] = _classes[ emEditor.emRef[names[k]] ]["className"];
            }

            check = names[k].split(splitValue);
            
            if( check[0] == splitCheck ) {
                
                i = parseInt(check[splitLenght]);
                i++;
                if( i > number ) {
                    number = i;
                }
                
            }
        }   
       
        return name+number;
    };
            
    emEditor.editorUI.views.add.entity.attribute = function(table, nextName, noName){

         //remove section on last selected elem
         $(emEditor.selectedItems.item).removeClass("selected");
         emEditor.selectedItems.item                = null;
         emEditor.emPropertiesTable.style.display   = "none";
         emEditor.attPropertiesTable.style.display  = "none";
         emEditor.emEventTable.style.display        = "none";
         emEditor.attEventTable.style.display       = "none";                    

        var n,
            trs = table.getElementsByTagName("tr"),
            lastTR = trs[trs.length-1];
        
        if (lastTR && YAHOO.util.Dom.getElementsByClassName("addNew", "div", lastTR)[0]) { 
            YAHOO.util.Dom.getElementsByClassName("addNew", "div", lastTR)[0].focus();
        } else { 
            emEditor.editorUI.panel.managePathCollumn(emEditor.editorUI.panel.getActiveID(), true);
            var l = YAHOO.util.Dom.getElementsByClassName("mainAttRow", "tr", table).length;
            var newRow = table.insertRow(l);
            newRow.className = "mainAttRow";
            newRow.id = "newAtt";
            _b.errorMessage.addContextualAlert(newRow, _conf.langage.en.alertTip.attAlreadyUsed);
            YAHOO.util.Dom.addClass(newRow, "notSaved");
            YAHOO.util.Dom.addClass(newRow, "mainAttRow");
            newCell2 = newRow.insertCell(-1);
            newCell2.innerHTML= "<div class='removeIcnForAttributes'><div class='removeIcnForAttributesI studio-icon-remove'></div></div><div class='privateAttKey'></div>";
            _b.entity.scopeTootip($(".privateAttKey",newCell2));
            
            if(noName){
                n = "";
            }else{
                (nextName != null) ? n = nextName : n = this.getNewName("att");
            }
            newCell2.appendChild(_b.editableBox('name', n));
            newCell2.className="name";
            newCell3 = newRow.insertCell(-1);
            newCell3.className="type";
            newCell3.innerHTML='<div class="keyIcns"></div><div class="typeIcns"></div>';
            newCell4 = newRow.insertCell(-1);
            YAHOO.util.Dom.addClass(newCell4, "path");
            newCell4.innerHTML=
            '<div class="editable_base" data-info="type">'+ 
            '<input title="type" type="text" class="editable_input"/>'+
            '</div>';
            hideShowCol = newRow.insertCell(-1);
            hideShowCol.className = 'dragHandle studio-sortable-handle';
            hideShowCol.style.width="";

            var sp = YAHOO.util.Dom.getElementsByClassName(_conf.htmlData.contentEditable, "div", newCell2)[0];
            //sp.focus();
            emEditor.editorUI.utilities.focusContentEditableBox(sp);
        }
        if( emEditor.handlePerms ) {
            _perm.hide();
        }
        emEditor.editorUI.panel.manageResizeWidth(YAHOO.util.Dom.getAncestorByClassName(table, "yui-module"), false);
                                        
    };
    
    emEditor.editorUI.views.add.entity.attributeByConf = function( pID, emName, conf , lookForExtend, extendFrom ){ 
                
            var n, 
                l, 
                rowCl, 
                a, 
                manyPath    = null,
                table       = $("#" + pID + " .attributesTable").get()[0],
                trs         = table.getElementsByTagName("tr"),
                lastTR      = trs[trs.length-1];
                
                if (lookForExtend) {
                    a = $("#" + pID + " .attributesTable tr.inherited."+extendFrom);
                    l = a[a.length-1].rowIndex + 1;
                    rowCl = "inherited";
                } else {
                    l = YAHOO.util.Dom.getElementsByClassName("mainAttRow", "tr", table).length;
                    rowCl = "mainAttRow";
                }
                
            var newRow = table.insertRow(l),
                newCell2, newCell3, newCell4, path, visibleType, idClass, cl,
                newRowJq = $(newRow);
                
                switch (conf.kind){ 
                case _conf.xmlData.relatedEntity : 
                    path = conf[_conf .xmlData.relationPath];
                    visibleType = conf.type;
                    idClass = "rel";
                    break;
                case _conf.xmlData.alias : 
                    path = conf[_conf .xmlData.relationPath];
                    visibleType = path;
                    idClass = "flat";
                    break;
                case _conf.xmlData.composition : 
                case _conf.xmlData.relatedEntities : 
                    if(conf.reversePath === "true" || conf.reversePath === true){ 
                        visibleType = conf.type;
                        manyPath = _b.editableBox(_conf .xmlData.relationPath, conf[_conf .xmlData.relationPath], true, "pathMany");
                    }else{
                        visibleType = conf[_conf .xmlData.relationPath];
                    }
                    idClass = "rel";
                    break;
                case "calculated": 
                    visibleType = conf.type; idClass = "calculated";
                    break;    
                default : visibleType = conf.type; idClass = "scal";
            }
            
            //row
            if (lookForExtend) {
                newRow.id = _conf .htmlData.classEm+"-"+ extendFrom +"-"+emName  +"-"+_conf.htmlData.classAttribute+"-"+conf.name;
                newRowJq.addClass(extendFrom);
            } else { 
                newRow.id = _conf.htmlData.classEm+"-"+ _g.dataClassName(emName)  +"-"+ _conf.htmlData.classAttribute +"-"+ conf.name;
                _b.errorMessage.addContextualAlert(newRow, _conf.langage.en.alertTip.attAlreadyUsed);
                newRowJq.addClass(rowCl);
            }
            
            newRowJq.addClass(idClass).addClass(rowCl);
            emEditor.uD.setWafData(newRow, conf.name);
            
            //name cell
            newCell2 = newRow.insertCell(-1);
            newCell2.innerHTML= "<div class='removeIcnForAttributes'><div class='removeIcnForAttributesI studio-icon-remove '></div></div>";
            n = conf.name;
            newCell2.appendChild(_b.editableBox('name', n));
            newCell2.className="name";
            
            //type cell 
            newCell3 = newRow.insertCell(-1);
            if(_check.isType(conf.type)){
                var scalarType = _check.scalarType(conf.type);
                cl = "typeIs"+scalarType;
            }
            
            if( emEditor.emRef[conf.type] != undefined ) { //_check.isEm(conf.type) || _check.isSingleEm(conf.type)
               (conf.kind === "relatedEntity") ? cl = "typeIsRelatedEntity" : cl = "typeIsRelatedEntities";
            }
            if(cl ===  null){
                cl = "typeIsunknown";
            }
            newCell3.className = "type";
            newCell3.innerHTML = '<div class="typeIcns '+cl+'">';

            //path cell
            newCell4 = newRow.insertCell(-1);
            YAHOO.util.Dom.addClass(newCell4, "path");
            newCell4.appendChild(_b.editableBox("type", visibleType, true, null, true));
            if(manyPath){
                newCell4.appendChild(manyPath);
            }
            
            //look if the collumn is hidden or not
            var path = _extra.panelExtraPro(_g.dataClassName(emName)).panel.pathVisible;
            
            if( !path || path === "false" ){
                  $(newCell4).addClass("tableHidden");  
            }
            //hideShowCol
            hideShowCol = newRow.insertCell(-1);
            hideShowCol.style.width="";
            if (rowCl = "mainAttRow") {
                 hideShowCol.className = "dragHandle studio-sortable-handle";
            }
            
            //set events
            if(!lookForExtend){
                var sp = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", newCell2)[0];
                sp.id=emEditor.ids++;
                var autoc = _aC.init(sp.title, sp.id);
                var spIN = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable+"2", "div", newCell4);
            }
            
            //set width                        
            emEditor.editorUI.panel.manageResizeWidth(YAHOO.util.Dom.getAncestorByClassName(table, "yui-module"), false);
      
            //load the relation curve for this em
            if(emEditor.relationCurve === "true"){
                emEditor.relationCurve = true;
            }
            if(emEditor.relationCurve === "false"){
                emEditor.relationCurve = false;
            }

            /*if(emEditor.curve && emEditor.relationCurve){ 
                _c.loadRelationCurve();
            }*/
    };    
            
    emEditor.editorUI.views.add.entity.property = function(table){
                var trs = table.getElementsByTagName("tr");
                var lastTR = trs[trs.length-1];
                if(YAHOO.util.Dom.getElementsByClassName("addNew", "div", lastTR)[0]){
                    YAHOO.util.Dom.getElementsByClassName("addNew", "div", lastTR)[0].focus(); 
                }else{
                    //YAHOO.util.Dom.getElementsByClassName("contentVerticalTitle", "td", table)[0].rowSpan++;
                    var newRow = table.insertRow(-1);
                    newCell2 = newRow.insertCell(-1);
                    newCell2.innerHTML=
                    '<div class="editable_base editable_input_area">'+
                    '<div class="editable_shawdow">'+
                    "<div title='"+_conf .htmlData.newEmProperty+"' contentEditable='true' class='"+_conf .htmlData.contentEditable+" addNew'></div>"+
                    '</div>'+
                    '</div>';
                    newCell2.className="keys";
                    newCell3 = newRow.insertCell(-1);
                    newCell3.className="values";
                    newCell3.innerHTML=
                    '<div class="editable_base editable_input_area">'+
                    '<div class="editable_shawdow" data-info="newEmValue">'+
                    "<div class='"+_conf .htmlData.contentEditable+"'></div>"+
                    '</div>'+
                    '</div>';
                    newCell4 = newRow.insertCell(-1);
                    var sp = YAHOO.util.Dom.getElementsByClassName(_conf .htmlData.contentEditable, "div", newCell2)[0];
                    //YAHOO.util.Event.addListener(sp, "focus", function (e) {_o.switchToEditMode(this);});
                    sp.id=emEditor.ids++;
                    //var autoc = _aC.init(sp.title, sp.id);
                    //YAHOO.util.Event.addListener(sp, "keydown", function (e) {_h.key.forNew(e, this);});
                    //YAHOO.util.Event.addListener(sp, "blur", function (e) { _h.blur.forNew(e, this);});
                    sp.focus();
                }
                                    
    };
        
})();