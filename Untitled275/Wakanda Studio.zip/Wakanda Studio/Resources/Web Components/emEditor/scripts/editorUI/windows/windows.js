/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

   emEditor.editorUI.windows = {};
   _windows = emEditor.editorUI.windows;

    _windows.makeTableRowDraggable = function( elem ) {

        elem
        .sortable( { 
                handle : ".dragHandle",
                revert: true, 
                delay: 200, 
                cancel: '.notSaved',
                start: function( event, ui ) { 
                    //store drag data into the panel object
                    
                    var panel = emEditor.panels[ emEditor.panelsRef[emEditor.selectedItems.emName] ];
                                        
                    ui.helper[0].style.width = $("#"+panel.id+"_c").get()[0].offsetWidth+"px";
                                       
                    panel.onDragItem = {
                        rowindex : ui.placeholder[0].rowIndex,
                        tableType : $(ui.placeholder).closest("table")[0].className
                    }

                },
                stop: function( event, ui ) {  

                    var panel = emEditor.panels[ parseInt(emEditor.panelsRef[emEditor.selectedItems.emName]) ],
                        dragObj = panel.onDragItem;

                    if( dragObj ) {
                        emEditor.editorData.updateCatalog.attributeRowOrder( panel.emName, dragObj.tableType, dragObj.rowindex, ui.item[0].rowIndex+1 );
                        dragObj = null;
                        _c.loadRelationCurve();
                    } else {
                        return false;
                    }

                }    
            } );
        //.disableSelection();
        
    };
        
   _windows.getPanelInitPos = function(){

        var cb = $("#center-body").get()[0];
        var cbp = cb.parentNode;

        cbp.scrollLeft = "0px";
        cbp.scrollTop = "0px";

        var maxX = emEditor.centerBody.body.offsetWidth;
        var maxy = 5000; //emEditor.centerBody.body.offsetHeight; 

        var lineHeight = "300"; 
        var places = [], notReady = true, finded = false, x, y;

        var finalPos = {};

        $.each(cb.childNodes, function(index, value) { 
            if(value.nodeName != "svg" &&  value.nodeName != "#text"){     
                places.push({"startX":value.offsetLeft+220, "endX":(value.offsetLeft+220)+value.offsetWidth, "startY":value.offsetTop, "endY":value.offsetTop+value.offsetHeight});
            }
        });

        var startX, xf;
        var startY, yf;
        var c = 1;

        while(notReady){

            if(c === 1){
                startX = 220;
                startY = 20;
                endX = 300;
                endY = 50;
            }else{
                if(startX > maxX){
                  startY = startY + 50;
                  endY = endY + 50;
                  startX = 220;
                  endX = 300;
                }else{
                  startX = startX + 10;
                  endX = endX + 10;
                }
            }

            $.each(places, function(index, values) { 

                xf = false;
                yf = false;

                if(values.startX < startX && startX< values.endX){
                    xf = true;
                }else if(values.startX < endX && endX < values.endX){
                    xf = true;
                }else if(startX < values.startX && values.startX< endX){
                    xf = true;
                }else if(startX < values.endX && values.endX< endX){
                    xf = true;
                }

                if(xf){
                     if(values.startY < startY && startY< values.endY){
                            yf = true;
                        }else if(values.startY < endY && endY < values.endY){
                            yf = true;
                        }else if(startY < values.startY && values.startY < endY){
                            yf = true;
                        }else if(startY < values.endY && values.endY < endY){
                            yf = true;
                        }
                }

                if(yf && xf){
                    return false;
                }

            });

            c++;
            if(!xf || !yf){
                notReady = false;
                x = startX;
                y = startY;
            }
        }
        
        finalPos.x = x - emEditor.centerBody.getAttributeConfig('left').value - 5; //- cbp.scrollLeft;
        finalPos.y = y //- cbp.scrollTop; 

        return finalPos;
    };
    /**
    * manage resize for panels
    * @param {YUI panel object} panelRef 
    * @param {object} p panel state
    * @param {string} emName panel's entity name
    */ 
    _windows.resize = function (panelRef, p, emName) {

            var pRef = emEditor.editorUI.panel.getPanelRef(emName);
            var resize = new YAHOO.util.Resize(panelRef.id, {
                handles: ["b"],   //'t', 'b', 'r', 'l', 'bl', 'br', 'tl', 'tr'. Defaults to: ['r', 'b', 'br']
                autoRatio: false,
                minHeight: 100,
                minWidth: 170, 
                status: false 
            });

             // Setup startResize handler, to constrain the resize width/height
             // if the constraintoviewport configuration property is enabled.
            resize.on("startResize", function(args) {
                
                var D = YAHOO.util.Dom;
                var clientRegion = D.getClientRegion();
                var elRegion = D.getRegion(this.element);
                if (this.cfg.getProperty("constraintoviewport")) {
                     resize.set("maxWidth", clientRegion.right - elRegion.left - YAHOO.widget.Overlay.VIEWPORT_OFFSET);
                     resize.set("maxHeight", clientRegion.bottom - elRegion.top - YAHOO.widget.Overlay.VIEWPORT_OFFSET);
                } else {
                     
                     var maxH = YAHOO.util.Dom.getElementsByClassName("contentContainer", "div", document.getElementById(pRef.id))[0].offsetHeight+21;
                     resize.set("maxHeight", maxH);
                     resize.set("maxWidth", elRegion.width);
                     resize.set("minWidth", elRegion.width);
                }

            }, panelRef, true);
            
            resize.on("endResize", function(args){

                    var emN = emEditor.editorUI.panel.getPanelRefFromID(args.target["_configs"]["id"]["value"]).emName;
                    _u.extraProperties(args.height, emN);
                    var c = document.getElementById(pRef.id);
                    var b = YAHOO.util.Dom.getElementsByClassName("bd", "div", c)[0];
                    var contH = YAHOO.util.Dom.getElementsByClassName("contentContainer", "div", c)[0].offsetHeight;
                    var contBd = b.offsetHeight;
                    if(contH === contBd){
                        b.style.height = "auto";
                        c.style.height = "auto";
                    }

                    if(emEditor.curve && emEditor.relationCurve){ 
                        _c.loadRelationCurve();
                    }
            });

            // Setup resize handler to update the Panel's 'height' configuration property 
            resize.on("resize", function(args) {
            
                var panelHeight = args.height;
                this.cfg.setProperty("height", panelHeight + "px");
            
            }, panelRef, true);
            //set height if needed (scroll)
            if (p && p.panel && p.panel.resizedHeight && p.panel.resizedHeight != null) {
            
                var pan = document.getElementById(panelRef.id);
                var h = pan.offsetHeight;
                var rh = p.panel.resizedHeight;
                if (h > rh) {
                    pan.style.height = rh+"px";
                    YAHOO.util.Dom.getElementsByClassName("bd", "div", pan)[0].style.height=rh-21+"px";
                } else {
                    _u.extraProperties.resizedHeight(null, emName);
                }
            }   
    };
    /**
    * juste remove the reference to the panel when closing (from "panels")
    * @param {string} id panel id
    */
    _windows.remove = function(id, noHideProp, del, process) { 
        var prop    = false, 
            emName  = null,
            pRef    = emEditor.editorUI.panel.getPanelRefFromID(id),
            emPropTab, 
            attPropTab,
            emProp,
            k, j;
        
        if (pRef) {
            emName = pRef.emName;
            emProp = $(".entityModelsPropertiesName").get()[0];
            
            $("#outline_"+emName + " td").removeClass("selected");
            
            if (emEditor.editorUI.panel.getPanelRefFromID(id).emName == emProp.innerHTML) { 
                if (!noHideProp) { 
                    _o.cleanTableRows(document.getElementById(_conf.htmlData.currentEmProperties));
                }
                _o.cleanTableRows(document.getElementById(_conf.htmlData.currentAttProperties));
            }

            for (var key in emEditor.panels) {
                if(emEditor.panels[key].id == id){
                    if( !prop && !process ){ emEditor.panels[key].panel.destroy(); };    //remove obj from dom
                    emEditor.panels.splice(key,1);
                    break;
                }
            }
            
            //update panels refs
            k = parseInt(key);
            while (emEditor.panels[k]) {
                j = emEditor.panelsRef[emEditor.panels[k]];
                emEditor.panelsRef[emEditor.panels[k].id] = k;
                emEditor.panelsRef[emEditor.panels[k].emName] = k;
                emEditor.panelsRef[_g.collectionName(emEditor.panels[k].emName)] = k;
                k = k + 1;
            }
            
            delete emEditor.panelsRef[id];
            delete emEditor.panelsRef[emName];
            delete emEditor.panelsRef[_g.collectionName(emName)];
                        
            _u.extraProperties.setPanelOpen(false, emName);

            if (emName === emEditor.selectedItems.emName) {
                emEditor.selectedItems = {};
            }
            
         //load the relation curve for this em
            
        if (!process) {

            if(emEditor.relationCurve === "true"){
               emEditor.relationCurve = true;
            }
            if(emEditor.relationCurve === "false"){
                emEditor.relationCurve = false;
            }

            if(emEditor.curve && emEditor.relationCurve){ 
                _c.loadRelationCurve();
            }

            emEditor.previewObj.updatePreview();
            }    
           
        }
        
        if (!emEditor.selectedItems.emName) {
            _h.selectModel();
        }
       
    };
    /**
    * reload the panels in the ui if needed
    * @param {bool} otherWin look if the reloaded em extends others ones
    */
    _windows.reLoad = function(emName, reloadExtendWin, reloadCurEm, rec, addFocus){
        
        if(!addFocus){addFocus = false;}
        var pRef = emEditor.editorUI.panel.getPanelRef(emName);
        
        if(pRef){
            if(reloadCurEm != false){ 
                this.remove(pRef.id, true);
                /*emEditor.panelsRef[_g.manyName(emName)] = -1;
                emEditor.panelsRef[emName] = -1;
                emEditor.panelsRef[pRef.id]= -1;*/
                emEditor.editorUI.panel.addFocusOrOpen(null, emName, pRef.id, null, false, false, true);
            }
        }
        if(reloadExtendWin){
            other = _check.whosExtends(emName);
            for(var key in other){
                 this.reLoad(other[key], false, true, null, false);
            }
        }
    };
    /**
    * hide/show windows by type's groups
    * @param {string} ty type
    */
    _windows.hideShow = function(ty, focus){

        for(var key in emEditor.panels){
            if(emEditor.panels[key].type == ty){

                if(focus){
                    emEditor.panels[key].visible=true;
                    emEditor.panels[key].panel.show();
                }else{
                    if(emEditor.panels[key].visible==true){
                        emEditor.panels[key].visible=false;
                        emEditor.panels[key].panel.hide();
                    }else{
                        emEditor.panels[key].visible=true;
                        emEditor.panels[key].panel.show();
                    }
                }
            }
        }
    };
    /**
    * fit container to inner content if needed   => NOT USE !!
    * @param {object} container
    * @param {object} bd 
    */
    _windows.fit = function(pid){
        var pid = emEditor.editorUI.panel.getActiveID();
        var container = $("#"+pid).get()[0];
        var bd = $("#"+pid + " .bd").get()[0];

        if(container.style.height){
            container.style.height=null;
            container.style.top=null; 
            bd.style.height=null;
        }else{
            YAHOO.util.Dom.addClass(document.getElementById(pid), "hightLightRed");
            setTimeout(function() { YAHOO.util.Dom.removeClass(document.getElementById(pid), "hightLightRed");},400);
        }

        //manage width if needed
        //var scrollL = bd.scrollLeft;
        //if(scrollL != 0){
            //var bdWidth = bd.offsetWidth+scrollL;
            //container.style.width=bdWidth+_conf .htmlData.panelBdMargins+"px";
        //}

    };
    /**
    * add focus to the panel, manage scroll properties, manage user focus feedback
    * @param {object} elem panel
    * @param {string} ty type
    */
    _windows.putFocus = function(panel, ty, noFocusIndicator){ 
        this.manageContainerScroll(panel);
        panel.focus();
        if(!noFocusIndicator){
            YAHOO.util.Dom.addClass(document.getElementById(panel.id), "hightLightRed");
            setTimeout(function() { YAHOO.util.Dom.removeClass(document.getElementById(panel.id), "hightLightRed");},400);
        }

    };
    /**
    * set the container scroll properties
    * @param {yui object} panel panel reference
    */
    _windows.manageContainerScroll = function(panel){ 
        // scrollTo
        emEditor.centerBody.body.scrollLeft = Math.round(panel.element.offsetLeft - (emEditor.centerBody.body.offsetWidth - panel.element.offsetWidth) / 2);
        emEditor.centerBody.body.scrollTop = Math.round(panel.element.offsetTop - (emEditor.centerBody.body.offsetHeight - panel.element.offsetHeight) / 2);
    };
    /**
    * look for the panel object from "panels"
    * @param {string} panelID 
    * @return {object}
    */
    _windows.getPanel = function(panelID){
        var pan = null;
        for(var key in emEditor.panels){
            if(emEditor.panels[key].id == panelID){
                pan = emEditor.panels[key].panel;
                break;
            }
        }
        return pan;
    };
    _windows.updatePanelID = function(panelID, newValue){
        var pan;
        var newID = newValue+"-"+_conf .htmlData.classEm;
        for(var key in emEditor.panels){
            if(emEditor.panels[key].id == panelID){
                emEditor.panels[key].id = newID;
                pan = emEditor.panels[key].panel;
                break;
            }
        }
        var ov = document.getElementById(panelID);
        ov.id = newID;
        pan.id=newID;
        return pan;
    };
    /**
    * look if a the panel is openned or not from panels array
    * @param {string} panelID id of the panel
    * @param {number} ref of the panel in the array "panels" 
    */
    _windows.isPanelOpenned = function(panelID){
        var panelArrayRef = null;
        for(var key in emEditor.panels){
            if(emEditor.panels[key]["id"] == panelID){panelArrayRef = key;}
        }
        return panelArrayRef;
    };

        

})();