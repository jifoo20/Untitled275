/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {  

            _h.click = {};
            
            /**
            * Close all the panels opened
            */
            _h.click.closeAll = function() {
                
                var panToRm = [],
                    process = true;
                    
                $.each(emEditor.panels, function(index, value) { 
                    if(value["id"]){
                        panToRm.push(value["id"]);
                    }
                });
                
                $.each(panToRm, function(i, v) { 
                    _windows.remove(v, false, false, process);
                });
                
                $(".yui-panel-container").remove();
            };
            /**
            * if the row is not selected, the text boxes in it are not editable, but the row is selected
            * @param {event} e mouse event
            * @param {object} target target of the mouse event
            */
            _h.click.preventDefaultRowSelection = function(e, target){
              /*var tr = YAHOO.util.Dom.getAncestorByTagName(target, "tr");
              var sp = tr.id.split("-");
                if(sp[0] === "entityModels" || sp[2] === "method"){
                    if(!YAHOO.util.Dom.hasClass(tr, "selected")){
                        e.stopPropagation();
                         //if(!YAHOO.util.Dom.hasClass(tr, "inherited")){
                             //_o.selectRow(tr, false, false);  
                         //}
                    }
                }*/
            };
            /**
            * allow to change the relation curve params (also called by the studio's toolbar)
            */
            _h.click.changeRelationCurve = function(p_sType, p_aArgs, elem){

                YAHOO.util.Dom.removeClass(YAHOO.util.Dom.getElementsByClassName("state", "div", p_aArgs[1].element.parentNode), "active");
                var st = YAHOO.util.Dom.getElementsByClassName("state", "div", p_aArgs[1].element)[0];
                YAHOO.util.Dom.addClass(st, "active");

                var oEvent = p_aArgs[0],	//	DOM event
        			oMenuItem = p_aArgs[1];	//	MenuItem instance that was the 

        		if (oMenuItem) {
        			var val = oMenuItem.value;
        		}
                switch(parseInt(val)){
                case 0: 
                    emEditor.relationCurve = false;
                    emEditor.editorUI.svgDrowSpace.clear();
                    break;
                case 1: 
                    emEditor.relationCurve = true;
                    emEditor.relationCurveMode = 1;
                    _c.loadRelationCurve();
                    break;
                case 2: 
                    emEditor.relationCurve = true;
                    emEditor.relationCurveMode = 2;
                    _c.loadRelationCurve();
                    break;
                default:
                }

                _u.extraProperties.setRelationState(emEditor.relationCurve, emEditor.relationCurveMode);
            };
            
            _h.click.addEvents = function(p_sType, p_aArgs, type, elem){

                var emName = emEditor.selectedItems.emName, 
                    attributeName,
                    table,
                    val,
                    from,
        		    oEvent = p_aArgs[0],	
        			oMenuItem = p_aArgs[1];

        		if (oMenuItem) {
        			val = oMenuItem.value;
        		}

        		if (type == "em") {

        		} else {
        		    attributeName = emEditor.uD.getWafData( emEditor.selectedItems.item );
        		}

        		//update xml data
                from = _u.events.get(emName, type, val, attributeName);

                if (type == "em") {
                    _b.events.entity(emName);
                } else {
                    _b.events.attribute(emName, attributeName);
                }

            };
            
            _h.click.removeEvents = function(e, elem) { 

                var 
                table   = YAHOO.util.Dom.getAncestorByTagName(elem, "table"),
                tr      = YAHOO.util.Dom.getAncestorByTagName(elem, "tr"),
                ev      = tr.getElementsByTagName("td")[2].dataset.event,
                type,
                emName  = emEditor.selectedItems.emName,
                attributeName,
                from,
                res,
                rm;

                if (table.id == _conf .htmlData.emEventsPanels) {
        		    type = "em";
        		} else {
        		    type = "att";
        		    attributeName = emEditor.uD.getWafData( emEditor.selectedItems.item );
        		}

                //remove from xml data
                from = _u.remove.events(type, emName, ev, attributeName);

                //add removed item to the button
                if (type == "em") {
                   _b.events.entity(emName);
                } else {
                   _b.events.attribute(emName, attributeName);
                }

                res = "";  
                $.each(from.split("."), function(index, value) { 

                  if (value != "methods" && value != "guidedModel" ) {
                     
                      if (index != 1) { res = res + "."; }
                      res = res + value;
                  }

                });
                
                rm = elem.innerHTML = "";

                emEditor.studio.doScript(_conf.studioMessage.removeEvent, res);
            };
            
            _h.click.events = function(e, elem){
                
                var eventKind       = elem.dataset.event,
                    emName          = emEditor.selectedItems.emName,
                    attributeName,
                    tableType       = YAHOO.util.Dom.getAncestorByTagName(elem, "table").id,
                    type;

                if (tableType == "emEventsPanels") {
                    type = "em";
                } else {
                    attributeName = emEditor.uD.getWafData( emEditor.selectedItems.item );
                    type = "att";
                }

                //update xml data
                var from    = _u.events.get(emName, type, eventKind, attributeName),
                    el      = $(elem.firstChild),
                    rm      = elem.previousSibling.previousSibling;

                //update view
                if ($(elem.firstChild).hasClass("createScript")) {
                    rm.innerHTML = "<div class='removeEvent'></div>";
                    $(elem.firstChild).removeClass("createScript");
                    $(rm.firstChild).click(function(e){_h.click.removeEvents(e, this);});
                }
                
                //send edit message to studio
                if (_u.events.isUserDefined(emName, type, eventKind, attributeName)) {
                    emEditor.studio.doScript("gotoDefinition",from);
                } else {
                    _o.editScript(from);
                }


            };

            /**
            * delegate for click
            */
            _h.click.delegate = function(e){
                 
                var tr = YAHOO.util.Dom.getAncestorByTagName(e.target, "tr"),
                    sp, 
                    r, 
                    val, 
                    emName, 
                    attName,
                    oldKey, 
                    activeID,
                    linkedAtributes = [],
                    message;
                
                activeID = emEditor.editorUI.panel.getActiveID()    
                    
                if (tr && e.type == "mousedown") {                     
                    
                    if (activeID) {
                        emName = emEditor.editorUI.panel.getPanelRefFromID(activeID)["emName"];
                    }
                    
                    sp = tr.id.split("-");
                    
                    if(sp[0] === "entityModels" || sp[2] === "methods"){ 

                        if(!YAHOO.util.Dom.hasClass(tr, "selected") && !$(tr.parentNode.parentNode.parentNode).hasClass("methodsContainer") ){ 
                            
                            _o.selectRow(tr, e);
                            e.stopPropagation();
                            e.preventDefault();
                            
                        } else { 
                            
                            if ($(tr).hasClass("noEdit")) {
                                e.stopPropagation();
                                e.preventDefault();
                                return;
                            }

                            if (sp[0] === "entityModels" ) {

                               if ($(event.target).hasClass("editable_input2")) {
                                   
                                   //attName = $(tr).attr("waf-data");
                                   attName = tr.dataset.info;
                                   attData = _g.emAttribute(emName, attName);
                              
                                    if (attData.kind === "relatedEntity") {
                                        linkedAtributes = _nav.getPathTree(emName, attName, true, emName);
                                    } else if ( attData.kind === "storage") {
                                        linkedAtributes = _nav.flattenedPathTree(emName, attName);
                                    }   
                              
                                    if ( linkedAtributes ) {
                                        
                                        if (linkedAtributes.length != 0) {
                                            e.stopPropagation();
                                            e.preventDefault();
                                                                            
                                            message = _conf.langage.en.alertTip.typeUpdate;
                                            $.each(linkedAtributes, function(index, value) { 
                                                message = message + "-<i> "+value.attName+"</i> in the <i>"+value.emName+"</i> class.<br>";
                                            });
                                        
                                            _b.errorMessage.addNotEditableTypeAlert(tr, message);

                                            $(tr).btOn();     
                                        }
                                    }
                                }
                            }
         
                            if( $(e.target).hasClass("keyIcns") ){ 

                                var t = $(e.target).closest(".type");
                                
                                if (!t.hasClass("primKey")) {

                                    r = $(e.target).closest(".mainAttRow"),
                                    val =  emEditor.uD.getWafData( r.get()[0] );   
                                    oldKey = _g.primKey(emName);

                                    //update data
                                    if (val != null && val != "") { 
                                        _u.attributeProperty(emName, _conf.xmlData.primKey, val, "true");
                                        _u.attributeProperty(emName, _conf.xmlData.unique, val, "true");
                                    } 
                                    //update UI
                                    _vu.primKey(emName, val, oldKey);
                                    
                                    emEditor.errorManager.lookForErrorToRemove( emName, "key" );
                                    
                                } else if (t.hasClass("primKey")) { 
                                   
                                    emEditor.errorManager.addError({
                                       "class"        : emName,
                                       "message"      : "key"    
                                    },
                                    false);
                                
                                    r = $(e.target).closest(".mainAttRow");
                                    val =  emEditor.uD.getWafData( r.get()[0] );   
                                    emName = emEditor.editorUI.panel.getPanelRefFromID(emEditor.editorUI.panel.getActiveID())["emName"];
                                    oldKey = _g.primKey(emName);
                                    $(e.target.parentNode.previousSibling).find(".editable_input").removeClass("primKey");
                                    $(e.target.parentNode).removeClass("primKey");
                                    _u.attributeProperty(emName, _conf .xmlData.primKey, val, "true");
                                    _vu.primKey(emName, val, oldKey);
                                    
                                }
                            }
                        }
                    }
                }

                if(e.target.nodeName == "UL"){ 
                    e.stopPropagation();
                    e.preventDefault();
                }

            };
            /**
            * add new type
            */
            _h.click.addNewType = function(){
                var table = document.getElementById(_conf .htmlData.typesTable);
                emEditor.editorUI.views.add.type(table);
            };
            /**
            * add new em
            * @param {string} extendName if needed, create a extend em from this name
            */
            _h.click.addNewEm = function( extendName, name ) {  

                $(".editClassNameInPanel").blur();
                $.queued.add(function(){ 
                     if( emEditor.onEditBox.ref ) {
                         emEditor.onEditBox.ref.blur();
                     }
                 }); 
                $.queued.add(function(){ 
                    if( emEditor.onEditBox.ref ) {
                        emEditor.onEditBox.ref.blur();
                    }
                });
                
                $.queued.add(function(){ 
                     
                     var newName;
                    
                     //extendName
                     if (name) {
                        newName = name;
                     } else {
                        newName = emEditor.editorUI.views.add.entity.getNewName("em");
                     }

                     var 
                     emPos = _u.entity(newName, extendName),
                     i = emEditor.ids++,
                     tab = $("#"+_conf .htmlData.menuTableEm).get()[0],
                     ty = tab.className,       
                     newRow = tab.insertRow(-1),
                     newDiv,
                     col;
                      
                     //newRow.title = newName;
                     $(newRow).attr("data-title", newName); 
                     newRow.id = "outline_"+newName;
                     newRow.className=ty;
                     newCell = newRow.insertCell(-1);
                     newDiv = document.createElement("div");
                     newDiv.className="rmEMButton studio-icon-remove ";
                     newCell.appendChild(newDiv);
                 
                     newDiv2 = document.createElement("div");
                     newDiv2.className = "emMenuList";
                 
                     col = document.createElement("div");
                     col.className = "colPrev";
                     col.style.backgroundColor = _extra.panelColor(newName); //_classes[emPos-1].extraProperties.panelColor;
                     newDiv2.appendChild(col);             
                     newCell.appendChild(newDiv2);
                 
                     $(newDiv2).append("<div class='emName'>"+newName+"</div>");
                 
                     $("#"+newRow.id ).contextMenu({
                           menu: 'panelContMenu'
                       },
                           function(action, el, pos) { 
                               _h.contextual.dock(action, el);
                       });
                   
                     YAHOO.util.Event.addListener(newDiv, "click", function (e) { _oR.entityModel(e, this); });
                     YAHOO.util.Event.addListener(newRow, "click", function(event){ event.stopPropagation(); event.preventDefault(); emEditor.editorUI.panel.addFocusOrOpen(this); });
                 
                     emEditor.editorUI.panel.addFocusOrOpen(null, newName, null, false, false, false, false, true); 

                     if (!name) {
                         //nothing
                     } else{ 
  
                        //reload ui if needed
                        if (emEditor.emToUpdateForUI.length > 0) {
                            for(var k in emEditor.emToUpdateForUI){
                                _windows.reLoad(emEditor.emToUpdateForUI[k], true, true);
                            }
                            emEditor.emToUpdateForUI = [];
                        }
                     }
                     
                     $.queued.clear();
              });
              
                 
            };
            /**
            * add elements on click (attibute or method)
            * @param {html object} elem clicked element
            * @param {string} type class of the clicked element
            */
            _h.click.addOnClick = function(type, ev, selection){ 
               var  aid = emEditor.editorUI.panel.getActiveID(),
                    pan = document.getElementById(aid),
                    tab, 
                    inPanel, 
                    isHidden = false;

                var pref = emEditor.editorUI.panel.getPanelRefFromID(aid);
                if(emEditor.onFlip && emEditor.onFlip.em == pref.emName){
                    _windows.rotate.flip(pref.emName, true)
                }    

               if( pan ) { 
                    var nextName = null;
                    switch ( type ) {
                        case _conf.htmlData.classEm:  //case add an attribute
                            tab = YAHOO.util.Dom.getElementsByClassName("attributesTable", "table", pan)[0];   
                            if($(tab).find(".notSaved").length > 0){
                                $(tab).find(".notSaved").find(".editable_input2").get()[0].focus(); 
                            }else{
                                emEditor.editorUI.views.add.entity.attribute(tab, null);
                            }                         
                        break;
                    case _conf.htmlData.classMeth:   //case add an method

                            if(!ev){
                                if($("#"+aid+" div.objHeader.meth").hasClass("removedHidden")){
                                    inPanel = false;
                                    isHidden = true;
                                    tab = $("#"+emEditor.methodContainer.id +" table");
                                    if(tab){
                                        tab = tab.get()[0];
                                    }else{
                                        tab == "toBuild"
                                    }
                                }else{
                                    inPanel = true;
                                    tab = $("#"+aid+" table.methodsTable").get()[0];
                                }
                            }else{
                                if(!$(ev.srcElement.parentNode).hasClass("meth")){  
                                    tab = YAHOO.util.Dom.getElementsByClassName("methodsTable", "table", pan)[0];
                                    //_h.hidePathCollumn(null, tab, true, false);
                                    if($("#"+aid+" div.objHeader.meth").hasClass("removedHidden")){
                                        isHidden = true;
                                    }
                                    inPanel = false;
                                    tab = YAHOO.util.Dom.getAncestorByClassName(ev.srcElement, "methodsTable"); 
                                    if(!tab){tab = "toBuild";}
                                    
                                }else{
                                    inPanel = true;
                                    tab = YAHOO.util.Dom.getElementsByClassName("methodsTable", "table", pan)[0];
                                    //_h.hidePathCollumn(null, tab, true, false);
                                }
                            }

                            if(!inPanel){
                                if(emEditor.leftTabview.get('activeIndex') != 2){
                                    emEditor.leftTabview.set('activeIndex', 2); // make tab at index 2 active  
                                }
                            }

                            setTimeout(function() { /* keep this timeout */
                                emEditor.editorUI.views.add.entity.methods(tab, inPanel, null, false, isHidden, null, selection);
                                                                            
                            },0);

                        break;
                        default: console.error("handlers.addOnDblClick");
                    }
                }else{
                    //alert("oups ! You have to select an Entity Model first !");
                }
            };
})();