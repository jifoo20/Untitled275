/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
emEditor.getJsonObject           = false;
emEditor.curve                   = true;
emEditor.bezierCurve             = false;
emEditor.displayMethodInPanel    = true;
emEditor.emindex                 = true;
emEditor.handlePerms             = true;
emEditor.allowInheritedSelection = true;

//*** locale format values
emEditor.locale =  ["ae", "at", "au", "de", "dk", "br", "ca", "ch", "cn", "cz", "eg", "fr", "fi", "gb", "gr", "hk", "il", "in", "it", "ja", "ru", "se", "sk", "th", "tw", "us", "vn" ];

//*** config object
emEditor.config  = {
    defaultPresentationValue : "text",
	reservedForAttributs : [

		"getDataClass",
		"getKey",
		"getStamp",
		"getTimeStamp",
		"isLoaded",
		"isModified",
		"isNew",
		"next",
		"refresh",
		"release",
		"remove",
		"save",
		"toString",
		"valid",
		"validate",
		"length",
		"queryPath",
		"queryPlan",
		"add",
		"and",
		"average",
		"compute",
		"count",
		"distinctValues",
		"find",
		"first",
		"forEach",
		"max",
		"min",
		"minus",
		"or",
		"orderBy",
		"query",
		"sum",
		"toArray",
		"all",
		"createEntity",
		"createEntityCollection",
		"fromArray",
		"getFragmentation",
		"getName",
		"getScope",
		"setAutoSequenceNumber",
		"addEntity",
		"addListener",
		"addNewElement",
		"allEntities",
		"autoDispatch",
		"buildFromSelection",
		"calculated",
		"callMethod",
		"declareDependencies",
		"dispatch",
		"filterQuery",
		"getAttribute",
		"getAttributeNames",
		"getAttributeValue",
		"getClassAttributeByName",
		"getClassTitle",
		"getCurrentElement",
		"getDataClass",
		"getElement",
		"getEntityCollection",
		"getID",
		"getOldAttributeValue",
		"getPosition",
		"getSelection",
		"isNewElement",
		"mustResolveOnFirstLevel",
		"newEntity",
		"noEntities",
		"parentCategory",
		"removeAllListeners",
		"removeCurrent",
		"removeListener",
		"resolveSource",
		"select",
		"selectByKey",
		"selectNext",
		"selectPrevious",
		"serverRefresh",
		"setCurrentEntity",
		"setDisplayLimits",
		"setEntityCollection",
		"sync",
		/*"string",
		"number",
		"bool",
		"byte",
		"date",
		"long",
		"long64",
		"duration",
		"image",
		"uuid", 
		"word",
		"blob"*/
	],
	reservedForMethods : [
		"all",
		"average",
		"compute",
		"count",
		"createEntity",
		"createEntityCollection",
		"distinctValues",
		"find",
		"first",
		"forEach",
		"fromArray",
		"getFragmentation",
		"getName",
		"getScope",
		"max",
		"min",
		"orderBy",
		"query",
		"remove",
		"setAutoSequenceNumber",
		"sum",
		"toArray",
		"toString"
	],
	reserved :[
		"dataClasses",
		"close",
		"flushCache",
		"getDataFolder",
		"getModelFolder",
		"getName",
		"getTempFolder"
		/*"length",
		"queryPath",
		"queryPlan",
		"add",
		"and",
		"average",
		"compute",
		"count",
		"distinctValues",
		"find",
		"first",
		"forEach",
		"getDataClass",
		"max",
		"min",
		"minus",
		"or",
		"orderBy",
		"query",
		"remove",
		"sum",
		"toArray",
		"toString",
		"getKey",
		"getStamp",
		"getTimeStamp",
		"isLoaded",
		"isModified",
		"isNew",
		"next",
		"refresh",
		"release",
		"save",
		"valid",
		"validate",
		"addEntity",
		"addListener",
		"addNewElement",
		"all",
		"allEntities",
		"autoDispatch",
		"buildFromSelection",
		"calculated",
		"callMethod",
		"declareDependencies",
		"dispatch",
		"filterQuery",
		"getAttribute",
		"getAttributeNames",
		"getAttributeValue",
		"getClassAttributeByName",
		"getClassTitle",
		"getCurrentElement",
		"getElement",
		"getEntityCollection",
		"getID",
		"getOldAttributeValue",
		"getPosition",
		"getSelection",
		"isNewElement",
		"mustResolveOnFirstLevel",
		"newEntity",
		"noEntities",
		"parentCategory",
		"removeAllListeners",
		"removeCurrent",
		"removeListener",
		"resolveSource",
		"select",
		"selectByKey",
		"selectNext",
		"selectPrevious",
		"serverRefresh",
		"setCurrentEntity",
		"setDisplayLimits",
		"setEntityCollection",
		"sync"
*/
		/*
		"abstract", 
		"boolean", 
		"byte", 
		"char", 
		"break", 
		"class", 
		"case", 
		"catch", 
		"const", 
		"continue", 
		"debugger", 
		"default", 
		"delete", 
		"do", 
		"double", 
		"else", 
		"enum", 
		"export", 
		"extends", 
		"final", 
		"finally", 
		"float", 
		"for", 
		"function", 
		"goto", 
		"if", 
		"in", 
		"instanceof", 
		"int", 
		"interface", 
		"implements", 
		"import", 
		"long",
		"native",
		"new",
		"package",
		"private",
		"protected",
		"public",
		"return",
		"short",
		"static",
		"super",
		"synchronized",
		"switch",
		"this",
		"throw",
		"throws",
		"transient",
		"try",
		"typeof",
		"var",
		"void",
		"volatile",
		"while",
		"with",
		"true",
		"null",
		"false",
		"alert",
		"eval",	
		"Link",	
		"outerHeight",
		"scrollTo",
		"Anchor",
		"FileUpload",
		"location",
		"outerWidth",
		"Select",
		"Area",
		"find",
		"Location",
		"Packages",
		"self",
		"arguments",
		"focus",
		"locationbar",
		"pageXoffset",
		"setInterval",
		"Array",
		"Form",
		"Math",
		"pageYoffset",
		"setTimeout",
		"assign",
		"Frame",
		"menubar",
		"parent",
		"status",
		"blur",
		"frames",
		"MimeType",
		"parseFloat",
		"statusbar",
		"Boolean",
		"Function",
		"moveBy",
		"parseInt",
		"stop",
		"Button",
		"getClass",
		"moveTo",
		"Password",
		"String",
		"callee",
		"Hidden",
		"personalbar",
		"Submit",
		"caller",
		"history",
		"NaN",
		"Plugin",
		"sun",
		"captureEvents",
		"History",
		"navigate",
		"print",
		"taint",
		"Checkbox",
		"home",
		"navigator",
		"prompt",
		"Text",
		"clearInterval",
		"Image",
		"Navigator",
		"prototype",
		"Textarea",
		"clearTimeout",
		"Infinity",
		"netscape",
		"Radio",
		"toolbar",
		"close",	
		"innerHeight",
		"Number",
		"ref",
		"top",
		"closed",
		"innerWidth",
		"Object",
		"RegExp",
		"toString",
		"confirm",
		"isFinite",
		"onBlur",
		"releaseEvents",
		"unescape",
		"constructor",
		"isNan",
		"onError",
		"Reset",
		"untaint",
		"Date",
		"java",
		"onFocus",
		"resizeBy",
		"unwatch",
		"defaultStatus",
		"JavaArray",
		"onLoad",
		"resizeTo",
		"valueOf",
		"document",
		"JavaClass",
		"onUnload",
		"routeEvent",
		"watch",
		"Document",
		"JavaObject",
		"open",
		"scroll",
		"window",
		"Element",
		"JavaPackage",
		"opener",
		"scrollbars",
		"Window",
		"escape",
		"length",
		"Option",
		"scrollBy",
		*/


	],

    notToValidate : {
        emProperty : [
    		"description",
    		"restrictingQuery"	
    	]
    },
    permissions: {
        classes : ["read", "create", "update", "remove"],
        methods : ["execute", "promote"]
    },
    param:{
        scopeDefaultValue: "public",
        scopeDefaultValueForMeth: "publicOnServer",
        panelToolBarShowDelay : "1500" //ms, time before hidding the panel mini toolbar -DEPRECATED-
    },
	bool : [
		"unique",
		"nullable",
		"readonly",
		"not_null",
		"neverNull",
		"textAsBlob",
		"autosequence"
	],
	modelProperty : [
	    {publishAsJSGlobal  : "boolean"},
	    {separator          : ""},
		{notes          	: "string"}
	],
	emProperty : [
			{primKey            :"select"},
			{separator          : ""},
			{className          : "string"},
			{collectionName     : "string"},
			{"extends"          : "string"},
			{separator          : ""},
			{publishAsJSGlobal  : "boolean"},
			{allowOverrideStamp : "boolean"},
			{separator          : ""},
			{scope              :["public", "publicOnServer"]},
			{restrictingQuery   : "string"},
			{defaultTopSize     : "number"},
			{separator          : ""},
			{notes          	: "string"}	
	],
	defaultValues : {
		"defaultTopSize" : "50" //not used
    },	
	scalarTypes : [
		"string", 
		"number",
		"bool",
		"byte",
		"date",
		"long",
		"long64",
		"duration",
		"image",
		"uuid", 
		"word",
		"blob"
	],
	primKeyType : [
	    "string", 
		"number",
		"long",
		"long64",
		"uuid" 
	],
	methEvents: ["onInit", "onLoad", "onValidate", "onSave", "onRemove", "onRestrictingQuery"],
	extendedClassEvents: ["onInit", "onLoad", "onValidate", "onSave", "onRemove", "onRestrictingQuery"],
	attEvents: ["onInit", "onLoad", "onSet", "onValidate", "onSave", "onRemove"],
	attProperties : {
		forRelatedEntities:[
			{composition:"boolean"},
			{reversePath:"boolean"},
			//{cascadingDelete:"boolean"},
			{scope:["private", "protected", "public", "publicOnServer"]}
		],
		forRelatedEntity:[
		    {scope:["private", "protected", "public", "publicOnServer"]}
		],
		forFlattened:[
		    {scope:["private", "protected", "public", "publicOnServer"]},
		    {multiLine          : "boolean"}
		],
		forUUID:[
		    {autogenerate   :"boolean"}
		    ],
		forBool:[
			
		],
		forNumbers:[
			{autosequence       : "boolean"},
			{unique             : "boolean"},
			{separator          : ""}
		],
		forString:[
			
			{textAsBlob         : "boolean"},
			{autoComplete       : "boolean"},
			{unique             : "boolean"},
			{multiLine          : "boolean"},
			{separator          : ""},
			{limiting_length    : "number"}
			
		],
		forScript:[
			{scriptKind:["No Script", "db4d", "javascript"]}			
		],
		forScript:{
			forBool:[
				{scriptKind:["No Script", "db4d", "javascript"]}
			],
			forOther:[
				{scriptKind:["No Script", "javascript"]}
			]
		},
		forDb4D:[
			{onGet:""}
		],
		forJavascript:[
			{onGet  :""},
			{onSet  :""},
			{onQuery:""},
			{onSort :""}
		],
		forDate: [
			{simpleDate   :"boolean"}
		],
		forAll:[
		    {separator          : ""},
			{indexKind  :["btree", "cluster", "keywords", "auto"]},
			{scope      :["private", "protected", "public", "publicOnServer"]},
			{separator          : ""},
			{not_null   :"boolean"},
			{identifying:"boolean"}
		],
		forAllCalculated: [
		    {separator          : ""},
			{scope      :["private", "protected", "public", "publicOnServer"]},
			{separator          : ""},
			{not_null   :"boolean"},
			{identifying:"boolean"}
		]
	},
	methProperties : {
	    scope       :["private", "protected", "public", "publicOnServer"],
	    returnType  :[]
	},
	typeProperties : {
	        common:[
	            {name       :"string"},
			    {"extends"  :"string"}
	            ],
			date:[
				{defaultFormat:{ 
						presentation:["text"],
						locale : emEditor.locale
					}
				}
			],
			string:[
				{fixedLength     :"number"},
				{minLength  :"number"},
				{maxLength  :"number"},
				//{format:[ "capitalize", "uppercase" , "lowercase" ]},
				{separator          : ""},
				{pattern    :"string"},
				{separator          : ""},
				//{enumeration:"string"}
				{defaultFormat:{ 
						presentation:["text"],
						locale : emEditor.locale
					}
				}
			],
			number:[
				{minValue       :"number"},
				{maxValue       :"number"},
				{defaultValue   :"number"},
				{separator          : ""},
				{defaultFormat:{ 
						presentation:["text and slider", "text", "slider"],
						locale : emEditor.locale
					}
				}
			],
			presentation : { 
				"text and slider":{
					format      :"string",
					sliderMin   :"number",
					sliderMax   :"number",
					sliderInc   :"number"
				},
				"text":{
					format      :"string"
				},
				"slider":{
					sliderMin   :"number",
					sliderMax   :"number",
					sliderInc   :"number"
				}
			}
	},
	typePropertiesForAlias : {
	        
			date:[
				{defaultFormat:{ 
						presentation:["text"],
						locale : emEditor.locale
					}
				}
			],
			string:[
				
				{separator          : ""},
				{defaultFormat:{ 
						presentation:["text"],
						locale : emEditor.locale
					}
				}
			],
			number:[
				
				{separator          : ""},
				{defaultFormat:{ 
						presentation:["text and slider", "text", "slider"],
						locale : emEditor.locale
					}
				}
			]
	},
	xmlData:{
	    collection      : "Collection",
		indexKind       : "indexKind",
		primKey         : "primKey",
		relationPath    : "path",
		composition     : "composition",
		relatedEntities : "relatedEntities",
		relatedEntity   : "relatedEntity",
		calculated      : "calculated",
		storage         : "storage",
		alias           : "alias",
		javascript      : "javascript",
		db4d            : "db4d",
		kindRemoved     : "removed",
		xmlAttName      : "name",
		xmlAttType      : "type",
		xmlAttKind      : "kind",
		xmluuid         : "uuid",
		xmlfieldPos     : "fieldPos", //deprecated wak4
		unique          : "unique"
	},
	htmlData:{
		layout:{
			left    :"left",
			right   :"right"
		},
		minInputSizeForType                 : 110,
		manyIndicator                       : "[many]",
		emEventsPanels                      : "emEventsPanels",
		attEventsPanels                     : "attEventsPanels",
		typesTable                          :"typesTable",
		menuTableEm                         : "menuTableEm",
		propertiesContainerID               : "emPropertiesPanel",
		classEm                             : "entityModels",
		classAttribute                      : "attribute",
		contentEditable                     : "editable_input",
		primKeyClass                        : "primKey",
		currentEmProperties                 : "currentEmProperties",
		currentAttProperties                : "currentAttProperties",
		emDockPanel                         : "emDockPanel",
		typesTable                          : "typesTable",
		mainOverlayContainer                : "center-body",
		idTypePanel                         : "waf-type-panel",
		//ids from html markup
		dockEmID                            : "menuTableEm", 					
		dockRelationsID                     : "menuTableRelations",			
		dockTypesID                         : "menuTableTypes",					
		//emDockPanel : "emDockPanel",					
		//class or id name in order to identifying elem in the UI
		classRelation                       : "relations",				
		classType                           : "types",
		classMeth                           : "methods",							
		editableSelect                      : "editableSelect",
		onEditID                            : "onedit",
		newEmProperty                       : "newEmProperty",	
		newEmAttribute                      : "newEmAttribute",
		ajustWidth                          : 25,							//value to add for the width auto ajust
		panelBdMargins                      : 13,						// = left + right margins (see css)
		minAttTableWith                     : 100						// also defined in the css file, class .yui-panel !!
	},
	defaultAcValue          :"string",
	autocompletionRenderID  :"",
	studioMessage:{
	    deleteMethod    : "deleteMethod",
	    deleteEntity    : "deleteEntity",
	    deleteAttribute : "deleteAttribute",
	    renameEntity    : "renameEntity",
	    renameMethod    : "renameMethod",
	    renameAttribute : "renameAttribute",
	    removeEvent     : "removeEvent",
	    editScript      : "editScript",
	    createScript    : "createScript"
	},
	methodPath:{
		param       : ":function(",
		nameSpace   : "guidedModel",
		target      : ["entity", "entityCollection", "dataClass"]
	},
	panelColor:[
	    'fff', 'eee', 'D8D8D8', 'BFBFBF', '7F7F7F', //gray
	    '548DD4', 'B7DDE8', '8DB3E2', 'B8CCE4', //blue
	    '996699', 'B2A2C7', 'E5B9B7', 'CCC1D9', 'D88CFF', //violet
	    '76923C', 'C4BD97', 'D7E3BC', 'C3D69B', '70CCC2', '4FA997', //green
        'E36C09', 'FBD5B5', 'FAC08F', 'FFC000',//yellow
        'FFFF00', 'FFFFCC', 
        'FF4E59', 'C73D45', 'EDAEB1', //red
        'FFE6FF'
    ],
    format : {
        date : {
           text : [
            { value : "MM d, yy",  description : "March 1, 2011", category: ""},
            { value : "d MM yy",   description : "1 March 2011", category: ""},
            { value : "dd/mm/y",   description : "01/03/11", category: ""},
            { value : "dd/mm/yy",  description : "01/03/2011", category: ""},
            { value : "mm/dd/y",   description : "03/01/11", category: ""},
            { value : "mm/dd/yy",  description : "03/01/2011", category: ""},
            { value : "YY",  description : "2011", category: ""},
            { value : "dd/mm",  description : "03/01", category: ""},
            { value : "yyyy/mm/dd",  description : "2011 03 03", category: ""},
            { value : "yy/mm/dd",  description : "11 03 03", category: ""}
           ]
        },
        string : {
            text : [
            { value : "(###) ###-####",  description : "(408) 555-1212", category: "Telephone"},
            { value : "## ## ## ## ##",  description : "44 44 44 44 44", category: "Telephone"}
            ]
        }
    }    
};

_conf = emEditor.config ;

/*
•   d - day of month (no leading zero) 
•	dd - day of month (two digit) 
•	o - day of the year (no leading zeros) 
•	oo - day of the year (three digit) 
•	D - day name short 
•	DD - day name long 
•	m - month of year (no leading zero) 
•	mm - month of year (two digit) 
•	M - month name short 
•	MM - month name long 
•	y - year (two digit) 
•	yy - year (four digit)
*/