/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* get : this part only fetch information from the file, no update here
*/
(function() { 
    emEditor.editorData.get = {
        
           extendTree:function(emName){

              /* var ext = _check.whosExtends(emName);
               var extendsTree = [];
               
               while (ext[0]) {
                   extendsTree.push(ext[0]);
                   ext = _check.whosExtends(ext);
               }*/
               
                var ext,
                    tempExtendsTree,
                    extendsTree     = [],
                    items           = this.isNotExtended(),
                    classToCheck    = null,
                    temp            = [];

                $.each(items, function(index, value) { 

                    tempExtendsTree = []
                    classToCheck = value;
                    tempExtendsTree.push(value);
                    if( value != emName ) {
                        tempExtendsTree = tempExtendsTree.concat(_g.extendParents(value));
                        if (_uA.isValueIn ( emName, tempExtendsTree )) { //tempExtendsTree[tempExtendsTree.length-1] === emName
                            tempExtendsTree.pop();  
                            tempExtendsTree.reverse();
                            temp = $.map( tempExtendsTree, function(val, i) {
                                if (val != emName) {
                                    return val;
                                } else {
                                    return;
                                }
                            });
                            
                            extendsTree.push(temp);
                        }
                    }
                    
                });
                
                return extendsTree;
               
           },
           isNotExtended : function() {
               
                var res = [];
                
                $.each(_classes, function(index, value) { 
                    
                    if( _check.whosExtends(value["className"]).length ===  0 ) {
                        res.push(value["className"]);
                    }
                    
                });       
                
                return res;
           },
           extendParents:function(emName) {
              
               var ext = _check.doesExtends(emName);
               var extendsTree = [];
               
               while (ext) {
                   extendsTree.push(ext);
                   ext = _check.doesExtends(ext);
               }
               
                return extendsTree;
               
           },
            /**
            * look for the primKey in the given Em
            * @param {string} emName 
            * @return {string} 
            */
            primKey:function(emName){ 
                var emPos = this.entityModel(emName), p, res = null, emAttPrim = null;
            
                if(emPos != null){  
                    var emAtt = _classes[emPos]["attributes"];
                    if(_classes[emPos]["key"]){
                        /*** remove KEY node and switch to primKey property if needed / part to update later to handle multiple KEYS ***/
                        res = _classes[emPos]["key"][0]["name"];
                        emAttPrim = this.emAtrribute(emPos, res);
                        delete _classes[emPos]["key"];
                        if(_classes[emPos]["attributes"]){
                            _classes[emPos]["attributes"][emAttPrim][emEditor.config.xmlData.primKey] = true;
                        }
                    }else{ //if no change to do
                        for(var key in emAtt){
                            p = emAtt[key][emEditor.config.xmlData.primKey];
                            if(p){
                                res = emAtt[key]["name"];
                                break;
                            }
                        }
                    }
                }
                return res;
            },
            panelsToOpen: function() {

                var ems = _classes, 
                    result = [], 
                    temp = {},
                    ep,
                    className;
                    
                for(var k in ems){

                    className = ems[k]["className"];

                    if (_classesProperties[className]) { 
                        
                        temp = {};
                        ep = _classesProperties[className];

                        if (ep.panel) {
                                if(ep.panel.isOpen == "true"){
                                    
                                    temp.emName = className;                      
                                    
                                    if(ep.panel.position){
                                        temp.x = ep.panel.position.X;
                                        temp.y = ep.panel.position.Y;
                                    }
                                    result.push(temp);
                                }
                        }
                    }
                }
                
                return result;
            },
            isPanelOpen:function(className){ 

                var result = {};
                
                if (_classesProperties[className]) {
                    
                    var ep = _classesProperties[className];
                    
                    if (ep.panel) {
                        result.isOpen = ep.panel.isOpen;
                        
                        if (ep.panel.position) {
                            result.x = ep.panel.position.X;
                            result.y = ep.panel.position.Y;
                        }
                    }
                }
            
                return result;
            },
            isRemovedVisible:function(className){
                
                var res;
                
                if (_classesProperties[className]) {

                    ec = _classesProperties[className];
                    if (ec.removedVisible === false || ec.removedVisible === "false") {
                        res = false;
                    } else {
                        res = true;
                    }
                }
                
                return res;
            },
            /**
            * get presentation attributes
            * @param {String} pres name of the presentation property
            * @return {array} 
            */
            presentationProp:function(pres){ 
                return emEditor.config.typeProperties.presentation[pres];
            },
            /**
            * find if a method does exist into an entity
            * @param {String} emPos the pos of the em to search in  
            * @param {String} methName the name of the methods to search    
            * @return {number} position of the meth in the array "method"   (could be null) 
            */
            method:function(emPos, methName){

                var 
                l, 
                pos = null;
                
                if (_classes[emPos]["methods"]) {
                    l = _classes[emPos]["methods"].length;
                    for (i=0; i<l; i++) {
                        if (_classes[emPos]["methods"][i]["name"] === methName) {
                            pos = i; 
                            break;
                        }
                    }
                } 
                return pos;
            },
            methodData:function(emName, methName){
                var emPos = this.entityModel(emName), tp, val= null;
                var l = _classes[emPos]["methods"].length, pos=null;
                for(i=0; i<l; i++){
                    if(_classes[emPos]["methods"][i]["name"] == methName){
                        val = _classes[emPos]["methods"][i];
                        break;
                    }
                }
                return val;
            },
            typeProperties:function(type){
                var val = null;
                switch (type){
                    case "string": val = emEditor.config.typeProperties.string; break;
                    case "integer":  
                    case "long":  
                    case "number": 
                    case "double": 
                    case "decimal": 
                    case "money": val = emEditor.config.typeProperties.number;break;
                    case "bool": 
                    case "byte": 
                    case "date": 
                    case "media": 
                    case "time": 
                    case "unit": 
                    case "object": 
                    case "function": val = []; break;
                    default:console.log("typeProperties");
                }
                return emEditor.config.typeProperties.common.concat(val);
            },
            /**
            * find if a type does exist into an entity
            * @param {String} typeName the name of the type to use  
            * @return {number} position of the type in the array "type" (could be null) 
            */
            typePos:function(typeName){
                var pos=null, exist=null;
                if(emEditor.catalog.type){
                    var l = emEditor.catalog.type.length;
                    for(var i=0; i<l; i++){
                        if(emEditor.catalog.type[i]["name"] == typeName){pos = i; break;}
                    }
                }else{
                    emEditor.catalog.type = new Array();
                    pos = null;
                }
                return pos;
            },
            typeByName:function(name){
                return emEditor.catalog.type[this.typePos(name)];
            },
            types:function(){
                if(emEditor.catalog.type){
                    return emEditor.catalog.type;
                }else{
                    return null;
                }
            
            },
            typesName:function(){
                return emEditor.config.scalarTypes.concat(this.customTypes());
            },
            /**
            * return a table of all the computed attributes 
            * @param {number} emID pos of the em    
            * @return {array} computed attributes       
            */
            computedAttributes:function(emID){
                var att = _classes[emID]["attributes"];
                var tab = [];
                for(key in att){
                    if(att[key].kind == "calculated" && att[key].scriptKind==emEditor.config.xmlData.javascript){tab.push(key);}
                }
                return tab;
            },
            methodFrom:function(emName, methName){ 
                var emPos = this.entityModel(emName), from = null;
                var meth = _classes[emPos]["methods"];
                for(var key in meth){
                    if(meth[key].name == methName){
                        from = meth[key].from;
                        break;
                    }
                }
                return from;
            },
            methodsList:function(emName){
                var emPos = this.entityModel(emName);
                if(_classes[emPos]["methods"]){
                    return _classes[emPos]["methods"];
                }else{
                    return null;
                }           
            },
            /**
            * get all the extra properties of the given em  
            * @param {string} emName 
            * @return {object}      
            */
            panelState:function(className, pID){
                
                var pos = {};
                
                /*switch(pID){
                case "waf-type-panel": 
                    pos = emEditor.catalog.type["extraProperties"];
                    break;
                default:
                    var emPos = this.entityModel(emName);
                    pos = _classesProperties[className];
                }*/
                
                if (_classesProperties[className]) {
                    pos = _classesProperties[className];
                }

                return pos;
            },
            panelPosition:function(className, pID){
                
                var pos = {};
                
                /*switch(pID){
                case "waf-type-panel": 
                    if(emEditor.catalog.type["extraProperties"]){
                        ec = emEditor.catalog.type["extraProperties"];
                        if(ec.panel.position){
                            pos.x = ec.panel.position.X;
                            pos.y = ec.panel.position.Y;
                        }
                    }
                    break;
                default:
                    var emPos = this.entityModel(emName);
                    if(_classes[emPos]["extraProperties"]){
                        ec = _classes[emPos]["extraProperties"];
                        if(ec.panel.position){
                            pos.x = ec.panel.position.X;
                            pos.y = ec.panel.position.Y;
                        }
                    }
                }*/

                //var emPos = this.entityModel(emName);

                if (_classesProperties[className]) {

                    ec = _classesProperties[className];
                    if (ec.panel.position) {
                        pos.x = ec.panel.position.X;
                        pos.y = ec.panel.position.Y;
                    }

                }
            
                return pos;
            },
            typeOfAttribute:function(emName, attName){
                var emPos = this.entityModel(emName);
                var emAtt = this.emAtrribute(emPos, attName);
                var extEmn, atts;
                
                if( !emAtt ) {
                    extEm = _check.doesExtends(emName);
                    while(extEm){
                        emPos = this.entityModel(extEm);
                        atts = _classes[emPos]["attributes"];
                        for(var key in atts){ 
                            if(atts[key].name == attName){
                                emAtt = key;
                                break;
                            }
                        }
                        extEm = _check.doesExtends(extEm);
                    }
                }

                return _classes[emPos]["attributes"][emAtt].type;
            },
            /**
            * get all the n->1 relation for the given em
            * @param {String} emName    
            * @return {bool} ext inlude or not the extended ones    
            */
            manyToOnRelation:function(emName, ext){ 
                var emPos;
                var emAtt;
                var res = [];
            
                while(emName){
                    emPos = this.entityModel(emName);
                    emAtt = _classes[emPos].attributes;
                    for (var key in emAtt){
                        if(emAtt[key].kind == "relatedEntity"){
                            res.push(emAtt[key].name);
                        }
                    }
                    (ext) ? emName = _check.doesExtends(emName) : emName = null;
                }

                return res;
            },
            /**
            * get all the relations for the given em (1->n, n->1)
            * @param {String} emName    
            * @return {bool} ext inlude or not the extended ones    
            */
            relations:function(emName, ext, noCollection) { 
                var emPos;
                var emAtt;
                var res = [];

                while(emName) {
                    emPos = this.entityModel(emName);
                    emAtt = _classes[emPos].attributes;
                    for (var key in emAtt){
                        
                        if( noCollection ) {
                            if(emAtt[key].kind == "relatedEntity" || emAtt[key].kind == "alias"){
                                  res.push(emAtt[key].name);
                              }
                        } else {
                            if(emAtt[key].kind == "relatedEntity" || emAtt[key].kind == "relatedEntities" || emAtt[key].kind == "alias"){
                                  res.push(emAtt[key].name);
                              }
                        }
  
                    }
                    (ext) ? emName = _check.doesExtends(emName) : emName = null;
                }

                return res;
            },
            relationShips:function(emName){ 

                    var emPos = this.entityModel(emName);

                    var emAtt = _classes[emPos].attributes;
                    var res = [];
                    for ( var key in emAtt ) {
                        if( emAtt[key].kind == "relatedEntity" || emAtt[key].kind == "relatedEntities" || emAtt[key].kind == "alias" ) {
                                res.push( {type:emAtt[key].type, name:emAtt[key].name, kind:emAtt[key].kind, path:emAtt[key].path} );
                        }
                    } 
                   
                    return res;
            },
            /**
            * find if a type does exist into an entity
            * @param {String} typeName the name of the type to use  
            * @return {number} position of the type in the array "type" (could be null) 
            */
            type:function(typeName){
                var pos=null, exist=null;
                var ty = emEditor.catalog.type;
                if(ty){
                    for(var i in ty){
                        if(ty[i]["name"] == typeName){pos = i; break;}
                    }
                }else{
                    emEditor.catalog.type = new Array();
                    pos = null;
                }
                return pos;
            },
            typePropertyValue:function(typeName, prop, innerProp){ 
                        
                var pos = this.type(typeName), val = null;
            
                if(emEditor.catalog.type[pos][innerProp] && emEditor.catalog.type[pos][innerProp][0]){
                    if(emEditor.catalog.type[pos][innerProp][0][prop]){
                        val = emEditor.catalog.type[pos][innerProp][0][prop];
                    }
                }

                return val;
            },
            customTypeExtend:function(type){
                var typePos = this.type(type);
                if(typePos){
                    return emEditor.catalog.type[typePos]["extends"];
                }else{
                    return false;
                }
            
            },
            /**
            * find all the attributes already used by the attribute
            * @param {String} emName the name of the em to use
            * @param {String} attName the name of the att to use    
            * @return {array}   
            */
            attProperties:function(emName, attName){
                    var emPos = this.entityModel(emName);
                    var attPos = this.emAtrribute(emPos, attName);
                    var att = _classes[emPos]["attributes"][attPos];
                    var result=[];
                    for(var key in att){
                        switch (key){
                        case "uuid":
                        case "type":
                        case "kind":
                        case "name":    
                        case "fieldPos":break;      
                        default:result.push({"key":key, "val":att[key]});   
                        }
                    }
                    return result;
            },
            /**
            * return the value of a computed properties (onget, onset...)
            * @param {String} emName the name of the em to use
            * @param {String} attName the name of the att to use    
            * @param {String} type the properties, onGet, onSet…
            * @return {string} value    
            */
            computedValue:function(emName, attName, type){
                var emPos = this.entityModel(emName);
                var attPos = this.emAtrribute(emPos, attName);
                return _classes[emPos]["attributes"][attPos][type][0]["from"];
            },
            idComputedUserDefined:function(emName, attName, type){
                var emPos = this.entityModel(emName);
                var attPos = this.emAtrribute(emPos, attName);
                return _classes[emPos]["attributes"][attPos][type][0]["userDefined"];
            },
            propertyList4Autocomp:function(type, kind, scriptKind){ 
                
                var res, 
                    val = null, 
                    forAll = "forAll";

                if (scriptKind) {
                    forAll = "forAllCalculated";
                }    
                
                switch (kind){
                    case "calculated" : 
                        (type == "bool") ?  res = emEditor.config.attProperties.forScript.forBool : res = emEditor.config.attProperties.forScript.forOther;
                        if(scriptKind === emEditor.config.xmlData.javascript){
                            res = res.concat(emEditor.config.attProperties.forJavascript);
                        }else{
                            res = res.concat(emEditor.config.attProperties.forDb4D);
                        }           
                        break;
                    case "storage" : 
                        var is= null;
                        if(_check.isInDataList(type, emEditor.config.scalarTypes)){  //is scallare
                            is = "ty";
                        }
                        var custom = this.customTypes();
                        if(_check.isInDataList(type, custom)){   //is custom ????????????
                            is = "ty";              
                            type = this.customTypeExtend(type);
                        }
                        if (is == "ty") { 

                                switch (type){
                                    case "string": val = emEditor.config.attProperties[forAll].concat( emEditor.config.attProperties.forString); 
                                        val = val.concat(emEditor.config.typeProperties.string);
                                        break;
                                    case "long":  
                                    case "long64":
                                    case "float":
                                    case "number": val = emEditor.config.attProperties[forAll].concat( emEditor.config.attProperties.forNumbers); 
                                        val = val.concat(emEditor.config.typeProperties.number);
                                        break;
                                    case "bool": 
                                        val = emEditor.config.attProperties[forAll].concat(emEditor.config.attProperties.forBool); 
                                        break;
                                    case "date":
                                        val = emEditor.config.attProperties[forAll].concat(emEditor.config.attProperties.forDate).concat(emEditor.config.typeProperties.date); 
                                        break; 
                                    case "duration": 
                                        val = emEditor.config.attProperties[forAll].concat(emEditor.config.typeProperties.date); 
                                        break;  
                                    case "uuid": 
                                        val = emEditor.config.attProperties[forAll].concat(emEditor.config.attProperties.forUUID); 
                                        break;    
                                    case "byte": 
                                    case "blob": 
                                    case "image": 
                                    case "word": 
                                    case "function": val = emEditor.config.attProperties[forAll]; break;
                                    default:
                                }
                        }else{
                            //is em
                            var emList = this.emList();
                            if(_check.isInDataList(type, custom)){   //is custom
                                val = emEditor.config.attProperties.forAll;
                            }
                        }
                        res = val;
                        break;
                    case "alias" : 
                        //res = emEditor.config.attProperties.forFlattened;
                        res = emEditor.config.attProperties.forFlattened.concat(emEditor.config.typePropertiesForAlias[type]); 
                        break;    
                    case "composition": 
                    case "relatedEntities" : res = emEditor.config.attProperties.forRelatedEntities; break;
                    case "relatedEntity" : res = emEditor.config.attProperties.forRelatedEntity; break;
                    default : res = null; 
                }
                return res;
            },
            typeList:function(noEm, ac, onlyEm){
                var r;
                var cus = this.customTypes(ac);
                var tp = cus.concat(emEditor.config.scalarTypes);
                if(noEm){
                    return tp.sort();
                }else{
                    var em = this.emList(false, true, ac);
                    if(onlyEm){
                        r = em;
                    }else{
                        r = tp.concat(em);
                    }

                    return r.sort();
                }

            },
            customTypes:function(ac){
                var values = emEditor.catalog.type, tab = [], addMarq = "";
                if(ac){
                    addMarq = "&?cusTypes";
                }
                for(key in values){
                    tab.push(values[key].name+addMarq);
                }
                return tab;
            },
            scalarTypes:function(){
                return emEditor.config.scalarTypes;
            },
            relationUsedByAtt:function(emName, attName){
                var emPos = this.entityModel(emName);
                var attPos = this.emAtrribute(emPos, attName);
                var rel = null;
                if(_classes[emPos]["attributes"][attPos]["relationship"]){
                    rel = this.relation(_classes[emPos]["attributes"][attPos]["relationship"]);   
                }
                return emEditor.catalog.relationship[rel];
            },
            relation:function(relName){
                var pos=null, exist=null;
                if(emEditor.catalog.relationship){
                    var l = emEditor.catalog.relationship.length;
                    for(var i=0; i<l; i++){
                        if(emEditor.catalog.relationship[i]["name"] == relName){pos = i; break;}
                    }
                }else{
                    emEditor.catalog.relationship = new Array();
                    pos = null;
                }

                return pos;
            },
            emAtrribute:function(emPos, attName) { 
                //find pos of the em    
                var em = _classes[emPos], atts, pos = null;
                if(em["attributes"]){
                    atts = em["attributes"];
                    for(var i in atts){
                        if(em["attributes"][i]["name"] == attName){pos = i; break;}
                    }
                }       
                return pos;
            },
            defaultValue:function(val){
                if(emEditor.config.defaultValues[val]){
                    return emEditor.config.defaultValues[val];
                }else{
                    return null;
                }
            },
            getModelProperties : function( ) {
                return emEditor.config.modelProperty;
            },
            modelPropertiesValuesByName : function(propName) {
                
                var res = null;
                
                if (propName) {
                    if (emEditor.catalog[propName]) {
                        res = emEditor.catalog[propName];
                    }
                }
                
                return res;
            },
            emPropertiesList:function(){
                /*var tab2 = new Array();
                for( var i in emEditor.config.emProperty ) {
                       tab2[i] = emEditor.config.emProperty[i];
                }
                return tab2;*/
                
                return emEditor.config.emProperty;
            },
            emAttributeName:function(emName, attName){
                //find pos of the em 
                var emPos = this.entityModel(emName);
                var a = _classes[emPos]["attributes"];
                var val = null;
                if(a){
                    var l = a.length;
                    for(var i=0; i<l; i++){
                        if(a[i]["name"] == attName){val = a[i]["kind"]; break;}
                    }
                }
                return val;
            },
            methodeProperty:function(emName, methName, propName){
                 
                var 
                emPos   = this.entityModel(emName),  
                val     = null,
                pos     = null,
                tp,
                l;
                
                if (_classes[emPos]["methods"]) {
                    l = _classes[emPos]["methods"].length;
                } else {
                    l = 0;
                }
                 
                for(i=0; i<l; i++){
                    if(_classes[emPos]["methods"][i]["name"] == methName){
                        tp = _classes[emPos]["methods"][i][propName];
                        if(tp){
                            val = tp;
                        }
                        break;
                    }
                }
                return val;
            },
            /**
            * return the value of a given attribute's property  
            * @param {String} emName 
            * @param {String} attName 
            * @param {String} propName 
            * @return {string} value            
            */
            emAttPropertyValue:function(emName, attName, propName, innerProp){

                var emPos = this.entityModel(emName),
                    attPos = this.emAtrribute(emPos, attName), 
                    val = null;
                                            
                if (!attPos) {
                    e = _g.extendParents(emName);
                    if (e.length != 0) {
                        emPos = this.entityModel(e[e.length-1]);
                        attPos = this.emAtrribute(emPos, attName);
                    }
                }
                
                if (innerProp && _classes[emPos]["attributes"][attPos][propName]) {
                    val = _classes[emPos]["attributes"][attPos][propName][0][innerProp];
                } else {
                    val = _classes[emPos]["attributes"][attPos][propName];
                }
                
                return val;
            },
            /**
            * return the value of a given attribute's property  
            * @param {String} emName 
            * @param {String} attName 
            * @param {String} propName 
            * @return {string} value            
            */
            classAttPropertyValue:function(emName, attName, propName, innerProp){

                var emPos = this.entityModel(emName),
                    attPos = this.emAtrribute(emPos, attName), 
                    val = null;
                
                if (attPos) {
                 
                    if (innerProp && _classes[emPos]["attributes"][attPos][propName]) {
                        val = _classes[emPos]["attributes"][attPos][propName][0][innerProp];
                    } else {
                        val = _classes[emPos]["attributes"][attPos][propName];
                    }
                }

                return val;
            },
            emAttributesList:function( emName, tableOnly, noRelation, onlyManyToOneRel, noField ) {
                
                var emPos   = this.entityModel(emName),
                    pk      = this.primKey(emName),
                    attList = [], 
                    att, 
                    t;
                    
                att = _classes[emPos]["attributes"];
                
                if (tableOnly) {
                    t = "tableOnly";
                }
                
                if (noRelation) {
                    t = "noRelation";
                }
                
                if (onlyManyToOneRel) {
                    t = "onlyManyToOneRel";
                }
                
                if (noField) {
                     t = "noField";
                }
                
                for( var key in att ) {
                    if( att[key].kind != "removed" ){ 
                        switch (t){
                        case "noField" : 
                            if( att[key].kind != "storage" && att[key].kind != "calculated" ) {
                                attList.push(att[key].name);
                            } 
                            break;    
                        case "tableOnly" : 
                            if( att[key].kind=="storage" ) {
                                attList.push(att[key].name);
                            } 
                            break;
                        case "noRelation" : 
                            if( att[key].kind!="relatedEntity" && att[key].kind!="relatedEntities" ) {
                                attList.push(att[key].name);
                            }
                            break;
                        case "onlyManyToOneRel" :   
                            if( att[key].kind!="relatedEntities" ) {
                                attList.push(att[key].name);
                            }
                            break;
                        default: 
                            if( att[key].name != pk ) { 
                                attList.push(att[key].name );
                            }
                        }
                    }
                }
                return attList;
            },
            emNoRelationAttributeNames:function(emName){
                var emPos = this.entityModel(emName);
                var attList = [];
                att = _classes[emPos]["attributes"];
              
                for (var key in att){
                    if( att[key].kind != "relatedEntity" && att[key].kind != "relatedEntities" ) {
                        attList.push(att[key].name );  //add a param to check that
                    }
                    
                }
                return attList;
            },
            emPrimKeyComplientList:function(emName){
                
                var emPos = this.entityModel(emName);
                var att = _classes[emPos]["attributes"];
                var res = [];

                $.each(att, function(index, value) {                         
                    if( value.kind == "storage" && _uA.isValueIn( value.type, emEditor.config.primKeyType) ){
                            res.push(value.name);
                    }
                });
                
                return res;
            },
            emProperties:function(emName){
                var emPos = this.entityModel(emName);
                var emObj = _classes[emPos];
            
                var prop = [];
                for(var key in emObj){
                    switch (key){
                        case "key":
                        case "uuid":
                        case "tablePos":    
                        case "name":
                        case "attributes": //???? update ??
                        case "__CDATA":
                        case "identifyingAttribute":
                        case "methods": break;
                        default :prop.push(key);                    
                    }               
                }
    
                if(prop.length === 0){
                    return prop = null;
                }
                return prop;
            },
            emPropertiesValues:function(emName){
                var emPos = this.entityModel(emName);
                var emObj = _classes[emPos];

                var prop = [];
                for(var key in emObj){
                    switch (key){
                        case "key":
                        case "uuid":
                        case "tablePos":    
                        case "attributes":
                        case "__CDATA":
                        case "identifyingAttribute":
                        case "methods": break;
                        default :prop.push({"key":key, "val":emObj[key]});                  
                    }               
                }

                if(prop.length === 0){
                    return prop = null;
                }
                return prop;
            },
            emAttribute:function(emName, attName){ 
                var emPos = this.entityModel(emName);
                var attPos = this.emAtrribute(emPos, attName), val = null;
                return _classes[emPos]["attributes"][attPos];
            },
            property:function(emName, property){
            
                //find pos of the em 
                var l = _classes.length, pos=null, exist=null;
                for(i=0; i<l; i++){
                    if(_classes[i]["className"] == emName || _classes[i]["collectionName"] == emName) { pos = i; break; }
                }
                //find if the property does exist
                var values = _classes[pos];
                for ( var key in values ) {
                    if(key === property){
                        exist=pos; break;
                    }
                }//end for
                return exist;
            },
            propertyValue:function(emName, property){
            
                //find pos of the em 
                var l = _classes.length, pos=null, exist=null;
                pos =  this.entityModel(emName);
                //find if the property does exist
                var values = _classes[pos];

                for ( var key in values ) {
                    if(key === property){
                        exist=values[key]; break;
                    }
                }//end for
                return exist;
            },
            collectionName:function(na){ //manyName
                var pos=null, exist=null, i;
                var c = _classes;
                
                $.each(c, function(index, value) { 
                    if( value["className"] == na ) { i = index; return; }
                  });
                
                if( c[i] ) {
                    return c[i]["collectionName"];
                }else{
                    return null;
                }
                
            },
            dataClassName:function(na){ //singleName
                var pos=null, exist=null, i;
                var c = _classes;
                
                $.each(c, function(index, value) { 
                  if(value["collectionName"] == na){ i = index; return; }
                });
                
                if( c[i] ) {
                    return c[i]["className"];
                } else { 
                    if (this.collectionName(na) != null) {
                        return na;
                    } else {
                        return null;
                    }
                }                
            },
            /**
            * return the list of the em in the emEditor.catalog  
            * @param {String} tableOnly get only table  
            * @return {js object} list          
            */
            emList:function(tableOnly, forAutoComp, ac){
            
                var values = _classes;
                var list = [], addMarq = "";
                if(ac){
                    addMarq = "&?em";
                }
            
                for ( var key in values ) {
                    if(tableOnly){
                        if(!values[key]["extends"]){list.push(values[key].collectionName+addMarq);}
                    }else{ 
                        if(ac){
                            if(this.primKey(values[key].collectionName) || values[key]["extends"]){
                                list.push(values[key].collectionName+addMarq);
                            
                                if(forAutoComp){
                                    list.push(values[key]["className"]+"&?emSing");
                                }
                            }
                        }else{
                            list.push(values[key].collectionName);
                            if(forAutoComp){
                                list.push(values[key]["className"]);
                            }
                        }
                    
                    }

                }//end for

                return list.sort();
            },
            /**
            * find an em 
            * @param {String} emName the name of the entity model to use    
            * @return {number} position of the em in the emEditor.catalog    
            */
            entityModel:function(emName){ 
                if(emEditor.emindex){ 
                    if(emEditor.emRef[emName] != null){
                        return emEditor.emRef[emName]; 
                    }else{
                        return null;
                    }
                }else{
                    var l = _classes.length, pos=null, exist=null;
                    for(var i=0; i<l; i++){
                        if( _classes[i]["className"] == emName ) { pos = i; break; } //name
                    }
                    return pos;
                }

            }
    };
    
    _g = emEditor.editorData.get;
})();