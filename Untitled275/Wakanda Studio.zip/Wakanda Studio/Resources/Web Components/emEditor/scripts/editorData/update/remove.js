/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() {
    _u.remove = {   
        
            computedScript:function(emName, attName, type){
                var pos = emEditor.editorData.findEntityModel(emName);
                var attPos = _g.emAtrribute(pos, attName);
                delete _classes[pos].attributes[attPos][type];
                emEditor.studio.doScript(_conf .studioMessage.deleteMethod, emName+"."+attName+"."+type);
                emEditor.studio.setDirty();
            },
            events:function(type, emName, ev, attName){
                var emPos = emEditor.editorData.findEntityModel(emName);
                var attPos, eve, val;
                if(type == "em"){
                    eve =  _classes[emPos]["events"];
                }else{
                    attPos = emEditor.editorData.findEmAtrribute(emPos, attName);
                    eve =  _classes[emPos]["attributes"][attPos]["events"];
                }
                for(var k in eve){
                    if(eve[k].kind == ev){
                        val = eve[k].from;
                        eve.splice(k,1)
                        break;
                    }
                }
                emEditor.studio.setDirty();
                return val;
            },
            type:function(typeName){
                var pos = _g.type(typeName);
                    emEditor.catalog.type.splice(pos, 1)
                emEditor.studio.setDirty();
            },
            typeProperty:function(typeName, propName, innerVal){
            
                var pos = _g.type(typeName);
                if(innerVal){
                    delete emEditor.catalog.type[pos]["defaultFormat"][0][propName];
                }else{
                    delete emEditor.catalog.type[pos][propName];
                }
                emEditor.studio.setDirty();
            },
            /**
            * remove a method
            * @param {String} emName the name of the em
            * @param {String} onEditValue the name of the method
            */
            method:function(emName, methName){
                var pos     = emEditor.editorData.findEntityModel(emName),
                    attPos  = _g.method(pos, methName),
                    from    = _classes[pos]["methods"][attPos].from;

                _classes[pos]["methods"].splice(attPos, 1);
                
                emEditor.studio.doScript(_conf.studioMessage.deleteMethod, emName +"."+ from.split(".")[2]+"."+ methName);

                //check perms
                _perms.checkPermToRemove( {
                    target      : 'method', 
                    className   : emName, 
                    elemName    : methName
                }); 

                $.each(_classes, function(index, value) {
                  if (value["extends"] && value["extends"] === emName && value.methods) {
                    $.each(value.methods, function(i, v) { 
                        if (!v.from && v.name === methName) {
                            value.attributes.splice(i, 1);
                            return;
                        }
                    });
                  }
                });

                _u.extraProperties.removeMethod(emName, methName);

                emEditor.studio.setDirty();
            },
            /**
            * remove a Entity
            * @param {String} emName name of the em to remove           
            */
            entity:function(emName){ 

                var pos     = emEditor.editorData.findEntityModel(emName),
                    colName = _g.collectionName(emName),
                    em      = _classes;    
                                
                _classes.splice(pos, 1);
                
                //update panels refs
                if (emEditor.emindex) {

                    delete emEditor.emRef[colName];
                    delete emEditor.emRef[emName];
                    
                    var k = parseInt(pos), j;
                    while (em[k]) { 
                        emEditor.emRef[em[k]["className"]] = k;
                        emEditor.emRef[em[k]["collectionName"]] = k;
                        k = k + 1;
                    }

                }
                
                //send message to the studio
                emEditor.studio.doScript(_conf.studioMessage.deleteEntity, emName);

                //check perms
                _perms.checkPermToRemove( {
                    target      :'class', 
                    className   : emName, 
                    elemName    : null
                }); 

                _u.extraProperties.removeClass(emName);

                emEditor.studio.setDirty();
            },
            allProperties:function(emName, propName, attName, newType){ 
             
                if (propName == "type") {
                    
                    var type = _check.scalarType( _g.typeOfAttribute(emName, attName));
                    
                    switch (type){
                        case "string": 
                            val = _conf.attProperties.forString.concat(_conf.typeProperties.string);
                            break;
                        case "long":  
                        case "number": 
                        case "double": 
                        case "decimal": 
                        case "money": 
                            val = _conf.attProperties.forNumbers.concat(_conf.typeProperties.number);
                            break;
                        case "bool": val = []; break;
                        case "byte": 
                        case "date": 
                        case "media": 
                        case "time": 
                        case "unit": 
                        case "object": 
                        case "function": val = []; break;
                        default: val = [];
                    }
                    
                    if (newType && !_uA.isValueIn(newType, _conf.primKeyType)) {
                        val.push({"primKey":""});
                    }
                    
                    for (var key in val) {
                        for(var key2 in val[key]){
                            if (key2 != "separator") {
                                this.attributeProperty(emName, key2, attName);
                            }
                        }
                    
                    }
                }
                
            },
            /**
            * remove an Attribute
            * @param {String} emName name of the em 
            * @param {String} attName name of the att to remove         
            */
            attributes:function(emName, attName) { 
                var pos = emEditor.editorData.findEntityModel(emName);
                var attPos = _g.emAtrribute(pos, attName), 
                att;
               
                if (attPos != null) { 

                    att = _classes[pos]["attributes"][attPos];
                    
                    if(att.kind === _conf.xmlData.calculated && att.scriptKind === _conf.xmlData.javascript){ 
                       
                    } else { 
                        $.each(_classes, function(index, value) { 
                          if(value["extends"] && value["extends"] == emName && value.attributes){
                              $.each(value.attributes, function(i, v) { 
                                if ((v.kind === "removed" || !v.kind) && v.name === attName) {
                                    value.attributes.splice(i, 1);
                                    return;
                                }
                              });
                          }
                        });
                        
                    }

                    emEditor.studio.setDirty(); 
                    emEditor.studio.doScript(_conf.studioMessage.deleteAttribute, emName+"."+attName);
                    _classes[pos]["attributes"].splice(attPos, 1);

                    _u.extraProperties.removeAttribute(emName, attName);
                }
            },
            /**
            * remove a property
            * @param {String} emName the name of the entity model   
            * @param {String} property name 
            * @param {String} attrubute name        
            */
            attributeProperty:function(emName, property, attribute){
                            
                if (attribute) { 
                    //find em
                    var emPos = emEditor.editorData.findEntityModel(emName);
                    //find attribute
                    var attPos = emEditor.editorData.findEmAtrribute(emPos, attribute);
                    delete _classes[emPos]["attributes"][attPos][property];
                } else {
                    var prop = emEditor.editorData.findProperty(emName, property);
                    delete _classes[prop][property];
                }
                //send message to studio
                emEditor.studio.setDirty();

            },
             /**
            * remove a method property
            * @param {String} emName the name of the entity model   
            * @param {String} property name 
            * @param {String} attrubute name        
            */
            methodProperty:function(emName, property, methodName){

                if (methodName) { 
                    var emPos = emEditor.editorData.findEntityModel(emName);
                    var attPos = _g.method(emPos, methodName);
                    delete _classes[emPos]["methods"][attPos][property];
                } 
                
                emEditor.studio.setDirty();

            },
            attributeUnderProperty:function(emName, propName, attN, underKey){
                var emPos = emEditor.editorData.findEntityModel(emName);
                var attPos = emEditor.editorData.findEmAtrribute(emPos, attN);
                var elem = _classes[emPos].attributes[attPos];
                if (elem[underKey]) {
                    delete elem[underKey][0][propName];
                }
                
            /*  if(elem[underKey][0]){
                    delete elem[underKey];
                }
            */  
                //send message to studio
                emEditor.studio.setDirty();
            },
            entityProperty:function(emName, propName){
                var pos = emEditor.editorData.findEntityModel(emName);
                delete _classes[pos][propName];
                emEditor.studio.setDirty();
            },
            noneScriptProperties:function(emName, attName){
                var emPos = emEditor.editorData.findEntityModel(emName);
                var attPos = emEditor.editorData.findEmAtrribute(pos, attName);
                var prop = _classes[emPos]["attributes"][attPos];

                    for(var key in prop){
                        switch (key){
                        case "type":
                        case "kind":
                        case "name":
                        case "scriptKind": break;       
                        default:delete _classes[emPos]["attributes"][attPos][key];  
                    }
                }
            },
            scriptProperties:function(emName, attName){ 
                
                var emPos = emEditor.editorData.findEntityModel(emName);
                var attPos = emEditor.editorData.findEmAtrribute(emPos, attName);
                var prop = _classes[emPos]["attributes"][attPos];

                    for(var key in prop){
                        switch (key){
                        case "scriptKind": 
                            delete _classes[emPos]["attributes"][attPos][key]; 
                            break;
                        case "onGet": 
                            delete _classes[emPos]["attributes"][attPos][key]; 
                            emEditor.studio.doScript(_conf.studioMessage.deleteMethod, emName+"."+attName+".onGet");
                            break;
                        case "onQuery": 
                            delete _classes[emPos]["attributes"][attPos][key]; 
                            emEditor.studio.doScript(_conf.studioMessage.deleteMethod, emName+"."+attName+".onQuery");
                            break;
                        case "onSet": 
                            delete _classes[emPos]["attributes"][attPos][key]; 
                            emEditor.studio.doScript(_conf.studioMessage.deleteMethod, emName+"."+attName+".onSet");
                            break;       
                        case "onSort": 
                            delete _classes[emPos]["attributes"][attPos][key]; 
                            emEditor.studio.doScript(_conf.studioMessage.deleteMethod, emName+"."+attName+".onSort");
                            break;    
                        default:  
                    }
                }
                _classes[emPos]["attributes"][attPos]["uuid"] = emEditor.editorUI.uuid.use();
                //_classes[emPos]["attributes"][attPos]["fieldPos"] = emEditor.editorData.setFieldPos(emPos); deprecated wak4
            },
        allMethods : function() {
            var ems = _classes;
            $.each(ems, function(index, value) { 
                //rm all methods & events at class level
                delete value.methods;
                delete value.events;
                if( value.attributes ) {
                    $.each(value.attributes, function(index, value) { 
                        //rm all event script at attributes level
                        delete value.methods;
                        delete value.events;
                        delete value.onGet;
                        delete value.onSet;
                        delete value.onQuery;
                        delete value.onSort;
                        });
                }

            });
            
        }    
    };
})();