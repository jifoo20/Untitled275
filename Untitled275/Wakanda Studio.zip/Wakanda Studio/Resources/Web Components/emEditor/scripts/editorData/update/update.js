/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* updateCatalog : object to manage create/update into the emEditor.catalog       
*/
(function() { 
    
    emEditor.editorData.updateCatalog = {};
    _u = emEditor.editorData.updateCatalog;
    
    emEditor.editorData.updateCatalog = {    
        
        attributeRowOrder : function( emName, tableType, startIndex, endIndex ) {

            var emPos = emEditor.editorData.findEntityModel(emName),
                atts,
                meths,
                dragRow = null;

            if( tableType === "attributesTable" ) {
                
                atts = _classes[emPos]["attributes"];
                
                //remove row to move
                $.each(atts, function(index, value) { 
                  if( index === startIndex-1 ) {
                      dragRow = atts.splice( index, 1 );
                      return false;
                  }
                });  

                //add again the row to the right place        
                atts.splice( endIndex-1, 0, dragRow[0] );
                
            } else {
              
                meths = _classes[emPos]["methods"];

                //remove row to move
                $.each(meths, function(index, value) { 
                  if( index === startIndex-1 ) {
                      dragRow = meths.splice( index, 1 );
                      return false;
                  }
                });  

                //add again the row to the right place    
                meths.splice( endIndex-1, 0, dragRow[0] );
    
            }    

            //dirty mode
            emEditor.studio.setDirty();
        },
        
        /*resizedHeight:function( h, emName ) {
    
            var emPos = emEditor.editorData.findEntityModel(emName);
            if(_classes[emPos]["extraProperties"]){
                ec = _classes[emPos]["extraProperties"];
            }else{
                ec = _classes[emPos]["extraProperties"] = {};
                ec.panel = {};
            }
            ec.panel.resizedHeight = h;
            emEditor.studio.setDirty();
        },
        setPathState:function( visible, emName ) {
            var emPos = emEditor.editorData.findEntityModel(emName);
            if(_classes[emPos]["extraProperties"]){
                ec = _classes[emPos]["extraProperties"];
            }else{
                ec = _classes[emPos]["extraProperties"] = {};
                ec.panel = {};
            }
            if(visible){
                ec.panel.pathVisible = true;
            }else{
                ec.panel.pathVisible = false;
            }
            emEditor.studio.setDirty();
        },
        setPanelOpen:function( open, emName ) { 
            var emPos = emEditor.editorData.findEntityModel(emName);
            if(_classes[emPos]["extraProperties"]){
                ec = _classes[emPos]["extraProperties"];
            }else{
                ec = _classes[emPos]["extraProperties"] = {};
            }

            if(!ec.panel){
                ec.panel = {};
            }

            if(open){
                if(ec.panel.isOpen != "true"){ 
                    ec.panel.isOpen = "true";
                    emEditor.studio.setDirty();
                }
            }else{
                ec.panel.isOpen = "false";
                emEditor.studio.setDirty();
            }
        
        },*/
        /**
        * if the em name has been updated, chnage it in the whole document
        * @param {String} oldValue old em's name    
        * @param {String} newValue new em's name        
        */
        emName:function( oldValue, newValue ) { 
            //look where this em is used as a type
            var em  = _classes, 
                att, 
                ems = [];

            for (var k in em ){
                att = em[k].attributes;
                for(var i in att){  
                    if(att[i]["type"] === oldValue){
                        
                        att[i]["type"] = newValue;
                                                
                        ems.push( {emName:em[k]["className"], attProp:att[i], oldValue:oldValue} );
                        
                        if (att[i]["path"] === oldValue) { 
                            att[i]["path"] = newValue;
                        }
                    }
                }
            }
            
            for (var e in em) {
                if (em[e]["extends"] && em[e]["extends"] == oldValue) {
                    em[e]["extends"] = newValue;
                    ems.push( {emName:em[e]["className"], attProp:"extend", oldValue:newValue} );
                }
            }

            emEditor.studio.setDirty();
            return ems;
        },
        /**
        * just rename the custom type name
        * @param {String} oldValue old em's name    
        * @param {String} newValue new em's name  
        * @return {array} list of em updated    
        */
        updateCustomTypeName:function( oldValue, newValue ) {
            var em = _classes, att, emTable=[];
            for(var key in em){
                att = em[key].attributes;
                for(var k in att){
                    if(att[k]["type"] == oldValue || att[k]["type"] == newValue){ 
                        att[k]["type"] = newValue; 
                        emTable.push(em[key]["name"]);
                    }
                }
            }
            emEditor.studio.setDirty();
            return emTable;
        },
        checkPreviousDestination:function( emNameOgi, emNameCheck, path, l ) {
            
            var i = 0,
                max = l-1,
                destination = emNameOgi;
                
            if(max == 0){
                destination = _check.isRelatedAtt(destination, path[0]);
            }else{
                while(max != i-1){ /* check !! */  
                    destination = _check.isRelatedAtt(destination, path[i]);
                    i++;
                }
            }            
            
            return destination; //_g.manyName(

        },
        flattenedAtt:function( emName, oldValue, newValue ) {
            
            var emToUpload  = [], 
                emPos, 
                p, 
                i, 
                newPath     = "",
                fAtts       = _nav.getAllByEntity(emName),
                em          = _classes;

            for(var a in fAtts) {
                
                allF = _nav.getPathTree(fAtts[a].emName, fAtts[a].attName, false, emName);
 
                for(var k in allF){ 
                    if(allF[k]){
                        if(_g.emAttPropertyValue(allF[k].emName, allF[k].attName, "kind") == _conf.xmlData.alias || _g.emAttPropertyValue(allF[k].emName, allF[k].attName, "kind") == _conf.xmlData.relatedEntities || _g.emAttPropertyValue(allF[k].emName, allF[k].attName, "kind") == _conf.xmlData.relatedEntity ){
                            
                            emPos = emEditor.editorData.findEntityModel(allF[k].emName);
                            attPos = _g.emAtrribute(emPos, allF[k].attName);
                            newPath = "";
                            if(_nav.isInPath(oldValue, allF[k].path)){ 
                                    p = allF[k].path.split(".");

                                    $.each(p, function(index, value) { 
                                        if(index != 0){
                                            newPath = newPath + ".";
                                        }

                                        if(value == oldValue && _u.checkPreviousDestination(allF[k].emName, emName, p, index) == emName){
                                            newPath = newPath + newValue;
                                        }else{
                                            newPath = newPath + value;
                                        }
                                    });

                                    em[emPos].attributes[attPos].path = newPath;
                                    emToUpload.push({emName:allF[k].emName, attProp : em[emPos].attributes[attPos]});
                            }
                        }
                    }
                }
            }
        
            return emToUpload;

        },
        navigationAtt:function( emName, oldAttName, attName, idField ) {

            var emPos, att, attEmName = null, f, attPos, newPath = "", i=0, emUploaded=[];
            var em = _classes;
                      
            if(!idField){ 
                var attToUpload = _nav.getPathTree(emName, oldAttName, false, emName);
                var f = _nav.lookForFlattenedUse(emName, oldAttName);      /* check !!  */
                
                attToUpload = f.concat(attToUpload);
               
                for(var k in attToUpload){
                    
                    newPath = "";                    
                    if(attToUpload[k].emName != attEmName){
                        attEmName = attToUpload[k].emName;
                        emPos = emEditor.editorData.findEntityModel(attEmName);
                    }
                    attPos = _g.emAtrribute(emPos, attToUpload[k].attName);
                    att = em[emPos].attributes[attPos];
                    f = att.path.split('.');
                    i=0;
                    while(f[i]){
                        if(f[i] == oldAttName){f[i] = attName;}
                        if(i!=0){newPath = newPath + ".";}
                        newPath = newPath + f[i];
                        i++;
                    }
                    att.path = newPath; 
                    //emUploaded.push(attEmName);
                    emUploaded.push({emName:attEmName, attProp : em[emPos].attributes[attPos]});
                }
            }else{ 
                var em = _classes;
                var type = _check.isRelatedAtt(emName, oldAttName); 
                emPos = emEditor.editorData.findEntityModel(emName);
                if(type != null){
                    att = em[emPos].attributes;
                    for(var k in att){
                        if(att[k].kind == "alias" || att[k].kind == "relatedEntities" ){// att[k].kind == "relatedEntity" || 
                            f = att[k].path.split('.');
                            if(f[0]==oldAttName){ 
                                newPath = attName;
                                i=1;
                                while(f[i]){
                                    newPath = newPath + ".";
                                    newPath = newPath + f[i];
                                    i++;
                                }
                                att[k].path = newPath; 
                                //emUploaded.push(emName);
                                emUploaded.push({emName:emName, attProp : att[k]});
                            }
                        }
                    }       
                }

                //look for ohter use in other em as a navigation att (path)
                for(var e in em){  
                    if(e != emPos){
                        att = em[e].attributes;
                        for(var r in att){

                            if(att[r].type == _g.collectionName(emName)){  //_g.manyName(emName)
                                this.updatePathValue(e, r, oldAttName, attName); 
                                //emUploaded.push(em[e].name);
                                emUploaded.push({emName:em[e]["className"], attProp : att[r]});
                            }
                        }
                    }
                }

                //do the same in the extended em
                var extEm = _check.whosExtends(emName);
                for(var m in extEm){
                    this.navigationAtt(extEm[m], oldAttName, attName);
                }
            }
        
            emEditor.studio.setDirty();
            return emUploaded;
        },
        updatePathValue:function( emPos, attPos, oldVal, newVal ) {
            
            var em = _classes[emPos], newPath, i, f;
            var att = em.attributes;
            var attName = att[attPos].name;
            var emName = em["className"];
                    
            while(emName){
                for(var k in att){ 
                   //if(k != attPos){ 
                        if(att[k].kind === "alias" || att[k].kind === "relatedEntities"){ 
                            f = att[k].path.split('.');
                            if(f[0] === oldVal){ //attName
                                newPath = newVal; //attName
                                i=1;
                                while(f[i]){
                                    newPath = newPath + ".";
                                    (f[i] === oldVal) ? newPath = newPath + newVal :  newPath = newPath + f[i];     
                                    i++;
                                }
                                att[k].path = newPath;
                            }
                        }
                    //}
                }
                emName = _check.doesExtends(emName);
                if(emName != null){
                    emPos = emEditor.editorData.findEntityModel(emName);
                    em = _classes[emPos];
                    att = em.attributes;
                }
            }
        
            emEditor.studio.setDirty();
        },
        panelPos:function( X, Y, emName, panelID ) {
        
            var path,
                pathPos;

            path = _u.extraProperties.checkForClass(emName);

            if (!path.panel) {
                
                path.panel = {};
                path.panel.position = {};

            } else {

                if (!path.panel.position) {
                    path.panel.position = {};
                }

                pathPos = path.panel.position;
            }
                    
            pathPos.X = X;
            pathPos.Y = Y;     
            
            emEditor.studio.setDirty();
        },
        /**
        * remove a relation
        * @param {String} relName name of the rel to remove         
        */
        removeRelation:function( relName ) {
            var pos = emEditor.editorData.findRelation(relName.id);
            emEditor.catalog.relationship.splice(pos, 1);
            emEditor.studio.setDirty();
        },
        /**
        * remove a type
        * @param {String} typeName name of the type to remove           
        */
        removeType:function( typeName ) {
            var pos = emEditor.editorData.findType(typeName.id);
            emEditor.catalog.type.splice(pos, 1);
            emEditor.studio.setDirty();
        },
        /**
        * remove a property type
        * @param {String} typeName the name of the type
        * @param {String} propName the name of the property
        */
        removeTypeProperty:function( typeName, propName ) {
            var pos = emEditor.editorData.findType(typeName);
            delete emEditor.catalog.type[pos][propName];
            emEditor.studio.setDirty();
        },
        /**
        * create an attribute kind "removed"
        * @param {String}   to do               
        */
        manageRemoved:function( attName, emName, remove ) {

            var emPos = emEditor.editorData.findEntityModel(emName),
                attPos = emEditor.editorData.findEmAtrribute(emPos, attName);
                
            if(remove){
                
                if (!_classes[emPos]["attributes"]) {
                    _classes[emPos]["attributes"] = [];
                }
                
                if (attPos) {
                    _classes[emPos]["attributes"][attPos].kind = "removed";
                } else {    
                    _classes[emPos]["attributes"].push({"name":attName, "kind":"removed"});
                }                               
                
            }else{

                var attpos = emEditor.editorData.findEmAtrribute(emPos, attName);               
                
                if (_classes[emPos]["attributes"][attPos].columnName) {
                    delete _classes[emPos]["attributes"][attPos].kind;
                } else {
                    _classes[emPos]["attributes"].splice(attpos, 1);
                }
            }
        
            //send message to the studio
            emEditor.studio.setDirty();
        },
        /**
        * create new entity model in the emEditor.catalog
        * @param {String} newEntity the name of the entity model    
        * @return {number} position of the nex em               
        */
        entity:function( newEntity, extendName ) {  
            
            var nonValideTypes  = _check.lookForNonValideType(newEntity), 
                emToReload      = [], 
                nem,
                id,
                tp;
            
            for (var k in nonValideTypes) {
                if (!_check.isType(newEntity)) {
                    this.newAttribute(nonValideTypes[k].emName, nonValideTypes[k].attName, newEntity, "relatedEntity", true, newEntity+_conf.xmlData.collection, false);
                    if (!_uA.isValueIn(nonValideTypes[k].emName, emEditor.emToUpdateForUI)) {
                        emEditor.emToUpdateForUI.push(nonValideTypes[k].emName);
                    }
                }
            }

            id = emEditor.editorUI.uuid.use();
            //tp = emEditor.editorData.setTablePos();
            
            if (extendName) {
                nem = {"collectionName":newEntity+_conf.xmlData.collection, "className":newEntity, "extends":extendName/*, extraProperties: { panelColor:"#"+emEditor.editorUI.utilities.getRandomColor() }*/ };
            } else {
                nem = {"collectionName":newEntity+_conf.xmlData.collection, "className":newEntity, "uuid":id /*"tablePos":tp , extraProperties: { panelColor:"#"+emEditor.editorUI.utilities.getRandomColor() }*/ };
            }

            _u.extraProperties.definePanelColor(newEntity, "#"+emEditor.editorUI.utilities.getRandomColor());
            
            //update the emEditor.catalog object
            var pos = _classes.push(nem);
            
            //update index table for ems
            if(emEditor.emindex){
                emEditor.emRef[newEntity] = pos-1;
                emEditor.emRef[newEntity+_conf.xmlData.collection] = pos-1;
            }
            
            var att;
            emEditor.waitingToBeAdded = {};
            emEditor.waitingToBeAdded.pos = pos-1;
            emEditor.waitingToBeAdded.emName = newEntity;
            
            if(!extendName){
                this.endNewEntity(emEditor.editorUI.uuid.use());
            }
            //send message to the studio
            emEditor.studio.setDirty(); 
            return pos;     
        },
        endNewEntity:function( uid ) {
            //add default attibute
            var p       = emEditor.waitingToBeAdded.pos,
                name    = emEditor.waitingToBeAdded.emName,
                att;

            _classes[p].attributes = [];
            
            //fp = emEditor.editorData.setFieldPos(p); deprecated wak4
            
            att = {
                    "name"          :"ID", 
                    "kind"          :"storage", 
                    "type"          :"long", 
                    "uuid"          :uid, 
                    "autosequence"  :"true", 
                    "unique"        :"true", 
                    "primKey"       : "true"
                    //"fieldPos"   :fp
            };
            
            _classes[p].attributes.push(att);
            
        },
        create1NRelation:function( type, emName, pathVal ) {

            var emPos   = emEditor.editorData.findEntityModel(emName),
                id      = emEditor.editorUI.uuid.use(),
                //fp      = emEditor.editorData.setFieldPos(emPos), deprecated wak4
                rel     = {
                            "name" : pathVal,
                            "kind": "relatedEntity",
                            "type": type,
                            "uuid": id,
                            //"fieldPos": fp, 
                            "path": type,
                            "scope": _conf .param.scopeDefaultValue
                        }
            
            if (!_classes[emPos]["attributes"]) {
                _classes[emPos]["attributes"] = [];
            }

            _classes[emPos]["attributes"].push(rel);
        },
        //temp function to handle old names !!!*****
        scripsNames: function (emName, newValue) {
            var property = "className";
            var prop = emEditor.editorData.findEntityModel(emName, property);
            var attName, att, scriptToRn, ev;
            
            //look for methods to update 
            var compute = _g.computedAttributes(prop), attName;
        
            if (compute.length > 0) { scriptToRn = true; }
        
            for(key in compute){ 
                attName = _classes[prop]["attributes"][compute[key]].name;
                if(_classes[prop]["attributes"][compute[key]]["onGet"]){          
                    _classes[prop]["attributes"][compute[key]]["onGet"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onGet";
                    }
                if(_classes[prop]["attributes"][compute[key]]["onSet"]){
                    _classes[prop]["attributes"][compute[key]]["onSet"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onSet";
                    }
                if(_classes[prop]["attributes"][compute[key]]["onQuery"]){
                    _classes[prop]["attributes"][compute[key]]["onQuery"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onQuery";
                    }
                
            }
            
            //update method if needed
            if(_classes[prop]["methods"]){
                scriptToRn = true;
                att = _classes[prop]["methods"];
                for(key in att){ 
                    att[key].from = _conf.methodPath.nameSpace +"."+ newValue+"."+att[key].name;
                }
            }
            
            //update events if needed
            if(_classes[prop].attributes){
                att = _classes[prop].attributes;
                for(key2 in att){ 
                    if(att[key2].events) {
                        ev = att[key2].events;
                        for(key3 in ev) {
                            ev[key3].from = _conf.methodPath.nameSpace +"."+ newValue+"."+att[key2].name+".events."+ev[key3].kind;
                        }
                    }
                }
            }
            
            if(_classes[prop].events){
                ev = _classes[prop].events;
                for(key3 in ev) {
                    ev[key3].from = _conf.methodPath.nameSpace +"."+ newValue+".events."+ev[key3].kind;
                }
                
            }

            //if (scriptToRn){
                emEditor.studio.doScript(_conf.studioMessage.renameEntity, emName+"."+newValue);
            //}
        },
        /**
        * create new key/value property OR just update it if existing
        * @param {String} emName the name of the entity model to use
        * @param {String} property  name of the property to update/create
        * @param {String} newValue  value of the property           
        */
        property:function( emName, property, newValue ) { 

            var prop        = null, 
                lookForMeth = true, 
                scriptToRn  = false, 
                eventsToRn  = false, 
                att, 
                ev;
        
            //look for em position on the emEditor.catalog
            prop = emEditor.editorData.findEntityModel(emName, property);//return null or the position in the emEditor.catalog (number)          
            if (prop == null) {
                prop = _u.entity(newValue)-1;
                lookForMeth = false;
            }   
        
            //update or create property
            if (property === "restrictingQuery") {
                _classes[prop][property] = [];
                _classes[prop][property][0] = {};
                _classes[prop][property][0]["queryStatement"] = newValue;
            } else {
                _classes[prop][property] = newValue;
            }
        
            if (lookForMeth && property === "className") { 
                
                if (emEditor.emindex) {
                    emEditor.emRef[newValue] = emEditor.emRef[emName];
                    delete emEditor.emRef[emName];
                }
                
                //look for methods to update 
                var compute = _g.computedAttributes(prop), attName;
            
                if (compute.length > 0) { 
                    scriptToRn = true; 
                }
            
                for(key in compute){ 
                    attName = _classes[prop]["attributes"][compute[key]].name;
                    if (_classes[prop]["attributes"][compute[key]]["onGet"]) {          
                        _classes[prop]["attributes"][compute[key]]["onGet"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onGet";
                    }
                    
                    if (_classes[prop]["attributes"][compute[key]]["onSet"]) {
                        _classes[prop]["attributes"][compute[key]]["onSet"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onSet";
                    }
                    
                    if (_classes[prop]["attributes"][compute[key]]["onQuery"]) {
                        _classes[prop]["attributes"][compute[key]]["onQuery"][0].from = _conf.methodPath.nameSpace +"."+newValue+"."+attName+".onQuery";
                    }
                }
                
                //update method if needed
                if (_classes[prop]["methods"]) {
                    scriptToRn = true;
                    att = _classes[prop]["methods"];
                    for(key in att){ 
                        sp = att[key].from.split(".");
                        att[key].from = _conf.methodPath.nameSpace +"."+ newValue+"."+sp[2]+"."+att[key].name;
                    }
                }
                
                //update events if needed
                if (_classes[prop].attributes) {
                    att = _classes[prop].attributes;
                    for(key2 in att){ 
                        if(att[key2].events) {
                            ev = att[key2].events;
                            for(key3 in ev) {
                                ev[key3].from = _conf.methodPath.nameSpace +"."+ newValue+"."+att[key2].name+".events."+ev[key3].kind;
                            }
                        }
                    }
                }
                
                if (_classes[prop].events) {
                    ev = _classes[prop].events;
                    for(key3 in ev) {
                        ev[key3].from = _conf.methodPath.nameSpace +"."+ newValue+".events."+ev[key3].kind;
                    }
                    
                }

                //look for attribute events (almost one)
                for ( var ev in _classes[prop].attributes ) {
                    if( _classes[prop].attributes[ev] && _classes[prop].attributes[ev].events ) {
                        eventsToRn = true;
                        break;
                    }
                }

                //send rename event to the studio if needed
                if (scriptToRn || eventsToRn || _classes[prop].events || _classes[prop].methods) { 
                    emEditor.studio.doScript(_conf.studioMessage.renameEntity, emName+"."+newValue); 
                }
            }
            //send message to studio
        
            emEditor.studio.setDirty();
                
        },//end property
        singleEMName:function( emName, t, newValue, oldValue ) {
            
            var em = _classes, att, emToReLoad = [];
            
            $.each(em, function(index, value) { 
                att = value["attributes"];
                if(att){
                    $.each(att, function(attI, attV) { 
                        if(attV.kind == "relatedEntity" && attV.type == oldValue){
                            attV.type = newValue;
                            emToReLoad.push({emName : value["className"], attProp : {name : attV.name } });
                        }
                    }); 
                }
            });
      
            return emToReLoad;
        },
        /**
        * create new key/value property OR just update it if existing for a relation
        * @param {String} emName the name of the entity model to use
        * @param {String} property  name of the property to update/create
        * @param {String} newValue  value of the property           
        */
        relationProperty:function( relName, property, newValue, onEditElem ) {
    
            var prop = null, l, nbOfPathBefore=0, pos, attrN;
            //look for rel position in the emEditor.catalog
            prop = emEditor.editorData.findRelation(relName);//return null or the position in the emEditor.catalog (number)  
            attrN = emEditor.uD.getWafData(onEditElem);
            
            if(prop == null){
                prop = _u.relation(newValue)-1;
                //throw("Entity Model not found. 'Prop' is null. See 'eme.js' (_u.property)");
            }
    
            if(property == "relationPath"){
                //update or create property
                if(emEditor.catalog.relationship[prop]["relationPath"]){ 
                
                    //look if a relationPath already exist at this place (no id to catch it), should not be in editData...
                    l = emEditor.catalog.relationship[prop]["relationPath"].length;
                    onEditElem = onEditElem.previousSibling;
                    while( attrN == "relationPath" ){   //onEditElem.title == "relationPath"
                        onEditElem = onEditElem.previousSibling;
                        nbOfPathBefore++;
                    }
                
                    if(nbOfPathBefore == l){//this is a new one
                        emEditor.catalog.relationship[prop]["relationPath"].push({relationship:newValue});
                    }else{//this is an update
                        pos = l-nbOfPathBefore;
                        emEditor.catalog.relationship[prop]["relationPath"][pos]["relationship"] = newValue;
                    }

                }else{
                    emEditor.catalog.relationship[prop]["relationPath"] = [];
                    emEditor.catalog.relationship[prop]["relationPath"].push({relationship:newValue});
                }
            
            }else{
            
                //update or create property
                emEditor.catalog.relationship[prop][property] = newValue;
            
            }
        
            //send message to studio
            emEditor.studio.setDirty();

            
        },
        /**
        * add a type
        * @param {String} typeName the name of the type
        * @param {String} extend scalar type
        * @return {number} position of the new type (in the array "type")       
        */
        type:function( typeName, extend ) {
        
            var nem = {"name":typeName, "extends":extend};
            var objToUpdate;
            var nonValideTypes = _check.lookForNonValideType(typeName);
            if(nonValideTypes.length > 0){
                for(var k in nonValideTypes){
                    //objToUpdate = nonValideTypes[k];
                    //_classes[objToUpdate.emPos]["attribute"][objToUpdate.attPos].type = typeName;
                    emEditor.emToUpdateForUI.push(nonValideTypes[k].emName);
                }
            }
        
            //update the emEditor.catalog object
            if(!emEditor.catalog.type){
                emEditor.catalog.type = new Array();
            }
            var pos = emEditor.catalog.type.push(nem);
            //send message to the studio
            emEditor.studio.setDirty(); 
            return pos;
        },
        /**
        * add/update a type property
        * @param {String} relName the name of the type
        * @param {String} property the name of the property
        * @param {String} newValue the value of the property
        */
        typeProperty:function( typeName, property, newValue, innerProp ) { 
              
                var prop = null, l, nbOfPathBefore=0, pos, otherProp;
                //look for rel position in the emEditor.catalog
                prop = _g.typePos(typeName);//return null or the position in the emEditor.catalog (number)  
                
                if(property === "extends"){
                    var em = _classes, att, emTable=[];
                    for(var key in em){
                        att = em[key].attributes;
                        for(var k in att){
                            if(att[k]["type"] == typeName){ 
                                emTable.push(em[key]["name"]);
                            }
                        }
                    }
                }
               
                
                
                if(prop == null){
                    prop = _u.type(newValue)-1;
                }else{
                    //update or create property
                    if(property === "extends"){
                        otherProp = emEditor.catalog.type[prop];
                        for(var k in otherProp){
                            if(k != "name" && k != "extends"){
                                delete otherProp[k];
                            }
                        }
                    }
                    if(innerProp){
                        if(!emEditor.catalog.type[prop]["defaultFormat"]){
                            emEditor.catalog.type[prop]["defaultFormat"] = [];
                            emEditor.catalog.type[prop]["defaultFormat"][0] = {};
                        } 
                        emEditor.catalog.type[prop]["defaultFormat"][0][property] = newValue;
                    }else{
                        emEditor.catalog.type[prop][property] = newValue;
                    }
                        
                }
                //send message to studio
                emEditor.studio.setDirty();
                
                if(emTable){
                    return emTable;
                }
        },
        /**
        * add/update a method property
        * @param {String} emName the name of the type
        * @param {String} property the name of the property
        * @param {String} newValue the value of the property
        * @param {String} oldValue the old value of the property
        * @param {String} methName the name of the method
        */
        methodProperty:function( emName, property, newValue, oldValue, methName, notDone, isInherited ) {     


            var emPos           = emEditor.editorData.findEntityModel(emName), 
                methPos         = null, 
                methdNameSpace, 
                oldApply;    

            if (property === "name") {

                _u.extraProperties.renameMethodName(emName, oldValue, newValue);

                if (!_classes[emPos]["methods"]) {
                    _classes[emPos]["methods"] = new Array();
                    methPos = null;
                } else { 
                    methPos = _g.method(emPos, oldValue);
                }
     
                if (methPos != null) { 

                    _classes[emPos]["methods"][methPos].name = newValue;
                    var oldN = _classes[emPos]["methods"][methPos].from;
                    _classes[emPos]["methods"][methPos].from = oldN.replace(oldValue, newValue);
                    if (!notDone) {
                        emEditor.studio.doScript(_conf.studioMessage.renameMethod, oldN.replace(_conf.methodPath.nameSpace+".", "")+"."+newValue);
                    }

                } else {
                    _classes[emPos]["methods"].push({name:newValue});
                }
            
            } else {
                    
                methPos = _g.method(emPos, methName);
                
                if (property === "from") {
                    
                    var val = newValue.split(".");
                    
                    switch (_classes[emPos]["methods"][methPos].applyTo) {
                    case "dataClass": 
                        methdNameSpace = "methods";
                        break;
                    case "entityCollection": 
                        methdNameSpace = "collectionMethods";
                        break;
                    case "entity": 
                        methdNameSpace = "entityMethods";
                        break;
                    default:
                        methdNameSpace = "methods";
                    }
                    
                    newValue = val[0] + "." + methdNameSpace + "." + val[1];    
                    
                } else {
                    
                    if (methPos === null && isInherited) {
                        if(!_classes[emPos]["methods"]){
                            _classes[emPos]["methods"] = new Array();
                        }
                        methPos = _classes[emPos]["methods"].push({name:methName});
                        methPos--;
                    }
                
                    if ( newValue == null ) {
                        delete _classes[emPos]["methods"][methPos][property];
                    } else { 
                        
                        oldApply = _classes[emPos]["methods"][methPos][property];
                    
                        _classes[emPos]["methods"][methPos][property] = newValue;
                        
                        if( property == "applyTo" ) {
                            switch (_classes[emPos]["methods"][methPos].applyTo) {
                            case "dataClass": 
                                methdNameSpace = "methods";
                                break;
                            case "entityCollection": 
                                methdNameSpace = "collectionMethods";
                                break;
                            case "entity": 
                                methdNameSpace = "entityMethods";
                                break;
                            default:
                                methdNameSpace = "methods";
                            }
                            
                            _classes[emPos]["methods"][methPos]["from"] = _conf.methodPath.nameSpace +"."+ emName + "." + methdNameSpace + "." + _classes[emPos]["methods"][methPos].name;
                            
                            if ( oldApply && property == "applyTo" ) {
                                
                                switch (oldApply) {
                                 case "dataClass": 
                                     oldMethdNameSpace = "methods";
                                     break;
                                 case "entityCollection": 
                                     oldMethdNameSpace = "collectionMethods";
                                     break;
                                 case "entity": 
                                     oldMethdNameSpace = "entityMethods";
                                     break;
                                 default:
                                     oldMethdNameSpace = "methods";
                                 }
                                
                                emEditor.studio.doScript("editApplyTo", emName + "." + oldMethdNameSpace + "." + _classes[emPos]["methods"][methPos].name+"."+emName + "." + methdNameSpace + "." + _classes[emPos]["methods"][methPos].name);
                            }
                            
                            
                        }
                    }   
                    
                }
            }   

            //send message to studio
            emEditor.studio.setDirty();
            
        },
        attributeUnderProperty:function( emName, propName, attN, value, underKey, isInherited ) {                               
                                                       
            var emPos   = emEditor.editorData.findEntityModel(emName),
                attPos  = emEditor.editorData.findEmAtrribute(emPos, attN),
                elem;

            if (isInherited) {
                if (!_classes[emPos]["attributes"]) {
                    _classes[emPos]["attributes"] = [];
                }

                if (attPos === null) {
                    attPos = _classes[emPos]["attributes"].push({"name":attN})
                    attPos--;
                }
            }    
            
            elem = _classes[emPos].attributes[attPos];

            if (!elem[underKey]) {
                elem[underKey] = [];
            }
            
            if (!elem[underKey][0]) {
               elem[underKey][0] = {};
            }
            
            if (underKey === "defaultFormat" && !elem[underKey][0].presentation) {
                elem[underKey][0].presentation = _conf.defaultPresentationValue;
            }
            
            elem[underKey][0][propName] = value;
            
            //send message to studio
            emEditor.studio.setDirty();
        },
        inheritedAttributeProperty: function(emName, propName, attName, newValue) {
       
            var emPos           = emEditor.editorData.findEntityModel(emName), 
                attPos          = emEditor.editorData.findEmAtrribute(emPos, attName);    
            
            if (!_classes[emPos]["attributes"]) {
                _classes[emPos]["attributes"] = [];
            }

            if (attPos === null) {
                attPos = _classes[emPos]["attributes"].push({"name":attName})
                attPos--;
            }

            if (newValue === undefined || newValue === null) {
                delete _classes[emPos]["attributes"][attPos][propName];
            } else {
                _classes[emPos]["attributes"][attPos][propName] = newValue;
            }
            
            emEditor.studio.setDirty();
        },
        /**
        * create/update a property
        * @param {String} emName the name of the entity model   
        * @param {String} propName name 
        * @param {String} attName name
        * @param {String} newValue value        
        */
        attributeProperty:function( emName, propName, attName, newValue, kindName, box ) {  

            var emPos           = emEditor.editorData.findEntityModel(emName), 
                attPos          = emEditor.editorData.findEmAtrribute(emPos, attName),
                sciptToUpdate   = false,
                id,
                finalD;

            if (propName === "name") {
                _u.extraProperties.renameAttributeName(emName, attName, newValue);
            }

            if (attPos == null) {
                
                    attPos = this.createNewAttribute(emPos, newValue); 
                    if (kindName == "storage" || kindName == "relatedEntity") {
                        id = emEditor.editorUI.uuid.use();
                        _classes[emPos]["attributes"][attPos-1]["uuid"] = id;
                    }

            } else { 
                if (_classes[emPos]["attributes"][attPos]["kind"] == "calculated" && propName == "name") {
                    if (_classes[emPos]["attributes"][attPos]["scriptKind"] === "javascript") { 
                    
                        sciptToUpdate = true;
                        //update methods name if existing
                        if (_classes[emPos]["attributes"][attPos]["onGet"]) {
                            _classes[emPos]["attributes"][attPos]["onGet"][0].from = _conf .methodPath.nameSpace +"." + emName+"."+newValue+".onGet";
                        }
                        if (_classes[emPos]["attributes"][attPos]["onSet"]) {
                            _classes[emPos]["attributes"][attPos]["onSet"].from = _conf .methodPath.nameSpace + "." + emName+"."+newValue+".onSet";
                        }
                        if (_classes[emPos]["attributes"][attPos]["onQuery"]) {
                            _classes[emPos]["attributes"][attPos]["onQuery"].from = _conf .methodPath.nameSpace + "." + emName+"."+newValue+".onQuery";
                        }
                        if (_classes[emPos]["attributes"][attPos]["onSort"]) {
                            _classes[emPos]["attributes"][attPos]["onSort"][0].from = _conf .methodPath.nameSpace +"." + emName+"."+newValue+".onGet";
                        }
                    }else{ 
                        //update methods name if existing
                        if (_classes[emPos]["attributes"][attPos]["onGet"]) {
                            _classes[emPos]["attributes"][attPos]["onGet"][0].from = newValue;
                        }
                    }
                    if (sciptToUpdate) { emEditor.studio.doScript(_conf .studioMessage.renameAttribute, emName+"."+attName+"."+newValue); }
                } 
                //update or create property
                if (propName === "onGet" || propName === "onSet" || propName === "onQuery" || propName === "onSort") {  

                        if (_classes[emPos]["attributes"][attPos][propName]) { 
                            finalD = _classes[emPos]["attributes"][attPos][propName];
                            //just update the data if already existing
                            if(finalD[0].from){
                                _classes[emPos]["attributes"][attPos][propName][0].from = _conf .methodPath.nameSpace +"."+newValue;
                            }else{
                                _classes[emPos]["attributes"][attPos][propName][0].__CDATA = newValue;
                            }
                        } else {//or create it if not
                            //add new node
                            _classes[emPos]["attributes"][attPos][propName]=[];
                            finalD = _classes[emPos]["attributes"][attPos][propName];

                            if (_classes[emPos]["attributes"][attPos].scriptKind == _conf .xmlData.javascript) {
                                finalD.push({"from": _conf .methodPath.nameSpace +"."+newValue});
                            } else {
                                finalD.push({"__CDATA": newValue});
                            }

                        }

                } else {      

                    if (propName == "kind" && newValue == "calculated" && _classes[emPos]["attributes"][attPos]["kind"] == "storage") {
                        delete _classes[emPos]["attributes"][attPos]["uuid"];
                        if (_classes[emPos]["attributes"][attPos]["fieldPos"]) {
                            delete _classes[emPos]["attributes"][attPos]["fieldPos"];
                        }
                    } 
            
                    if (propName == "type" && kindName == "storage") { 
                        if (_classes[emPos]["attributes"][attPos]["kind"] == "relatedEntity") {
                            delete _classes[emPos]["attributes"][attPos]["path"];
                        }
                        if (_classes[emPos]["attributes"][attPos]["kind"] == "relatedEntities") { 
                            delete _classes[emPos]["attributes"][attPos]["path"];
                            delete _classes[emPos]["attributes"][attPos]["reversePath"];
                            id = emEditor.editorUI.uuid.use();
                            _classes[emPos]["attributes"][attPos]["uuid"] = id;
                            //_classes[emPos]["attributes"][attPos]["fieldPos"] = emEditor.editorData.setFieldPos(emPos);
                        }
                        _classes[emPos]["attributes"][attPos]["kind"] = "storage";
                    }   
                
                    if (box && newValue === null) { 
                        delete _classes[emPos]["attributes"][attPos][propName];
                    } else { 
                        _classes[emPos]["attributes"][attPos][propName] = newValue;
                    }
                
                }
            }
            //send message to studio
            emEditor.studio.setDirty();
        },
        
        modelAttributeProperty : function(t, newValue) {

            emEditor.catalog[t] = newValue;
            emEditor.studio.setDirty();
        },
        
        newAttribute:function( emName, attName, typeName, kindName, relation, path, news, reversePath ) {  


            var rs = true,
                oldType,
                oldKind,
                oldPath,
                attPos,
                emPos;
                
            if (reversePath === false) {
                rs = false;
            }
            
            //find em
            attPos;         
            emPos = emEditor.editorData.findEntityModel(emName);

            if (news) {
                attPos = this.createNewAttribute(emPos, attName);   
            } else {
                attPos = emEditor.editorData.findEmAtrribute(emPos, attName);
                attPos++;
                _u.remove.allProperties(emName, "type", attName);
            }
            
            if (kindName === "storage" || kindName === "relatedEntity") { 
               
                if (path && path.split(".").length === 1) {
                    path = typeName;
                }
                
                if (!_classes[emPos]["attributes"][attPos-1]["uuid"]) {
                    var id = emEditor.editorUI.uuid.use();
                    _classes[emPos]["attributes"][attPos-1]["uuid"] = id;
                    //_classes[emPos]["attributes"][attPos-1]["fieldPos"] = emEditor.editorData.setFieldPos(emPos);
                }
                if (_classes[emPos]["attributes"][attPos-1]["reversePath"]) {
                    delete _classes[emPos]["attributes"][attPos-1]["reversePath"];
                }

            }
            
            oldPath = _classes[emPos]["attributes"][attPos-1]["path"];
            oldType = _classes[emPos]["attributes"][attPos-1]["type"];
            oldKind = _classes[emPos]["attributes"][attPos-1]["kind"];
            
            if( relation && kindName == "relatedEntities" ) {
                _classes[emPos]["attributes"][attPos-1]["reversePath"] = rs;
                _classes[emPos]["attributes"][attPos-1]["path"] = path;           
            } else if( relation ) {
                _classes[emPos]["attributes"][attPos-1]["path"] = path;                   
            }

            _classes[emPos]["attributes"][attPos-1]["type"] = typeName;
            _classes[emPos]["attributes"][attPos-1]["kind"] = kindName;

            if( _classes[emPos]["attributes"][attPos-1]["kind"] === "relatedEntities" ) {
                if(_classes[emPos]["attributes"][attPos-1]["uuid"]){
                    delete _classes[emPos]["attributes"][attPos-1]["uuid"];
                    if (_classes[emPos]["attributes"][attPos-1]["fieldPos"]) {
                        delete _classes[emPos]["attributes"][attPos-1]["fieldPos"];
                    }
                    
                }
            }
            
            if(kindName == "calculated") {
                _classes[emPos]["attributes"][attPos-1]["scriptKind"] = 'javascript';
            }
            
            //send message to studio
            emEditor.studio.setDirty();
          
            if( oldType && oldKind != "storage") {
                 return { oldPath: oldPath, oldTarget : emEditor.catalog.dataClasses[emEditor.emRef[oldType]].name };
            } else {
                return null;
            }
        },
        /**
        * save a new attribute
        * @param {String} emName the name of the entity model   
        * @param {object} att list of the key/values to save            
        */
        saveNewAttribute:function( emName, att ) {
        
            //find em
            var emPos = emEditor.editorData.findEntityModel(emName);
            var attPos = null;
        
            //look at properties and 1) create a new attribute and 2) add mandatory properties
            var id;

            for(var key in att){
    
                if (key === "name") {
                    //create the att and return the pos
                    attPos = this.createNewAttribute(emPos, att[key]);
                }else{
                    //create property
                    _classes[emPos]["attributes"][attPos-1][key] = att[key];
            
                
                    if(key === "kind" && att[key] === "storage"){
                    
                        id = emEditor.editorUI.useUUID();
                        _classes[emPos]["attributes"][attPos-1]["uuid"] = id;
                    /*  var p, newPos, tp;
                        for(var key2 in fieldPos){
                            if(fieldPos[key2].name === emName){p = key2; break;}
                        }
                        tp = fieldPos[p].val;
                        newPos = parseFloat(tp) + 1;
                        fieldPos[p].val = newPos;*/
                        //_classes[emPos]["attributes"][attPos-1]["fieldPos"] = emEditor.editorData.setFieldPos(emPos);                     
                    }
                }
            }
        
            //send message to studio
            emEditor.studio.setDirty();
        },
        /**
        * create a new attribute for given em pos. Just enter the name.
        * @param {number} emPos position of the em in the emEditor.catalog   
        * @param {string} nameValue name of the new attribute   
        * @return {number} pos of the new att in the em properties          
        */
        createNewAttribute: function( emPos, nameValue ) {
            var pos;
            if(_classes[emPos]["attributes"]){
                pos = _classes[emPos]["attributes"].push({"name":nameValue});
            }else{
                _classes[emPos]["attributes"] = [];
                pos = _classes[emPos]["attributes"].push({"name":nameValue});
            }
            //add the scope default value
            _classes[emPos]["attributes"][pos-1].scope = _conf .param.scopeDefaultValue;
            return pos;
        }
    };//end updateCatalog object
    
    _u.changeMethoViewState= function( viewInPanel ) {
        
    };    
    
    _u = emEditor.editorData.updateCatalog;
})();