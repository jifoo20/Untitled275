/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* check : this part only check informations in the calatlog, no update here
*/
(function() { 
    emEditor.editorData.check = {
        
        isNoEdit: function(emName) {

            var res = false,
                emPos = _g.entityModel(emName),
                classe = _classes[emPos];

            if (classe) {

               if (classe.noEdit || classe.noSave) {
                    res = true;
               }

            }     

            return res;

        },
        /**
        * look if a em is used in the emEditor.catalog as a type in a relation
        * @param {String} emName   
        * @return {array}          
        */
        useAsaTypeInRelation:function(emName){
            var ems = _classes, atts;
            var res = [];
            for(var k in ems){
                atts = ems[k]["attributes"];
                for(var a in atts){
                    if(atts[a]["kind"] == "relatedEntity" && atts[a]["type"] == emName){
                        //res.push(ems[k]["name"]);
                        res.push({emName:ems[k].name, attProp : atts[a]});
                    }
                }
            }
            return res;
        },
        isRelatedEntityInUseAsPath:function(emTarget, relName, emToLookIn){

            var rel = _g.relationShips(emToLookIn);
            var res = false;
            var mn = _g.collectionName(emTarget);
            
            $.each(rel, function(index, value) { 
              if(value.kind == "relatedEntities"){
                  if(value.path == relName && value.type == mn){
                      res = true;
                      return;
                  }
              } 
            });
        
            return res;
        
        },
        lookForNonValideType:function(test){
        
            var ems = _classes;
            var atts;
            var res = [];
            for(var e in ems){
                atts = ems[e].attributes;
                for(var a in atts){
                    if(atts[a].type === test){
                        keep = {emName:ems[e]["className"], emPos:e, attPos:a, attName:atts[a].name};
                        res.push(keep);
                    }
                } 
            }
        
            return res;
            //var emPos = _g.entityModel(emName);
            //this.isType(ty);
        },
        methodName:function(emName, methName){
            var exist = false;
            var emPos = _g.entityModel(emName);
            var meth = _classes[emPos]["methods"];
            for(key in meth){
                if(meth[key].name == methName){exist = true; break;}
            }
            return exist;
        },
        computedAttributes:function(emName, attName, type){
            var emPos = _g.entityModel(emName);
            var attPos = _g.emAtrribute(emPos, attName);
            var att = _classes[emPos]["attributes"][attPos];
            var exist = false;
            if(att[type]){
                exist = true;
            }
            return exist;
        },
        whosExtends:function(emName){
            var ems = _classes, ex, result=[];
            for(var key in ems){
                ex = ems[key]["extends"];
                if(ex){
                    if(ex == emName){
                        result.push(ems[key]["className"]);
                    }
                }
            }
            return result;
        },
        isRelatedAtt:function(emName, attName){ 
            var emPos = _g.entityModel(emName);
            var relName = null, relPos, destinationTable = null, extEm;
            var emAtt = _classes[emPos]["attributes"];
    
            for(var key in emAtt){ 
                if(emAtt[key].name == attName){
                    if(emAtt[key].kind == "relatedEntity" || emAtt[key].kind == "relatedEntities"){
                        relName = emAtt[key].type;
                    }
                    break;
                }
            }
        
            if(relName == null){
                    extEm = emEditor.editorData.check.doesExtends(emName);
                    while(extEm){
                        emPos = _g.entityModel(extEm);
                        emAtt = _classes[emPos]["attributes"];
                        for(var key in emAtt){ 
                            if(emAtt[key].name == attName){
                                if(emAtt[key].kind == "relatedEntity" || emAtt[key].kind == "relatedEntities"){
                                    relName = emAtt[key].type;
                                }
                                break;
                            }
                        }
                        extEm = emEditor.editorData.check.doesExtends(extEm);
                    }
            }
        
            return relName;
        
        },
        isInDataList:function(val, tab){ 
            var is = false;
            for(var key in tab){ 
                if(tab[key] == val){ is = true; break;}
            }
            return is;
        },
        isEm:function(name){

            /*var is = false;            
            for(var key in _classes){
                if( _classes[key]["collectionName"] == name ){ is = true; break;}
            }
            return is;*/
            
            var is = false
            if( _classes[emEditor.emRef[name]] && _classes[emEditor.emRef[name]]["collectionName"] == name ) {
                is = true;
            }
            return is;
            
        },
        isSingleEm:function(name){ 
            /*var is = false;            
            var ems = _classes;
            for(var key in ems){
                if(ems[key]["className"] == name){ is = true; break;}
            }
            return is;*/
            var is = false;
            if( _classes[emEditor.emRef[name]] && _classes[emEditor.emRef[name]]["className"] == name ) {
                is = true;
            }
            return is;
        
        },
        scalarType:function(ty){
            var cus = _g.customTypes();
            if(this.isInDataList(ty, cus)){
                return _g.customTypeExtend(ty);
            }else{
                return ty;
            }
        },
        isType:function(name){
            var cus = _g.customTypes();
            var r = cus.concat(_conf .scalarTypes);
            return this.isInDataList(name, r);
        },
        doesExtends:function(name){
            //find em pos
            var pos = _g.property(name, "extends");
            if(pos != null){
                return _classes[pos]["extends"];
            }else{
                return null;
            }
        
        },
        isBool:function(name){
            var isB = false;
            for(var key in _conf .bool){
                if(name == _conf .bool[key]){
                    isB= true;
                    break;
                }
            }

            return isB;
        },
        propertiesRemaining:function(emName, notSavedItems){
            var rem = true, props=[];
            props = _g.emProperties(emName);
        
            if(props){
                var remain = props.length+1;                //!!!!! +1
                if(notSavedItems){
                    remain = remain + notSavedItems.length;
                }                       
                if(remain === _conf .emProperty.length){
                    rem = false;
                }
            }
            return rem;
        },
        checkDataIntegrity:function(){
            //look for type 
            
            //look for path
            
        }
    };
    
    _check = emEditor.editorData.check;
})();