/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* data editor object, management of the Data
* 
*/

emEditor.editorData = (function() { 
    
    emEditor.catalog;
    emEditor.attTreeToRemove = [];
    emEditor.done = [];
    emEditor.waitingToBeAdded;
    emEditor.emRef = {};
 
  // publique members 
  return { 
    getEmData:function( jsonData, perms, directory) { 

        //console.timeEnd('getEmData');
        if( emEditor.getJsonObject && emEditor.webarea ) {
            alert(jsonData);
        }
        
        var al      = false,
            version = null;

        try {
            if (emEditor.catalog) {
                al = true; 
            }
            (typeof jsonData == "string") ? emEditor.catalog = JSON.parse(jsonData) : emEditor.catalog = jsonData;
        } catch(error) {
            alert("oups, the JSON string is not valide !");
        }

        if (!emEditor.catalog.dataClasses) {

            emEditor.catalog.extraProperties = {};
            emEditor.catalog.extraProperties.version = "1";
            emEditor.catalog.extraProperties.classes = {};
            emEditor.catalog.extraProperties.model = {};
            emEditor.catalog.dataClasses = []; 
            _classes = emEditor.catalog.dataClasses;

        } else {

            _classes = emEditor.catalog.dataClasses;

        }
        
        if (perms && directory) {
            
            emEditor.handlePerms = true;
            this.initPermission( perms, directory );
        
        } else {
        
            emEditor.handlePerms = false;
        
        }
        
        if (emEditor.catalog.dbInfo && emEditor.catalog.dbInfo[0].name) {
        
            emEditor.modelName = emEditor.catalog.dbInfo[0].name;
        
        }

        if (emEditor.catalog.extraProperties && emEditor.catalog.extraProperties.version === "1") {

            _classesProperties  = emEditor.catalog.extraProperties.classes;
            _modelProperties    = emEditor.catalog.extraProperties.model;

            if (al) { 
                emEditor.editorUI.reloadCatInUI();
            } else {
                emEditor.editorUI.initUI();
            }

        } else { 

            if (emEditor.catalog.extraProperties && emEditor.catalog.extraProperties.version) {
                version = parseInt(emEditor.catalog.extraProperties.version);
            }

            if (version != null && version > 1) {

                $("body").removeClass("waf-loading").css("overflow", "hidden");
                $("#updateMaskRecent").show();

            } else { 

                $("body").removeClass("waf-loading").css("overflow", "hidden");
                $("#updateMask").show();
                $("#update").click(function(){
                    $("body").addClass("waf-loading").css("overflow", "auto");
                    $("#updateMask").remove();
                    _u.extraProperties.switchFromWak3();
                    emEditor.editorUI.initUI();
                    emEditor.studio.setDirty();
                });

            }
        }
    
    },
    initPermission : function( perms, directory ) { 
        
     //   console.log(perms, directory, "initPermission");
        
        _perm.hide();
        var noPerm = false;
        
        if( emEditor.getJsonObject && emEditor.webarea ) {
            alert(perms);
            alert(directory);
        }
        
        if ( !emEditor.perms ) {
            emEditor.perms = {};
        }
        
        try{
            (typeof perms == "string") ? emEditor.perms.perms = JSON.parse(perms) : emEditor.perms.perms = perms;
        }catch(error){
            noPerm = true;
            error.log("oups, the permsmissions JSON string is not valide !");
        }
        
        try{
            (typeof directory == "string") ? emEditor.perms.groups = JSON.parse(directory) : emEditor.perms.groups = directory;
        }catch(error){
            noPerm = true;
            error.log("oups, the directory JSON string is not valide !");
        }
        
        if(!emEditor.perms.perms) {
            emEditor.perms.perms = {};
        }

        if( noPerm || !emEditor.perms.groups.group ) {
            
            emEditor.handlePerms = false;
            emEditor.perms = {};
        }
        
       // console.log("permissions", emEditor.perms)

    },
    reloadPerms:function( jsonString ) {
            //console.log("reloadPerms", jsonString);
            try{
                (typeof jsonString == "string") ? emEditor.perms.perms = JSON.parse(jsonString) : emEditor.perms.perms = jsonString;
            }catch(error){
                error.log("oups, the permsmissions JSON string is not valide !");
            }
            _perms.get.userGroups();
            _perms.set.buildIndex();
            _perm.build(); 
        
    },
    reloadDirectory:function( jsonString ) {
            //console.log("reloadDirectory", jsonString)  
            try{
                (typeof jsonString == "string") ? emEditor.perms.groups = JSON.parse(jsonString) : emEditor.perms.groups = jsonString;
                noPerm = false;
            }catch(error){
                noPerm = true;
                error.log("oups, the permsmissions JSON string is not valide !");
            }
          
            if (!emEditor.perms.groups.group) {
                noPerm = true;
            } else {
                noPerm = false;
            }
            
            if( !emEditor.perms.perms ){
                emEditor.perms.perms = {};
                emEditor.perms.perms.allow = [];
            }
            
            if (noPerm) {
                emEditor.handlePerms = false;
                _perm.hide();
            } else {
                emEditor.handlePerms = true;
                _perms.get.userGroups();
                _perms.set.buildIndex();
                _perm.build();
            }
        
    },
    /*
    *   deprecated wak4
    */
    setFieldPos:function(emPos){
        var att = _classes[emPos].attributes, fieldpos = null, fp = [];
        for(var k in att){
            if(att[k].fieldPos){ 
                fp.push(parseInt(att[k].fieldPos));
            }
        }
        fp.sort(function(a,b){return a - b}) 
        
        for(var b in fp){
            if(fieldpos != null && parseInt(fieldpos)+1 != fp[b]){
                break;
            }else{
                fieldpos = fp[b];
            }
        }
        if(fieldpos == null){fieldpos = 0;}
        
        return parseInt(fieldpos)+1;
    },
    /*
    *   deprecated wak4
    */
    setTablePos:function(){ 
        var ems = _classes, tablepos = null, tp=[];
        for(var k in ems){
            if(ems[k].tablePos){ 
                tp.push(parseInt(ems[k].tablePos));
            }
        }
        tp.sort(function(a,b){return a - b}) 
        
        for(var b in tp){
                if(tablepos != null && parseInt(tablepos)+1 != tp[b]){
                    break;
                }else{
                    tablepos = tp[b];
                }
        }
        if(tablepos == null){tablepos = 0;}
        return parseInt(tablepos)+1;
    },
    /**
    * add the dbInfo into the file
    */
    isBool:function(name){  //REMOVE REMOVE REMOVE REMOVE REMOV ??????
        var isB = false;
        for(var key in _conf .bool){
            if(name == _conf .bool[key]){
                isB= true;
                break;
            }
        }
        
        return isB;
    },
    /**
    * receive and process json data
    * @param {String} jsonData This is the Entity Model file into json string
    */
    addDbInfo:function(){
        if(!emEditor.catalog.dbInfo){
            emEditor.catalog.dbInfo= new Array;
            var id = emEditor.editorUI.uuid.use();
            emEditor.catalog.dbInfo.push({uuid:id, collation_locale: "fr"});
        } 
    },
    /**
    * return the emEditor.catalog's js object 
    * @return {onject} em emEditor.catalog
    */
    cat:function(){
        return emEditor.catalog;
    },
    /**
    * find if a em extends another one
    * @param {String} enMame the name of the entity model   
    * @return {string} value of the property                
    */
    doesExtends:function(enMame){
        //find em pos
        var value = null;
        var pos = this.findProperty(enMame, "extends");
        if(pos){value = _classes[pos]["extends"];}
        return value;
    },
    /**
    * return the list of the em in the emEditor.catalog  //REMOVE REMOVE REMOVE REMOVE REMOV
    * @param {String} tableOnly get only table  
    * @return {js object} list          
    */
    getEmList:function(tableOnly){
        var values = _classes;
        var list = [];
        for ( var key in values ) {
            if(tableOnly){
                if(!values[key]["extends"]){list.push(values[key].name);}
            }else{
                list.push(values[key].name);
            }
            
        }//end for
        
        return list;
    },
    //not used
    getTypeAttributeList:function(typeName){
        var pos = this.findType(typeName);
        var values = emEditor.catalog.type[pos], attTab = [];
        for ( var key in values ) {
            attTab.push({key:key , value:values[key]});
        }//end for
        
        return attTab;
    },
    /**
    * return the list of all the attributes of an em
    * @param {String} emName 
    * @param {bool} juste look for field type attributes            
    * @return {array}           
    */
    getAttributesList:function(emName, tableOnly){ //REMOVE REMOVE REMOVE REMOVE REMOVE

        var emPos = this.findEntityModel(emName);
        var attList = [], att;
        att = _classes[emPos]["attributes"];
        for ( var key in att ) {
            if( att[key].kind != "removed" ) {
                if(tableOnly){
                    if( att[key].kind=="storage" ){ attList.push(att[key].name); }
                }else{
                    attList.push(att[key].name);
                }
            }
            
        }
        return attList;
    },
    /**
    * return the list of all the types of an em         
    * @return {array} array of types names          
    */
    getTypes:function(from){
        var values = emEditor.catalog.type, tab = [];
        for(key in values){
            tab.push(values[key].name);
        }
        return tab;
    },
    /**                             DEPRECATED
    * return the list of the relations in the emEditor.catalog   
    * @return {js object} list          
    */
    getRelationsList:function(oneToMany, all){ 
        var values = emEditor.catalog.relationship;
        var list = [];
        for ( var key in values ) {
            if(all){
                list.push(values[key].name);
            }else{
                if(oneToMany){
                    if(values[key].kind === "oneToMany"){list.push(values[key].name);}
                }else{
                    if(values[key].kind != "oneToMany"){list.push(values[key].name);}
                }
            }
        }//end for
        
        return list;
    },
    /**
    * send a message to the c for the "not saved" indicator
    * 
    */
    dataUpdated:function(jsonData){
        this.wafMessage.send(modified);
    },
    stringify:function(data, key) {
         // Initialise any required variables
         var i = null,
             built = '',
             meta = {
           '\b': '\\b',
           '\t': '\\t',
           '\n': '\\n',
           '\f': '\\f',
           '\r': '\\r',
           '"': '\\"',
           '\\': '\\\\'
             },
             escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

         /**
          * Returns the JSON correctly
          * 
          * @param {String} str The JSON string
          * @returns {String} The correct JSON string with keys included if required
          * @private
          */

         function ret(str) {
            return (key) ? '"' + key + '":' + str : str;
         }

         /**
          * Escapes certain characters out of the string
          * 
          * @param {String} string The string with characters that need to be escaped
          * @returns {String} The escaped string
          * @private
          */
         function esc(string) {
            // Escape characters
            escapable.lastIndex = 0;
            return escapable.test(string) ? '"' + string.replace(escapable, function(a) {
                    var c = meta[a];
                    return typeof c === 'string' ? c : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                }) + '"' : '"' + string + '"';
            }

            // Check what it is
            if (data instanceof Array) {
                // Loop through the array
                for (i = 0; i < data.length; i++) {
                    built += emEditor.editorData.stringify(data[i]) + ',';
                }

                return ret('[' + built.slice(0, built.length - 1) + ']');
            }
            else if (typeof data === 'object') {
                // Loop through the object
                for (i in data) {
                    // Check the value is not a prototype
                    if (data.hasOwnProperty(i)) {
                        built += emEditor.editorData.stringify(data[i], i) + ',';
                    }
                }

                return ret('{' + built.slice(0, built.length - 1) + '}');
            }
            else if (typeof data === 'string') {
                // Return the string
                return ret(esc(data));
            }
            else {
                // Return anything else (numbers, booleans etc) as a string
                return ret(data.toString());
            }
    },
    /**
    * 
    * return the catalog for save purpose
    */
    saveEmFile:function() {
        
        var str,
            dataClasses,
            object = {};
        
        //remove noSave/noEdit classes
        dataClasses = jQuery.map(emEditor.catalog.dataClasses, function(n, i){
            if (!n.noSave && !n.noEdit) {
                return n;    
            }   
        });

        //build new object to save
        $.each(emEditor.catalog, function(index, value) { 
            if (index === "dataClasses") {
                object[index] = dataClasses;    
            } else {
                object[index] = value;
            }
        });

        if( emEditor.catalog ) {
            str = JSON.stringify(object);
        } else {
            str = "";
        }

        return str;
    },
    savePermFile:function() {
        var str;
        
        if( emEditor.perms && emEditor.perms.perms ) {
            str = JSON.stringify( emEditor.perms.perms );
        } else {
            str = "";
        }
        
        return str;
    },
    /**
    * find if a method does exist into an entity
    * @param {String} emPos the pos of the em to search in  
    * @param {String} attName the name of the att to search     
    * @return {number} position of the att in the array "attribute" (could be null) 
    */
    findEmAtrribute:function(emPos, attName){
        //find pos of the em 
        if(!_classes[emPos]["attributes"]){
            _classes[emPos]["attributes"]= new Array;
        }
        var l = _classes[emPos]["attributes"].length, pos=null;
        for(i=0; i<l; i++){
            if(_classes[emPos]["attributes"][i]["name"] == attName){pos = i; break;}
        }
        return pos;
    },
    /**                 
    * find an em                                    deprecated!!
    * @param {String} emName the name of the entity model to use    
    * @return {number} position of the em in the emEditor.catalog    
    */
    findEntityModel:function(emName){ 
      if( emEditor.emindex ){
            if( emEditor.emRef[emName] != null ){
                return emEditor.emRef[emName]; 
            }else{
                return null;
            }
        }else{
            var l = _classes.length, pos=null, exist=null;
            for( var i=0; i<l; i++ ) {
                if (_classes[i]["className"] == emName ){ pos = i; break; } //name
            }
            return pos;
        }
    },//end find property
    /**
    * find if a relation does exist into an entity                          REMOVE-REMOVE-REMOVE-REMOVE-REMOVE-REMOVE-REMOVE !!
    * @param {String} relName the name of the rel to use    
    * @return {number} position of the rel in the array "relationShip"  (could be null) 
    */
    findRelation:function(relName){
        var pos=null, exist=null;
        if(emEditor.catalog.relationship){
            var l = emEditor.catalog.relationship.length;
            for(var i=0; i<l; i++){
                if(emEditor.catalog.relationship[i]["name"] == relName){pos = i; break;}
            }
        }else{
            emEditor.catalog.relationship = new Array();
            pos = null;
        }
        
        return pos;
    },
    /**                                             REMOVE-REMOVE-REMOVE-REMOVE-REMOVE-REMOVE-REMOVE !!
    * find if a property does exist into an entoty
    * @param {String} emName the name of the entity model to use    
    * @param {String} property name of the property to search
    * @return {number} position of the entity model in the emEditor.catalog  (could be null) 
    */
    findProperty:function(emName, property){                        //REMOVE REMOVE REMOVE REMOVE
        
        //find pos of the em 
        var l = _classes.length, pos=null, exist=null;
        for(i=0; i<l; i++){
            if(_classes[i]["name"] == emName){pos = i; break;}
        }
        
        //find if the property does exist
        var values = _classes[pos];
        for ( var key in values ) {
            if(key === property){
                exist=pos; break;
            }
        }//end for

        return exist;
        
    }//end find property
    
  }; 


  
})();
//***end emEditor.editorData