/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
/**
* all about extraProperties     
*/
(function() { 
    _u.extraProperties = { 
        switchFromWak3: function() {

            if (emEditor.catalog.extraProperties) {
                
                var temp = jQuery.extend(true, {}, emEditor.catalog.extraProperties);
                delete emEditor.catalog.extraProperties;

                emEditor.catalog.extraProperties            = {};
                emEditor.catalog.extraProperties.model      = {};
                emEditor.catalog.extraProperties.classes    = {};

                emEditor.catalog.extraProperties.model = temp;

            } else {

                emEditor.catalog.extraProperties            = {};
                emEditor.catalog.extraProperties.model      = {};
                emEditor.catalog.extraProperties.classes    = {};

            }

            _classesProperties  = emEditor.catalog.extraProperties.classes;
            _modelProperties    = emEditor.catalog.extraProperties.model;

            emEditor.catalog.extraProperties.version = "1";

            var classes = emEditor.catalog.dataClasses,
                className;

            $.each(classes, function(index, value) { 
                
                className = value.name;    

                if (value.extraProperties) {
                    _classesProperties[className] = jQuery.extend(true, {}, value.extraProperties);
                    //delete value.extraProperties;
                }

                if (value.attributes) {
                    
                    $.each(value.attributes, function(indexAtt, valueAtt) { 
                        
                        if (valueAtt.extraProperties) {
                            if (!_classesProperties[className].attributes) {
                                _classesProperties[className].attributes = {};
                            }
                            _classesProperties[className].attributes[valueAtt.name] = valueAtt.extraProperties;
                            //delete valueAtt.extraProperties;
                        }

                    });

                }

                if (value.methods) {
                    
                    $.each(value.methods, function(indexMeth, valueMeth) { 
                        
                        if (valueMeth.extraProperties) {
                            if (!_classesProperties[className].methods) {
                                _classesProperties[className].methods = {};
                            }
                            _classesProperties[className].methods[valueMeth.name] = valueMeth.extraProperties;
                            //delete valueMeth.extraProperties;
                        }

                    });

                }

            });
        },
        cleanExtraProperties: function() {
            //to do
        },
        renameClassName: function(oldName, newName) {

            if (_classesProperties[oldName]) {
                _classesProperties[newName] = jQuery.extend(true, {}, _classesProperties[oldName]);
                delete _classesProperties[oldName];
            }

        },
        renameAttributeName: function(className, oldName, newName) {

            if (_classesProperties[className] && _classesProperties[className].attributes && _classesProperties[className].attributes[oldName]) {
                _classesProperties[className].attributes[newName] = jQuery.extend(true, {}, _classesProperties[className].attributes[oldName]);
                delete _classesProperties[className].attributes[oldName];
            }

        },
        renameMethodName: function(className, oldName, newName) {

            if (_classesProperties[className] && _classesProperties[className].methods && _classesProperties[className].methods[oldName]) {
                _classesProperties[className].methods[newName] = jQuery.extend(true, {}, _classesProperties[className].methods[oldName]);
                delete _classesProperties[className].methods[oldName];
            }

        },
        removeClass: function extraProperties_removeClass (className) {

            if (_classesProperties[className]) {
                delete _classesProperties[className];
            }

        },
        removeAttribute: function extraProperties_removeAttribute (className, attName) {

            if (_classesProperties[className] && _classesProperties[className].attributes && _classesProperties[className].attributes[attName]) {
                delete _classesProperties[className].attributes[attName];
            }

        },
        removeMethod: function extraProperties_removeMethod(className, methName) {

            if (_classesProperties[className] && _classesProperties[className].methods && _classesProperties[className].methods[methName]) {
                delete _classesProperties[className].methods[methName];
            }

        },
        checkForClass : function(className) {

            if (!_classesProperties[className]) {
                _classesProperties[className] = {};
            }            

            return _classesProperties[className];

        },
        checkForMethod : function(className, methName) {

            if (!_classesProperties[className]) {
                _classesProperties[className] = {};
            }

            if (!_classesProperties[className].methods) {
                _classesProperties[className].methods = {};
            } 

            if (!_classesProperties[className].methods[methName]) {
                _classesProperties[className].methods[methName] = {};
            } 

            return _classesProperties[className].methods[methName];

        },
        checkForAttribut : function(className, attName) {

            if (!_classesProperties[className]) {
                _classesProperties[className] = {};
            }

            if (!_classesProperties[className].attributes) {
                _classesProperties[className].attributes = {};
            } 

            if (!_classesProperties[className].attributes[attName]) {
                _classesProperties[className].attributes[attName] = {};
            } 

            return _classesProperties[className].attributes[attName];

        },
        noteForMethods : function(className, methName, value) {

            var path = this.checkForMethod(className, methName);

            path.note = value;
            emEditor.studio.setDirty();
        },
        noteForAttributes : function(className, attName, value) {

            var path = this.checkForAttribut(className, attName); 

            path.note = value;

            emEditor.studio.setDirty();
        },
        noteForClass : function(className, value) {
            
            var emPos = emEditor.editorData.findEntityModel(className),
                path;

            path = this.checkForClass(className);

            path.note = value;

            emEditor.studio.setDirty();
        },
        noteForModel : function( newValue ) {

            var ec = _modelProperties;
            ec.note = newValue;
            
            emEditor.studio.setDirty();
        },  
        resizedHeight:function( h, emName ) {

            var path = this.checkForClass(emName);

            if (!path.panel) {
                path.panel = {};
            }

            path.panel.resizedHeight = h;

            emEditor.studio.setDirty();



        },
        setPathState:function( visible, emName ) {

            var path = this.checkForClass(emName);

            if (!path.panel) {
                path.panel = {};
            }

            if (visible) {
                path.panel.pathVisible = true;
            }else{
                path.panel.pathVisible = false;
            }

            emEditor.studio.setDirty();
        },
        setPanelOpen:function( open, emName ) { 

            var path = this.checkForClass(emName);

            if (!path.panel) {
                path.panel = {};
            }

            if (open) {
                if(path.panel.isOpen != "true"){ 
                    path.panel.isOpen = "true";
                    emEditor.studio.setDirty();
                }
            } else {
                path.panel.isOpen = "false";
                emEditor.studio.setDirty();
            }

        },
        changeAttViewState:function(exp, viewInPanel){
            var ems = _classes,
                path;

            $.each(ems, function(index, value) { 
              
                path         = this.checkForClass(className);
                path[exp]    = viewInPanel+"";

            });
            
            emEditor.studio.setDirty();
        }, 
        setScriptMode: function( mode ) {
            
            _modelProperties["scriptMode"] = mode;

            emEditor.scriptMode = mode;
            
            emEditor.studio.setDirty();
        },
        set: function(emName, k, res) {

            var path = this.checkForClass(emName);
            path[k] = res+"";
            
            emEditor.studio.setDirty();
        },
        definePanelColor:function(emName, color){

               var path = this.checkForClass(emName);
               path.panelColor = color;

               emEditor.studio.setDirty();
            
        },
        defineMinimizeState: function(emName, state) {

            var path = this.checkForClass(emName);
            path.isMinimized =  ""+ state +"";

            emEditor.studio.setDirty();
        },
        defineAttDisplay: function(exp, set) {

           _modelProperties[exp] = set+"";

           emEditor.studio.setDirty();
        },
        setRelationState: function(relationCurve, relationCurveMode) {  

            if (!_modelProperties.relationCurve) {
                _modelProperties.relationCurve = {};
            }

            _modelProperties.relationCurve.run = relationCurve;
            _modelProperties.relationCurve.mode = relationCurveMode;

            emEditor.studio.setDirty();
        },
        /**
        * set if removed extended attributes are visible or not for this em
        * @param {String} emName
        * @param {bool} visible     
        */
        keepRemovedState:function(emName, visible){

           var path = this.checkForClass(emName);
           path.removedVisible = visible;

           emEditor.studio.setDirty();
       }
    };
})();