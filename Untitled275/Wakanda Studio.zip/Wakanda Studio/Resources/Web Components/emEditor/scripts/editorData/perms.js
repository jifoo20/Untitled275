/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() { 
    
    //selectedGroup.forcedGroup && selectedGroup.group != selectedGroup.forcedGroup
    
    emEditor.editorData.perms = {};
    _perms = emEditor.editorData.perms;
    
    _perms.get = {};
    _perms.set = {};
    
    _perms.get.userGroups = function() {
        
        var gp = emEditor.perms.groups.group;
        emEditor.usergroup = [];
        
        $.each(gp, function(index, value) { 
          emEditor.usergroup.push(value.name); 
        }); 
        
        return emEditor.usergroup;       
    };
    
    _perms.get.userGroups = function() {
        
         var gp;
         emEditor.usergroup = [];
        
        if( emEditor.perms && emEditor.perms.groups ) {

            gp = emEditor.perms.groups.group;
                
            $.each(gp, function(index, value) { 
              emEditor.usergroup.push(value.name); 
            }); 
        
        }
        
        return emEditor.usergroup;       
    };
    
    _perms.buildGroupIndex = function() {
        var groups = emEditor.perms.groups.group;
        emEditor.perms.groupIndex = {};
        
        $.each(groups, function(index, value) { 
          emEditor.perms.groupIndex[value.ID] = value.name;
        })
        
    };
    
    _perms.get.permissionsData = function( target, verb ) { //target = "class" || "meth"
        
        var currentElem     = emEditor.selectedItems,
            emName          = null,
            target,
            methName        = null,
            allow           = emEditor.perms.perms.allow, 
            group           = null,
            forcedGroup     = null,
            isForced        = false,
            hasBeenDefined  = false,
            originalGroup;

        function findGroupAtModelLevel ( checkForce ) {
            
            var defined = false;
            
            if( _permIndex["*"] && _permIndex["model"][emEditor.modelName][verb] ) {
                group = _permIndex["model"][emEditor.modelName][verb].group;
                defined = true;
                if( _permIndex["model"][emEditor.modelName][verb].force == "true" ) {
                    forcedGroup = group;
                    if( checkForce ) { isForced = true; }
                }
            }
            
            if( _permIndex["model"] && _permIndex["model"][emEditor.modelName] && _permIndex["model"][emEditor.modelName][verb] ) {
                group = _permIndex["model"][emEditor.modelName][verb].group;
                defined = true;
                if( _permIndex["model"][emEditor.modelName][verb].force == "true" ) {
                    forcedGroup = group;
                    if( checkForce ) { isForced = true; }
                }
            }
            
            return defined;
        };
        
        function findGroupAtClassLevel ( checkForce ) {
                        
            var defined = false;
                        
            if( _permIndex["dataClass"] && _permIndex["dataClass"][emEditor.modelName+"."+emName] && _permIndex["dataClass"][emEditor.modelName+"."+emName][verb] ) {
                group = _permIndex["dataClass"][emEditor.modelName+"."+emName][verb].group;
                defined = true;
                if( checkForce ) {
                    hasBeenDefined = false;
                }
                if( _permIndex["dataClass"][emEditor.modelName+"."+emName][verb].force  == "true" ) {
                    forcedGroup = group;
                    if( checkForce ) { isForced = true; }
                }
            }
            return defined;
        };    
        
        function findGroupAtMethodLevel ( checkForce ) {
            
            var defined = false;
            
            if( _permIndex["method"] && _permIndex["method"][emEditor.modelName+"."+emName+"."+methName] && _permIndex["method"][emEditor.modelName+"."+emName+"."+methName][verb] ) {
                group = _permIndex["method"][emEditor.modelName+"."+emName+"."+methName][verb].group;
                defined = true;
                if( checkForce ) {
                    //hasBeenDefined = false;
                }
                if( _permIndex["method"][emEditor.modelName+"."+emName+"."+methName][verb].force  == "true" ) {
                    forcedGroup = group;
                    if( checkForce ) { isForced = true; }
                }
            }
            return defined;
        };

        if( currentElem.item ) { //method selected
            
            target      = "method";
            methName    = currentElem.item.dataset.info;
            //methName    = $(currentElem.item).attr("waf-data");
            emName      = currentElem.emName;
            
        } else if( currentElem.emName == "___MODEL" ) { //model selected
            
            target = "model";
            
        } else { //class selected
            
            emName = currentElem.emName;
            target = "dataClass";
            
        }
        
        if( !emEditor.perms.index ) {
            
            _perms.set.buildIndex();
            
        }


        switch( target ) {
        case "model": 
            
            //model level
            findGroupAtModelLevel( true );
                        
            break;
        case "dataClass": 
            
            //model level
            hasBeenDefined = findGroupAtModelLevel();

            //dataClass Level
            findGroupAtClassLevel( true );

            break;
        case "method": 
            var a = false;
            //model level
            hasBeenDefined = findGroupAtModelLevel();
            if(hasBeenDefined) {
                a = true;
            }
            //dataClass Level
            hasBeenDefined = findGroupAtClassLevel();
            if(hasBeenDefined) {
                a = true;
            }
            //method level
            hasBeenDefined = findGroupAtMethodLevel( true );

            if(!hasBeenDefined && a){
                hasBeenDefined = a;
            } else if ( hasBeenDefined ) {
                hasBeenDefined = false;
            }
            break;
        default:
        }
     
        if( forcedGroup ) {
            originalGroup = group;
            group = forcedGroup;       
        }

        return { "group":group, isForced:isForced, isHerited : hasBeenDefined, forcedGroup:originalGroup };
    }

    _perms.set.buildIndex = function() {
        
        var allow = emEditor.perms.perms.allow,
            toRemove = [],
            go;
        _perms.buildGroupIndex();
       
        emEditor.perms.index            = {};
        emEditor.perms.index.model      = {};
        emEditor.perms.index.method     = {};
        emEditor.perms.index.dataClass  = {};
        
        _permIndex = emEditor.perms.index;
        
        if( allow ) {
            $.each(allow, function(index, value) { 
                
                if( !emEditor.perms.groupIndex[value.groupID] ) { 
                      if(!_uA.isValueIn( value.groupID, toRemove ) ) {
                          toRemove.push(value.groupID);
                      }
                } else {
                     if( value.type == "model" ) {

                            if (!_permIndex.model[value.resource]) {
                                _permIndex.model[value.resource] = {};
                            }
              
                            _permIndex.model[value.resource][value.action]        = {};                    
                            _permIndex.model[value.resource][value.action].group  = emEditor.perms.groupIndex[value.groupID];
                            _permIndex.model[value.resource][value.action].force  = value.temporaryForcePermissions;

                      }

                      if( value.type == "dataClass" ) {
                          if (!_permIndex.dataClass[value.resource]) {
                              _permIndex.dataClass[value.resource] = {};
                          }
                          _permIndex.dataClass[value.resource][value.action]          = {};
                          _permIndex.dataClass[value.resource][value.action].group    = emEditor.perms.groupIndex[value.groupID];
                          _permIndex.dataClass[value.resource][value.action].force    = value.temporaryForcePermissions;

                      }

                      if( value.type == "method" ) {
                          if (!_permIndex.method[value.resource]) {
                              _permIndex.method[value.resource] = {};
                          }
                          _permIndex.method[value.resource][value.action]         = {};
                          _permIndex.method[value.resource][value.action].group   = emEditor.perms.groupIndex[value.groupID];
                          _permIndex.method[value.resource][value.action].force   = value.temporaryForcePermissions;
                      }
                }

            });



           /*if( toRemove.length != 0 ) {
                $.each(toRemove, function(index, value) { 
                    go = true;
                    
                    while( go ) {
                        $.each(allow, function(idx, val) { 
                            if (idx == allow.length-1 ) {
                                go = false;
                            }
                            
                            if( val.groupID === value ) {
                                allow.splice(idx, 1);
                                return false;
                            }
                            
                        })
                    }
                  
                })
            
                emEditor.studio.setDirty();
            }*/
        
        }
        
    };

    _perms.set.right = function( newValue, type, extra ) {
     
        var sp = type.parentNode.parentNode.className.split(" "),
            verb = sp[2],
            target = null,
            currentElem = _perm.selectedItems,
            emName,
            methName,
            elem = type,
            force,
            rm;
           
        if (currentElem.item) { //method selected

            target      = "method";
            //methName    = $(currentElem.item).attr("waf-data");
            methName    = currentElem.item.dataset.info;
            emName      = currentElem.emName;

        } else if( currentElem.emName == "___MODEL" ) { //model selected

            target = "model";

        } else { //class selected

            emName = currentElem.emName;
            target = "dataClass";

        }
        
        //perm-force
        if (elem.parentNode.parentNode.nextSibling && elem.parentNode.parentNode.nextSibling.firstChild) {
            force =  elem.parentNode.parentNode.nextSibling.firstChild;
            force.disabled = false;
        }
        
        rm = $(elem.parentNode).find(".perm-remove");
        rm.show();
        _perms.set.defineRight( newValue, target, verb, emName, methName, false, extra ); 
            
    };
    
    _perms.set.forced = function( elem ) {
        
        var sp = elem.className.split(" ");
        var verb = sp[2],
            target = null,
            currentElem = emEditor.selectedItems,
            emName,
            methName,
            newValue = elem.checked;
            
        if( currentElem.item ) { //method selected

            target      = "method";
            methName    = currentElem.item.dataset.info;
            emName      = currentElem.emName;

        } else if( currentElem.emName == "___MODEL" ) { //model selected

            target = "model";

        } else { //class selected

            emName = currentElem.emName;
            target = "dataClass";

        }
        
        _perms.set.defineRight( newValue, target, verb, emName, methName, true );
    };
    
    _perms.set.defineRight = function ( newValue, target, verb, emName, methName, updateForce, extra ) {

        var modelName   = emEditor.modelName,
            rootFile    = emEditor.perms.perms.allow,
            updateDone  = false,
            resource    = null,
            toRemove    = null,
            groupID;
        
        
        if(! rootFile ) {
            rootFile = emEditor.perms.perms.allow = [];
        }
        
        $.each( emEditor.perms.groupIndex, function(index, value) { 
          if( newValue === value ) {
              groupID = index;
          }
        });
        
        switch(target) {
        case "model": 
            
            if( updateForce ) {
                _permIndex.model[modelName][verb].force = ""+newValue+"";
                
            } else {

                if( !newValue ) { 
                    //updateIndex
                    if( _permIndex.model && _permIndex.model[modelName] && _permIndex.model[modelName][verb] ) {
                        delete _permIndex.model[modelName][verb];
                    }
                    //updateRootFile
                    
                    $.each(rootFile, function(index, value) { 
                      if( value.type == "model" && value.action == verb && value.resource == modelName ) {
                          toRemove = index;
                          return false;
                      } 
                    });
                     rootFile.splice(toRemove, 1);
                    //updateRootFile
                    updateDone = true;
                } else {
                    //updateIndex
                    if(!_permIndex.model) {
                         _permIndex.model = {};
                    }
                    if(!_permIndex.model[modelName]) {
                         _permIndex.model[modelName] = {};
                    }
                    if(!_permIndex.model[modelName][verb]) {
                         _permIndex.model[modelName][verb] = {};
                    }
                    
                    _permIndex.model[modelName][verb].group = newValue;
                    
                }
                
            }

            //updateRootFile
            $.each(rootFile, function(index, value) { 

              if( value.type == "model" && value.action == verb && value.resource == modelName ) {
                  if( updateForce ) {
                    value.temporaryForcePermissions = ""+newValue+""; 
                  } else {
                    value.groupID = groupID;
                    value.groupName = newValue;
                    updateDone = true;
                  }
                  return false;
              } 
            });


            if( !updateDone && !updateForce ) {
                rootFile.push(
                    {
                        action: verb,
                        groupName: newValue,
                        groupID: groupID,
                        resource: modelName,
                        temporaryForcePermissions: "false",
                        type : "model"
                    }
                );
            }
            
            
            break;
        case "dataClass": 
            
            resource = modelName+"."+emName;
            
            if( updateForce ) {
                
                _permIndex.dataClass[resource][verb].force = ""+newValue+""
                
            } else {
          
                if( !newValue ) {
                    //updateIndex
                    if( _permIndex.dataClass[resource] && _permIndex.dataClass[resource][verb] ) {
                        delete _permIndex.dataClass[resource][verb];
                    }
                    
                    //updateRootFile
                    $.each(rootFile, function(index, value) { 
                      if( value.type == "dataClass" && value.action == verb && value.resource == resource) {
                            toRemove = index;
                            return false;
                        } 
                    });

                    rootFile.splice(toRemove, 1);
                    updateDone = true;
                } else {

                    //updateIndex
                    if( !_permIndex.dataClass ) {
                         _permIndex.dataClass = {};
                    }
                    if( !_permIndex.dataClass[resource] ) {
                         _permIndex.dataClass[resource] = {};
                    }
                    if( !_permIndex.dataClass[resource][verb] ) {
                         _permIndex.dataClass[resource][verb] = {};
                    }
                    _permIndex.dataClass[resource][verb].group = newValue;

                }
            }
            
            if( newValue ) {
                
                //updateRootFile
                $.each(rootFile, function(index, value) { 
                  if( value.type == "dataClass" && value.action == verb && value.resource == resource ) {

                      if( updateForce ) {
                          value.temporaryForcePermissions = ""+newValue+""; 
                        } else {
                          value.groupID = groupID;
                          value.groupName = newValue;
                          updateDone = true;
                        }
                      return false;
                  } 
                });

                if( !updateDone && !updateForce) {
                    rootFile.push(
                        {
                            action: verb,
                            groupName: newValue,
                            groupID: groupID,
                            resource: resource,
                            temporaryForcePermissions: "false",
                            type : "dataClass"
                        }
                    );
                }
            }
            
            
            
            break
        case "method": 
            
            resource = modelName+"."+emName+"."+methName;
            
            if( updateForce ) {
                
                _permIndex.method[resource][verb].force = ""+newValue+"";
                
            } else {
            
                if( !newValue ) { 
                    //updateIndex
                    if( _permIndex.method[resource] && _permIndex.method[resource][verb] ) {
                        delete _permIndex.method[resource][verb];
                    }
                    //updateRootFile
                    $.each(rootFile, function(index, value) { 
                      if( value.type == "method" && value.action == verb && value.resource == resource) {
                          toRemove = index;
                          return false;
                      } 
                    });
                     rootFile.splice(toRemove, 1);
                    //updateRootFile
                    updateDone = true;
                } else {

                    //updateIndex
                    if( !_permIndex.method ) {
                         _permIndex.method = {};
                    }
                    if( !_permIndex.method[resource] ) {
                         _permIndex.method[resource] = {};
                    }
                    if( !_permIndex.method[resource][verb] ) {
                         _permIndex.method[resource][verb] = {};
                    }
                    _permIndex.method[resource][verb].group = newValue;

                    //updateRootFile
                    $.each(rootFile, function(index, value) { 
                      if( value.type == "method" && value.action == verb && resource == value.resource ) {
                          if( updateForce ) {
                            value.temporaryForcePermissions = ""+newValue+""; 
                          } else {
                            value.groupID = groupID;
                            value.groupName = newValue;
                            updateDone = true;
                          }
                          return false;
                      } 
                    });

                    if( !updateDone && !updateForce) {
                        rootFile.push(
                            {
                                action: verb,
                                groupName: newValue,
                                groupID: groupID,
                                resource: resource,
                                temporaryForcePermissions: "false",
                                type : "method"
                            }
                        );
                    }

                }
            }            
            
            break
        default:
        }
        
        if(!extra && emEditor.handlePerms){
           _perm.build();
        }
        emEditor.selectedInput = null;
        emEditor.studio.setDirty();
    };
    
    _perms.remove = function( elem ) { 
        var 
        sp = elem.className.split(" "),
        verb = sp[1],
        target = null,
        currentElem = emEditor.selectedItems,
        emName,
        methName,
        newValue = elem.checked;

        if( currentElem.item ) { //method selected

            target      = "method";
            methName    = currentElem.item.dataset.info;
            emName      = currentElem.emName;

        } else if( currentElem.emName == "___MODEL" ) { //model selected

            target = "model";

        } else { //class selected

            emName = currentElem.emName;
            target = "dataClass";

        }

        _perms.set.defineRight( "", target, verb, emName, methName, false );
    }

    _perms.checkPermToRemove = function( data ) {

        if( !emEditor.perms ) {
            return;
        }
        
        var permFile    = emEditor.perms.perms,
            idx         = emEditor.perms.index,
            modelName   = emEditor.modelName,
            target      = data.target,
            className   = data.className,
            elemName    = data.elemName,
            sp,
            extensPath,
            keep = true;
          
        if( permFile && idx &&  permFile.allow ) {
        
            permFile = permFile.allow;
            switch (target) {
                case "class": 

                    emEditor.perms.perms.allow = $.map(emEditor.perms.perms.allow, function (item, index) {

                        keep = true;

                        if (item.resource === modelName+"."+className && item.type === "dataClass") {
                            delete idx.dataClass[item.resource];
                            keep = false;
                        }

                        sp = item.resource.split(".");
                        if (sp[0]+"."+sp[1] === modelName+"."+className && item.type === "method") {
                            delete idx.method[item.resource];
                            keep = false;
                        }  

                        if (keep) {
                            return item;
                        } else {
                            return null;
                        }
                        
                    });

                    break;
                case "method": 

                   emEditor.perms.perms.allow = $.map(emEditor.perms.perms.allow, function (item, index) {

                        keep = true;

                        if (item.resource === modelName+"."+className+"."+elemName && item.type === "method") {
                            delete idx.method[item.resource];
                            keep = false;
                        }  

                        if (keep) {
                            return item;
                        } else {
                            return null;
                        }
                        
                    });

                    break;
                }
        }
        
        if (data.target === "method" && data["className"]) {
            extensPath = _g.extendTree(data["className"]);
            $.each(extensPath, function(index, value) { 
                $.each(value, function(idx, val) { 
                    _perms.checkPermToRemove({
                        className : val,
                        elemName : elemName,
                        target : "method"
                    });
                 });
            });
        }    
    }

    _perms.updateNames = function( target, oldName, newName, className) {
        
        if( !emEditor.perms ) {
            return;
        }
        
        var permFile = emEditor.perms.perms,
            idx = emEditor.perms.index,
            modelName   = emEditor.modelName,
            oldObj;
          
        if( permFile && idx &&  permFile.allow ) {
        
            permFile = permFile.allow;
             switch (target) {
                case "class": 

                    $.each( permFile, function(index, value) { 

                        if( value.resource === modelName+"."+oldName) {
                            value.resource = modelName+"."+newName;
                            oldObj = idx.dataClass[modelName+"."+oldName];
                            idx.dataClass[modelName+"."+newName] = oldObj;
                            delete idx.dataClass[modelName+"."+oldName];
                        }

                    });
                    break;
                case "method": 
                    extensPath = _g.extendTree(className);
                    
                    $.each( permFile, function(index, value) { 

                        if( value.resource === modelName+"."+className+"."+oldName) {
                            value.resource =  modelName+"."+className+"."+newName;
                            oldObj = idx.method[modelName+"."+className+"."+oldName];
                            idx.method[modelName+"."+className+"."+newName] = oldObj;
                            delete idx.method[modelName+"."+className+"."+oldName];
                        }
                        
                        $.each(extensPath, function(index, v) { 
                            $.each(v, function(i, val) { 
                                if( value.resource === modelName+"."+val+"."+oldName) {
                                    value.resource =  modelName+"."+val+"."+newName;
                                    oldObj = idx.method[modelName+"."+val+"."+oldName];
                                    idx.method[modelName+"."+val+"."+newName] = oldObj;
                                    delete idx.method[modelName+"."+val+"."+oldName];
                                }
                            });
                        });
                            

                    });

                    break;
                }
        }    
       
        
    }
})();