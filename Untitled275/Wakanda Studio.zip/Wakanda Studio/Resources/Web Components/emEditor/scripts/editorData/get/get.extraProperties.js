/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
(function() { 
    _g.extraProperties = {
    
    methodNote: function (className, methName) {
        /*var emPos = emEditor.editorData.findEntityModel(emName);
        var methPos = emEditor.editorData.get.method(emPos, methName);

        if(_classes[emPos].methods[methPos]["extraProperties"] && _classes[emPos].methods[methPos]["extraProperties"].note){
            return _classes[emPos].methods[methPos]["extraProperties"].note;
        } else {
            return null;
        }*/

        var res = null;

        if (_classesProperties[className] && _classesProperties[className].methods && _classesProperties[className].methods[methName] && _classesProperties[className].methods[methName].note){
            res = _classesProperties[className].methods[methName].note;
        }

        return res;
    },  
    attributeNote: function (className, attName) {
        /*var emPos = emEditor.editorData.findEntityModel(emName);
        var attPos = emEditor.editorData.findEmAtrribute(emPos, attName);

        if (attPos && _classes[emPos].attributes[attPos]["extraProperties"] && _classes[emPos].attributes[attPos]["extraProperties"].note) {
            return _classes[emPos].attributes[attPos]["extraProperties"].note;
        } else {
            return null;
        }*/

        var res = null;

        if (_classesProperties[className] && _classesProperties[className].attributes && _classesProperties[className].attributes[attName] && _classesProperties[className].attributes[attName].note){
            res = _classesProperties[className].attributes[attName].note;
        }

        return res;
    },
    modelNote : function() {
        /*if (emEditor.catalog.extraProperties && emEditor.catalog.extraProperties.note) {
            return emEditor.catalog.extraProperties.note;
        } else {
            return null;
        }*/

        var res = null;

        if (_modelProperties && _modelProperties.note){
            res = _modelProperties.note;
        }

        return res;
    },
    classNote: function (className) {
        /*var emPos = emEditor.editorData.findEntityModel(emName);
        if (_classes[emPos]["extraProperties"] && _classes[emPos]["extraProperties"].note) {
            return _classes[emPos]["extraProperties"].note;
        } else {
        return null;
        }*/

        var res = null;

        if (_classesProperties[className] && _classesProperties[className].note){
            res = _classesProperties[className].note;
        }

        return res;
    },
    panelColor: function(className) {

        var res = "#eee";

        if (_classesProperties[className] && _classesProperties[className].panelColor){
            res = _classesProperties[className].panelColor;
        }

        return res;;
    },    
    panelExtraPro:function( className ) {
        /*var emPos = emEditor.editorData.findEntityModel(emName);
        if (_classes[emPos]["extraProperties"]) {
            return _classes[emPos]["extraProperties"];
        } else {
            return null;
        }*/

        var res = null;

        if (_classesProperties[className]){
            res = _classesProperties[className];
        }

        return res;
    },
    methodsDisplay:function() {

        /*if (emEditor.catalog["extraProperties"]) {
           return emEditor.catalog["extraProperties"].methodShowMode;
        } else {
           return null;
        }*/

        var res = null;

        if (_modelProperties && _modelProperties.methodShowMode){
            res = _classesProperties.methodShowMode;
        }

        return res;
    },
    scriptMode:function() {
         
        /*var mode;
          
        if (emEditor.catalog["extraProperties"] && emEditor.catalog["extraProperties"].scriptMode) {
            return emEditor.catalog["extraProperties"].scriptMode;
        } else {
            return "auto";
        }*/

        var res = "auto";

        if (_modelProperties && _modelProperties.scriptMode){
            res = _classesProperties.scriptMode;
        }

        return res;
        
    },
    attDisplay:function( type ) {
        /*if( emEditor.catalog["extraProperties"] ) {
            return emEditor.catalog["extraProperties"][type];
        }else{
            return null;
        }*/

        var res = null;

        if (_modelProperties && _modelProperties[type]){
            res = _classesProperties[type];
        }

        return res;
    },
    relationCurve:function() { 
        /*var res = null;
        if( emEditor.catalog.extraProperties && emEditor.catalog.extraProperties.relationCurve ) {
            res = {};
            res.run = emEditor.catalog.extraProperties.relationCurve.run;
            res.mode = emEditor.catalog.extraProperties.relationCurve.mode;
        }
        return res;*/

        var res = null;

        if (_modelProperties && _modelProperties.relationCurve){

            res = {};
            res.run = _modelProperties.relationCurve.run;
            res.mode = _modelProperties.relationCurve.mode;

        }

        return res;

    },
    isMinimized: function(className) {

        var res = false;

        if (_classesProperties && _classesProperties[className]) {
            res = _classesProperties[className].isMinimized;
        }

        return res;
        
    }

    };
    _extra = _g.extraProperties; 
})();