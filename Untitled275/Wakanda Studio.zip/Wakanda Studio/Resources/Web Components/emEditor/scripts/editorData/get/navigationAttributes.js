/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
 (function() { 
     _g.navigationAttribute = {
        
            /**
            * look for all the relation attributes using the given EM
            * @param {string} emName 
            * @return {array} 
            */
            getAllByEntity:function(emName){
            
                var cat = _classes, 
                    atts, 
                    att, 
                    k, 
                    em, 
                    result=[],
                    sn = _g.collectionName(emName);
                    
                for( var k in cat ) {
                    em = cat[k]["className"];
                    //if( emName != em ) {
                        atts = cat[k].attributes;
                        for( var a in atts ) {
                            att = atts[a];
                            k = att.kind;
                            if( k === emEditor.config.xmlData.relatedEntity || k === emEditor.config.xmlData.relatedEntities ){
                                
                                if(att.type === emName || att.type == sn){
                                    result.push({emName:em, attName:att.name, path:att.path});
                                }
                            }
                       // }
                    }
                }
                return result;
            },
            /**
            * look in an Entity Mod. if : 1) a navigation att is used for a flattened & if the given attribute is involved in the path 
            * @param {string} emName 
            * @return {array} 
            */
            getPathTree:function( emName, attName, noFlat, rootEmName ) {   
                                
                var other;
                emEditor.attTreeToRemove = [];
                emEditor.done.push(emName); 
                this.lookForLocalAndRelatedUse(emName, emName, attName, rootEmName); 
                if (!noFlat) { 
                    this.lookForFlattenedUse(emName, attName);
                }
                emEditor.done = [];
                return emEditor.attTreeToRemove;
            
            },
            /**
            * look in an Entity Mod. if : 1) a field att is used for a flattened 
            * @param {string} emName 
            * @return {array} 
            */
            flattenedPathTree:function( emName, attName ) { 
                var emToUpload = [], emPos, p;
                var fAtts = _g.navigationAttribute.getAllByEntity(emName);
                var em = _classes;
                
                for(var a in fAtts){ 
                                    
                    allF = _g.navigationAttribute.getPathTree(fAtts[a].emName, fAtts[a].attName, true, emName);
                    
                    for(var k in allF){
                        if(allF[k]){
                            if(_g.emAttPropertyValue(allF[k].emName, allF[k].attName, "kind") == emEditor.config.xmlData.alias){
                                emPos = emEditor.editorData.findEntityModel(allF[k].emName);
                                attPos = _g.emAtrribute(emPos, allF[k].attName);
                                p = allF[k].path.split(".");
                                if(p[p.length-1] == attName){
                                    emToUpload.push(allF[k]);
                                }
                            }
                        }
                    }
                }

                return emToUpload;
            },
            lookForFlattenedUse : function( emName, attName ) {   

                var emPos = emEditor.editorData.findEntityModel(emName),
                    emToUpload = [],
                    atts = _classes[emPos].attributes,
                    rm = true;

                if (atts) {

                    $.each(atts, function(index, value) { 
                        rm = true;
                        if (value.kind == "alias" || value.kind == "relatedEntity" || value.kind == "relatedEntities"){ 
                            if ( _g.navigationAttribute.isInPath(attName, value.path) ) {

                                if ( value.reversePath &&  value.kind == "relatedEntities") {

                                } else {
                                    emToUpload.push({attName:value.name, emName:emName});

                                    $.each(emEditor.attTreeToRemove, function(idx, val) { 
                                        if (val.attName === value.name && val.emName === emName) {
                                            rm = false;
                                        }
                                    });
                                    if (rm) {
                                        emEditor.attTreeToRemove.push({attName:value.name, emName:emName, path:value.path});
                                    }
                                }
                            }
                        } 
                    });
                }
                return emToUpload;
            },
            /**
            * look for the use of a navigation att in the given em, and in through the related entities 
            * @param {string} emName em to search in
            * @return {string} sartEmName use to start the search (could be the same than emName)
            * @return {string} attName attribute use to start the search
            */
            lookForLocalAndRelatedUse:function( emName, sartEmName, attName, rootEmName ) {  

                var other       = this.getAllByEntity(emName), 
                    extendsTree = [],
                    extendPath,
                    that = this;

                for(var k in other){
                    
                    extendPath = _g.extendTree(other[k].emName);
                    
                    //extendsTree = _g.extendTree(other[k].emName)[0];
                    that.lookForLocalUse(other[k].emName, other[k].attName, attName, sartEmName, rootEmName);
                    
                    $.each(extendPath, function(index, value) { 
                        extendsTree = value;
                        for(var e in extendsTree){
                            that.lookForLocalUse(extendsTree[e], other[k].attName, attName, sartEmName, rootEmName);
                        }
                    });
                    
                    if(!_o.isInDataList(other[k].emName, emEditor.done)){
                        emEditor.done.push(other[k].emName);
                        that.lookForLocalAndRelatedUse(other[k].emName, sartEmName, attName, rootEmName);
                    }
                    
                }
            
            },
            /**
            * look for the use of a navigation att in the given em
            * @param {string} emName em to search in
            * @return {string} attName to search in
            * @return {string} navAttName relation attribute
            */
            lookForLocalUse:function( emName, attName, navAttName, targetEmName, rootEmName ) { 

                var type,
                    emPos           = _g.entityModel(emName),
                    atts            = _classes[emPos].attributes, 
                    rootAttribute   = _g.emAttribute(rootEmName, navAttName),
                    add,
                    attPos,
                    att,
                    rootClassName,
                    rootClassNameForRenamed;

                for ( var k in atts ) { 


                    add = false;
                  
                    if( atts[k].kind == emEditor.config.xmlData.alias || atts[k].kind == emEditor.config.xmlData.relatedEntities || atts[k].kind == emEditor.config.xmlData.relatedEntity ) {

                        path    = atts[k].path; 
                        att     = atts[k];
                        type    = att.type;

                        if (this.isInPath(navAttName, path) || path === rootEmName) { //emName

                            add = true;
                            for( var i in emEditor.attTreeToRemove ) {
                                
                                if( emEditor.attTreeToRemove[i].attName === atts[k].name && emEditor.attTreeToRemove[i].emName === emName ) {
                                    add = false;
                                    break;
                                }
                            }
                            
                            if (add) {     //&& targetEmName != emName

                               if( atts[k].kind === "relatedEntities" ) {
                                  
                                   if (att.reversePath) {
                                      rootClassName = _g.dataClassName(type);
                                      
                                      if( rootAttribute && rootAttribute.kind != "storage" && rootAttribute.kind != "alias" && rootClassName === targetEmName) {  
                                           emEditor.attTreeToRemove.push( {attName:atts[k].name, emName:emName, path:path} );
                                      }   
                                   }                                   
                               }
                               
                               /*if( atts[k].kind === "relatedEntity" && emName != emEditor.selectedItems.emName) {   
                                   emEditor.attTreeToRemove.push( {attName:atts[k].name, emName:emName, path:path} );
                               }*/
                               
                               if( atts[k].kind === "alias" ) { 
                                   emEditor.attTreeToRemove.push( {attName:atts[k].name, emName:emName, path:path} ); 
                               }
                            }
                        }
                    }
                }
               
            },
            /**
            * look for an attName in the giver path
            * @param {string} attName em to search in
            * @return {string} path to search in
            * @return {boolean} 
            */
            isInPath:function(attName, path){
                var ps = path.split(".");
                var res = false;
                for(var k in ps){
                    if(ps[k] == attName){
                        res = true;
                        break;
                    }
                }
                return res;
            }
    };
    
    _nav = _g.navigationAttribute;
})();