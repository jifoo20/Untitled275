/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/
//*** 
_conf.langage = {
	en:{
	    onRestrictingQuery              : "On Restricting Query",
	    notes                           : "Notes",
	    composition                     : "Composition",
	    publishAsJSGlobal               : "Allow Global Access",
	    allowOverrideStamp              : "Allow Stamp Override",
	    cascadingDelete                 : "Cascading Delete",    
	    javascript                      : "javascript",
	    db4d                            : "Query Language",
	    autogenerate                    : "Autogenerate",
	    autosequence                    : "Autosequence",
	    simpleDate						: "Date only",
	    locale                          : "Locale",    
	    dataStoreClasses                : "Datastore Classes",
	    returnType                      : "Return Type",
	    fixedLength                     : "Length",
	    pattern                         : "Pattern",
	    defaultValue                    : "Default Value",    
	    description                     : "Description",
	    scope                           : "Scope",
	    identifying                     : "Identifying",
	    unique                          : "Unique",
	    not_null                        : "Mandatory",
	    noReturnType                    : "No Return Type",    
	    collectionName                  : "Collection Name",            //Collection Name
	    name                            : "Collection Name",
	    typeName                        : "Type Name", 
	    singleEntityName                : "Class Name", 
	    className                       : "Class Name",                 //Class Name   
		ongetDb4D                       : "Query",
		primKey                         : "Primary Key",
		properties                      : "Properties",					
		attributes                      : "Attributes",
		newEmText                       : "newEntity",	
		newTypeText                     : "New type",
		newMethText                     : "New Methods",		
		nameAlreadyExist                : "This name already exist !",
		restrictingQuery                : "Restricting Query",
		autoComplete                    : "Autocomplete",
		multiLine                       : "Multi Line",
		reversePath                     : "Reverse Path",
		limiting_length                 : "Limiting Length",
		scriptKind                      : "Script Kind",
		indexKind                       : "Index Kind",
		onGet                           : "On Get",
		onSet                           : "On Set",
		onQuery                         : "On Query",
		onSort                          : "On Sort",
		onInit                          : "On Init",
		onLoad                          : "On Load",
		onRestrict                      : "On Restricting Query",
		onValidate                      : "On Validate",
		onSave                          : "On Save",
		onRemove                        : "On Remove",
		defaultFormat                   : "Default Format",
		sliderMin                       : "Slider Min",
		sliderMax                       : "Slider Max",
		sliderInc                       : "Slider Step",
		textAsBlob                      : "Text as BLOB",
		minLength                       : "Min Length",
		maxLength                       : "Max Length",
		defaultTopSize                  : "Default Top Size",
		maxValue                        : "Max Value",
		minValue                        : "Min Value",
		newName                         : "DataClass",
		newAttName                      : "attribute",
		newType                         : "newType",
		newMethod                       : "method",
		presentation                    : "Presentation",
		format                          : "Format",
		indexKind_list                  : {
		                    btree       : "B-tree",
		                    cluster     : "Cluster",
		                    keywords    : "Keywords",
		                    auto        : "Automatic"              
		},
		scope_list                      : {
		                    "public"            : "Public",
		                    "publicOnServer"    : "Public On Server",
		                    "protected"         : "Protected",
		                    "private"           : "Private",
		},  
		presentation_list               : {
		            text                : "Text",
		            "text and slider"   : "Text and Slider",
		            slider              : "Slider"
		},
		scriptKind_list                 : {
		            javascript          : "JavaScript",
		            db4d                : "Query Language",
		},
		applyTo_list                    : {
		            dataClass           : "Class",
		            entity              : "Entity",
		            entityCollection    : "Collection"
		            
		},
		helpTips: {
		    aboutEmNames                : "The <b>Model Name</b> represents the Entities models collection. <br> The <b>Entity Name</b> represents a single Entity from the collection. <br>",
		    scopeAtt                    : "A <b>public</b> attribute can be used from anywhere. <br> A <b>private</b> attribute can only be used by code called from inside the datastore class, including calculated attribute events, datastore class methods, and events.<br> A <b>protected</b> attribute can be used from datastore classes as well as from derived datastore classes. <br>A <b>public on server</b> attribute can be used only on the server side.",
		    scopeClass                  : "A <b>public</b> attribute can be used from anywhere. <br>A <b>public on server</b> attribute can be used only on the server side.",
		    scopeMeth                   : "A <b>public</b> datastore class method can be used from anywhere.<br> A <b>private</b> datastore class method can only be used inside the datastore class. <br>A <b>protected</b> datastore class method can be used from datastore classes as well as from derived datastore classes. <br>A <b>public on server</b> datastore class method can be used only on the server side."
		},		
		
		
		
		alertTip: {
			typeUpdate					: "You cannot update the type of this attribute because it is being used by the following attribute(s): <br>",
		    attAlreadyUsed              : "The name of the attribute must be unique, and must not use any JavaScript reserved words.",
		    className                   : "The name of the Datastore Class must be unique, cannot be empty, and must not use any JavaScript reserved words.",
		    collectionName              : "The name of the Datastore Class collection must be unique, cannot be empty, and must not use any JavaScript reserved words.",
		    deleteObjets                : "Click Delete to delete ",
		    deleteForEm                 : "the datastore class.",
		    deleteForEms                : "the datastore class(es).",
		    deleteForAtt                : "the attributes.",
		    deleteForAtts               : "the attribute(s).",
		    deleteForBoth               : "both the datastore class and relation attribute(s) listed above.",
		    deleteForMeth               : "the datastore class method.",
		    deleteMessageNavAtt         : "The following relation attribute(s) are using ",
		    deleteMessageNavAttandClass : "The following relation attribute(s) and Entity Model(s) are using ",
		    deleteForExtend             : "The following datastore class(es) were extended from ",
		    deleteForDependencies       : "The following attribute(s) are using ",
		    willDelete                  : " will be deleted.",
		    deleteWith                  : "They will be deleted along with ",
		    nameAlreadyUsed             : "The name of the Method must be unique, cannot be blank, and must not be one of the JavaScript reserved keywords.",
		    deleteDsclassMessage        : "Deleting a Datastore Class...",
		    deleteAttributeMessage      : "Deleting an Attribute...",
		    deleteAttributeMessageAsking : " is no longer used in the catalog.",
		    errorManager_messageAtt     : "- An error has been detected on the attribute(s) : ",
            errorManager_messagePrimKey : "- This datastore class must have one attribute defined as its Primary Key.",    
		    
		    methodModeSwitch: {
		        title   : "Switching to Free Script Mode",
		        content : "By clicking \"Confirm,\" you will be switching to a mode where you must manage your scripts manually. Please refer to the documentation for more information. This operation cannot be undone.",
		        cancel  : "Cancel",
		        confirm : "Confirm"
		    }
		}
	}
}



