/*
* This file is part of Wakanda software, licensed by 4D under
*  (i) the GNU General Public License version 3 (GNU GPL v3), or
*  (ii) the Affero General Public License version 3 (AGPL v3) or
*  (iii) a commercial license.
* This file remains the exclusive property of 4D and/or its licensors
* and is protected by national and international legislations.
* In any event, Licensee's compliance with the terms and conditions
* of the applicable license constitutes a prerequisite to any use of this file.
* Except as otherwise expressly stated in the applicable license,
* such license does not include any other license or rights on this file,
* 4D's and/or its licensors' trademarks and/or other proprietary rights.
* Consequently, no title, copyright or other proprietary rights
* other than those specified in the applicable license is granted.
*/


	/*
		Only the first line of git's output goes to stdout. The rest is dumped to stderr. There is a known issue with git's stderr where it is not
		easily piped back to stdout. First of all, "--progress" needs to be specified. Second, "2>&1" is needed to redirect stderr. However, system 
		workers pass the whole string for execution and the underlying shell does not receive the redirection instruction - 2>&1. In order to force
		redirection, the git command is executed via bash shell. In this way, the whole string is analyzed by the shell before execution.
	*/


var			_isGitModuleReady = false;
var			_gitExecPath = "";
var			_gitLogCallback = null;
var			_gitProxy = null;

function debug_alert ( inMessage )
{
	studio. alert ( inMessage );
	// console. log ( "GIT MODULE ALERT: " + ... );
}

function _gitCreateFile ( inPath )
{
	var		flResult = null;
	
	try
	{
		flResult = new File ( inPath );
	}
	catch ( e )
	{
		flResult = studio. File ( inPath );
	}
	
	return flResult;
}

function _gitCreateFolder ( inPath )
{
	var		fldrResult = null;
	
	try
	{
		fldrResult = new Folder ( inPath );
	}
	catch ( e )
	{
		fldrResult = studio. fldrResult ( inPath );
	}
	
	return fldrResult;
}

function _gitPrepareFilePath ( inPath )
{
	var		pathConverted = inPath;
	
	if ( os. isMac )
	{
		pathConverted = "'" + pathConverted + "'";
	}

	return pathConverted;
}

function _gitExecuteHTTPRequest ( inURL, inVerb, inBody )
{
	var headers, resultObj;

	var			strResult = "";

	// TODO: Proxy handling
	
	var			xhr;
	if ( typeof ( studio ) === "undefined" || studio == null )
	{
		if ( typeof ( _gitProxy ) === "undefined" || _gitProxy == null )
			xhr = new XMLHttpRequest ( );
		else
			xhr = new XMLHttpRequest ( _gitProxy );
	}
	else
	{
		if ( typeof ( _gitProxy ) === "undefined" || _gitProxy == null )
			xhr = new studio. XMLHttpRequest ( );
		else
			xhr = new studio. XMLHttpRequest ( _gitProxy );
	}
   
	xhr. onreadystatechange = function ( )
	{
		var		state = this. readyState;
		if ( state !== 4 )
		{
			// while the status event is not Done we continue
			return;
		}
	 
		strResult = this. responseText;
     };
   
	xhr. open ( inVerb, inURL );
	if ( typeof ( inBody ) != "undefined" && inBody != null )
		xhr. send ( inBody );
	else
		xhr. send ( );
		
	return ( xhr. status == 200 || xhr. status == 201 ? strResult : undefined );
}

function _isGitHubURL ( inURL )
{
	var		nStartIndex = inURL. indexOf ( "//" );
	nStartIndex = inURL. indexOf ( "/", nStartIndex + 2 );
	
	return ( inURL. indexOf ( "api.github.com" ) == nStartIndex - "api.github.com". length );
}

function _isWakandaURL ( inURL )
{
	if ( _isGitHubURL ( inURL ) )
		return false;
		
	var		nStartIndex = inURL. indexOf ( "//" );
	nStartIndex = inURL. indexOf ( "/", nStartIndex + 2 );
	nStartIndex = inURL. indexOf ( "gitservice/repo", nStartIndex + 1 );

	return ( nStartIndex > -1 );
}

function _gitExtractFolderArray ( inPaths )
{
	var			arrUniqueFolders = new Array ( );
	for ( var i = 0; i < inPaths. length; i++ )
	{
//debug_alert ( "_gitExtractFolderArray : " + inPaths [ i ] );
		if ( inPaths [ i ]. charAt ( inPaths [ i ]. length - 1 ) == '/' )
		{
			if ( arrUniqueFolders. indexOf ( inPaths [ i ] ) < 0 )
				// add folders as is
				arrUniqueFolders. push ( inPaths [ i ] );
		}
		/*else
		{
			var		strFolder = inPaths [ i ]. substring ( 0, inPaths [ i ]. lastIndexOf ( "/" ) );
			if ( arrUniqueFolders. indexOf ( strFolder ) < 0 )
				// move up one level from file to folder
				arrUniqueFolders. push ( strFolder );
		}*/
	}
	
	return arrUniqueFolders;
}

function _gitGetRepoAndTree ( inWorkTree )
{
	var		strResult = "";
	
	var		strRepository = inWorkTree;
	if ( strRepository [ strRepository. length - 1 ] != "/" )
		strRepository += "/";
		
	strRepository += ".git";
	
	if ( os. isMac )
		strResult = " --git-dir=" + "'" + strRepository + "'" + " --work-tree=" + "'" + inWorkTree + "'";
	else
		strResult = " --git-dir=" + '"' + strRepository + '"' + " --work-tree=" + '"' + inWorkTree + '"';
		
	return strResult;
}

var myTestImpl = function ( )
{
	var			isGitHub = _isGitHubURL ( "https://sergiy:t@api.github.com/user/repos" );
	debug_alert ( "https://sergiy:t@api.github.com/user/repos is for GitHub == " + isGitHub );
	isGitHub = _isGitHubURL ( "http://sergiy:123@127.0.0.1:8081/gitservice/repo master" );
	debug_alert ( "http://sergiy:123@127.0.0.1:8081/gitservice/repo master is for GitHub == " + isGitHub );

	var			isWakanda = _isWakandaURL ( "http://sergiy:123@127.0.0.1:8081/gitservice/repo master" );
	debug_alert ( "http://sergiy:123@127.0.0.1:8081/gitservice/repo master is for Wakanda == " + isWakanda );
	isWakanda = _isWakandaURL ( "https://sergiy:t@api.github.com/user/repos" );
	debug_alert ( "https://sergiy:t@api.github.com/user/repos is for Wakanda == " + isWakanda );
}

function _gitGetConfigProperty ( inProperty, inIsGlobal, inRepoAndTreePath )
{
	var				gitCommand = "";
	if ( os. isWindows )
	{
		gitCommand = gitExecPath + inRepoAndTreePath + " config ";
		if ( inIsGlobal )
			gitCommand += "--global ";

		gitCommand += "--get " + inProperty;
	}
	else if ( os. isMac )
	{
		gitCommand = 'bash -c "' + _gitExecPath + ' ' + inRepoAndTreePath + ' config ';
		if ( inIsGlobal )
			gitCommand += '--global ';
			
		
		gitCommand += '--get ' + inProperty + ' 2>&1"';
	}
	else
		debug_alert ( "Error: unknown OS" );
		
//debug_alert ( gitCommand );
	var				arrResponse = _gitExecute ( gitCommand );
	
	if ( typeof ( arrResponse ) === "undefined" || arrResponse == null || arrResponse. length == 1 )
		return null;
		
	return arrResponse [ 0 ];
}

function _gitSetConfigProperty ( inProperty, inValue, inIsGlobal, inRepoAndTreePath )
{
	var				gitCommand = "";
	if ( os. isWindows )
	{
		gitCommand = gitExecPath + inRepoAndTreePath + " config ";
		if ( inIsGlobal )
			gitCommand += "--global ";

		gitCommand += "--add " + inProperty + " " + inValue;
	}
	else if ( os. isMac )
	{
		gitCommand = 'bash -c "' + _gitExecPath + ' ' + inRepoAndTreePath + ' config ';
		if ( inIsGlobal )
			gitCommand += '--global ';
			
		
		gitCommand += '--get ' + inProperty + ' ' + inValue + ' 2>&1"';
	}
	else
		debug_alert ( "Error: unknown OS" );
		
//debug_alert ( gitCommand );
	var				arrResponse = _gitExecute ( gitCommand );

	return arrResponse;
}

function _gitInitUserAndEMail ( inRepoAndTreePath )
{
	if ( typeof ( inRepoAndTreePath ) === "undefined" || inRepoAndTreePath == null )
		return;
		
	var				gitUserName = _gitGetConfigProperty ( "user.name", false, inRepoAndTreePath );
	if ( gitUserName == null )
		_gitSetConfigProperty ( "user.name", "Your_Wakanda_Developer_Name_Here", false, inRepoAndTreePath ); // The default value

	var				gitUserEMail = _gitGetConfigProperty ( "user.email", false, inRepoAndTreePath );
	if ( gitUserEMail == null )
		_gitSetConfigProperty ( "user.email", "WakandaDeveloper@wakanda.org", false, inRepoAndTreePath ); // The default value
}

/**
 * Initializes the git module. Needs to be called only once for a given JS context. 
 *
 * @param {String} inGitExecPath
 * 	The path to git executable.
 * @param {function} inLogCallback
 *  A callback function to be called by git module each time it executes a git command.
 *  Accepts two parameters: inCommand - command executed, gitResponse - text response returned by git
 * @param {String} inWorkTree
 *	Git repository root path
 *
 * @return nothing
 *
 */
var gitInitImpl = function ( inGitExecPath, inLogCallback, inWorkTree )
{
	if ( _isGitModuleReady )
	{
		// debug_alert ( "git module has already been initialized!" );
		
		return;
	}
	
	_gitExecPath = inGitExecPath;
//debug_alert ( "_gitExecPath == '" + _gitExecPath + "'" );
	_gitLogCallback = inLogCallback;
	_isGitModuleReady = true;
	
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	_gitInitUserAndEMail ( strRepoAndTreePath );
}

/**
 * Sets the path to the git executable. 
 * 
 * @param {String} inGitExecPath
 * 	The path to git executable.
 *
 * @return nothing
 *
 */
var gitSetGitExecPathImpl = function ( inGitExecPath )
{
	_gitExecPath = inGitExecPath;
}

/**
 * Sets the proxy parameters for outgoung HTTP requests semt by the module.
 * 
 * @param {String} inHost
 * 	IP address or DNS name of the proxy server
 * @param {Number} inPort
 * 	Port number of the proxy server
 * 
 * @return nothing
 */
var gitSetProxyImpl = function ( inHost, inPort )
{
	if ( typeof ( inHost ) === "undefined" || inHost == null )
	{
		debug_alert ( "Error: setProxy - host name can not be null or undefined" );
		
		return;
	}
	
	if ( typeof ( inPort ) === "undefined" || inPort == null )
	{
		debug_alert ( "Error: setProxy - port number can not be null or undefined" );
	}

	_gitProxy = new Object ( );
	_gitProxy. host = inHost;
	_gitProxy. port = inPort;
}

/**
 * Executes a given git command.
 * 
 * @param {String} inCommand
 * 	The command to be executed.
 * @param {String} inRootPath
 *  An absolute path to be used by git as the root folder for its actions.
 * @param {Number} inTimeOut
 *  Optional time in milliseconds to wait for command execution.
 *	Default wait is 15000 milliseconds.
 * 
 * @return {String} git response in text form.
 *
 */
var gitExecuteImpl = function ( inCommand, inRootPath, inTimeOut )
{
	var			gitWorker;
	if ( inRootPath == undefined || inRootPath == null || inRootPath == "" )
		gitWorker = new SystemWorker ( inCommand );
	else
		gitWorker = new SystemWorker ( inCommand, inRootPath );
		
	gitWorker. setBinary ( true );

	var			gitResponse = "";
	var			isZombie	= false;
	
	gitWorker. onmessage = function ( e )
	{
		if (!isZombie) {
		
			var		result = arguments [ 0 ]. data;	
			
			//gitDebugMsg ( "onmessage: " + result. toString ( ) );
			gitResponse += result. toString ( );
			//gitDebugMsg ( "git returned " + result. length + " bytes" );
	
		}
	}
	
	gitWorker. onerror = function ( e )
	{
		if (!isZombie) {
		
			var		result = arguments [ 0 ]. data;
				
			//gitDebugMsg ( "onerror: " + result. toString ( ) );
			gitResponse += result. toString ( );
			//gitDebugMsg ( "git returned " + result. length + " bytes" );
	
		}
	}
	
	gitWorker. onterminated = function ( )
	{
		if (!isZombie) {
		
			//gitDebugMsg ( "inside gitWorker::onterminated" );
			exitWait ( );
			
		}
	}

	if ( typeof ( inTimeOut ) === "undefined" || inTimeOut == null )
		inTimeOut = 15000;
		
	wait ( inTimeOut );
	isZombie = true;
	
//	trace("gitResponse : " + gitResponse + "\n");
	
	return gitResponse;
}

/**
 * Internal private git command execution.
 * 
 * @param {String} inCommand
 * 	The command to be executed.
 * @param {String} inRootPath
 *  An optional absolute path to be used by git as the root folder for its actions.
 * @param {Number} inTimeOut
 *  Optional time in milliseconds to wait for command execution.
 * 
 *  Calls the log callback so that module's user knows exactly what commands are executed.
 *
 * @return {String} git response in the form of array of strings.
 *
 */
function _gitExecute ( inCommand, inRootPath, inTimeOut )
{
	var			gitResponse = gitExecuteImpl ( inCommand, inRootPath, inTimeOut );
	if ( _gitLogCallback != null )
		_gitLogCallback ( inCommand, gitResponse );
		
	var			arrLines = gitResponse. split ( "\n" );
	
	return arrLines;
}

/**
 * Verifies if git module is being used within a valid git repository.
 * 
 * @param {String} inPath
 *  The folder to be tested for presence of a Git repository.
 *
 * @return {Boolean} true if repository is valid, false otherwise.
 *
 */
var	gitVerifyRepositoryImpl = function ( inPath )
{
	if ( os. isWindows )
		inPath += "\\";
	else if ( os. isMac )
		inPath += "/";
	else
		debug_alert ( "Error: unknown OS" );
		
	inPath += ".git";
	if ( os. isWindows )
		inPath += "\\";
	else if ( os. isMac )
		inPath += "/";
	else
		debug_alert ( "Error: unknown OS" );
		
	inPath += "index";
	
	var			flDotGit = _gitCreateFile ( inPath );
	
	return flDotGit. exists;
}

/**
 * Verifies if git response has any errors (conflicts only for now) in it.
 * 
 * @param {String} inLines
 * 	git response text in the forms of array of strings
 * 
 * @return {Boolean} true if there are errors, false otherwise.
 *
 */
var	gitResponseHasConflictsImpl = function ( inLines )
{
	var		bResult = false;
	
	try
	{
		for ( var i = 0; i < inLines. length; i++ )
		{
			if ( /^CONFLICT \(content\):/. test ( inLines [ i ] ) )
			{
				bResult = true;
			
				break;
			}
		}
	}
	catch ( e )
	{
		debug_alert ( e. message );
	}

	//debug_alert ( "bResult == " + bResult );
	
	return bResult;
}

/**
 * Verifies if there are any modifications in a given repository.
 * 
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {Boolean} true if there is at least one modification, false otherwise.
 *
 */
var	gitRepositoryHasModificationsImpl = function ( inWorkTree )
{
	var				bResult = false;

	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " status --porcelain --untracked-files=no";
	else if ( os. isMac )
		//gitCommand = 'bash -c "' + _gitExecPath + gitRepoAndTree + ' status --porcelain --untracked-files=no 2>&1"';
		//gitCommand = 'git' + gitRepoAndTree + ' status --porcelain --untracked-files=no 2>&1';
		//gitCommand = 'git status --porcelain --untracked-files=no 2>&1';
		gitCommand = 'bash -c "' + _gitExecPath + ' ' + strRepoAndTreePath + ' status --porcelain --untracked-files=no 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );

	var				arrLines = _gitExecute ( gitCommand );
	for ( var i = 0; i < arrLines. length; i++ )
	{
		if (	arrLines [ i ] [ 0 ] == 'M' || arrLines [ i ] [ 1 ] == 'M' ||
				arrLines [ i ] [ 0 ] == 'A' || arrLines [ i ] [ 1 ] == 'A' ||
				arrLines [ i ] [ 0 ] == 'D' || arrLines [ i ] [ 1 ] == 'D' ||
				arrLines [ i ] [ 0 ] == 'R' || arrLines [ i ] [ 1 ] == 'R' ||
				arrLines [ i ] [ 0 ] == 'C' || arrLines [ i ] [ 1 ] == 'C' ||
				arrLines [ i ] [ 0 ] == 'U' || arrLines [ i ] [ 1 ] == 'U' )
		{
			bResult = true;
			//debug_alert ( "Matching line: " + arrLines [ i ] );
			
			break;
		}
	}

	return bResult;
}

/**
 * Provides a default .gitignore content for a  Wakanda solution.
 * 
 * @return {String} The default ignore filters for a Wakanda solution.
 *
 */
var gitGetDefaultIgnoreImpl = function ( )
{
	var		strIgnore = "# OS X\n";
	strIgnore += "*.DS_Store\n";
	strIgnore += "._*\n";
	strIgnore += "# Wakanda data\n";
	strIgnore += "*.waData\n";
	strIgnore += "# Wakanda preferences\n";
	strIgnore += "*.waPreferences\n";
	strIgnore += "# Wakanda log\n";
	strIgnore += "*.waLog\n";
	strIgnore += "*/Logs\n";
	strIgnore += "studio_log*\n";
	strIgnore += "# Wakanda code symbols\n";
	strIgnore += "*.waSym\n";
	strIgnore += "*.waSymData\n";
	strIgnore += "# Wakanda index\n";
	strIgnore += "*.waIndex\n";
	strIgnore += "*.Match\n";
	strIgnore += "# Wakanda User and Group cache\n";
	strIgnore += "*.cacheUAG\n";
	strIgnore += "# Wakanda backup\n";
	strIgnore += "*.waBackup\n\n";
	
//debug_alert ( "Result of getDefaultIgnore: \n" + strIgnore );
	return strIgnore;
}

function _getIgnoreFilePath ( inWorkTree )
{
	var			gitIgnorePath = inWorkTree;
	if ( os. isWindows )
		gitIgnorePath += "\\";
	else if ( os. isMac )
		gitIgnorePath += "/";
	else
	{
		debug_alert ( "Error: unknown OS" );
		
		return null;
	}
		
	gitIgnorePath += ".gitignore";
	
	return gitIgnorePath;
}

/**
 * Creates if necessary a default .gitignore file tailored for Wakanda solutions.
 * 
 * @param {String} inWorkTree
 * 	git working tree path where to create the .gitignore
 * 
 * @return {String}
 *  Returns empty string if the .gitignore file exists aready, returns full file path if it was
 *  actually created, returns null on error.
 *
 */
var gitInitIgnoreImpl = function ( inWorkTree )
{
	// debug_alert ( "Calling gitInitIgnoreImpl on work tree " + inWorkTree );
	var			gitIgnorePath = _getIgnoreFilePath ( inWorkTree );
	
	var			flIgnore = _gitCreateFile ( gitIgnorePath );
	if ( flIgnore. exists )
		return "";
	else
	{
		var		bCreated = flIgnore. create ( );
		if ( !bCreated )
		{
			debug_alert ( "Failed to create " + gitIgnorePath );
			
			return null;
		}
	}
	
	// Now let's write the default content for Wakanda .gitignore
	var			strmIgnore = TextStream ( flIgnore, "write" );
	strmIgnore. write ( "# OS X\n");
	strmIgnore. write ( "*.DS_Store\n");
	strmIgnore. write ( "._*\n");
	strmIgnore. write ( "# Wakanda data\n");
	strmIgnore. write ( "*.waData\n");
	strmIgnore. write ( "# Wakanda preferences\n");
	strmIgnore. write ( "*.waPreferences\n");
	strmIgnore. write ( "# Wakanda log\n");
	strmIgnore. write ( "*.waLog\n");
	strmIgnore. write ( "*/Logs\n");
	strmIgnore. write ( "studio_log*\n");
	strmIgnore. write ( "# Wakanda code symbols\n");
	strmIgnore. write ( "*.waSym\n");
	strmIgnore. write ( "*.waSymData\n");
	strmIgnore. write ( "# Wakanda index\n");
	strmIgnore. write ( "*.waIndex\n");
	strmIgnore. write ( "*.Match\n");
	strmIgnore. write ( "# Wakanda User and Group cache\n");
	strmIgnore. write ( "*.cacheUAG\n");
	strmIgnore. write ( "# Wakanda backup\n");
	strmIgnore. write ( "*.waBackup\n\n");
	strmIgnore. flush ( );
	strmIgnore. close ( );
	
	return gitIgnorePath;
}

/**
 * Returns the content of the current .gitignore file for a given repository.
 * 
 * @param {String} inWorkTree
 * 	git working tree path where to read the .gitignore
 * 
 * @return {String}
 *  Returns .gitignore content.
 *
 */
var gitGetIgnoreContentImpl = function ( inWorkTree )
{
	var			gitIgnorePath = _getIgnoreFilePath ( inWorkTree );
	var			flIgnore = _gitCreateFile ( gitIgnorePath );
	if ( !flIgnore. exists )
	{
//debug_alert ( gitIgnorePath + " does not exist" );
		return "";
	}

	var			strIgnore = "";
	var			strmIgnore = TextStream ( flIgnore, "read" );
	while ( !strmIgnore. end ( ) )
	{
		var		strLine = strmIgnore. read ( "" );
		//debug_alert ( "line " + strLine + " of length " + strLine. length );
		if ( strLine. length > 0 )
			strIgnore += strLine + "\n";
	}
	
	//debug_alert ( ".gitignore:\n" + strIgnore );
	strmIgnore. close ( );
	
//debug_alert ( "Result of getIgnoreContent: \n" + strIgnore );
	return strIgnore;
}

/**
 * Sets the content of the current .gitignore file for a given repository.
 * 
 * @param {String} inNewContent
 * 	New content of the .gitignore file to be save
 * @param {String} inWorkTree
 * 	git working tree path where to read the .gitignore
 * 
 * @return nothing
 *
 */
var gitSetIgnoreContentImpl = function ( inNewContent, inWorkTree )
{
	var			gitIgnorePath = _getIgnoreFilePath ( inWorkTree );
	var			flIgnore = _gitCreateFile ( gitIgnorePath );
	if ( !flIgnore. exists )
	{
		var		bCreated = flIgnore. create ( );
		if ( !bCreated )
		{
			debug_alert ( "Failed to create " + gitIgnorePath );
			
			return;
		}
	}

	var			strmIgnore = TextStream ( flIgnore, "Overwrite" );
	strmIgnore. write ( inNewContent );
	strmIgnore. flush ( );
	strmIgnore. close ( );
}

/**
 * Returns git's version string
 * 
 */
var	gitGetVersionImpl = function ( )
{
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + " version";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + ' version 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );

	var				strResult = null;
	
	var				arrLines = _gitExecute ( gitCommand );
	if ( typeof ( arrLines ) === "undefined" || arrLines == null )
		debug_alert ( "Failed to retrieve git version" );
	else
	{
		if (	arrLines [ 0 ]. indexOf ( "command not found" ) == -1 &&
				arrLines [ 0 ]. indexOf ( "bash" ) == -1 &&
				arrLines [ 0 ]. length > 0 )
			strResult = arrLines [ 0 ];
		//else
			//debug_alert ( "git is not installed" );
		
	}
	
	//for ( var i = 0; i < arrLines. length; i++ )
	//	debug_alert ( "line " + i + " == " + arrLines [ i ] );

	return strResult;
}

/**
 * Runs external merge tool for all merge conflicts in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repository root path
 * 
 * @return nothing
 *
 */
var	gitRunMergeAllImpl = function ( inWorkTree )
{
/*
[http]
        sslVerify = false
[user]
        name = Sergiy
        email = stemnikov@gmail.com
[merge]
        tool = p4merge
[diff]
        tool = p4merge
[difftool "p4merge"]
        path = /Applications/p4merge.app/Contents/MacOS/p4merge
[mergetool "p4merge"]
        path = /Applications/p4merge.app/Contents/MacOS/p4merge
        keepTemporaries = false
        keepBackup = false
[mergetool]
        keepBackup = false
*/

	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " mergetool -y";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' mergetool -y 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );

	return _gitExecute ( gitCommand, inWorkTree, 10000 );
}

/**
 * Executes a given stash command in a given repository.
 * 
 * @param {String} inActionName
 *  Stash command in the form of a string
 * @param {String} inWorkTree
 *  Git repository root path
 * @param {String} inComment
 *  A comment to be attached to the action.
 * 
 *  @return {String} git response in the form of array of strings.
 *
 */
function gitExecuteStashAction ( inActionName, inWorkTree, inComment )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " stash " + inActionName;
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' stash ' + inActionName;
	else
		debug_alert ( "Error: unknown OS" );
		
	if ( inActionName == "save" )
	{
		var			gitComment = "";
		// TODO: verify that comment does not contain escape characters that can mess up file paths or exec command
		if ( os. isWindows )
			gitComment = ' "' + inComment + '"';
		else if ( os. isMac )
			gitComment = " '" + inComment + "'";
		else
			debug_alert ( "Error: unknown OS" );
			
		gitCommand += gitComment;
	}

	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	return _gitExecute ( gitCommand, inWorkTree );
}

/**
 * Save the current modifications into a stash in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repository root path
 * @param {String} inComment
 *  A comment to be attached to the stash.
 * 
 * @return nothing
 *
 */
var	gitSaveStashImpl = function ( inWorkTree, inComment )
{
	return gitExecuteStashAction ( "save", inWorkTree, inComment );
}

/**
 * Pops the latest stash in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repositry root path
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitPopLatestStashImpl = function ( inWorkTree )
{
	return gitExecuteStashAction ( "pop", inWorkTree, "" );
}

/**
 * Lists all existing stashes in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repositry root path
 * 
 * @return nothing
 *
 */
var gitListStashesImpl = function ( inWorkTree )
{
	return gitExecuteStashAction ( "list", inWorkTree, "" );
}

/**
 * Shows (in the log for now) the latest stash in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repositry root path
 * 
 * @return nothing
 *
 */
var gitShowLatestStashImpl = function ( inWorkTree )
{
	return gitExecuteStashAction ( "show -v", inWorkTree, "" );
}

/**
 * Clears all existing stashes in a given repository.
 * 
 * @param {String} inWorkTree
 *  Git repositry root path
 * 
 * @return nothing
 *
 */
var gitClearAllStashesImpl = function ( inWorkTree )
{
	return gitExecuteStashAction ( "clear", inWorkTree, "" );
}

/**
 * Pulls updates from a remote server using given URL.
 * 
 * @param {String} inURL
 *  URL of a remote server to pull updates from.
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var	gitPullImpl = function ( inURL, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " pull " + inURL; // TODO: see if a URL needs to be "quoted" if it contains spaces or other "weird" chars
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + " pull " + inURL + ' 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );

	return _gitExecute ( gitCommand, null, 60 * 60 * 1000 );
}

/**
 * Pushes updates to a remote server using given URL.
 * 
 * @param {String} inURL
 *  URL of a remote server to push updates to.
 * @param {String} inRepository
 * 	git repository to be used directly in the git command
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitPushImpl = function ( inURL, inRepository )
{
	var				gitCommand;
	
	if ( os. isWindows )
	{
		inRepository = '"' + inRepository + '"';
		gitCommand = _gitExecPath + " --git-dir=" + inRepository + " push " + inURL + " master:master";
	}
	else if ( os. isMac )
	{
		inRepository = "'" + inRepository + "'";
		gitCommand = 'bash -c "' + _gitExecPath + ' --git-dir=' + inRepository + " push " + inURL + ' master:master' + ' --progress 2>&1"';
	}
	else
		debug_alert ( "Error: unknown OS" );

	//debug_alert ( gitCommand );
	var			arrLines = _gitExecute ( gitCommand, null, 60 * 60 * 1000 );
	if ( arrLines != null && arrLines. length >= 3 )
	{
		if ( /^error\: failed/. test ( arrLines [ 2 ] ) )
			debug_alert ( "Failed to push changes to remote repository.\n\nPlease see log for more details.\nYou may need to pull from remote repository, resolve conflicts if there are any, and then\npush again." );
	}
	
	return arrLines;
}

/**
 * Commits all staged modifications into a local repository.
 * 
 * @param {String} inComment
 *  A comment to be stored with the commit.
 * @param {String} inWorkTree
 * 	git repository root path
 * @param {Array of String} inPathsOptional
 *  Array of file paths to commit
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitCommitLocalImpl = function ( inComment, inWorkTree, inPathsOptional )
{
	var				gitCommand;

	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	// TODO: verify that comment does not contain escape characters that can mess up file paths or exec command
	if ( os. isWindows )
		inComment = '"' + inComment + '"';
	else if ( os. isMac )
		inComment = "'" + inComment + "'";
	else
		debug_alert ( "Error: unknown OS" );
		
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " commit -m " + inComment;
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + " commit -m " + inComment;
	else
		debug_alert ( "Error: unknown OS" );
		
	if ( typeof ( inPathsOptional ) != "undefined" && inPathsOptional != null )
	{
		gitCommand += " -- ";
		for ( var i = 0; i < inPathsOptional. length; i++ )
		{
			if ( os. isWindows )
				gitCommand += ' "' + inPathsOptional [ i ] + '"';
			else if ( os. isMac )
				gitCommand += " " + _gitPrepareFilePath ( inPathsOptional [ i ] );
			else
				debug_alert ( "Error: unknown OS" );
		}
	}
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';

//debug_alert ( gitCommand );
	var				arrLines = _gitExecute ( gitCommand, null, 5 * 60 * 1000 );
	
	return arrLines;
}

/**
 * Clone a remote repository to a local folder.
 * 
 * @param {String} inURL
 *  URL of a remote server to push updates to.
 * @param {String} inDestinationFolderPath
 * 	A path to a local folder to clone to. The folder will be created if necessary.
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitCloneImpl = function ( inURL, inDestinationFolderPath )
{
	var				gitCommand;
	if ( os. isMac )
	{
		inDestinationFolderPath = "'" + inDestinationFolderPath + "'";
		gitCommand = 'bash -c "' + _gitExecPath + ' ' + " clone " + inURL + " " + inDestinationFolderPath + ' --progress 2>&1"';
	}
	else if ( os. isWindows )
	{
		inDestinationFolderPath = '"' + inDestinationFolderPath + '"';
		gitCommand = _gitExecPath + " clone " + inURL + " " + inDestinationFolderPath + " --progress";
	}
	else
		debug_alert ( "Error: unknown OS" );
		
	var				arrLines = _gitExecute ( gitCommand, null, 60 * 60 * 1000 );
	
	return arrLines;
}

/**
 * Init a git repository in a given local folder.
 * 
 * @param {String} inFolderPath
 *  Folder path to init a repository in
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitInitRepositoryImpl = function ( inFolderPath )
{
	var				gitCommand;
	var				gitCommand2;
	var				gitDir = inFolderPath;
	if ( gitDir [ gitDir. length - 1 ] != '/' )
		gitDir += '/';
		
	gitDir += '.git';
	
	if ( os. isWindows )
	{
		inFolderPath = '"' + inFolderPath + '"';
		gitCommand = _gitExecPath + " init " + inFolderPath;
		gitCommand2 = _gitExecPath + " --git-dir=" + gitDir + " --work-tree=" + inFolderPath + " config http.sslVerify false";
	}
	else if ( os. isMac )
	{
		inFolderPath = "'" + inFolderPath + "'";
		gitCommand = 'bash -c "' + _gitExecPath + ' init ' + inFolderPath + ' 2>&1"';
		gitCommand2 = 'bash -c "' + _gitExecPath + ' --git-dir=' + gitDir + ' --work-tree=' + inFolderPath + ' config http.sslVerify false' + ' 2>&1"';
	}
	else
		debug_alert ( "Error: unknown OS" );
		
	var				arrLines = _gitExecute ( gitCommand );
	
	// This is needed to enable git over https with self-signed certificates on the server
	// which is usually the case when a developer just  starts working on an application
	//debug_alert ( "Running " + gitCommand2 );
	var				arrLines2 = _gitExecute ( gitCommand2 );
	
	arrLines. push. apply ( arrLines, arrLines2 );
	
	var				inRepoAndTreePath = " --git-dir=" + gitDir + " --work-tree=" + inFolderPath;
	_gitInitUserAndEMail ( inRepoAndTreePath );
	
	return arrLines;
}

/**
 * Stage an array of files within a given repository
 * 
 * @param {Array[String]} inArrPath
 *  An array of file paths to stage
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitStageFilesImpl = function ( inArrPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " add";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' add';
	else
		debug_alert ( "Error: unknown OS" );
		
	for ( var i = 0; i < inArrPaths. length; i++ )
	{
		if ( os. isWindows )
			gitCommand += ' "' + inArrPaths [ i ] + '"';
		else if ( os. isMac )
			gitCommand += " " + _gitPrepareFilePath ( inArrPaths [ i ] );
		else
			debug_alert ( "Error: unknown OS" );
	}
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	return _gitExecute ( gitCommand, null, 60000 );
}

/**
 * Returns the status of a given git repository.
 * 
 * @param {String} inWorkTree
 * 	git working tree path where to get the status
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitStatusImpl = function ( inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " status -v";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' status -v"';
	else
		debug_alert ( "Error: unknown OS" );
		
	_gitExecute ( gitCommand, inWorkTree );
}

/**
 * Remove given files from a given repository
 * 
 * @param {Array[String]} inArrPath
 *  An array of file paths to remove
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {String} git response in the form of array of strings.
 *
 */
var gitRemoveImpl = function ( inArrPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " rm --cached";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' rm --cached';
	else
		debug_alert ( "Error: unknown OS" );
		
	for ( var i = 0; i < inArrPaths. length; i++ )
	{
		if ( os. isWindows )
			gitCommand += ' "' + inArrPaths [ i ] + '"';
		else if ( os. isMac )
			gitCommand += ' ' + _gitPrepareFilePath ( inArrPaths [ i ] );
		else
			debug_alert ( "Error: unknown OS" );
	}
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	return _gitExecute ( gitCommand );
}

/**
 * Creates and initializes over HTTP a new remote repository hosted on a remote SmartHTTP server.
 * The new repositry is non-bare and is ready to be pushed to. The two currently supported hosts are Wakanda and github.com
 * 
 * @param {String} inURL
 *  URL of a remote server to create a repository on.
 * @param {String} inRemotePath
 * 	A 'path' on the remote SmartHTTP server. In case of Wakanda it is an absolute (very soon to be 
 *  changed to relative) folder path; in case of fithub it is a repository name.
 * 
 * @return {String} HTTP response (success or fail) or 'undefined' if XHR call fails.
 *
 */
var gitInitRemoteRepositoryImpl = function ( inURL, inRemotePath )
{
	var		strHTTPResponse = "";
	
	if ( _isWakandaURL ( inURL ) )
		strHTTPResponse = gitInitRepositoryOnRemoteWakandaImpl ( inURL, inRemotePath );
	else if ( _isGitHubURL ( inURL ) )
	{
		strHTTPResponse = gitInitRepositoryOnRemoteGitHubImpl ( inURL, inRemotePath );
	}
	else
	{
		debug_alert ( "Unknown URL type: " + inURL );
		throw ( "Unknown URL type: " + inURL );
	}
	
	return strHTTPResponse;
}

/**
 * Creates and initializes over HTTP a new remote repository hosted on Wakanda server.
 * The new repositry is non-bare and is ready to be pushed to.
 * 
 * @param {String} inURL
 *  URL of a remote server to create a repository on.
 * @param {String} inRemoteFullFolderPath
 * 	Full file path on the remote Wakanda server.
 * 
 * @return {String} HTTP response (success or fail) or 'undefined' if XHR call fails.
 *
 */
var gitInitRepositoryOnRemoteWakandaImpl = function ( inURL, inRemoteFullFolderPath )
{
	// TODO: eveything in the full URL must be properly encoded
		
	var			fullURL = inURL;
	if ( fullURL [ fullURL. length - 1 ] != "/" )
		fullURL += "/";

	fullURL += ( "init?path=" + inRemoteFullFolderPath );

	// Exampe of a full URL: http://admin:123@127.0.0.1:8081/gitservice/repo/init?path=/Volumes/SECOND/DBs/ClonedFromWakanda5
	return _gitExecuteHTTPRequest ( fullURL, "GET", null );
}

var gitInitRepositoryOnRemoteGitHubImpl = function ( inURL, inRepositoryName )
{
	/* TODO: Needs to accept user name and password as parameters and compose the URL here. */
	
	var			strBody = '{ "name": "' + inRepositoryName + '", "description": "Created by studio", "homepage": "https://github.com", "private": false, "has_issues": true, "has_wiki": true, "has_downloads": true }';

	return _gitExecuteHTTPRequest ( inURL, "POST", strBody );
}


/**
 * Sets the root of the current git repository on a remote SmartHTTP server.
 * 
 * @param {String} inURL
 *  URL of a remote server to set a repository root on.
 * @param {String} inRemotePath
 * 	Full (very soon to be relative) folder path in case of remote Wakanda server.
 *  Repository name in case of github.com.
 * 
 * @return {String} HTTP response (success or fail) or 'undefined' if XHR call fails.
 *
 */
var gitSetRemoteRepositoryImpl = function ( inURL, inRemotePath )
{
	// TODO: eveything in the full URL must be properly encoded
	
	var			strHTTPResponse = "";
	
	if ( _isWakandaURL ( inURL ) )
	{
		var			fullURL = inURL;
		if ( fullURL [ fullURL. length - 1 ] != "/" )
			fullURL += "/";

		fullURL += ( "dir?path=" + inRemotePath );

		// Exampe of a full URL: http://admin:123@127.0.0.1:8081/gitservice/repo/dir?path=/Volumes/SECOND/DBs/LocalToBePushed
		strHTTPResponse = _gitExecuteHTTPRequest ( fullURL, "GET", null );
	}
	else if ( _isGitHubURL ( inURL ) )
	{
		; // TODO: Implement for GitHub.com
		// github parameters: URL, repository name
	}
	else
	{
		debug_alert ( "Unknown URL type: " + inURL );
		throw ( "Unknown URL type: " + inURL );
	}
	
	return strHTTPResponse;
}

/**
 * Gets the root of the current git repository on a remote SmartHTTP server.
 * 
 * @param {String} inURL
 *  URL of a remote server to get a repository root from.
 * 
 * @return {String} HTTP response (success or fail) or 'undefined' if XHR call fails.
 *
 */
var gitGetRemoteRepositoryImpl = function ( inURL )
{
	// TODO: eveything in the full URL must be properly encoded
	
	var			strHTTPResponse = "";
	
	if ( _isWakandaURL ( inURL ) )
	{
		var			fullURL = inURL;
		if ( fullURL [ fullURL. length - 1 ] != "/" )
			fullURL += "/";

		fullURL += "dir";

		// Exampe of a full URL: http://admin:123@127.0.0.1:8081/gitservice/repo/dir
		_gitExecuteHTTPRequest ( fullURL, "GET", null );
	}
	else if ( _isGitHubURL ( inURL ) )
	{
		; // TODO: Implement for GitHub.com
		// github parameters: URL, repository name
		// TODO: just extract repository name from the given url
	}
	else
	{
		debug_alert ( "Unknown URL type: " + inURL );
		throw ( "Unknown URL type: " + inURL );
	}
	
	return strHTTPResponse;
}

/**
 * Revert given files within a given repository
 * 
 * @param {Array[String]} inArrPath
 *  An array of file paths to revert
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {Array{{Array{String}}} git response in the form of array of arrays of strings.
 *
 */
var gitRevertImpl = function ( inArrPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand1;
	var				gitCommand2;
	
	if ( os. isWindows )
	{
		gitCommand1 = _gitExecPath + strRepoAndTreePath + " reset HEAD";
		gitCommand2 = _gitExecPath + strRepoAndTreePath + " checkout";
	}
	else if ( os. isMac )
	{
		gitCommand1 = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' reset HEAD';
		gitCommand2 = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' checkout';
	}
	else
		debug_alert ( "Error: unknown OS" );
		
	for ( var i = 0; i < inArrPaths. length; i++ )
	{
		if ( os. isWindows )
		{
			gitCommand1 += ( ' "' + inArrPaths [ i ] + '"' );
			gitCommand2 += ( ' "' + inArrPaths [ i ] + '"' );
		}
		else if ( os. isMac )
		{
			gitCommand1 += ( ' ' + _gitPrepareFilePath ( inArrPaths [ i ] ) );
			gitCommand2 += ( ' ' + _gitPrepareFilePath ( inArrPaths [ i ] ) );
		}
		else
			debug_alert ( "Error: unknown OS" );
	}
	
	if ( os. isMac )
	{
		gitCommand1 += ' 2>&1"';
		gitCommand2 += ' 2>&1"';
	}
		
	var			arrResult = new Array ( );
	arrResult. push ( _gitExecute ( gitCommand1 ) );
	arrResult. push ( _gitExecute ( gitCommand2 ) );
	
	return arrResult;
}

/**
 * Provides git file status for all files within a given directory
 * 
 * @param {String} inFolderPath
 *  A path to folder which contains files to get status of.
 * @param {bool} inIsStaged
 *  If true then staged files are included, if false - not included.
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {Object} An object with the following atributes:
 *  addedFiles, modifiedFiles, deletedFiles, unmergedFiles, renamedFiles, notModifiedFiles, notFollowedFiles, ignoredFiles
 *  Each attribute is an array of file paths for a given type of status.
 */
var gitProvideFolderStatusImpl = function ( inFolderPath, inIsStaged, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand = "";
	var				gitCommandBody = " diff --name-status ";
	if ( inIsStaged )
		gitCommandBody += "--cached ";
		
	gitCommandBody += "--diff-filter=ACDMRUX";
	
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + gitCommandBody;
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + gitCommandBody;
	else
		debug_alert ( "Error: unknown OS" );
		
	if ( os. isWindows )
		gitCommand += ' "' + inFolderPath + '"';
	else if ( os. isMac )
		gitCommand += ' ' + _gitPrepareFilePath ( inFolderPath );
	else
		debug_alert ( "Error: unknown OS" );
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';

	var				arrLines = _gitExecute ( gitCommand );

	var				gitPathRoot = inWorkTree;
	if ( os. isWindows )
		gitPathRoot = gitPathRoot. replace ( /\\/g, "/" ) + "/";
	else if ( os. isMac )
		gitPathRoot += "/";
	else
		debug_alert ( "Error: unknown OS" );
		
	var				arrAddedFiles = [ ];
	var				arrModifiedFiles = [ ];
	var				arrDeletedFiles = [ ];
	var				arrUnmergedFiles = [ ];
	var				arrRenamedFiles = [ ];
	
	var				strLine = ""
	for ( var i = 0; i < arrLines. length; i++ )
	{
		strLine = arrLines [ i ];
		if ( strLine. length < 2 )
			continue;
		
		//debug_alert ( "Line to consider " + strLine );
		if ( /^A\t/. test ( strLine ) )
		{
			arrAddedFiles. push ( gitPathRoot + strLine. substring ( 2 ) );
			//debug_alert ( "To be added: " + arrAddedFiles [ arrAddedFiles. length - 1 ] );
		}
		else if ( /^M\t/. test ( strLine ) )
		{
			arrModifiedFiles. push ( gitPathRoot + strLine. substring ( 2 ) );
			//debug_alert ( "Modified: " + arrModifiedFiles [ arrModifiedFiles. length - 1 ] );
		}
		else if ( /^D\t/. test ( strLine ) )
		{
			arrDeletedFiles. push ( gitPathRoot + strLine. substring ( 2 ) );
			//debug_alert ( "To be deleted: " + arrDeletedFiles [ arrDeletedFiles. length - 1 ] );
		}
		else if ( /^U\t/. test ( strLine ) )
		{
			arrUnmergedFiles. push ( gitPathRoot + strLine. substring ( 2 ) );
			//debug_alert ( "To be merged: " + arrUnmergedFiles [ arrUnmergedFiles. length - 1 ] );
		}
		else if ( /^R\t/. test ( strLine ) )
		{
			arrRenamedFiles. push ( gitPathRoot + strLine. substring ( 2 ) );
			//debug_alert ( "To be merged: " + arrRenamedFiles [ arrRenamedFiles. length - 1 ] );
		}
	}
	
	// Now let's list those files that are tracked, but not modified and not assumed unchanged (by using ignore)
	// git ls-files -vc
	// 'H' - not modified and should be reported, 'h' - ignored and should not be reported
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " ls-files -vc --others";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' ls-files -vc --others 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );
		
	arrLines = _gitExecute ( gitCommand );
	
	var				arrNotModifiedFiles = [ ];
	var				arrNotFollowed = [ ];
	var				arrIgnored = [ ];
	for ( var i = 0; i < arrLines. length; i++ )
	{
		strLine = arrLines [ i ];
		if ( strLine. length < 2 )
			continue;
			
		//studio. alert ( "Line to consider " + strLine );
		if ( /^h/. test ( strLine ) )
		{
			strLine = gitPathRoot + strLine. substring ( 2 );
			arrIgnored. push ( strLine );
			//studio. alert ( "Ignored: " + arrIgnored [ arrIgnored. length - 1 ] );
			
			continue; // skip files that are assumed unchanged
		}
			
		var			bIsNotTracked = ( strLine. charAt ( 0 ) == '?' );
		strLine = gitPathRoot + strLine. substring ( 2 );
		if ( bIsNotTracked )
		{
			arrNotFollowed. push ( strLine );
			//studio. alert ( "Not followed: " + arrNotFollowed [ arrNotFollowed. length - 1 ] );
		}
		else if (	arrAddedFiles. indexOf ( strLine ) < 0 &&
				arrModifiedFiles. indexOf ( strLine ) < 0 &&
				arrDeletedFiles. indexOf ( strLine ) < 0 &&
				arrUnmergedFiles. indexOf ( strLine ) < 0 &&
				arrRenamedFiles. indexOf ( strLine ) < 0 )
		{
			if ( strLine. indexOf ( inFolderPath ) == 0 )
			{
				arrNotModifiedFiles. push ( strLine );
				//studio. alert ( "Tracked but not modified: " + arrNotModifiedFiles [ arrNotModifiedFiles. length - 1 ] );
			}
		}
	}
	
	var		result = { };
	result. addedFiles = arrAddedFiles;
	result. modifiedFiles = arrModifiedFiles;
	result. deletedFiles = arrDeletedFiles;
	result. unmergedFiles = arrUnmergedFiles;
	result. renamedFiles = arrRenamedFiles;
	result. notModifiedFiles = arrNotModifiedFiles;
	result. notFollowedFiles = arrNotFollowed;
	result. ignoredFiles = arrIgnored;
	
	return 	result;
}

function _gitExtractNonIndexedPaths ( inArrayPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand = "";
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " ls-files -vc --others -- ";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' ls-files -vc --others -- ';
	else
		debug_alert ( "Error: unknown OS" );
		
	for ( var i = 0; i < inArrayPaths. length; i++ )
	{
		if ( os. isWindows )
			gitCommand += ' "' + inArrayPaths [ i ] + '"';
		else if ( os. isMac )
			gitCommand += ' ' + _gitPrepareFilePath ( inArrayPaths [ i ] );
		else
			debug_alert ( "Error: unknown OS" );
	}
		
	if ( os. isMac )
		gitCommand += ' 2>&1"';

	var				arrLines = _gitExecute ( gitCommand );
	
	var				gitPathRoot = inWorkTree;
	if ( os. isWindows )
		gitPathRoot = gitPathRoot. replace ( /\\/g, "/" ) + "/";
	else if ( os. isMac )
		gitPathRoot += "/";
	else
		debug_alert ( "Error: unknown OS" );
	
	var			strLine = "";
	var			arrNotFollowed = new Array ( );
	for ( var i = 0; i < arrLines. length; i++ )
	{
		strLine = arrLines [ i ];
		if ( strLine. length < 2 )
			continue;
			
		var			bIsNotTracked = ( strLine. charAt ( 0 ) == '?' );
		if ( bIsNotTracked )
		{
			strLine = strLine. substring ( 2 );
			arrNotFollowed. push ( gitPathRoot + strLine );
//debug_alert ( "Not in index: " + arrNotFollowed [ arrNotFollowed. length - 1 ] );
		}
	}
	
	return arrNotFollowed;
}

function _gitIgnorePaths ( inArrayPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var			arrUniqueFolders = _gitExtractFolderArray ( inArrayPaths );
	// Apply --assume-unchanged to all subfolders
	for ( var i = 0; i < arrUniqueFolders. length; i++ )
	{
		var		fldr = _gitCreateFolder ( arrUniqueFolders [ i ] );
		var		arrSubFolders = fldr. folders;
		var		arrSubFolderPaths = new Array ( );
		for ( j = 0; j < arrSubFolders. length; j++ )
		{
//debug_alert ( "SUBFOLDER " + arrSubFolders [ j ]. path + " of " + fldr. path );
			arrSubFolderPaths. push ( arrSubFolders [ j ]. path );
		}
			
		_gitIgnorePaths ( arrSubFolderPaths, inWorkTree );
	}

	// Let's tell the git index to stop following selected files
	var				gitCommand;
	
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " update-index --assume-unchanged";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' update-index --assume-unchanged';
	else
		debug_alert ( "Error: unknown OS" );
		
	var		nFileCount = 0;
	for ( var i = 0; i < inArrayPaths. length; i++ )
	{
		var		bPathIsFolder = ( inArrayPaths [ i ] [ inArrayPaths [ i ]. length - 1 ] == "/" );
		var		strFilePattern = ( bPathIsFolder ? "*.*" : "" );
		if ( os. isWindows )
		{
			// On Windows a folder can not be ignored directly with wildcard *.*. Need to list files one by one manually
			if ( arrUniqueFolders. indexOf ( inArrayPaths [ i ] ) >= 0 )
			{
				// inArrayPaths [ i ] is a folder, not a file
				var				fldrT = _gitCreateFolder ( inArrayPaths [ i ] );
				var				arrFiles = fldrT. files;
				for ( var j = 0; j < arrFiles. length; j++ )
				{
					nFileCount++;
//debug_alert ( "Ignoring file" + arrFiles [ j ]. path );
					gitCommand += ' "' + arrFiles [ j ]. path + '"';
				}
			}
			else
			{
				nFileCount++;
//debug_alert ( "Ignoring folder " + inArrayPaths [ i ] );
				gitCommand += ' "' + inArrayPaths [ i ] + '"';
			}
		}
		else if ( os. isMac )
		{
			nFileCount = 1;
			gitCommand += ' ' + gitPrepareFilePath ( inArrayPaths [ i ] ) + strFilePattern;
		}
		else
			debug_alert ( "Error: unknown OS" );
	}
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	if ( nFileCount > 0 )
		_gitExecute ( gitCommand );
}


/**
 * Ignore a list of given files within a given repository
 * 
 * @param {String} inPaths
 *  An array of file paths to ignore.
 * @param {String} inWorkTree
 * 	git working tree path where the repository is declared
 * 
 * @return 
 */
var gitIgnoreImpl = function ( inPaths, inWorkTree )
{
	// Add path to .gitignore
	// git update-index --assume-unchanged <file>		<--- stop tracking
	// git update-index --no-assume-unchanged <file>	<--- start tracking again
	
	var			gitIgnorePath = inWorkTree;
	if ( inWorkTree [ inWorkTree. length - 1 ] != "/" )
		gitIgnorePath += "/";
		
	gitIgnorePath += ".gitignore";
	
	var			flIgnore = _gitCreateFile ( gitIgnorePath );
	if ( !flIgnore. exists )
	{
		debug_alert ( "Failed to open " + gitIgnorePath );
		
		return false;
	}

	// TODO: Verify if a given file is already ignored
	// TODO: Verify if a given folder can be ignored

	// .git/info/exclude	<--- same as .gitignore but local to repository
	
	var			strmIgnore = TextStream ( flIgnore, "write" );
	for ( var i = 0; i < inPaths. length; i++ )
	{
		var		pathRelative = inPaths [ i ]. substring ( inWorkTree. length );
		//debug_alert ( "TODO: Should ignore " + pathRelative );
		strmIgnore. write ( "\n" + pathRelative + "\n");
	}
	strmIgnore. flush ( );
	strmIgnore. close ( );
	
	_gitIgnorePaths ( inPaths, inWorkTree );
}

function _gitFollowPaths ( inArrayPaths, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var			arrUniqueFolders = _gitExtractFolderArray ( inArrayPaths );
	// Apply --no-assume-unchanged to all subfolders
	for ( var i = 0; i < arrUniqueFolders. length; i++ )
	{
		var		fldr = _gitCreateFolder ( arrUniqueFolders [ i ] );
		var		arrSubFolders = fldr. folders;
		var		arrSubFolderPaths = new Array ( );
		for ( j = 0; j < arrSubFolders. length; j++ )
			arrSubFolderPaths. push ( arrSubFolders [ j ]. path );
			
		_gitFollowPaths ( arrSubFolderPaths, inWorkTree );
	}
	
	var			gitCommand = "";
	
	/*	Files that have never been followed by Git (never been added to the index) can not be followed using "update-index".
		They need to be added and then committed before running "update-index". */
	var			gitCommand2 = "";
	
	if ( os. isWindows )
	{
		gitCommand = _gitExecPath + strRepoAndTreePath + " update-index --no-assume-unchanged";
		//gitCommand2 = 
	}
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' update-index --no-assume-unchanged';
	else
		debug_alert ( "Error: unknown OS" );
		
	var			arrAllPaths = new Array ( );
	var			nFileCount = 0;
	for ( var i = 0; i < inArrayPaths. length; i++ )
	{
		var		bPathIsFolder = ( inArrayPaths [ i ] [ inArrayPaths [ i ]. length - 1 ] == "/" );
		var		strFilePattern = ( bPathIsFolder ? "*.*" : "" );
		if ( os. isWindows )
		{
			// On Windows a folder can not be followed directly with wildcard *.*. Need to list files one by one manually
			if ( arrUniqueFolders. indexOf ( inArrayPaths [ i ] ) >= 0 )
			{
				// inArrayPaths [ i ] is a folder, not a file
				var				fldrT = _gitCreateFolder ( inArrayPaths [ i ] );
				var				arrFiles = fldrT. files;
				for ( var j = 0; j < arrFiles. length; j++ )
				{
					nFileCount++;
					//studio. alert ( "Ignoring " + arrFiles [ j ]. path );
					gitCommand += ' "' + arrFiles [ j ]. path + '"';
					arrAllPaths. push ( arrFiles [ j ]. path );
				}
			}
			else
			{
				nFileCount++;
				gitCommand += ' "' + inArrayPaths [ i ] + '"';
				arrAllPaths. push ( inArrayPaths [ i ] );
			}
		}
		else if ( os. isMac )
		{
			nFileCount = 1;
			gitCommand += ' ' + gitPrepareFilePath ( inArrayPaths [ i ] ) + strFilePattern;

			if ( arrUniqueFolders. indexOf ( inArrayPaths [ i ] ) >= 0 )
			{
				// inArrayPaths [ i ] is a folder, not a file
				var				fldrT = _gitCreateFolder ( inArrayPaths [ i ] );
				var				arrFiles = fldrT. files;
				for ( var j = 0; j < arrFiles. length; j++ )
					arrAllPaths. push ( arrFiles [ j ]. path );
			}
			else
				arrAllPaths. push ( inArrayPaths [ i ] );
		}
		else
			debug_alert ( "Error: unknown OS" );
	}
	
	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	
	var			arrPathsToAddAndCommit = _gitExtractNonIndexedPaths ( arrAllPaths, inWorkTree );
	if ( arrPathsToAddAndCommit. length > 0 )
	{
		gitStageFilesImpl ( arrPathsToAddAndCommit, inWorkTree );
		gitCommitLocalImpl ( "Followed from studio", inWorkTree, arrPathsToAddAndCommit );
	}
	
	if ( nFileCount > 0 )
		_gitExecute ( gitCommand );
}

/**
 * Follow a list of given files within a given repository
 * 
 * @param {String} inPaths
 *  An array of file paths to follow.
 * @param {String} inWorkTree
 * 	git working tree path where the repository is declared
 * 
 * @return 
 */
var gitFollowImpl = function ( inPaths, inWorkTree )
{
	// First, let's build an array of paths "absolute" to git repository root
	var			arrAbsolutePaths = [ ];
	// Second, let's build an array of patterns that match extensions of provided files
	var			arrExtensionPatterns = [ ];
	for ( var i = 0; i < inPaths. length; i++ )
	{
		var		flIgnore = _gitCreateFile ( inPaths [ i ] );
		if ( flIgnore. exists && flIgnore. extension. length > 0 )
		{
			arrExtensionPatterns. push ( "*." + flIgnore. extension );
		}

		arrAbsolutePaths. push ( inPaths [ i ]. substring ( inWorkTree. length ) );
		//debug_alert ( "Must remove '" + arrAbsolutePaths [ i ] + "' from .gitignore if it is present there" );
	}

	var			gitIgnorePath = inWorkTree;
	if ( inWorkTree [ inWorkTree. length - 1 ] != "/" )
		gitIgnorePath += "/";
		
	gitIgnorePath += ".gitignore";

	var			flIgnore = _gitCreateFile ( gitIgnorePath );
	if ( !flIgnore. exists )
	{
		debug_alert ( "Failed to open " + gitIgnorePath );
		
		return false;
	}
	
	// Read .gitignore line by line and remove those lines that correspond to files or folders selected for git following.
	var			strNewIgnore = "";
	var			strmIgnore = TextStream ( flIgnore, "read" );
	while ( !strmIgnore. end ( ) )
	{
		var		strLine = strmIgnore. read ( "" );
		//debug_alert ( "line " + strLine + " of length " + strLine. length );
		// Remove line if it exactly matches one of arrAbsolutePaths
		if ( arrAbsolutePaths. indexOf ( strLine ) >= 0 || arrExtensionPatterns. indexOf ( strLine ) >= 0 )
		{
			//debug_alert ( "'" + strLine + "' is currently ignored and should be followed" );
		}
		else
		{
			if ( strLine. length > 0 )
				strNewIgnore += strLine + "\n";
		}
	}
	
	//debug_alert ( "New .gitignore:\n" + strNewIgnore );
	strmIgnore. close ( );
	
	flIgnore = _gitCreateFile ( gitIgnorePath );
	
	strmIgnore = TextStream ( flIgnore, "Overwrite" );
	strmIgnore. write ( strNewIgnore );
	strmIgnore. flush ( );
	strmIgnore. close ( );

	_gitFollowPaths ( inPaths, inWorkTree );
}

/**
 * Reset all files in a "to be merged" state to their original state before the merge was started.
 * 
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return 
 */
var gitResetAllMergedImpl = function ( inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );

	var				gitCommand;
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " reset --merge HEAD";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' reset --merge HEAD' + ' 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );
		
	_gitExecute ( gitCommand, null, 60000 );
}

/**
 * Launch an external default UI application to browse a given repostiory's history.
 * 
 * @param {String} inWorkTree
 * 	git working tree path where the repository is declared
 * 
 * @return {String} git response in the form of array of strings.
 */
var gitLaunchHistoryAppImpl = function ( inWorkTree )
{
	var			fl = _gitCreateFile ( _gitExecPath );
	if ( fl == null )
	{
		debug_alert ( "Failed to create file reference" );
		
		return false;
	}

	var			gitkPath = fl. parent. parent. path + "cmd/gitk";
	//debug_alert ( gitkPath );
	
	var			gitCommand;
	if ( os. isWindows )
		gitCommand = 'cmd.exe /C "' + gitkPath + '"';
	else if ( os. isMac )
		gitCommand = 'bash -c "gitk"';
	else
		debug_alert ( "Error : unknown os" );

	return _gitExecute ( gitCommand, inWorkTree, 5000 );
}

/**
 * Reset all files in a given repository to their original state of the last commit and revert all changes.
 * 
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return 
 */
var gitHardResetAllImpl = function ( inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand;
	
	if ( os. isWindows )
		gitCommand = _gitExecPath + strRepoAndTreePath + " reset --hard HEAD";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' reset --hard HEAD 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );
		
	_gitExecute ( gitCommand, null, 60000 );
}

/**
 * Launch an external file diff UI application; it needs to be preconfigured in advance.
 * 
 * @param {String} inPaths
 * 	A list of files to perform the diff on
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {String} git response in the form of array of strings.
 */
var gitLaunchDiffAppImpl = function ( inPaths, inWorkTree )
{
/*
	KDiff3 needs to be installed and configured.
	git global config needs to contain something similar:

[http]
	sslVerify = false
[merge]
	tool = kdiff3
[mergetool "kdiff3"]
	path = c:\\Program Files (x86)\\KDiff3\\kdiff3.exe
[diff]
	tool = kdiff3
[difftool "kdiff3"]
	path = c:\\Program Files (x86)\\KDiff3\\kdiff3.exe

The [diff] and [difftool ...] are necessary when running diff as a system worker from the studio because
apparently system environment is not exactly the same when running directly from command line.
*/

	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );

	var				gitCommand;
	if ( os. isWindows )
	{
		gitCommand = _gitExecPath + strRepoAndTreePath + ' difftool --cached -y';
	}
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' difftool --cached -y';
	else
		debug_alert ( "Error: unknown OS" );

	for ( var i = 0; i < inPaths. length; i++ )
	{
		if ( os. isWindows )
			gitCommand += ' "' + inPaths [ i ] + '"';
		else if ( os. isMac )
			gitCommand += ' ' + gitPrepareFilePath ( inPaths [ i ] );
		else
			debug_alert ( "Error: unknown OS" );
	}

	if ( os. isMac )
		gitCommand += ' 2>&1"';
		
	return _gitExecute ( gitCommand, null, 10000 );
}

/**
 * Execute a custom git command on a given repository.
 * 
 * @param {String} inCommand
 * 	A command to be executed
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return {String} git response in the form of array of strings.
 */
var gitExecuteCustomImpl = function ( inCommand, inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand = "";
	if ( os. isWindows )
		gitCommand = gitExecPath + strRepoAndTreePath + " " + inCommand;
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' ' + inCommand + ' 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );
		
	return _gitExecute ( gitCommand, null, 5 * 60 * 1000 );
}

/**
 * Extracts error messages from git's execution output.
 * 
 * @param {String} inLines
 * 	An array of strings that contains text output of git
 * @param {String} inMask
 * 	A string to replace when showing alerts or log messages. Typically, is used to mask user password.
 * 
 * @return {String} git response in the form of array of strings.
 */
var gitExtractErrorImpl = function ( inLines, inMask )
{
	if ( typeof ( inLines ) === "undefined" || inLines == null || inLines. length == 0 )
		return null;
		
	inMask = ":" + inMask + "@";
	var		nMaskIndex = -1;
	
	var		result = new Object ( );
	result. error = "";
	result. fatal = "";
	result. warning = "";
	for ( var i = 0; i < inLines. length; i++ )
	{
		if ( /^error\: /. test ( inLines [ i ] ) )
		{
			result. error = inLines [ i ]. substring ( 7 );
			nMaskIndex = result. error. indexOf ( inMask );
			if ( nMaskIndex >= 0 )
				result. error = result. error. substring ( 0, nMaskIndex + 1 ) + "*****" + result. error. substring ( nMaskIndex + inMask. length - 1 );
				
			break;
		}
	}
	for ( var i = 0; i < inLines. length; i++ )
	{
		if ( /^fatal\: /. test ( inLines [ i ] ) )
		{
			result. fatal = inLines [ i ]. substring ( 7 );
			nMaskIndex = result. fatal. indexOf ( inMask );
			if ( nMaskIndex >= 0 )
				result. fatal = result. fatal. substring ( 0, nMaskIndex + 1 ) + "*****" + result. fatal. substring ( nMaskIndex + inMask. length - 1 );
			
			break;
		}
	}
	
	for ( var i = 0; i < inLines. length; i++ )
	{
		if ( /^warning\: /. test ( inLines [ i ] ) )
		{
			result. warning = inLines [ i ];
			nMaskIndex = result. warning. indexOf ( inMask );
			if ( nMaskIndex >= 0 )
				result. warning = result. warning. substring ( 0, nMaskIndex + 1 ) + "*****" + result. warning. substring ( nMaskIndex + inMask. length - 1 );
			
			break;
		}
	}
	
	if ( result. error == "" && result. fatal == "" && result. warning == "" )
		result = null;
	
	return result;
}

/**
 * Get a total number of commits for a given repository.
 * 
 * @param {String} inWorkTree
 * 	git repository root path
 * 
 * @return Total number of commits.
 */
var gitGetCommitCountImpl = function ( inWorkTree )
{
	var				strRepoAndTreePath = _gitGetRepoAndTree ( inWorkTree );
	
	var				gitCommand = "";
	if ( os. isWindows )
		gitCommand = gitExecPath + strRepoAndTreePath + " rev-list --all";
	else if ( os. isMac )
		gitCommand = 'bash -c "' + _gitExecPath + strRepoAndTreePath + ' rev-list --all' + ' 2>&1"';
	else
		debug_alert ( "Error: unknown OS" );
		
	var			arrResponse = _gitExecute ( gitCommand );
	
	return arrResponse. length - 1; // The last line is empty
}

function _gitSetToolPath ( inToolType, inToolPath )
{
	if ( os. isMac )
	{
		// The app package is likely to be selected instead of the executable binary itself. Lets append the 
		// necessary path to the executable.
		if ( inToolPath. charAt ( inToolPath. length - 1 ) == "/" )
			inToolPath = inToolPath. substring ( 0, inToolPath. length - 1 );
			
		if (	inToolPath. lastIndexOf ( ".app" ) >= 0 &&
				inToolPath. lastIndexOf ( ".app" ) == inToolPath. length - ".app". length )
		{
			var		appFolder = _gitCreateFolder ( inToolPath );
			inToolPath += "/Contents/MacOS/" + appFolder. nameNoExt;
		}
	}
	
//debug_alert ( inToolPath );
	var				toolFile = _gitCreateFile ( inToolPath );
	if ( toolFile == null || !toolFile. exists )
	{
		debug_alert ( "Error: " + inToolPath + " does not exist." );
		
		return;
	}
	
	var				toolName = toolFile. nameNoExt;
	
	var				gitCommand1 = "";
	var				gitCommand2 = "";
	var				gitCommand3 = "";
	var				gitCommand4 = "";
	if ( os. isWindows )
	{
		gitCommand1 = gitExecPath + " config --global " + inToolType + ".tool " + toolName;
		gitCommand2 = gitExecPath + " config --global " + inToolType + "tool." + toolName + ".path " + '"' + inToolPath + '"';
		if ( inToolType == "merge" )
		{
			// A couple of things specific to merge
			gitCommand3 = gitExecPath + " config --global mergetool.keepBackup false";
			gitCommand4 = gitExecPath + " config --global mergetool.keepTemporaries false";
		}
	}
	else if ( os. isMac )
	{
		gitCommand1 = 'bash -c "' + _gitExecPath + ' config --global ' + inToolType + '.tool ' + toolName + ' 2>&1"';
		gitCommand2 = 'bash -c "' + _gitExecPath + ' config --global ' + inToolType + 'tool.' + toolName + '.path ' + "'" + inToolPath + "'" + ' 2>&1"';
		if ( inToolType == "merge" )
		{
			// A couple of things specific to merge
			gitCommand3 = 'bash -c "' + _gitExecPath + ' config --global mergetool.keepBackup false 2>&1"';
			gitCommand4 = 'bash -c "' + _gitExecPath + ' config --global mergetool.keepTemporaries false 2>&1"';
		}
	}
	else
		debug_alert ( "Error: unknown OS" );
		
	var				arrResponse = _gitExecute ( gitCommand1 );
	arrResponse = _gitExecute ( gitCommand2 );
	if ( inToolType == "merge" )
	{
		arrResponse = _gitExecute ( gitCommand4 );
		arrResponse = _gitExecute ( gitCommand4 );
	}

	return;
}

/**
 * Sets the path to the default diff application.
 * 
 * @param {String} inDiffToolPath
 * 	A full path to the new default diff application
 * 
 * @return nothing
 */
var gitSetDiffToolPathImpl = function ( inDiffToolPath )
{
	_gitSetToolPath ( "diff", inDiffToolPath );
}

/**
 * Sets the path to the default merge application.
 * 
 * @param {String} inMergeToolPath
 * 	A full path to the new default merge application
 * 
 * @return nothing
 */
var gitSetMergeToolPathImpl = function ( inMergeToolPath )
{
	_gitSetToolPath ( "merge", inMergeToolPath );
}



var				exports;

exports. myTest = myTestImpl;
exports. init = gitInitImpl;
exports. setGitExecPath = gitSetGitExecPathImpl;
exports. execute = gitExecuteImpl;
exports. verifyRepository = gitVerifyRepositoryImpl;
exports. responseHasConflicts = gitResponseHasConflictsImpl;
exports. repositoryHasModifications = gitRepositoryHasModificationsImpl;
exports. initIgnore = gitInitIgnoreImpl;
exports. getVersion = gitGetVersionImpl;
exports. mergeAll = gitRunMergeAllImpl;
exports. saveStash = gitSaveStashImpl;
exports. popStash = gitPopLatestStashImpl;
exports. listStashes = gitListStashesImpl;
exports. showLatestStash = gitShowLatestStashImpl;
exports. clearAllStashes = gitClearAllStashesImpl;
exports. pull = gitPullImpl;
exports. push = gitPushImpl;
exports. commit = gitCommitLocalImpl;
exports. clone = gitCloneImpl;
exports. initRepository = gitInitRepositoryImpl;
exports. stage = gitStageFilesImpl;
exports. getStatus = gitStatusImpl;
exports. remove = gitRemoveImpl;
exports. initRemoteRepository = gitInitRemoteRepositoryImpl;
exports. setRemoteRepository = gitSetRemoteRepositoryImpl;
exports. getRemoteRepository = gitGetRemoteRepositoryImpl;
exports. revert = gitRevertImpl;
exports. getDefaultIgnore = gitGetDefaultIgnoreImpl;
exports. getIgnoreContent = gitGetIgnoreContentImpl;
exports. setIgnoreContent = gitSetIgnoreContentImpl;
exports. provideFolderStatus = gitProvideFolderStatusImpl;
exports. ignore = gitIgnoreImpl;
exports. follow = gitFollowImpl;
exports. resetAllMerged = gitResetAllMergedImpl;
exports. launchHistoryApp = gitLaunchHistoryAppImpl;
exports. hardResetAll = gitHardResetAllImpl;
exports. launchDiffApp = gitLaunchDiffAppImpl;
exports. executeCustom = gitExecuteCustomImpl;
exports. extractError = gitExtractErrorImpl;
exports. getCommitCount = gitGetCommitCountImpl;
exports. setDiffToolPath = gitSetDiffToolPathImpl;
exports. setMergeToolPath = gitSetMergeToolPathImpl;
exports. setProxy = gitSetProxyImpl;