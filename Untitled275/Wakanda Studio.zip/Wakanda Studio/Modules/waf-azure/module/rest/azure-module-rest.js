var

modulePath ,

net				= require( 'net' );

modulePath		= getWalibFolder( "folder" ).parent.path + "Modules/waf-azure/";

azure.module 	= {};

//include( modulePath + "util/azure-util.js" );



azure.module.rest = function ( azure , json ) {
	
    this.azure				= azure;
    
    this.version			= json.version;
    
    this.baseURL			= json.baseURL;
    
    this.xmlns				= json.xmlns;
    
    this.socket				= json.socket;
    
    this.auth_field			= json.auth_field;
    
    this.auth_format		= json.auth_format;
    
    this.Algorithm			= json.Algorithm;
	
    var
    
    that = this;
    
    this.request	= function( req_json ) {
    	
        return new rest_module.request( that , req_json , json.version );
        
    }
    
}

var

rest_module = azure.module.rest;

azure.module.rest.request = function ( module , json , module_version ) {
	
    this.azure			= module.azure;
    
    this.module			= module;
    
    this.HTTPVerb       = json.HTTPVerb;
    
    this.HTTPVersion    = "1.1";
    
    this.reqBaseURL		= ( json.baseURL )?json.baseURL + '.' + module.baseURL : module.baseURL;
    
    this.resource       = json.resource;
    
    this.rsrc_variables = ( json.rsrc_variables )? json.rsrc_variables : [ ];
    
    this.params         = json.params;
    
    this.headers        = ( json.headers )? json.headers : [ ];
    
    this.body           = ( json.body == undefined )? "" : json.body;
    
    this.body_type      = ( json.body_type == undefined )? "normal" : json.body_type;
    
    this.body_root		= json.body_root;
    
    this.body_structure = json.body_structure;
    
    this.body_variables = json.body_variables;
    
    this.outputFile		= json.outputFile;
   
    this.rsrc_variables[ "subscriptionId" ] = module.azure.subscriptionId;
    
    this.send      		= function( ) {
    	
        return azure.module.rest.request.send.call( this );
        
    };
    
    this.getResource    = function( ) {
    	
        return azure.module.rest.request.getResource.call( this );
        
    };
    
}

rest_module.request.getResource = function( ) {
	
    var
    
    resource = this.resource,
    
    pString = "";
    
    for ( var i in this.rsrc_variables ) {
    	
        resource = resource.replace( new RegExp( "\\$" + i , "g" ) , this.rsrc_variables[ i ] );
        
    }

    //Add parameters
    if ( this.params != undefined ) {
    	
        pString = "?";

        for( i in this.params ) {
        	
            pString += ( pString == "?" )? i + "=" + this.params[ i ] : "&" + i + "=" + this.params[ i ];
            
        }
        
    }
    
    return resource + pString;
    
}

rest_module.request.send = function( ) {
	
	//debugger;
	
    var
    
    out = "",
    
    body = "",
    
    file = null;
	
    if ( this.headers == undefined ) {
    	
        this.headers = [ ];
        
    }

    //Add body
    switch ( this.body_type ) {
    	
        case "normal" :
        
            body = this.body;
            
            this.headers[ "Content-Length" ] = body.length;
            
            break;
            
        case "vars" :
        
            body = this.body;
            
            if ( this.body_variables != undefined ) {
            	
                for( var i in this.body_variables ) {
                	
                    body = body.replace( new RegExp( "\\$" + i , "g" ) , this.body_variables[ i ] );
                    
                }
                
            }
            
            this.headers[ "Content-Length" ] = body.length;
            
            break;
            
        case "file" :
        
            file = File( this.body );
            
            this.headers[ "Content-Length" ] = file.size;
            
            break;
            
    }
		    
    this.headers.Host 	= this.reqBaseURL;
    
    //this.headers.Date	= azure.util.getNowTimeStamp( );
    
    this.headers['x-ms-version'] = this.module.version;
    
    this.headers['Content-type'] = 'application/xml';    
		
    if ( this.module.socket ){
	    
        
    } else {
    	
        var
        
        url		= 'https://' + this.headers.Host + this.getResource(),
        
        xhr		= new XMLHttpRequest(),
        
        result	= '';     
            
        //debugger;
        function getResponse() {
	    	
            if (xhr.readyState == 4) {

                result = xhr.responseText; //JSON.parse(XmlToJSON(xhr.responseText, "json-bag", ""));

            }
        }
		
        xhr.onreadystatechange = getResponse;
    
        xhr.open( this.HTTPVerb , url );
        
        for ( var header in this.headers ) {

            if ( header != "Host" ) {
            	
                xhr.setRequestHeader( header , this.headers[ header ] );
                
            }
            
        }
        
		xhr.setClientCertificate( this.azure.keyPath, this.azure.certPath );
		
        if ( typeof this.body != 'undefined' ) {
        	
            xhr.send( this.body );
            
        } else {
        	
			//debugger;
			
            xhr.send( null );
             
        }  	

        return result;
        
    }
    
}