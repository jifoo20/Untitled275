var

modulePath;

modulePath = getWalibFolder( "folder" ).parent.path + "Modules/waf-azure/";

include( modulePath + "module/rest/azure-module-rest.js" );

//include( modulePath + "module/request/azure-module-request.js" );