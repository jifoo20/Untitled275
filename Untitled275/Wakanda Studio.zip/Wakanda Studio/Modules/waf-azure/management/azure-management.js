﻿var
modulePath;

modulePath = getWalibFolder("folder").parent.path + "Modules/waf-azure/";

azure.modules.management = {
	type : "rest",
	config : {
		version 			: "2011-12-01",
		baseURL				: "management.core.windows.net",
		//xmlns				: "http://doc.s3.amazonaws.com/2006-03-01",
		socket 				: false
	}
}