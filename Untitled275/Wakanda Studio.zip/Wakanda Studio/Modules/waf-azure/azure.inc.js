var

azure ,

modulePath;

azure		= {};

modulePath	= getWalibFolder( "folder" ).parent.path + "Modules/waf-azure/";

azure = function( subscriptionId , keyPath , certPath ){
	
    this.subscriptionId = subscriptionId;
    
    this.keyPath		= keyPath;
    
    this.certPath		= certPath;
    
    for ( var mod in azure.modules ) {
    	
        var
        
        modType 	= azure.modules[ mod ].type,
        
        modConfig 	= azure.modules[ mod ].config;
		
        this[ mod ] = new azure.module[ modType ]( this , modConfig );
        
    }
    
}

if ( azure.modules == undefined ) {
	
    azure.modules = {};
    
}

// Module including area
include( modulePath + "module/azure-module.js" );
include(modulePath + "management/azure-management.js");
