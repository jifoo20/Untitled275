var
modulePath;

modulePath = getWalibFolder("folder").parent.path + "Modules/waf-azure/";

include(modulePath + "azure.inc.js");

exports.client = azure;