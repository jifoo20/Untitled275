#waf-aws : Module to ensure communication with Amazon Web Services APIs
Supports : EC2, S3, Route53 and can easily be updated to support a new service.
The source code still needs cleaning though.
