/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function _browse(request, response){
   return JSON.stringify("return from _browse");
}