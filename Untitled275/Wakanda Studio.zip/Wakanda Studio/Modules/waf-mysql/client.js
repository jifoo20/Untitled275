/*
 * This file is part of Wakanda software, licensed by 4D under
 *  (i) the GNU General Public License version 3 (GNU GPL v3), or
 *  (ii) the Affero General Public License version 3 (AGPL v3) or
 *  (iii) a commercial license.
 * This file remains the exclusive property of 4D and/or its licensors
 * and is protected by national and international legislations.
 * In any event, Licensee's compliance with the terms and conditions
 * of the applicable license constitutes a prerequisite to any use of this file.
 * Except as otherwise expressly stated in the applicable license,
 * such license does not include any other license or rights on this file,
 * 4D's and/or its licensors' trademarks and/or other proprietary rights.
 * Consequently, no title, copyright or other proprietary rights
 * other than those specified in the applicable license is granted.
 */
var utils = require('waf-mysql/utils');

var Client = function(args) {
        var params = {};
        if (typeof args[0] == 'object') {
            params = args[0];
        }
        else {
            params.hostname = args[0] || 'localhost';
            params.user = args[1] || 'root';
            params.password = args[2] || '';
            params.database = args[3] || '';
            params.port = args[4] || 3306;
            params.ssl = args[5] || false;
        }

        this._connector = new SQLConnector("mysql");
        this._impl = this._connector.createSession(params);
    };

Client.prototype.useDatabase = function(database) {
    var query = 'USE ' + database;
    return this.execute(query);
};

Client.prototype.execute = function(query) {
    this._impl.executeQuery(query);
    var res = new ResultSet();
    res._impl = this._impl.getNextResultSet();
    return res;
};

Client.prototype.hasMoreResults = function() {
    return this._impl.hasMoreResultSet();
};

Client.prototype.getResultCount = function() {
    return this._impl.getResultSetCount();
};

Client.prototype.find = function(fields, table, key) {
    //find("*", "table", {id:1});
    //find("fields", "from", "where conditions");
    var
    //the query that will be constructed
    query, keyVal;
    //argument syntax error
    if (arguments.length < 2) {
        throw new Error('too few parameters given for find function!');
    }
    else if (arguments.length >= 2) {
        if (typeof arguments[0] != 'string' || typeof arguments[1] != 'string') {
            throw new Error('Syntax Error in find function!');
        }
        query = "SELECT " + arguments[0] + " FROM " + arguments[1];
    }
    if (arguments.length >= 3) {
        if (typeof arguments[2] != 'object') {
            throw new Error('Syntax Error');
        }
        keyVal = Object.keys(arguments[2])[0];
        query += " WHERE " + keyVal + "=";

        if (typeof arguments[2][keyVal] == 'string') {
            query += "'" + utils.addSlashes(arguments[2][keyVal]) + "'";
        }
        else if (typeof arguments[2][keyVal] == 'number') {
            query += arguments[2][keyVal];
        }
        else {
            throw new Error('Syntax Error in find function!');
        }
    }

    res = this.execute(query);
    row = res.getNextRow();

    return row;
};

Client.prototype.select = function(fields, table, key) {
    //select("*", "table", {id:1});
    //select("fields", "from", "where conditions");
    var
    //the query that will be constructed
    query, keyVal;
    //argument syntax error
    if (arguments.length < 2) {
        throw new Error('too few parameters given for select function!');
    }
    else if (arguments.length >= 2) {
        if (typeof arguments[0] != 'string' || typeof arguments[1] != 'string') {
            throw new Error('Syntax Error in select function!');
        }
        query = "SELECT " + arguments[0] + " FROM " + arguments[1];
    }
    if (arguments.length >= 3) {
        if (typeof arguments[2] != 'object') {
            throw new Error('Syntax Error');
        }
        keyVal = Object.keys(arguments[2])[0];
        query += " WHERE " + keyVal + "=";

        if (typeof arguments[2][keyVal] == 'string') {
            query += "'" + utils.addSlashes(arguments[2][keyVal]) + "'";
        }
        else if (typeof arguments[2][keyVal] == 'number') {
            query += arguments[2][keyVal];
        }
        else {
            throw new Error('Syntax Error in select function!');
        }
    }

    return this.execute(query);


};

Client.prototype.update = function(table, fieldsToUpdate, key) {
    //dbconn.update( "table_name" ; {age:42 , salary:1000} /* fields to update */ ; {id:100} /* where_clause */);
    var
    query, keyVal, _arguments, sep;
    // argument syntax error
    if (arguments.length < 3) {
        throw new Error('too few parameters given in update function!');
    }
    else if (arguments.length >= 3) {
        if (typeof arguments[0] != 'string' || typeof arguments[1] != 'object' || typeof arguments[2] != 'object') {
            throw new Error('Syntax Error in update function!');
        }

        query = "UPDATE " + arguments[0] + " SET ";
        _arguments = arguments[1];
        sep = "";
        Object.getOwnPropertyNames(_arguments).forEach(

        function(key) {
            query += sep + '`' + key + '`=';
            if (typeof _arguments[key] == 'string') {
                query += "'" + utils.addSlashes(_arguments[key]) + "'";
            }
            else if (typeof _arguments[key] == 'number') {
                query += _arguments[key];
            }
            else {
                throw new Error('Syntax Error in update function!');
            }
            sep = " ,"
        });

        keyVal = Object.keys(arguments[2])[0];
        query += " WHERE " + keyVal + "=";

        if (typeof arguments[2][keyVal] == 'string') {
            query += "'" + arguments[2][keyVal] + "'";
        }
        else if (typeof arguments[2][keyVal] == 'number') {
            query += arguments[2][keyVal];
        }
        else {
            throw new Error('Syntax Error in update function!');
        }
    }
    return this.execute(query);
};

Client.prototype.delete = function(table, key) {
    //dbconn.delete( "table_name" ; {id:100} /* where_clause */);
    var
    query, keyVal;
    if (arguments.length < 2) { // argument syntax error
        throw new Error('too few parameters given in delete function!');
    }
    else if (arguments.length >= 2) {

        if (typeof arguments[0] !== 'string' || typeof arguments[1] !== 'object') {
            throw new Error('Syntax Error in delete function!');
        }

        query = "DELETE FROM " + arguments[0];

        if (typeof arguments[1] != 'object') {
            throw new Error('Syntax Error in delete function!');
        }

        keyVal = Object.keys(arguments[1])[0];
        query += " WHERE " + keyVal + "=";

        if (typeof arguments[1][keyVal] == 'string') {
            query += "'" + utils.addSlashes(arguments[1][keyVal]) + "'";
        }
        else if (typeof arguments[1][keyVal] == 'number') {
            query += arguments[1][keyVal];
        }
        else {
            throw new Error('Syntax Error in delete function!');
        }
    }

    return this.execute(query);
};

Client.prototype.insert = function(table, values) {
    //dbconn.insert( "table_name" ; [ {name:"x" , age:1}, {name:y, age:2} ]);
    var
    query, sep, sep2, _arguments, i;
    if (arguments.length != 2) // argument syntax error
    throw new Error('too few parameters given in insert function!');

    if (typeof arguments[0] !== 'string' || typeof arguments[1] !== 'object') throw new Error('Syntax Error in insert function!');

    query = "INSERT INTO " + arguments[0] + " (";


    if (arguments[1].length == 0) {
        throw new Error('Syntax Error: Empty insert data');
    }

    _arguments = arguments[1][0];

    if (typeof _arguments != 'object') {
        throw new Error('Syntax Error in insert function!');;
    }

    sep = "";
    Object.getOwnPropertyNames(_arguments).forEach(

    function(key) {
        query += sep + '`' + key + '`';
        sep = " ,"
    });

    query += ") VALUES ";
    sep2 = "";
    for (i = 0; i < arguments[1].length; i++) {
        _arguments = arguments[1][i];
        if (typeof _arguments != 'object') {
            throw new Error('Syntax Error in insert function!');
        }
        sep = "";
        query += sep2 + "(";
        Object.getOwnPropertyNames(_arguments).forEach(

        function(key) {
            if (typeof _arguments[key] == 'string') {
                query += sep + "'" + utils.addSlashes(_arguments[key]) + "'";
            }
            else if (typeof _arguments[key] == 'number') {
                query += sep + _arguments[key];
            }
            sep = " ,"
        });
        query += ")";
        sep2 = ", ";
    }
    return this.execute(query);
};

Client.prototype.close = function() {
    this._impl.close();
};

Client.prototype.getNextResult = function() {
    var res, impl;
    impl = this._impl.getNextResultSet();

    if (impl == null) {
        res = null;
    }
    else {
        res = new ResultSet();
        res._impl = impl;
    }

    return res;
};

Client.prototype.createPreparedStatement = function(query) {
    var stmt, pStmt, impl;

    stmt = this._impl.createStatement(query);
    impl = stmt.getPreparedStatement();
    if (impl != null) {
        pStmt = new PreparedStatement();
        pStmt._impl = impl;
    }
    else {
        pStmt = null;
    }

    return pStmt;
};

Client.prototype.createNamedPreparedStatement = function(query) {
    //create a namedPreparedStatement from 'query'
    var parsedQuery, paramsMap = {},
        pStmt, namedPStmt;

    try {
        parsedQuery = utils.parse(query, paramsMap);
        pStmt = this.createPreparedStatement(parsedQuery);
    }
    catch (e) {
        throw new Error(e.message);
    }
    namedPStmt = new NamedPreparedStatement();
    namedPStmt.preparedStatement = pStmt;
    namedPStmt.paramsMap = paramsMap;
    return namedPStmt;

}

function ResultSet() {}

ResultSet.prototype.getAllRows = function() {
    return this._impl.getAllRows();
};

ResultSet.prototype.getNextRow = function() {
    return this._impl.getNextRow();
};

ResultSet.prototype.getNextRows = function(count) {
    return this._impl.getNextRows(count);
};

ResultSet.prototype.skipRows = function(count) {
    return this._impl.skipRows(count);
};

ResultSet.prototype.getRowsCount = function() {
    return this._impl.getRowCount();
};

ResultSet.prototype.hasNext = function() {
    return !this._impl.isEOF();
};

ResultSet.prototype.getColumnName = function(i) {
    var allNames = this._impl.getColumnNames();
    return allNames[i];
};

ResultSet.prototype.getColumnType = function(i) {
    var allTypes = this._impl.getColumnTypes();
    return allTypes[i];
};

ResultSet.prototype.getColumnFlags = function(i) {
    var allFlags = this._impl.getColumnFlags();
    return allFlags[i];
};

ResultSet.prototype.getColumnsCount = function(i) {
    return this._impl.getColumnCount();
};

ResultSet.prototype.isSelect = function() {
    return this._impl.isSelect();
};

ResultSet.prototype.isError = function() {
    return this._impl.isError();
};

ResultSet.prototype.getAffectedRowCount = function() {
    return this._impl.getAffectedRowCount();
};

function PreparedStatement() {}

PreparedStatement.prototype.getParameterCount = function() {
    return this._impl.getParamCount();
};

PreparedStatement.prototype.getColumnCount = function() {
    return this._impl.getColumnCount();
};

PreparedStatement.prototype.setNthParameter = function(index, value) {
    this._impl.setNthParameter(index, value);
};

PreparedStatement.prototype.setParameters = function(values) {
    for (var i = 0; i < values.length; ++i) {
        this._impl.setNthParameter(i + 1, values[i]);
    }
};

PreparedStatement.prototype.execute = function() {
    var res = new ResultSet();
    res._impl = this._impl.execute();
    return res;
};

function NamedPreparedStatement() {
    this.paramsMap = {};
    this.preparedStatement = new PreparedStatement();
}

/*
 * return number of parameters in the namedPreparedStatement
 */
NamedPreparedStatement.prototype.getParameterCount = function() {
    var count = 0;
    for (var att in this.paramsMap) {
        if (this.paramsMap.hasOwnProperty(att)) {
            ++count;
        }
    }

    return count;
};

NamedPreparedStatement.prototype.getColumnCount = function() {
    return this.preparedStatement.getColumnCount();
};

NamedPreparedStatement.prototype.setParameter = function(paramName, value) {
    if (arguments.length == 0) {
        throw new Error('Parameter name & value are missing!');
    }

    if (arguments.length < 2) {
        throw new Error('Parameter value is missing!');
    }

    var paramExit = false;
    for (param in this.paramsMap) {
        if (param == paramName) {
            paramExit = true;
            for (var i = 0; i < this.paramsMap[param].length; i++) {
                this.preparedStatement.setNthParameter(this.paramsMap[param][i], value);
            }
        }
    }
    if (!paramExit) {
        throw new Error('Parameter ' + paramName + ' doesn\'t exist!');
    }
};

NamedPreparedStatement.prototype.setParameters = function(values) {
    if (arguments.length == 0) {
        throw new Error('Parameters name & values are missing!');
    }

    if (typeof values != 'object') {
        throw new Error('Parameters must be an object!');
    }
	
    if (values == null) {
        throw new Error('Parameters can\'t be null!');
    }
	
    for (param in values) {
        if (this.paramsMap[param] == undefined) {
            throw new Error('Parameter ' + param + ' doesn\'t exist!');
        }

        for (var i = 0; i < this.paramsMap[param].length; i++) {
            this.preparedStatement.setNthParameter(this.paramsMap[param][i], values[param]);
        }
    }
};

NamedPreparedStatement.prototype.execute = function() {
    return this.preparedStatement.execute();
};

exports.Client = Client;